package com.uu898app.module.root;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uu898app.R;
import com.uu898app.module.base.BaseLazyFragment;
import com.uu898app.module.cart.CartFragment;
import com.uu898app.util.log.L;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class RootCartFragment extends BaseLazyFragment{

    public static RootCartFragment newInstance() {
        Bundle args = new Bundle();
        RootCartFragment fragment = new RootCartFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return  inflater.inflate(R.layout.root_fragment, container, false);
    }

    @Override
    protected void initLazyView(@Nullable Bundle savedInstanceState) {
        L.d("NewsRootFragment.initLazyView");
        if (null == savedInstanceState) {
            loadRootFragment(R.id.fl_container, CartFragment.newInstance());
        }
    }
}
