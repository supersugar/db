package com.uu393.market.module.center;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GGetShareFormHomeUserInfoByDay;
import com.uu393.market.model.request.GGetShareFormMore;
import com.uu393.market.model.response.BShareFormHomeUserInfoByDay;
import com.uu393.market.model.response.BShareFormMore;
import com.uu393.market.module.base.BaseViewPagerFragment;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.DateUtils;
import com.uu393.market.util.ToastUtil;

import java.util.Date;

import butterknife.Bind;
import butterknife.ButterKnife;
import okhttp3.Call;
import okhttp3.Response;

/**
 * @author wangxian
 *         <p>
 *         A simple {@link Fragment} subclass.
 *         分享赚今天、昨天记录 碎片
 */
public class ShareReportFormDayRecordFragment extends BaseViewPagerFragment {
    private static final String KEY_DAY = "which_day";
    @Bind(R.id.tv_uu_installed_number)
    TextView mTvUuInstalledNumber;
    @Bind(R.id.tv_pay_record_count)
    TextView mTvPayRecordCount;
    @Bind(R.id.tv_income)
    TextView mTvIncome;

    private String mWichDay;//当前为哪一天
    private BShareFormMore mShareFormMore;
    public ShareReportFormDayRecordFragment() {
    }

    public static ShareReportFormDayRecordFragment newInstance(String whichDay) {
        ShareReportFormDayRecordFragment fragment = new ShareReportFormDayRecordFragment();
        Bundle bundle = new Bundle();
        bundle.putString(KEY_DAY, whichDay);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_share_report_form_day_record, container, false);
        ButterKnife.bind(this, view);
        if (getArguments() != null) {
            mWichDay = getArguments().getString(KEY_DAY);//今天、昨天
        }
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

    @Override
    public void onResume() {
        super.onResume();
        GGetShareFormMore formMore = new GGetShareFormMore();
        Date today = new Date();
        if ("今天".equals(mWichDay.trim())) {
            String formatToday = cn.finalteam.toolsfinal.DateUtils.format(today, "yyyy-MM-dd");
            formMore.setBeginTime(formatToday);
            formMore.setEndTime(formatToday);
        } else if ("昨天".equals(mWichDay.trim())) {
            Date lastDay = DateUtils.getLastDay(today);
            String formatLast = cn.finalteam.toolsfinal.DateUtils.format(lastDay, "yyyy-MM-dd");
            formMore.setBeginTime(formatLast);
            formMore.setEndTime(formatLast);
        }
        doGetShareFormMore(formMore);

    }

    @Override
    public void onLazyInitView(@Nullable Bundle savedInstanceState) {
        super.onLazyInitView(savedInstanceState);
        GGetShareFormMore formMore = new GGetShareFormMore();
        Date today = new Date();
        if ("今天".equals(mWichDay.trim())) {
            String formatToday = cn.finalteam.toolsfinal.DateUtils.format(today, "yyyy-MM-dd");
            formMore.setBeginTime(formatToday);
            formMore.setEndTime(formatToday);
        } else if ("昨天".equals(mWichDay.trim())) {
            Date lastDay = DateUtils.getLastDay(today);
            String formatLast = cn.finalteam.toolsfinal.DateUtils.format(lastDay, "yyyy-MM-dd");
            formMore.setBeginTime(formatLast);
            formMore.setEndTime(formatLast);
        }
        doGetShareFormMore(formMore);
    }

    private void initView(BShareFormMore shareFormMore) {
        if (shareFormMore != null) {
            mTvUuInstalledNumber.setText(shareFormMore.getUUSYInstall());//UU手游安装数
            mTvPayRecordCount.setText(shareFormMore.getPaymentCount());//付款笔数
            mTvIncome.setText("¥"+shareFormMore.getInCome());//收入
        }else{
            mTvUuInstalledNumber.setText("无");//UU手游安装数
            mTvPayRecordCount.setText("无");//付款笔数
            mTvIncome.setText("无");//收入
        }
    }

    @Override
    public void refresh() {

    }

    /**
     * 获取分享赚首页简单的用户统计：APP053  换为054接口，053暂不用
     */
    private void doGetShareFormHomeUserInfoByDay(GGetShareFormHomeUserInfoByDay model) {
        if (model == null) return;
        showLoadToast();
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetShareFormHomeUserInfoByDay(model, new JsonCallback<BShareFormHomeUserInfoByDay>() {
            @Override
            public void onSuccess(BShareFormHomeUserInfoByDay UserInfoByDay, Call call, Response response) {
                hideLoadToast();
            }
            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
            }
        });

    }

    /*获取分享赚更多数据：APP054
    */
    private void doGetShareFormMore(GGetShareFormMore model) {
        if (model == null) return;
        showLoadToast();
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetShareFormMore(model, new JsonCallback<BShareFormMore>() {
            @Override
            public void onSuccess(BShareFormMore bShareFormMore, Call call, Response response) {
                hideLoadToast();
                if (bShareFormMore != null) {
                    mShareFormMore = bShareFormMore;
                    initView(mShareFormMore);
                } else {
                    initView(mShareFormMore);
                    ToastUtil.showToast(App.mContext, "未获取到分享信息");
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
                initView(mShareFormMore);
            }
        });

    }
}
