package com.uu661.module.home;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.uu661.R;
import com.uu661.model.response.BDiamond;
import com.uu661.util.NoDoubleClickUtils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by bo on 16/11/4.
 */

public class DiamondListAdapter extends RecyclerView.Adapter<DiamondListAdapter.MyHolder> {


    private Context mContext;
    private List<BDiamond> data = new ArrayList<>();

    public DiamondListAdapter(Context context) {
        this.mContext = context;
    }

    public void updateData(List<BDiamond> data) {
        this.data = data;
        notifyDataSetChanged();
    }

    @Override
    public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_home_diamond, parent, false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(MyHolder holder, int position) {
        BDiamond gameModel = data.get(position);
        holder.bindItem(gameModel);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        @BindView(R.id.item_diamond_parent) RelativeLayout mItemDiamondParent;
        @BindView(R.id.item_img) ImageView mItemImg;
        @BindView(R.id.item_tv_name) TextView mItemTvName;
        @BindView(R.id.item_tv_title) TextView mItemTvTitle;
        @BindView(R.id.item_progress_bar) ProgressBar mItemProgressBar;
        @BindView(R.id.item_tv_total) TextView mItemTvTotal;
        @BindView(R.id.item_tv_left) TextView mItemTvLeft;
        @BindView(R.id.item_button) Button mItemButton;
        @BindView(R.id.item_img_label) ImageView mItemImgLabel;
        @BindView(R.id.item_tv_type) TextView mItemTvType;

        private BDiamond mModel;

        public MyHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);//用butterKnife绑定
        }


        void bindItem(BDiamond model) {
            this.mModel = model;
            mItemTvName.setText(model.getPrice() + "U钻");
            mItemTvTitle.setText(model.getTitle());
            mItemButton.setText("立即" + model.getUnitPrice() + "元夺钻");
            mItemTvTotal.setText(Html.fromHtml("总需人次" + "<font color='#0fabff'>" + model.getTotalCount() + "</font>"));
            mItemTvLeft.setText(Html.fromHtml("剩余人次" + "<font color='#0fabff'>" + model.getLeftCount() + "</font>"));
            mItemProgressBar.setMax(model.getTotalCount());
            mItemProgressBar.setProgress(model.getAlreadySold());
            Glide.with(mContext).load(mModel.getImageUrl().trim()).error(R.drawable.ic_diamond_temp).into(mItemImg);
//            ViewAnimator
//                    .animate(mItemProgressBar)
//                    //                .translationX(0f ,1f)
//                    .pivotX(0)
//                    .scaleX(0,1f)
//                    .accelerate()
//                    .duration(500)
//                    .start();

            int labelRes = 0;
            String type = "";
        //先判断是否显示小试身手
            if(model.getXsss() == 0){
                switch (model.getTotalCount()) {
                    case 2:
                        labelRes = R.drawable.ic_diamond_label2;
                        type = "两人\n夺钻";
                        break;
                    case 5:
                        labelRes = R.drawable.ic_diamond_label5;
                        type = "五人\n夺钻";
                        break;
                    default:
                        labelRes = R.drawable.ic_diamond_label_many;
                        type = "多人\n夺钻";
                        break;
                }
                mItemImgLabel.setImageResource(labelRes);
                mItemTvType.setText(type);
                mItemTvType.setVisibility(View.VISIBLE);
            }else if(model.getXsss() == 1){//是小试身手的钻石
                labelRes = R.drawable.ic_xsss;
                mItemImgLabel.setImageResource(labelRes);
                mItemTvType.setVisibility(View.GONE);
            }
            mItemDiamondParent.setOnClickListener(this);
            mItemButton.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            if (NoDoubleClickUtils.isDoubleClick()) {
                return;
            }
            switch (v.getId()) {
                case R.id.item_button:
                    //点击之前要先刷新一下列表,获取最新的结果
                    if(null != onViewClickListener){
                        onViewClickListener.onBuyButtonClick(getLayoutPosition());
                    }
                    break;
                case R.id.item_diamond_parent:
                    if(null != onViewClickListener){
                        onViewClickListener.onItemClick(getLayoutPosition());
                    }
                    break;
                default:
                    break;
            }
        }
    }

    public interface OnViewClickListener{

        void onItemClick(int position);

        void onBuyButtonClick(int position);
    }

    private OnViewClickListener onViewClickListener;

    public OnViewClickListener getOnViewClickListener() {
        return onViewClickListener;
    }

    public void setOnViewClickListener(OnViewClickListener onViewClickListener) {
        this.onViewClickListener = onViewClickListener;
    }
}
