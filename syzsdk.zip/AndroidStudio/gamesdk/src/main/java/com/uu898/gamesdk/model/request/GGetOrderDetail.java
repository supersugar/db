package com.uu898.gamesdk.model.request;

import com.uu898.gamesdk.model.GBaseModel;

public class GGetOrderDetail extends GBaseModel {

    private String orderNo;//商品编号

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

}
