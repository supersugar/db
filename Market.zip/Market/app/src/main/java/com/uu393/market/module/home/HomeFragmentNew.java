package com.uu393.market.module.home;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.lzy.okgo.request.BaseRequest;
import com.sina.weibo.sdk.api.ImageObject;
import com.sina.weibo.sdk.api.TextObject;
import com.sina.weibo.sdk.api.WebpageObject;
import com.sina.weibo.sdk.api.WeiboMultiMessage;
import com.sina.weibo.sdk.api.share.BaseResponse;
import com.sina.weibo.sdk.api.share.IWeiboHandler;
import com.sina.weibo.sdk.api.share.IWeiboShareAPI;
import com.sina.weibo.sdk.api.share.SendMultiMessageToWeiboRequest;
import com.sina.weibo.sdk.api.share.WeiboShareSDK;
import com.sina.weibo.sdk.auth.AuthInfo;
import com.sina.weibo.sdk.auth.Oauth2AccessToken;
import com.sina.weibo.sdk.auth.WeiboAuthListener;
import com.sina.weibo.sdk.exception.WeiboException;
import com.sina.weibo.sdk.utils.Utility;
import com.tencent.connect.share.QQShare;
import com.tencent.mm.opensdk.modelmsg.SendMessageToWX;
import com.tencent.mm.opensdk.modelmsg.WXMediaMessage;
import com.tencent.mm.opensdk.modelmsg.WXWebpageObject;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import com.tencent.tauth.IUiListener;
import com.tencent.tauth.Tencent;
import com.tencent.tauth.UiError;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.Constant;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.PageModel;
import com.uu393.market.model.request.GGetBanner;
import com.uu393.market.model.request.GGetGameDetail;
import com.uu393.market.model.request.GGetGameList;
import com.uu393.market.model.response.BBanner;
import com.uu393.market.model.response.BGame;
import com.uu393.market.model.response.BGameKind;
import com.uu393.market.model.response.BGameTheme;
import com.uu393.market.module.base.BaseTabLazyFragment;
import com.uu393.market.module.base.BaseViewPagerFragment;
import com.uu393.market.module.bt.BTGameActivity;
import com.uu393.market.module.message.EventMessageActivity;
import com.uu393.market.module.newgame.NewGameActivity;
import com.uu393.market.module.search.SearchOpenServiceActivity;
import com.uu393.market.module.wbshare.AccessTokenKeeper;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.Base64Helper;
import com.uu393.market.util.GlideRoundTransform;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;
import com.uu393.market.view.lazyviewpager.LazyFragmentPagerAdapter;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;
import com.youth.banner.Banner;
import com.youth.banner.listener.OnBannerListener;
import com.youth.banner.loader.ImageLoader;

import org.greenrobot.eventbus.Subscribe;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.Call;
import okhttp3.Response;

import static com.uu393.market.app.App.mContext;


public class HomeFragmentNew extends BaseTabLazyFragment implements View.OnClickListener,  IUiListener, IWeiboHandler.Response {

    private Banner mBannerView;

    private View mSearchLayout;
    private View mMessageLayout;
    private View mShareLayout;
    private View mBTGameLayout, mNewGameLayout, mOpenServiceLayout, mHotLayout;
    private CircleImageView mMessageAlertPoint;
    private Button mBtFirstVolume;
    private TextView mDataStatus;
    private ImageButton mFirstRoll;

    private TabLayout mTabLayoutSelected;
    private List<BBanner> mBanners = new ArrayList<>();
    private AppGameSelectPopAdapter selectPopAdapter;
    private PullLoadMoreRecyclerView mRecyclerView;
    private AppBarLayout mAppBarLayout;
    private CoordinatorLayout mCoordinatorLayout;


    //游戏题材
    List<BGameKind> mGameThemes = new ArrayList<>();
    //智能排序
    List<BGameKind> mSort = new ArrayList<>();
    //游戏题材
    List<BGameKind> mGameKinds = new ArrayList<>();
    //去掉类型全部
    List<BGameKind> mGameAllKindsPop = new ArrayList<>();
    //记录每个Pop被点击的item
    HashMap<String, Integer> tabRVposion = new HashMap<>();
    //三个界面的pop数据源
    HashMap<String, List<BGameKind>> mPopData = new HashMap<>();
    //保存刷选后的molde的参数
    HashMap<String, String> mMolde = new HashMap<>();

    //当前的popData;
    List<BGameKind> mNewPopData = new ArrayList<>();

    private ArrayList<BGame> mGameList = new ArrayList<>();

    private String GameType = "1";
    private String GameTheme = "2";
    private String Intelligent = "3";

    //pop内部的xml
    RecyclerView mRvSelect;
    LinearLayout mRvNoData;
    Button mGetDataAgain;
    View inflate;

    private ApkListAdapter adapter;
    private View mNoResultView;
    private int mPageIndex = 1;


    private String[] tabTitles = {"游戏类型", "游戏题材", "智能排序"};
    private IWXAPI mWxApi;
    private Tencent mTencent;
    private PopupWindow mSharePopupWindow;

    private IWeiboShareAPI mWeiboShareAPI = null;

    public static HomeFragmentNew newInstance() {
        Bundle args = new Bundle();
        HomeFragmentNew fragment = new HomeFragmentNew();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mWxApi = WXAPIFactory.createWXAPI(_mActivity, Constant.WX_APP_ID, true);
        mTencent = Tencent.createInstance(Constant.QQ_APP_ID, _mActivity);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.home_fragment_new, container, false);
        mBannerView = (Banner) view.findViewById(R.id.banner_view);
        mSearchLayout = view.findViewById(R.id.search_layout);
        mMessageLayout = view.findViewById(R.id.message_layout);
        mShareLayout = view.findViewById(R.id.share_layout);
        mNoResultView = view.findViewById(R.id.no_result_view2);
        mDataStatus = (TextView) view.findViewById(R.id.tv_no_result_hint_text);
        mNoResultView.setVisibility(View.GONE);
        mMessageAlertPoint = (CircleImageView) view.findViewById(R.id.iv_home_message_hint);
        mRecyclerView = (PullLoadMoreRecyclerView) view.findViewById(R.id.tabs_recycleview);
        mBTGameLayout = view.findViewById(R.id.layout_bt_game);
        mNewGameLayout = view.findViewById(R.id.layout_new_game);
        mOpenServiceLayout = view.findViewById(R.id.layout_services);
        mHotLayout = view.findViewById(R.id.layout_hot_event);
        mBtFirstVolume = (Button) view.findViewById(R.id.bt_no_result);
        mFirstRoll = (ImageButton) view.findViewById(R.id.bt_first_volume);
        mAppBarLayout = (AppBarLayout) view.findViewById(R.id.appbar);
        mCoordinatorLayout = (CoordinatorLayout) view.findViewById(R.id.coordinatorlayout);


        //pop
        mTabLayoutSelected = (TabLayout) view.findViewById(R.id.tab_layout_home_new);
        selectPopAdapter = new AppGameSelectPopAdapter(_mActivity);
        inflate = LayoutInflater.from(_mActivity).inflate(R.layout.home_select_popup, null, false);
        mRvSelect = (RecyclerView) inflate.findViewById(R.id.rv_home_select_popup);
        mRvNoData = (LinearLayout) inflate.findViewById(R.id.no_result_view);
        mGetDataAgain = (Button) inflate.findViewById(R.id.bt_no_resultpop);

        mPopData.put(GameType, mGameAllKindsPop);
        mPopData.put(GameTheme, mGameAllKindsPop);
        mPopData.put(Intelligent, mGameAllKindsPop);

        tabRVposion.put(GameType, -1);
        tabRVposion.put(GameTheme, -1);
        tabRVposion.put(Intelligent, -1);

        mMolde.put(GameType, "-1");
        mMolde.put(GameTheme, "-1");
        mMolde.put(Intelligent, "-1");

        mRecyclerView.setLinearLayout();
        adapter = new ApkListAdapter(_mActivity);
        mRecyclerView.setAdapter(adapter);

        return view;
    }

    @Override

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mWeiboShareAPI = WeiboShareSDK.createWeiboAPI(_mActivity,Constant.WB_APP_KEY);
        mWeiboShareAPI.registerApp();
        if (savedInstanceState !=null){
            mWeiboShareAPI.handleWeiboResponse( _mActivity.getIntent(),  this);
        }

        mRecyclerView.setRefreshing(true);

        mRecyclerView.setOnPullLoadMoreListener(new PullLoadMoreRecyclerView.PullLoadMoreListener() {
            @Override
            public void onRefresh() {
                doGetGameList(false);
            }

            @Override
            public void onLoadMore() {
                doGetGameList(true);
            }
        });


        mSearchLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EB.postEmpty(EB.TAG.GO_SEARCH);
            }
        });
        initTabLayoutSelect();
        doGetGameThemes();
        doGetBaner();


        mMessageLayout.setOnClickListener(this);
        mShareLayout.setOnClickListener(this);
        mBTGameLayout.setOnClickListener(this);
        mNewGameLayout.setOnClickListener(this);
        mOpenServiceLayout.setOnClickListener(this);
        mHotLayout.setOnClickListener(this);
        mGetDataAgain.setOnClickListener(this);
        mBtFirstVolume.setOnClickListener(this);
        mFirstRoll.setOnClickListener(this);


        //判断广告页进入主页方式是否为立即查看
        if ((boolean) SPUtil.get(App.mContext, "isSelectBT", false)) {
            _mActivity.startActivity(new Intent(_mActivity, BTGameActivity.class));
            SPUtil.put(App.mContext, "isSelectBT", false);
        }
    }

    private View getTabItem(String title) {
        View tab_item = LayoutInflater.from(_mActivity).inflate(R.layout.item_tab_tablayout, null, false);
        TextView tabTitle = (TextView) tab_item.findViewById(R.id.tv_tab_title);
        tabTitle.setText(title);
        return tab_item;
    }

    private void initTabLayoutSelect() {
        TabLayout.Tab tab1 = mTabLayoutSelected.newTab();
        tab1.setText("全部游戏");
        mTabLayoutSelected.addTab(tab1);

        for (int i = 0; i < tabTitles.length; i++) {
            TabLayout.Tab tab2 = mTabLayoutSelected.newTab();
            tab2.setCustomView(getTabItem(tabTitles[i]));
            mTabLayoutSelected.addTab(tab2);
        }
        mTabLayoutSelected.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getCustomView() != null) {
                    View customView = tab.getCustomView();
                    TextView title = (TextView) customView.findViewById(R.id.tv_tab_title);
                    title.setTextColor(getResources().getColor(R.color.blue));
                    showSelectPopup(mTabLayoutSelected, title, tab.getPosition() + "");
                }

                if (tab.getPosition() == 0) {
                    mMolde.put(GameType, "-1");
                    mMolde.put(GameTheme, "-1");
                    mMolde.put(Intelligent, "-1");
                    doGetGameList(false);
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                if (tab.getCustomView() != null) {
                    View customView = tab.getCustomView();
                    TextView title = (TextView) customView.findViewById(R.id.tv_tab_title);
                    title.setTextColor(getResources().getColor(R.color.grey_666));
                }


            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

                if (tab.getCustomView() != null) {
                    View customView = tab.getCustomView();
                    TextView title = (TextView) customView.findViewById(R.id.tv_tab_title);
                    title.setTextColor(getResources().getColor(R.color.blue));
                    showSelectPopup(mTabLayoutSelected, title, tab.getPosition() + "");
                }
                if (tab.getPosition() == 0) {
                    mMolde.put(GameType, "-1");
                    mMolde.put(GameTheme, "-1");
                    mMolde.put(Intelligent, "-1");
                    doGetGameList(false);
                }

            }
        });
    }


    @Override
    protected void initLazyView(@Nullable Bundle savedInstanceState) {

    }

    @Override
    public void onTabReselected() {
        L.d("onTabReselected " + this);
        mGameList.clear();
        adapter.notifyDataSetChanged();
        mAppBarLayout.setExpanded(true);
        doGetBaner();
        doGetGameThemes();
    }


    @Override
    public void onLazyInitView(@Nullable Bundle savedInstanceState) {
        super.onLazyInitView(savedInstanceState);
        L.d("懒加载" + this);
        doGetBaner();
    }

    private void doGetBaner() {
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetBanner(new GGetBanner(), new JsonCallback<List<BBanner>>() {
            @Override
            public void onBefore(BaseRequest request) {
                super.onBefore(request);

            }

            @Override
            public void onSuccess(final List<BBanner> result, Call call, Response response) {

                if (null != result && !result.isEmpty()) {
                    List<String> images = new ArrayList<>();
                    mBanners.clear();
                    mBanners.addAll(result);
                    for (int i = 0; i < mBanners.size(); i++) {
                        images.add(mBanners.get(i).imageUrl);
                    }
                    mBannerView.setDelayTime(5000);//设置轮播间隔时间,需要放到setImages前面
                    mBannerView.setImageLoader(new GlideImageLoader());
                    mBannerView.setImages(images);
                    mBannerView.isAutoPlay(true);
                    mBannerView.setOnBannerListener(new OnBannerListener() {
                        @Override
                        public void OnBannerClick(int position) {
                            BBanner temp = result.get(position);
                            //0:游戏详情页面  1:活动页面
                            if (temp.linkType == 0) {
                                if (StringUtils.isEmpty(temp.gameID)) {
                                    ToastUtil.showToast(_mActivity, "游戏id参数错误");
                                    return;
                                }
                                Intent intent = new Intent(mContext, AppDetailActivity.class);
                                intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_ID, temp.gameID);
                                _mActivity.startActivity(intent);
                            } else if (temp.linkType == 1) {
                                if (StringUtils.isEmpty(temp.gameID)) {
                                    ToastUtil.showToast(_mActivity, "活动链接参数错误");
                                    return;
                                }
                                Intent intent = new Intent(_mActivity, WebActivity.class);
                                intent.putExtra(WebActivity.INTENT_KEY_URL, temp.linkUrl);
                                startActivity(intent);
                            }
                        }
                    });
                    mBannerView.start();
                }
            }
        });
    }

    private void showSelectPopup(View show, final TextView change, final String tabPosition) {

        final PopupWindow popupWindow = new PopupWindow(inflate, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popupWindow.setAnimationStyle(android.R.style.Animation_InputMethod);

        mRvSelect.setLayoutManager(new GridLayoutManager(_mActivity, 4, LinearLayoutManager.VERTICAL, false));
        selectPopAdapter.setPosition(tabRVposion.get(tabPosition));
        mNewPopData = mPopData.get(tabPosition);

        if (mNewPopData.isEmpty()) {
            mRvNoData.setVisibility(View.VISIBLE);
            mRvSelect.setVisibility(View.GONE);
            mGetDataAgain.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    doGetGameThemes();
                    popupWindow.dismiss();
                }
            });
        }

        selectPopAdapter.setData(mNewPopData);
        mRvSelect.setAdapter(selectPopAdapter);//todo 修改弹出框单项界面
        popupWindow.showAsDropDown(show);
        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {

            }
        });
        selectPopAdapter.setOnSelectedListener(new AppGameSelectPopAdapter.OnSelectedListener() {
            @Override
            public void onItemSelectedListener(BGameKind mBGameKind, int position) {
                change.setText(mBGameKind.typeName);
                change.setTextColor(getResources().getColor(R.color.blue));
                mNewPopData.get(position);
                mMolde.put(tabPosition, mNewPopData.get(position).id);
                tabRVposion.put(tabPosition, position);
                doGetGameList(false);
                popupWindow.dismiss();
            }
        });
    }

    private void showSharePopup() {
        //分享弹窗
        View inflate = LayoutInflater.from(_mActivity).inflate(R.layout.app_game_share_pop, null, false);
        mSharePopupWindow = new PopupWindow(inflate);
        mSharePopupWindow.setHeight(RelativeLayout.LayoutParams.WRAP_CONTENT);
        mSharePopupWindow.setWidth(RelativeLayout.LayoutParams.WRAP_CONTENT);
        mSharePopupWindow.setFocusable(true);
        mSharePopupWindow.setOutsideTouchable(true);
        mSharePopupWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        mSharePopupWindow.setAnimationStyle(android.R.style.Animation_InputMethod);

        Window window = _mActivity.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.alpha = 0.5f;
        window.setAttributes(lp);

        mSharePopupWindow.showAtLocation(mShareLayout, Gravity.CENTER, 0, 0);
        mSharePopupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                Window window = _mActivity.getWindow();
                WindowManager.LayoutParams lp = window.getAttributes();
                lp.alpha = 1.0f;
                window.setAttributes(lp);
            }
        });
        View sharePopToWX = inflate.findViewById(R.id.ll_home_share_pop_wx);
        View sharePopToWXComments = inflate.findViewById(R.id.ll_home_share_pop_comments);
        View sharePopToQQ = inflate.findViewById(R.id.ll_home_share_pop_qq);
        View sharePopToWB = inflate.findViewById(R.id.ll_home_share_pop_wb);
        sharePopToWX.setOnClickListener(this);
        sharePopToWXComments.setOnClickListener(this);
        sharePopToQQ.setOnClickListener(this);
        sharePopToWB.setOnClickListener(this);
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        L.d("onHiddenChanged" + hidden);
    }

    @Override
    public void onResume() {
        super.onResume();
        L.d("onResume()");
        MobclickAgent.onPageStart("HomeFragment");
        EB.register(this);
        adapter.setrefresh();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        L.d("onDestroy");
        MobclickAgent.onPageEnd("HomeFragment");
        EB.unregister(this);
    }

    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.APP_INSTALL:
                break;
            default:
                break;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.message_layout://我的消息
                mMessageAlertPoint.setVisibility(View.GONE);
                _mActivity.startActivity(new Intent(_mActivity, EventMessageActivity.class));
                break;
            case R.id.share_layout://分享
                showSharePopup();
                break;
            case R.id.layout_bt_game://BT游戏
                _mActivity.startActivity(new Intent(_mActivity, BTGameActivity.class));
                break;
            case R.id.layout_new_game://新游首发
                _mActivity.startActivity(new Intent(_mActivity, NewGameActivity.class));
                break;
            case R.id.layout_services://开服表
                _mActivity.startActivity(new Intent(_mActivity, SearchOpenServiceActivity.class));
                break;
            case R.id.layout_hot_event://热门活动
                _mActivity.startActivity(new Intent(_mActivity, HotActivity.class));
                break;
            case R.id.bt_no_resultpop://pop请求刷新
                doGetBaner();
                doGetGameThemes();
                break;
            case R.id.bt_no_result://首页刷新
                doGetGameThemes();
                doGetBaner();
                break;
            case R.id.bt_first_volume://首充卷
                _mActivity.startActivity(new Intent(_mActivity, FirstRollActivity.class));
                break;
            case R.id.ll_home_share_pop_wx://微信分享
                hideSharePop();
                doWXShare(SendMessageToWX.Req.WXSceneSession);
                break;
            case R.id.ll_home_share_pop_comments://朋友圈分享
                hideSharePop();
                doWXShare(SendMessageToWX.Req.WXSceneTimeline);
                break;
            case R.id.ll_home_share_pop_qq://QQ分享
                hideSharePop();
                shareToQQToFriends();
                break;
            case R.id.ll_home_share_pop_wb://微博分享
                hideSharePop();
                doShareWB();
                break;


        }
    }



    public class GlideImageLoader extends ImageLoader {
        @Override
        public void displayImage(Context context, Object path, ImageView imageView) {
            /**
             注意：
             1.图片加载器由自己选择，这里不限制，只是提供几种使用方法
             2.返回的图片路径为Object类型，由于不能确定你到底使用的那种图片加载器，
             传输的到的是什么格式，那么这种就使用Object接收和返回，你只需要强转成你传输的类型就行，
             切记不要胡乱强转！
             */
            //为什么 会得到类似You cannot start a load for a destroyed activity这样的异常呢？
            //不要再非主线程里面使用Glide加载图片，如果真的使用了，请把context参数换成getApplicationContext
            int defaultAndError = ImageHelper.randomImage();
            Glide.with(App.mContext).load((String) path).error(defaultAndError).placeholder(defaultAndError).into(imageView);
        }

    }

    private void doGetGameKinds() {

        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetGameKinds(new JsonCallback<List<BGameKind>>(this) {
            @Override
            public void onSuccess(List<BGameKind> gameKinds, Call call, Response response) {
                mGameKinds.clear();
                mSort.clear();
                if (null != gameKinds || !gameKinds.isEmpty()) {
                    if (null == gameKinds || gameKinds.isEmpty()) {
                        ToastUtil.showToast(_mActivity, "获取游戏类别失败");
                        return;
                    }
                    mGameKinds = gameKinds;
                    mPopData.put(GameType, mGameKinds);
                    //智能排序参数
                    BGameKind bSort = new BGameKind();
                    bSort.typeName = "默认排序";
                    bSort.id = "-1";

                    BGameKind bSort2 = new BGameKind();
                    bSort2.typeName = "折扣 ↑";
                    bSort2.id = "1";

                    BGameKind bSort3 = new BGameKind();
                    bSort3.typeName = "折扣 ↓";
                    bSort3.id = "2";

                    mSort.add(bSort);
                    mSort.add(bSort2);
                    mSort.add(bSort3);

                    mPopData.put(Intelligent, mSort);

                }
            }

            @Override
            public void onAfter(List<BGameKind> bGameKinds, Exception e) {
                super.onAfter(bGameKinds, e);
                doGetGameList(false);
            }
        });
    }

    private void doGetGameThemes() {
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetGameThemes(new JsonCallback<List<BGameTheme>>() {
            @Override
            public void onSuccess(List<BGameTheme> bGameThemes, Call call, Response response) {
                mGameThemes.clear();

                if (bGameThemes != null && !bGameThemes.isEmpty()) {
                    if (null == bGameThemes || bGameThemes.isEmpty()) {
                        ToastUtil.showToast(_mActivity, "获取游戏类别失败");
                        return;
                    }
                    //数据类型转换
                    for (int i = 0; i < bGameThemes.size(); i++) {
                        BGameKind bGameKind = new BGameKind();
                        bGameKind.typeName = bGameThemes.get(i).getThemeName();
                        bGameKind.id = bGameThemes.get(i).getId();
                        mGameThemes.add(bGameKind);
                    }
                    mPopData.put(GameTheme, mGameThemes);
                }

            }

            @Override
            public void onAfter(List<BGameTheme> bGameKinds, Exception e) {
                super.onAfter(bGameKinds, e);
                doGetGameKinds();
            }
        });
    }


    private void doGetGameList(final boolean loadMore) {
        GGetGameList model = new GGetGameList();
        model.gameType = mMolde.get(GameType);
        model.theme = mMolde.get(GameTheme);
        model.sort = mMolde.get(Intelligent);
        model.platForm = "0";
        model.isBT = "0";
        model.isFirst = "0";
        if (loadMore == false) {
            mGameList.clear();
            mPageIndex = 1;
            showLoadToast();
        }
        PageModel page = new PageModel(mPageIndex);
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetGameList(model, page, new JsonCallback<List<BGame>>() {
            @Override
            public void onSuccess(List<BGame> bGames, Call call, Response response) {
                if (null == bGames || bGames.isEmpty()) {
                    //无返回结果,需要根据当前页码判断是无结果,还是无更多
                    if (mPageIndex == 1) {
                        mDataStatus.setText("暂无数据");
                        mBtFirstVolume.setVisibility(View.GONE);
                        changeView(false);
                    } else {
                        ToastUtil.showToast(_mActivity, "没有更多了~");
                    }
                } else {
                    changeView(true);
                    mPageIndex++;
                    if (loadMore == false) {//非增量加载
                        mGameList.clear();
                    }
                    mGameList.addAll(bGames);
                }
            }

            @Override
            public void onAfter(List<BGame> bGames, Exception e) {
                super.onAfter(bGames, e);
                mRecyclerView.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        adapter.updateData(mGameList);
                        mRecyclerView.setPullLoadMoreCompleted();
                    }
                }, 100);
                hideLoadToast();
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                if (mPageIndex == 1) {
                    mDataStatus.setText("请求数据失败");
                    mBtFirstVolume.setVisibility(View.VISIBLE);
                    changeView(false);
                } else {
                    changeView(true);
                }
                hideLoadToast();

            }
        });
    }

    private void changeView(boolean hasData) {
        mRecyclerView.setVisibility(hasData ? View.VISIBLE : View.GONE);
        mNoResultView.setVisibility(hasData ? View.GONE : View.VISIBLE);
    }

    //===============微信、朋友圈分享======================

    private void doWXShare(int wx) {
        if (!mWxApi.isWXAppInstalled()) {
            ToastUtil.showToast(App.mContext, "未安装微信");
            return;
        }
        WXWebpageObject webpageObject = new WXWebpageObject();
        webpageObject.webpageUrl = "http://www.shouyouzhu.com/";
        WXMediaMessage msg = new WXMediaMessage(webpageObject);
        msg.title = "UU手游";//标题
        msg.description = "海量游戏，等你来玩";
        Bitmap thumb = BitmapFactory.decodeResource(getResources(), R.drawable.ic_logo);
        msg.thumbData = bmpToByteArray(thumb, true);//微信缩略图大小限制为32k一下，超过无法调起分享
        SendMessageToWX.Req req = new SendMessageToWX.Req();
        req.transaction = buildTransaction("uushouyou");
        req.scene = wx;
        req.message = msg;
        mWxApi.sendReq(req);
    }

    private String buildTransaction(final String type) {

        return (type == null) ? String.valueOf(System.currentTimeMillis()) : type + System.currentTimeMillis();
    }

    public static byte[] bmpToByteArray(final Bitmap bmp, final boolean needRecycle) {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, output);
        if (needRecycle) {
            bmp.recycle();
        }
        byte[] result = output.toByteArray();
        try {
            output.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    //^^^^^^^^^^^^^^^微信、朋友圈分享^^^^^^^^^^^^^^^^^^^^^^^

    //===============QQ空间=======================
    public void shareToQZone() {
        Bundle params = new Bundle();
        params.putInt(QQShare.SHARE_TO_QQ_KEY_TYPE, QQShare.SHARE_TO_QQ_TYPE_DEFAULT);
        params.putString(QQShare.SHARE_TO_QQ_TITLE, "UU手游");
        params.putString(QQShare.SHARE_TO_QQ_SUMMARY, "海量游戏，等你来玩");
        params.putString(QQShare.SHARE_TO_QQ_TARGET_URL, "http://www.shouyouzhu.com/");
        params.putString(QQShare.SHARE_TO_QQ_IMAGE_URL, "http://www.shouyouzhu.com/images/syz_08.png");
        params.putString(QQShare.SHARE_TO_QQ_APP_NAME, "UU手游");
        params.putInt(QQShare.SHARE_TO_QQ_EXT_INT, QQShare.SHARE_TO_QQ_FLAG_QZONE_AUTO_OPEN);
        mTencent.shareToQQ(_mActivity, params, this);
    }

    @Override
    public void onComplete(Object o) {
        ToastUtil.showToast(App.mContext, "分享成功");
    }

    @Override
    public void onError(UiError uiError) {
        ToastUtil.showToast(App.mContext, uiError.errorMessage);
    }

    @Override
    public void onCancel() {
        ToastUtil.showToast(App.mContext, "您已取消分享");
    }
    //^^^^^^^^^^^^^^^QQ空间^^^^^^^^^^^^^^^^^^^^^^^


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (mTencent != null) {
            Tencent.onActivityResultData(requestCode, resultCode, data, this);
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void hideSharePop(){
        if (mSharePopupWindow!=null&&mSharePopupWindow.isShowing()){
            mSharePopupWindow.dismiss();
        }
    }
    //===============微博=======================
    private void doShareWB(){
        sendMessage(true,true);
    }
    /**
     * 第三方应用发送请求消息到微博，唤起微博分享界面。
     */
    private void sendMessage(boolean hasText, boolean hasImage) {
        sendMultiMessage(hasText, hasImage);
    }
    /**
     * 第三方应用发送请求消息到微博，唤起微博分享界面。
     */
    private void sendMultiMessage(boolean hasText, boolean hasImage) {


        WeiboMultiMessage weiboMessage = new WeiboMultiMessage();
        if (hasText) {
            weiboMessage.textObject = getTextObj();
        }
        if (hasImage) {
            weiboMessage.imageObject = getImageObj();
        }
        SendMultiMessageToWeiboRequest request = new SendMultiMessageToWeiboRequest();
        request.transaction = String.valueOf(System.currentTimeMillis());
        request.multiMessage = weiboMessage;
        AuthInfo authInfo = new AuthInfo(App.mContext, Constant.WB_APP_KEY, Constant.WB_REDIRECT_URL, Constant.WB_SCOPE);
        Oauth2AccessToken accessToken = AccessTokenKeeper.readAccessToken(App.mContext);
        String token = "";
        if (accessToken != null) {
            token = accessToken.getToken();
        }
        mWeiboShareAPI.sendRequest(_mActivity, request, authInfo, token, new WeiboAuthListener() {

            @Override
            public void onWeiboException( WeiboException arg0 ) {
                ToastUtil.showToast(App.mContext, "分享失败");
            }

            @Override
            public void onComplete( Bundle bundle ) {
                Oauth2AccessToken newToken = Oauth2AccessToken.parseAccessToken(bundle);
                AccessTokenKeeper.writeAccessToken(App.mContext, newToken);
                ToastUtil.showToast(App.mContext, "分享成功");
            }

            @Override
            public void onCancel() {
                ToastUtil.showToast(App.mContext, "您已取消分享");
            }
        });

    }
    @Override
    public void onResponse(BaseResponse baseResponse) {
    }

    @Override
    protected void onNewBundle(Bundle args) {
        super.onNewBundle(args);
        mWeiboShareAPI.handleWeiboResponse(_mActivity.getIntent(),this);
    }
    /**
     * 获取分享的文本模板。
     */
    private String getSharedText() {
        int formatId = R.string.weibosdk_demo_share_text_template;
        String format = getString(formatId);
        String text = format;
        text ="测试"+"#UU手游# http://www.shouyouzhu.com/";
        return text;
    }


    /**
     * 创建文本消息对象。
     * @return 文本消息对象。
     */
    private TextObject getTextObj() {
        TextObject textObject = new TextObject();
        textObject.text = getSharedText();
        textObject.title = "UU手游";
        textObject.actionUrl = "http://www.shouyouzhu.com/";
        return textObject;
    }

    /**
     * 创建图片消息对象。
     * @return 图片消息对象。
     */
    private ImageObject getImageObj() {
        ImageObject imageObject = new ImageObject();
        Bitmap  bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_logo);
        imageObject.setImageObject(bitmap);
        return imageObject;
    }
    /**
     * 创建多媒体（网页）消息对象。
     *
     * @return 多媒体（网页）消息对象。
     */
    private WebpageObject getWebpageObj() {
        WebpageObject mediaObject = new WebpageObject();
        mediaObject.identify = Utility.generateGUID();
        mediaObject.title ="测试title";
        mediaObject.description = "测试描述";
        Bitmap  bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_logo);
        // 设置 Bitmap 类型的图片到视频对象里         设置缩略图。 注意：最终压缩过的缩略图大小不得超过 32kb。
        mediaObject.setThumbImage(bitmap);
        mediaObject.actionUrl = "http://news.sina.com.cn/c/2013-10-22/021928494669.shtml";
        mediaObject.defaultText = "Webpage 默认文案";
        return mediaObject;
    }
    //^^^^^^^^^^^^^^^微博^^^^^^^^^^^^^^^^^^^^^^^


    public void shareToQQToFriends(){
        Bundle bundle = new Bundle();
        bundle.putString(QQShare.SHARE_TO_QQ_TITLE, "UU手游");
        bundle.putString(QQShare.SHARE_TO_QQ_SUMMARY, "海量游戏，等你来玩");
        bundle.putString(QQShare.SHARE_TO_QQ_TARGET_URL, "http://www.shouyouzhu.com/");
        bundle.putString(QQShare.SHARE_TO_QQ_IMAGE_URL, "http://www.shouyouzhu.com/images/syz_08.png");
        bundle.putString(QQShare.SHARE_TO_QQ_APP_NAME, "UU手游");

        mTencent.shareToQQ(_mActivity, bundle , BaseUiListener);
    }

    IUiListener BaseUiListener = new IUiListener() {
        @Override
        public void onCancel() {
            ToastUtil.showToast(App.mContext, "您已取消分享");
        }
        @Override
        public void onComplete(Object response) {
            ToastUtil.showToast(App.mContext, "分享成功");
        }
        @Override
        public void onError(UiError e) {
            ToastUtil.showToast(App.mContext, e.errorMessage);
        }
    };
}
