package com.uu898.gamesdk.model.response;

import java.io.Serializable;

/**
 * Created by bo on 16/9/14.
 */
public class BAliPay implements Serializable {

    public String signOrderNo;
    public String tradeOrderNo;
}
