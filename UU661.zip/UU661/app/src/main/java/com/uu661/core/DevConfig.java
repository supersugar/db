package com.uu661.core;


import com.uu661.network.NetConstant;
import com.uu661.util.log.L;

import cn.finalteam.toolsfinal.StringUtils;

/**
 * Created by bo on 16/12/28.
 */

public class DevConfig {

    /**
     * 手动修改
     * 开发期 = true; 线上 = false
     */
    public static final boolean DEBUG = false;

    //当前连接服务器地址
    private String mCurrent898Url;
    private String mCurrent661Url;

    private static DevConfig instance = new DevConfig();

    private DevConfig() {
    }

    public static DevConfig getInstance() {
        return instance;
    }

    /**
     * 在application中调用
     */
    public void init(){
        L.init(true);//是否显示log输出
        setURL(DEBUG);//设置链接url
    }

    public String getURL(String api){
        //如果当前全局变量地址值为null了,默认让链接正式地址
        if(StringUtils.isEmpty(mCurrent898Url)){
            mCurrent898Url = NetConstant.URL.URL_898_OFFICIAL;
        }
        if(StringUtils.isEmpty(mCurrent661Url)){
            mCurrent661Url = NetConstant.URL.URL_661_OFFICIAL;
        }
        //在夺钻项目中,服务器有两个地址,账户链接的是898的,其他是661的,所有需要根据api来判断返回什么地址
        if(api.startsWith("uzuanapp0")){//898
            return mCurrent898Url;
        }else{
            return mCurrent661Url;
        }
    }

    /**
     * 设置链接的url,项目初始化时调用,如果是debug模式,链接测试地址,非debug模式,链接正式地址
     * @param debug
     */
    public void setURL(boolean debug){
        if(debug){
            this.mCurrent898Url = NetConstant.URL.URL_898_TEST;
            this.mCurrent661Url = NetConstant.URL.URL_661_TEST;
        }else{
            this.mCurrent898Url = NetConstant.URL.URL_898_OFFICIAL;
            this.mCurrent661Url = NetConstant.URL.URL_661_OFFICIAL;
        }
    }


}
