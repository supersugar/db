package com.uu661.module.account;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

import com.uu661.R;
import com.uu661.core.AccountManager;
import com.uu661.model.request.GGetVerifyCode;
import com.uu661.model.request.GLoginThird;
import com.uu661.model.request.GRegist;
import com.uu661.model.response.BLogin;
import com.uu661.module.base.BaseFragment;
import com.uu661.module.common.WebActivity;
import com.uu661.network.JsonCallback;
import com.uu661.network.NetConstant;
import com.uu661.network.TaskEngine;
import com.uu661.util.CommonUtils;
import com.uu661.util.CountDownTimer;
import com.uu661.util.NoDoubleClickUtils;
import com.uu661.util.PushUtil;
import com.uu661.util.ToastUtil;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.finalteam.toolsfinal.StringUtils;
import okhttp3.Call;
import okhttp3.Response;


/**
 * Created by zhangbo on 2016/6/23.
 */
public class ThirdBindFragment extends BaseFragment {


    @BindView(R.id.edt_account) EditText mEdtAccount;
    @BindView(R.id.edt_password) EditText mEdtPassword;
    @BindView(R.id.edt_verify_code) EditText mEdtVerifyCode;
    @BindView(R.id.bt_get_code_phone) Button mBtGetCodePhone;
    @BindView(R.id.bt_get_code_sms) Button mBtGetCodeSms;
    @BindView(R.id.checkbox) CheckBox mCheckbox;
    @BindView(R.id.bt_goto_agreement) TextView mBtGotoAgreement;
    @BindView(R.id.bt_submit) Button mBtSubmit;

    private boolean mIsApply = false;

    private GLoginThird mLoginThirdModel;

    public static ThirdBindFragment newInstance(GLoginThird loginThird) {
        Bundle args = new Bundle();
        ThirdBindFragment fragment = new ThirdBindFragment();
        args.putSerializable("GLoginThird", loginThird);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.account_third_bind_fragment, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "绑定手机", true);
        mLoginThirdModel = (GLoginThird) getArguments().getSerializable("GLoginThird");

        mIsApply = mCheckbox.isChecked();
        mCheckbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                mIsApply = isChecked;
            }
        });
    }

    @OnClick({R.id.bt_get_code_phone, R.id.bt_get_code_sms, R.id.bt_goto_agreement, R.id.bt_submit})
    public void onClick(View view) {
        if (NoDoubleClickUtils.isDoubleClick()) {
            return;
        }
        switch (view.getId()) {
            case R.id.bt_get_code_phone://获取电话验证码
                getVerifyCode(GGetVerifyCode.PHONE);
                break;
            case R.id.bt_get_code_sms://获取短信验证码
                getVerifyCode(GGetVerifyCode.SMS);
                break;
            case R.id.bt_goto_agreement://服务协议
                Intent intent = new Intent(_mActivity, WebActivity.class);
                intent.putExtra(WebActivity.INTENT_KEY_URL, NetConstant.WEB.USER_PROTOCOL);
                intent.putExtra(WebActivity.INTENT_KEY_TITLE, "UU898服务协议");
                startActivity(intent);
                break;
            case R.id.bt_submit://注册提交
                if(mIsApply){
                    verifyForm();
                }else{
                    ToastUtil.showToast(_mActivity, "您需要先阅读并同意《UU898服务协议》");
                }
                break;
        }
    }

    private void getVerifyCode(final int type) {
        String account = mEdtAccount.getText().toString();
        if (StringUtils.isEmpty(account)) {
            ToastUtil.showToast(_mActivity, "请输入手机号");
            return;
        }
        GGetVerifyCode model = new GGetVerifyCode();
        model.clientIP = CommonUtils.getIP(_mActivity);
        model.userId = account;
        model.isVoice = type;
        TaskEngine.getInstance().doGetVerifyCode(model, new JsonCallback<String>(this) {
            @Override
            public void onSuccess(String s, Call call, Response response) {
                new CountDownTimer(60000, 1000, mBtGetCodePhone, "获取语音验证码").start();
                new CountDownTimer(60000, 1000, mBtGetCodeSms, "获取短信验证码").start();
                if (type == GGetVerifyCode.PHONE) {
                    ToastUtil.showToast(_mActivity, "发送成功！您的手机将会受到固化呼叫，接通后自动播报您的验证码");
                } else if (type == GGetVerifyCode.SMS) {
                    ToastUtil.showToast(_mActivity, "发送成功！请稍后查看您的短信息");
                }
            }
        });
    }

    /**
     * 校验表单信息
     */
    private void verifyForm() {
        String account = mEdtAccount.getText().toString();
        String password = mEdtPassword.getText().toString();
        String authCode = mEdtVerifyCode.getText().toString();


        if (StringUtils.isEmpty(account)) {
            ToastUtil.showToast(_mActivity, "请输入手机号");
            return;
        }
        if (StringUtils.isEmpty(password)) {
            ToastUtil.showToast(_mActivity, "请设置密码");
            return;
        }
        if (StringUtils.isEmpty(authCode)) {
            ToastUtil.showToast(_mActivity, "请输入验证码");
            return;
        }

        doRegister(account, password, authCode);
    }

    private void doRegister(String account, String password, String authcode) {
        GRegist model = new GRegist();
        model.userId = account;
        model.password = CommonUtils.encryptString(password);
        model.phoneCode = authcode;
        model.clientIP = CommonUtils.getIP(_mActivity);
        model.loginType = mLoginThirdModel.loginType;
        model.loginThirdId = mLoginThirdModel.loginThirdId;
        model.qqUnionid = mLoginThirdModel.qqUnionid;
        model.accessToken = mLoginThirdModel.accessToken;
        TaskEngine.getInstance().doRegist(model, new JsonCallback<BLogin>(this) {
            @Override
            public void onSuccess(BLogin result, Call call, Response response) {
                ToastUtil.showToast(_mActivity, "注册成功");
                AccountManager.getInstance().saveLoginInfo(result);
                PushUtil.addAlias(result.Uid, _mActivity);
                _mActivity.setResult(Activity.RESULT_OK);
                _mActivity.finish();
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                AccountManager.getInstance().logout();
            }
        });
    }
}
