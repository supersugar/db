package com.uu393.market.model.response;

import java.io.Serializable;
import java.util.List;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    :
 * =====================================================
 */

public class BServerListByGameName implements Serializable {
    /**
     {
     "id": "123456",(游戏的唯一ID)
     "icon": "kjkjjk.jpg",(游戏图标)
     "gameName": "御剑情缘",(游戏名称)
     "typeName": "策略",(游戏类型)
     "size": "520.3",(游戏大小M)
     "describe": "最好玩的游戏",(游戏描述)
     "discount": "1”,(游戏折扣)
     "androidPackage": "1”,(安卓下载包地址)
     "packageName": "1”,(包名)
     "serverList":[{
     "id": "123",（服务器编号）
     "serverName": "360服",（服务器名称）
     "openTime": "2016-07-01 00:00:00"（开服时间）
     },......]
     "isRecommend": "0”,(是否推荐游戏 0否  1是)
     "isFirst": "0”,(是否首发游戏  0：不是首发   1首发游戏)
     "firstTime": "2017-3-31 00:00:00”,(首发时间)
     "isQuick": "0”,(是否加速版游戏  0：不是   1是)
     "isGift": "0”,(是否有礼包  0：没有   1有)
     "isActivity": "0”,(是否有活动  0：没有   1有)
     "platForm": "0”,(0app游戏  1h5游戏)

     */

    private String id;
    private String icon;
    private String gameName;
    private String typeName;

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getIsActivity() {
        return isActivity;
    }

    public void setIsActivity(String isActivity) {
        this.isActivity = isActivity;
    }

    public String getPlatForm() {
        return platForm;
    }

    public void setPlatForm(String platForm) {
        this.platForm = platForm;
    }

    private String size;
    private String describe;
    private String discount;
    private String androidPackage;
    private String packageName;
    private String isRecommend;
    private String isFirst;
    private String firstTime;
    private String isQuick;
    private String isGift;
    private String isActivity;
    private String platForm;

    private List<ServerList> serverList;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {
        this.describe = describe;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    public String getAndroidPackage() {
        return androidPackage;
    }

    public void setAndroidPackage(String androidPackage) {
        this.androidPackage = androidPackage;
    }

    public String getIsRecommend() {
        return isRecommend;
    }

    public void setIsRecommend(String isRecommend) {
        this.isRecommend = isRecommend;
    }

    public String getIsFirst() {
        return isFirst;
    }

    public void setIsFirst(String isFirst) {
        this.isFirst = isFirst;
    }

    public String getFirstTime() {
        return firstTime;
    }

    public void setFirstTime(String firstTime) {
        this.firstTime = firstTime;
    }

    public String getIsQuick() {
        return isQuick;
    }

    public void setIsQuick(String isQuick) {
        this.isQuick = isQuick;
    }

    public String getIsGift() {
        return isGift;
    }

    public void setIsGift(String isGift) {
        this.isGift = isGift;
    }

    public List<ServerList> getServerList() {
        return serverList;
    }

    public void setServerList(List<ServerList> serverList) {
        this.serverList = serverList;
    }

    public static class ServerList {
        /**
         * id : 123
         * serverName : 360服
         * openTime : 2016-07-01 00:00:00
         */

        private String id;
        private String serverName;
        private String openTime;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getServerName() {
            return serverName;
        }

        public void setServerName(String serverName) {
            this.serverName = serverName;
        }

        public String getOpenTime() {
            return openTime;
        }

        public void setOpenTime(String openTime) {
            this.openTime = openTime;
        }
    }
}
