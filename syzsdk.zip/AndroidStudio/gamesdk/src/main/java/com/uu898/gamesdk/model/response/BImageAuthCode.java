package com.uu898.gamesdk.model.response;

/**
 * Created by bo on 16/9/14.
 */
public class BImageAuthCode {

    public String token;
    public String validateCodeImg;
}
