package com.uu393.market.network;


import android.text.TextUtils;

import com.bugtags.library.Bugtags;
import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import com.lzy.okgo.callback.AbsCallback;
import com.lzy.okgo.request.BaseRequest;
import com.uu393.market.app.App;
import com.uu393.market.core.DevConfig;
import com.uu393.market.module.base.BaseFragment;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.log.L;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.net.ConnectException;
import java.net.SocketTimeoutException;

import okhttp3.Call;
import okhttp3.Response;


public abstract class JsonCallback<T> extends AbsCallback<T> {

    private BaseFragment mFragment;

    public JsonCallback() {
    }

    public JsonCallback(BaseFragment fragment) {
        this.mFragment = fragment;
    }

    @Override
    public void onBefore(BaseRequest request) {
        super.onBefore(request);
        if (mFragment != null) {
            mFragment.showLoadToast();
        }
    }

    @Override
    public void onAfter(T t, Exception e) {
        super.onAfter(t, e);
        if (mFragment != null) {
            mFragment.hideLoadToast();
        }
    }

    /**
     * 该方法是子线程处理，不能做ui相关的工作
     * 主要作用是解析网络返回的 response 对象,生产onSuccess回调中需要的数据对象
     * 这里的解析工作不同的业务逻辑基本都不一样,所以需要自己实现,以下给出的时模板代码,实际使用根据需要修改
     */
    @Override
    public T convertSuccess(Response response) throws Exception {
        String result = response.body().string();
        L.json(result);
        JSONObject jsonObject = null;
        String message = "";
        String status = "";
        try {
            jsonObject = new JSONObject(result);
            status = jsonObject.getString("status");
            message = jsonObject.getString("message");

            if (!status.equals("0")) {
                throw new APIException(status, message);
            }
            result = jsonObject.getString("data");
        } catch (JSONException e) {
            e.printStackTrace();
            L.e(e.getMessage());
        }

        Type genType = getClass().getGenericSuperclass();
        Type[] params = ((ParameterizedType) genType).getActualTypeArguments();
        Type type = params[0];

        if (type == String.class) {
            return (T) result;
        }

        Gson gson = new Gson();
        try {
            return gson.fromJson(result, type);
        } catch (JsonParseException e) {
            e.printStackTrace();
            L.e(e.getMessage());
        }
        return null;
    }

    @Override
    public void onError(Call call, Response response, Exception e) {
        super.onError(call, response, e);
        L.d(e.getMessage());
        String error_msg = "";
        String apiCode = "";
        if (e instanceof APIException) {
            error_msg = e.getMessage();
            apiCode = ((APIException) e).getCode();
        } else if (e instanceof JSONException) {
            error_msg = "Json数据解析错误";
        } else if (e instanceof UnsupportedEncodingException) {
            error_msg = "UnsupportedEncodingException";
        } else if (e instanceof SocketTimeoutException) {
            error_msg = "请求数据超时,请稍后重试";
        } else if (e.getMessage().equals("Gateway Time-out")) {
            error_msg = "504网关超时,请稍后重试";
        } else if (e instanceof ConnectException) {
            error_msg = "网络中断,请检查您的网络状态";
        } else {
            error_msg = "未知错误 : " + e.getMessage();
        }
        if ("你尚未登录或登录已失效".equals(error_msg.trim())){
            //登录失效后清空用户登录信息
            SPUtil.put(App.mContext, "isLogin", false);
            SPUtil.put(App.mContext, "thirdUserId", "");
            SPUtil.put(App.mContext, "loginType", "");
            SPUtil.put(App.mContext, "token", "");
            SPUtil.put(App.mContext, "userId", "");
            SPUtil.put(App.mContext, "uId", "");
            SPUtil.put(App.mContext, "chkMobile", "");
        }else if("服务器数据错误".equals(error_msg.trim())){
            //将信息提交进bug tags
            APIException exception = new APIException(apiCode, error_msg +"\n"+ App.EXCEPTION_URL.toString());
            Bugtags.sendException(exception);
        }else {
            if (!TextUtils.isEmpty(error_msg)){
                ToastUtil.showToast(App.mContext, error_msg);
            }
        }

    }

    public static class APIException extends Exception {
        public String code;
        public String message;

        public APIException(String code, String message) {
            this.code = code;
            this.message = message;
        }

        @Override
        public String getMessage() {
            return message;
        }

        public String getCode() {
            return code;
        }
    }
}