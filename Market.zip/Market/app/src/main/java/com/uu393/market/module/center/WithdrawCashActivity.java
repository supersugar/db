package com.uu393.market.module.center;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.bumptech.glide.Glide;
import com.uu393.market.Constant;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.DevConfig;
import com.uu393.market.model.request.GDoBindBank;
import com.uu393.market.model.request.GDoChangeBank;
import com.uu393.market.model.request.GDoCommitWithdrawOrderInfo;
import com.uu393.market.model.request.GGetPhoneCode;
import com.uu393.market.model.response.BBankInfo;
import com.uu393.market.model.response.BUserIsBindPhone;
import com.uu393.market.model.response.BWithdrawAccountInfo;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.login.CountDownTimer;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ContactCustomerServicesUtils;
import com.uu393.market.util.IPUtils;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.RsaHelper;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.view.progressbutton.FlatButton;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

public class WithdrawCashActivity extends BaseActivity {

    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    //未绑定银行卡
    @Bind(R.id.iv_bank_icon)
    ImageView mIvBankIcon;
    @Bind(R.id.tv_withdraw_bank_name)
    TextView mTvWithdrawBankName;
    @Bind(R.id.layout_select_no_bind)
    RelativeLayout mLayoutSelectNoBind;
    @Bind(R.id.et_withdraw_bank_account)
    EditText mEtWithdrawBankAccount;
    @Bind(R.id.et_withdraw_bank_account_name)
    EditText mEtWithdrawBankAccountName;
    @Bind(R.id.et_withdraw_set_pass)
    EditText mEtWithdrawSetPass;
    @Bind(R.id.et_withdraw_verify_pass)
    EditText mEtWithdrawVerifyPass;
    @Bind(R.id.et_withdraw_code)
    EditText mEtWithdrawCode;
    @Bind(R.id.bt_withdraw_get_code)
    Button mBtWithdrawGetCode;
    @Bind(R.id.layout_no_bind_bank)
    LinearLayout mLayoutNoBindBank;
    @Bind(R.id.iv_bank_icon_bind)
    ImageView mIvBankIconBind;
    @Bind(R.id.tv_withdraw_bank_name_bind)
    TextView mTvWithdrawBankNameBind;
    @Bind(R.id.tv_withdraw_bank_chang_bind)
    TextView mTvWithdrawBankChangBind;
    @Bind(R.id.tv_withdraw_yuan_bind)
    TextView mTvWithdrawYuanBind;
    @Bind(R.id.tv_withdraw_all_bind)
    TextView mTvWithdrawAllBind;
    @Bind(R.id.et_withdraw_pass_bind)
    EditText mEtWithdrawPassBind;
    @Bind(R.id.tv_withdraw_forgot_pass)
    TextView mTvWithdrawForgotPass;
    @Bind(R.id.iv_withdraw_change)
    ImageView mIvWithdrawChange;
    @Bind(R.id.tv_withdraw_change_bank_name)
    TextView mTvWithdrawChangeBankName;
    @Bind(R.id.et_withdraw_change_bank_account)
    EditText mEtWithdrawChangeBankAccount;
    @Bind(R.id.tv_withdraw_change_bank_account_name)
    TextView mTvWithdrawChangeBankAccountName;
    @Bind(R.id.et_withdraw_change_code)
    EditText mEtWithdrawChangeCode;
    @Bind(R.id.bt_withdraw_change_get_code)
    Button mBtWithdrawChangeGetCode;
    @Bind(R.id.layout_change_bank)
    LinearLayout mLayoutChangeBank;
    @Bind(R.id.tv_withdraw_contact)
    TextView mTvWithdrawContact;
    @Bind(R.id.layout_bind_bank)
    LinearLayout mLayoutBindBank;
    @Bind(R.id.rl_withdraw_change_bind_layout)
    RelativeLayout mRlWithdrawChangeBindLayout;
    @Bind(R.id.btn_withdraw_commit)
    Button mBtnWithdrawCommit;
    @Bind(R.id.et_bind_withdraw_money)
    EditText mEtBindWithdrawMoney;
    @Bind(R.id.tv_withdraw_hint_bind)
    TextView mTvWithdrawHintBind;
    @Bind(R.id.et_withdraw_phone_number)
    EditText mEtWithdrawPhoneNumber;
    @Bind(R.id.rl_phone_number_no_bind)
    RelativeLayout mRlPhoneNumberNoBind;
    @Bind(R.id.tv_bind_withdraw_money_beyond)
    TextView mTvBindWithdrawMoneyBeyond;
    private SelectBankPopupWindow mSelectBankPopupWindow;
    private boolean hasBindedBank = false;
    public static final String INTENT_KEY_TO_WITHDRAW = "hasbindedbank";
    private List<BBankInfo> mBankList = new ArrayList<>();//银行卡列表

    private String mNoBindBankId = "";//未绑定页面的银行的ID
    private String mNoBindBankName;//未绑定页面的银行的名字
    private String mNoBindBankNumber = "";//未绑定页面的银行卡号
    private String mNoBindAccountName = "";//未绑定页面的账户名
    private String mNoBindWithdrawPassword = "";//未绑定页面的提现密码
    private String mNoBindWithdrawPasswordVerify = "";//未绑定页面的提现密码确定
    private String mNoBindCode = "";//未绑定页面的验证码
    private String mNoBindPhoneNumber = "";//未绑定页面并未绑定手机时的手机号
    private boolean mNoBindIsBindPhone = false;//用户是否绑定了银行卡

    private int mCommitType = -1;
    private static final int COMMIT_TYPE_BIND_BANK = 0;//绑定银行卡
    private static final int COMMIT_TYPE_CHANGE_BIND = 1;//更改绑定银行卡
    private static final int COMMIT_TYPE_WITHDRAW = 2;//提交提现订单

    private String mChangeBindBankName;//更改绑定页面的银行名字
    private String mChangeBindBankNumber = "";//更改绑定页面的银行卡号
    private String mChangeBindAccountName = "";//更改绑定页面的账户名
    private String mChangeBindCode;//更改绑定页面的验证码

    private String mBindWithdrawMoney = "";//已绑定页面的提现金额
    private String mBindWithdrawPassword = "";//已绑定页面的提现密码
    private BWithdrawAccountInfo mBindAccountInfo;
    private String mBindWithdrawRealMoney = "";//扣除收费后的实际提现金额

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_withdraw_cash);
        ButterKnife.bind(this);
        initToolBar();
        StringUtils.bankCardNumAddSpace(mEtWithdrawBankAccount);//格式化输入的银行卡号
        StringUtils.bankCardNumAddSpace(mEtWithdrawChangeBankAccount);//格式化输入的银行卡号
        if (getIntent() != null) {
            hasBindedBank = getIntent().getBooleanExtra(INTENT_KEY_TO_WITHDRAW, false);
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        showView(hasBindedBank);//进入界面显示判断，有银行卡；没有银行卡
    }

    private void initToolBar() {
        mTitleBarRight.setVisibility(View.GONE);
        mTitleBarTitle.setText("提现");
    }

    //切换是否绑定银行卡视图
    private void showView(boolean hasBindBank) {
        if (hasBindBank) {//已绑定
            mCommitType = COMMIT_TYPE_WITHDRAW;
            mLayoutBindBank.setVisibility(View.VISIBLE);
            mLayoutNoBindBank.setVisibility(View.GONE);
            mLayoutChangeBank.setVisibility(View.GONE);
            doGetWithdrawAccountInfo();
            doGetUserIsBindPhone();

        } else {//未绑定
            mCommitType = COMMIT_TYPE_BIND_BANK;
            mLayoutBindBank.setVisibility(View.GONE);
            mLayoutNoBindBank.setVisibility(View.VISIBLE);
            mLayoutChangeBank.setVisibility(View.GONE);
            //更改提现账户、和绑定提现账户需要获取银行列表接口
            doGetBankList();
            doGetUserIsBindPhone();

        }
    }

    //显示更改绑定银行卡视图
    private void showChangeBank() {
        mCommitType = COMMIT_TYPE_CHANGE_BIND;
        mLayoutBindBank.setVisibility(View.GONE);
        mLayoutNoBindBank.setVisibility(View.GONE);
        mLayoutChangeBank.setVisibility(View.VISIBLE);
        //更改提现账户、和绑定提现账户需要获取银行列表接口
        doGetBankList();
        if (!TextUtils.isEmpty(mChangeBindAccountName)) {
            if (mChangeBindAccountName.length() < 3) {
                String substring = mChangeBindAccountName.substring(1);
                mChangeBindAccountName = "*" + substring;
            } else {
                String substring = mChangeBindAccountName.substring(2);
                mChangeBindAccountName = "**" + substring;
            }
        }
        mTvWithdrawChangeBankAccountName.setText(mChangeBindAccountName);//更改绑定银行卡显示的用户真实姓名，姓氏用**号代替
    }

    //初始化提现视图UI内容
    private void initBindUI() {
        if (mBindAccountInfo == null) return;
        // TODO: 2017/4/20 保存已绑定的银行卡的账户名字  张三
        mChangeBindAccountName = mBindAccountInfo.getAccountName();
        //银行图标
        //已绑定银行卡号
        if (!TextUtils.isEmpty(mBindAccountInfo.getAccount())) {
            int length = mBindAccountInfo.getAccount().trim().length();
            if (length >= 4) {
                mTvWithdrawBankNameBind.setText(mBindAccountInfo.getBankName() + "（" + mBindAccountInfo.getAccount().substring(length - 4) + "）");//银行卡号显示后四位
            }
        }
        int defaultAndError = ImageHelper.randomImage();
        Glide.with(App.mContext).load(mBindAccountInfo.getIcon())//绑定的银行卡的图标
                .error(defaultAndError)
                .placeholder(defaultAndError)
                .into(mIvBankIconBind);

        //账户可提现余额
        mEtBindWithdrawMoney.setHint("可提现金额为" + mBindAccountInfo.getMoney() + "元");
        //多久到账提示
        mTvWithdrawHintBind.setText(mBindAccountInfo.getPrompt());

        mEtBindWithdrawMoney.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                //动态计算手续费
                if (StringUtils.isRealMoney(s.toString().trim())) {
                    String money = mBindAccountInfo.getMoney();
                    //TODO  计算输入金额和账户上金额，，显示提示文本
                    if (StringUtils.isRealMoney(money)){
                        Float accountMoney = Float.valueOf(money);
                        Float inputMoney = Float.valueOf(s.toString().trim());
                        if (inputMoney>=accountMoney||inputMoney>50000f){
                            mTvBindWithdrawMoneyBeyond.setVisibility(View.VISIBLE);
                            mTvBindWithdrawMoneyBeyond.setText("提现金额超过账户余额或超过可提现到卡额度5万元");
                            return;
                        }else if (inputMoney<10){
                            mTvBindWithdrawMoneyBeyond.setVisibility(View.VISIBLE);
                            mTvBindWithdrawMoneyBeyond.setText("提现金额最少10元");
                            return;
                        }else {
                            mTvBindWithdrawMoneyBeyond.setVisibility(View.GONE);
                        }

                    }
                    if (Float.valueOf(s.toString().trim()) <= 50000f && Float.valueOf(s.toString().trim()) >= 10f) {
                        String bindWithdrawMoney = s.toString().trim();
                        Float fWantMoney = 0.0f;//想要提现金额
                        Float fMaxRate = 0f;//最大手续费
                        Float fMinRate = 0f;//最小手续费
                        fMaxRate = Float.valueOf(mBindAccountInfo.getMaxCharge());
                        fMinRate = Float.valueOf(mBindAccountInfo.getMinCharge());
                        fWantMoney = Float.valueOf(bindWithdrawMoney);
                        String chargeRate = mBindAccountInfo.getChargeRate();
                        Float fChargeRate = 0.0f;//提现手续费率
                        if (chargeRate != null) {
                            fChargeRate = Float.valueOf(chargeRate);
                        }
                        float chargeRateMoney = fWantMoney * fChargeRate;//计算出的手续费
                        float fRealWithdrawMoney = 0.0f;
                        if (chargeRateMoney >= fMaxRate) {//计算手续费大于最大手续费，取最大手续费
                            fRealWithdrawMoney = fMaxRate;
                        } else if (chargeRateMoney <= fMinRate) {//计算手续费小于最小手续费，取最小手续费
                            fRealWithdrawMoney = fMinRate;
                        } else {//计算手续费在两者之间，取计算手续费
                            fRealWithdrawMoney = chargeRateMoney;
                        }
                        //更改提示信息
                        mTvWithdrawHintBind.setText("转账手续费为" + StringUtils.keepTwoDecimals(fRealWithdrawMoney) + "元");//保留两位小数
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        if (!TextUtils.isEmpty(mBindAccountInfo.getIsTX())) {
            if ("true".equals(mBindAccountInfo.getIsTX().trim().toLowerCase())) {
                mTvWithdrawHintBind.setTextColor(getResources().getColor(R.color.blue));
                mTvWithdrawHintBind.setText("恶意套现收取总金额2%银行转账手续费");
            }
        }

    }

    //按钮点击事件
    @OnClick({R.id.title_bar_left, R.id.layout_select_no_bind,
            R.id.bt_withdraw_get_code, R.id.tv_withdraw_bank_chang_bind
            , R.id.tv_withdraw_contact, R.id.tv_withdraw_forgot_pass,
            R.id.rl_withdraw_change_bind_layout, R.id.btn_withdraw_commit,
            R.id.tv_withdraw_all_bind, R.id.bt_withdraw_change_get_code})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left://返回键
                super.onBackPressedSupport();
                break;
            case R.id.layout_select_no_bind://未绑定银行卡，显示选择银行卡弹出框
                showSelectBankPop(-1, mIvBankIcon, mTvWithdrawBankName, mBankList);
                break;
            case R.id.bt_withdraw_get_code://未绑定视图，获取验证码
                if (!mNoBindIsBindPhone) {
                    String phoneNumberNoBind = mEtWithdrawPhoneNumber.getText().toString().trim();
                    if (TextUtils.isEmpty(phoneNumberNoBind)) {
                        ToastUtil.showToast(App.mContext, "请输入手机号");
                        return;
                    } else {
                        mNoBindPhoneNumber = phoneNumberNoBind;
                    }
                    doGetPhoneCode(mBtWithdrawGetCode, Constant.GET_PHONE_CODE_TYPE_3);//完善资料
                }else {
                    doGetPhoneCode(mBtWithdrawGetCode, Constant.GET_PHONE_CODE_TYPE_3);//完善资料
                }
                break;
            case R.id.tv_withdraw_bank_chang_bind://已绑定，更改提现账户，切换视图
                showChangeBank();
                break;
            case R.id.tv_withdraw_all_bind://已绑定页面，全部提现按钮
                if (mBindAccountInfo == null) {
                    return;
                }
                mEtBindWithdrawMoney.setText(mBindAccountInfo.getMoney());//服务器上返回的用户中的可提现余额
                break;
            case R.id.tv_withdraw_contact://联系客服，三个页面公用
                ContactCustomerServicesUtils.doXiaoNeng();
                break;
            case R.id.tv_withdraw_forgot_pass://忘记提现密码，跳转身份验证
                WithdrawCashActivity.this.startActivity(new Intent(WithdrawCashActivity.this, IdentityVerifyActivity.class));
                break;
            case R.id.rl_withdraw_change_bind_layout://更改绑定银行卡视图，弹出银行选择窗口
                showSelectBankPop(-1, mIvWithdrawChange, mTvWithdrawChangeBankName, mBankList);
                break;
            case R.id.btn_withdraw_commit://公共按钮：提交按钮
                if (mCommitType == COMMIT_TYPE_BIND_BANK) {//提交绑定
                    if (DevConfig.DEBUG) {
                        ToastUtil.showToast(App.mContext, "提交绑定银行卡");
                    }
                    String noBindBankName = mTvWithdrawBankName.getText().toString().trim();
                    if (!TextUtils.isEmpty(noBindBankName)) {
                        if ("请选择提现银行".equals(noBindBankName)) {
                            ToastUtil.showToast(App.mContext, "请选择银行种类");
                            return;
                        } else {
                            mNoBindBankName = noBindBankName;
                        }
                    }
                    String noBindAccountNumber = mEtWithdrawBankAccount.getText().toString().trim().replace(" ", "");
                    Pattern pattern = Pattern.compile("^\\d{12,19}$");//是否在12-19位
                    if (TextUtils.isEmpty(noBindAccountNumber) || !pattern.matcher(noBindAccountNumber).matches()) {
                        ToastUtil.showToast(App.mContext, "请输入正确的银行卡号");
                        return;
                    } else {
                        mNoBindBankNumber = noBindAccountNumber;
                    }
                    String noBindAccountName = mEtWithdrawBankAccountName.getText().toString().trim();
                    if (TextUtils.isEmpty(noBindAccountName)) {
                        ToastUtil.showToast(App.mContext, "请输入您的姓名");
                        if (!StringUtils.isChineseChar(noBindAccountName) || noBindAccountName.length() < 1) {
                            ToastUtil.showToast(App.mContext, "姓名只能为1个以上中文字符");
                            return;
                        }
                        return;
                    } else {
                        mNoBindAccountName = noBindAccountName;
                    }
                    String noBindPassword = mEtWithdrawSetPass.getText().toString().trim();
                    if (TextUtils.isEmpty(noBindAccountName)) {
                        ToastUtil.showToast(App.mContext, "请输入提现密码");
                        return;
                    } else {
                        mNoBindWithdrawPassword = noBindPassword;
                    }
                    String noBindPasswordVerify = mEtWithdrawVerifyPass.getText().toString().trim();
                    if (TextUtils.isEmpty(noBindAccountName)) {
                        ToastUtil.showToast(App.mContext, "请输入提现确认密码");
                        return;
                    } else {
                        mNoBindWithdrawPasswordVerify = noBindPasswordVerify;
                    }
                    if (!mNoBindWithdrawPassword.equals(mNoBindWithdrawPasswordVerify)) {
                        ToastUtil.showToast(App.mContext, "两次密码不一致");
                        return;
                    }
                    if (!mNoBindIsBindPhone) {
                        String phoneNumberNoBind = mEtWithdrawPhoneNumber.getText().toString().trim().replace(" ", "");
                        if (TextUtils.isEmpty(phoneNumberNoBind)) {
                            ToastUtil.showToast(App.mContext, "请输入手机号");
                            return;
                        } else {
                            mNoBindPhoneNumber = phoneNumberNoBind;
                        }
                    }
                    String noBindCode = mEtWithdrawCode.getText().toString().trim();
                    if (TextUtils.isEmpty(noBindCode)) {
                        ToastUtil.showToast(App.mContext, "请输入验证码");
                        return;
                    } else {
                        mNoBindCode = noBindCode;
                    }
                    GDoBindBank bindBankModel = new GDoBindBank();
                    bindBankModel.setBankId(mNoBindBankId);
                    bindBankModel.setAccount(mNoBindBankNumber);
                    bindBankModel.setAccountName(mNoBindAccountName);
                    bindBankModel.setPayPassword(RsaHelper.encryptDataFromStr(mNoBindWithdrawPasswordVerify, RsaHelper.RSA_PUBLIC_KEY));//密码要加密
                    bindBankModel.setCode(mNoBindCode);
                    bindBankModel.setDecipheringType("0");//设备类型0安卓；1ios
                    bindBankModel.setPhoneNo(mNoBindPhoneNumber);
                    bindBankModel.setIp(IPUtils.getIPAddress(App.mContext));
                    doBindBank(bindBankModel);
                } else if (mCommitType == COMMIT_TYPE_CHANGE_BIND) {//提交更改绑定
                    if (DevConfig.DEBUG) {
                        ToastUtil.showToast(App.mContext, "提交更改绑定银行卡");
                    }
                    String changeBindBankName = mTvWithdrawChangeBankName.getText().toString().trim();
                    if (!TextUtils.isEmpty(changeBindBankName)) {
                        if ("请选择提现银行".equals(changeBindBankName)) {
                            ToastUtil.showToast(App.mContext, "请选择银行种类");
                            return;
                        } else {
                            mChangeBindBankName = changeBindBankName;
                        }
                        String changeBindBankNumber = mEtWithdrawChangeBankAccount.getText().toString().trim().replace(" ", "");
                        Pattern pattern = Pattern.compile("^\\d{12,19}$");//是否在12-19位
                        if (TextUtils.isEmpty(changeBindBankName) || !pattern.matcher(changeBindBankNumber).matches()) {
                            ToastUtil.showToast(App.mContext, "请输入正确的银行卡号");
                            return;
                        } else {
                            mChangeBindBankNumber = changeBindBankNumber;
                        }
                        String changeBindCode = mEtWithdrawChangeCode.getText().toString().trim();
                        if (TextUtils.isEmpty(changeBindCode)) {
                            ToastUtil.showToast(App.mContext, "请输入验证码");
                            return;
                        } else {
                            mChangeBindCode = changeBindCode;
                        }
                        GDoChangeBank changeBankModel = new GDoChangeBank();
                        changeBankModel.setBankId(mNoBindBankId);
                        changeBankModel.setAccount(mChangeBindBankNumber);
                        changeBankModel.setCode(mChangeBindCode);
                        doChangeBank(changeBankModel);
                    }

                } else if (mCommitType == COMMIT_TYPE_WITHDRAW) {//提交提现订单
                    if (DevConfig.DEBUG) {
                        ToastUtil.showToast(App.mContext, "提交订单");
                    }
                    String bindWithdrawMoney = mEtBindWithdrawMoney.getText().toString().trim();
                    if (TextUtils.isEmpty(bindWithdrawMoney) || !StringUtils.isRealMoney(bindWithdrawMoney)) {
                        ToastUtil.showToast(App.mContext, "请输入正确的金额");
                        return;
                    } else {
                        if (Float.valueOf(bindWithdrawMoney) < 10.0f || Float.valueOf(bindWithdrawMoney) > 50000.0f) {
                            ToastUtil.showToast(App.mContext, "提现金额最小10元，最大5万元");
                            return;
                        }
                        mBindWithdrawMoney = bindWithdrawMoney;
                    }
                    String bindWithdrawPassword = mEtWithdrawPassBind.getText().toString().trim();
                    if (TextUtils.isEmpty(bindWithdrawPassword)) {
                        ToastUtil.showToast(App.mContext, "请输入提现密码");
                        return;
                    } else {
                        mBindWithdrawPassword = bindWithdrawPassword;
                    }
                    //TODO: 2017/4/17 计算实际提现金额
                    Float fWantMoney = 0.0f;//想要提现金额
                    Float fMaxRate = 0f;//最大手续费
                    Float fMinRate = 0f;//最小手续费
                    if (mBindAccountInfo == null) {
                        if (DevConfig.DEBUG) {
                            ToastUtil.showToast(App.mContext, "账户信息为null");
                        }
                        return;
                    }
                    if (TextUtils.isEmpty(mBindAccountInfo.getMaxCharge())) {
                        return;
                    }
                    if (TextUtils.isEmpty(mBindAccountInfo.getMinCharge())) {
                        return;
                    }
                    fMaxRate = Float.valueOf(mBindAccountInfo.getMaxCharge());
                    fMinRate = Float.valueOf(mBindAccountInfo.getMinCharge());
                    fWantMoney = Float.valueOf(mBindWithdrawMoney);
                    if (TextUtils.isEmpty(mBindAccountInfo.getChargeRate())) {
                        return;
                    }
                    String chargeRate = mBindAccountInfo.getChargeRate();
                    Float fChargeRate = 0.0f;//提现手续费率
                    if (chargeRate != null) {
                        fChargeRate = Float.valueOf(chargeRate);
                    }
                    float chargeRateMoney = fWantMoney * fChargeRate;
                    float fRealWithdrawMoney = 0.0f;
                    if (chargeRateMoney >= fMaxRate) {//计算手续费大于最大手续费，取最大手续费
                        fRealWithdrawMoney = fMaxRate;
                    } else if (chargeRateMoney <= fMinRate) {//计算手续费小于最小手续费，取最小手续费
                        fRealWithdrawMoney = fMinRate;
                    } else {//计算手续费在两者之间，取计算手续费
                        fRealWithdrawMoney = chargeRateMoney;
                    }
                    if (!TextUtils.isEmpty(mBindAccountInfo.getIsTX())) {//是套现没有最大手续费上限
                        if ("true".equals(mBindAccountInfo.getIsTX().trim().toLowerCase())) {//是套现，直接扣除2%
                            if (fWantMoney * 0.02 <= fMinRate) {//计算手续费小于最小手续费，取最小手续费
                                mBindWithdrawRealMoney = String.valueOf((fWantMoney - fMinRate));
                            } else {
                                mBindWithdrawRealMoney = String.valueOf((fWantMoney - fWantMoney * 0.02));
                            }
                        } else {
                            mBindWithdrawRealMoney = String.valueOf((fWantMoney - fRealWithdrawMoney));
                        }
                    }

                    //创建提现订单请求bean对象
                    GDoCommitWithdrawOrderInfo bindWithdrawOrder = new GDoCommitWithdrawOrderInfo();
                    bindWithdrawOrder.setMoney(mBindWithdrawMoney);//要提现金额
                    bindWithdrawOrder.setActMoney(mBindWithdrawRealMoney);//扣除手续费后提现金额
                    bindWithdrawOrder.setPayPassword(RsaHelper.encryptDataFromStr(mBindWithdrawPassword, RsaHelper.RSA_PUBLIC_KEY));//提现密码加密
                    bindWithdrawOrder.setDecipheringType("0");//（设备类型：0安卓  1 IOS）
                    bindWithdrawOrder.setIp("" + IPUtils.getIPAddress(App.mContext));//手机IP地址
                    doCommitWithdrawOrderInfo(bindWithdrawOrder);
                }
                break;
            case R.id.bt_withdraw_change_get_code://更改绑定视图，获取验证码
                doGetPhoneCode(mBtWithdrawChangeGetCode, Constant.GET_PHONE_CODE_TYPE_9);//更改提现账户
                break;
        }
    }

    /**
     * 弹出选择银行的选择框
     */
    private void showSelectBankPop(int selectPosition, final ImageView icon, final TextView bankName, List<BBankInfo> datas) {
        if (mSelectBankPopupWindow == null) {
            mSelectBankPopupWindow = new SelectBankPopupWindow(WithdrawCashActivity.this, selectPosition);
        }
        mSelectBankPopupWindow.showSelectWindowFromBottom();
        final SelectBankPopupWindow.SelectBankAdapter adapter = mSelectBankPopupWindow.getAdapter();
        adapter.setOnItemSelectedListener(new SelectBankPopupWindow.SelectBankAdapter.OnItemSelectedListener() {
            @Override
            public void onItemSelectedListener(int position, BBankInfo bankInfo) {
                mSelectBankPopupWindow.hideSelectWindow();
                if (bankInfo == null) return;
                int defaultAndError = ImageHelper.randomImage();
                Glide.with(App.mContext).load(bankInfo.getIcon())
                        .error(defaultAndError)
                        .placeholder(defaultAndError)
                        .into(icon);
                bankName.setText(bankInfo.getBankName());
                mNoBindBankId = bankInfo.getId();
            }
        });
        adapter.refreshItem(datas);
    }

    //获取银行列表信息APP042
    private void doGetBankList() {
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetBankList(new JsonCallback<List<BBankInfo>>() {
            @Override
            public void onSuccess(List<BBankInfo> bBankInfos, Call call, Response response) {
                if (bBankInfos != null && !bBankInfos.isEmpty()) {
                    mBankList.clear();
                    mBankList.addAll(bBankInfos);
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
            }
        });
    }

    //绑定银行卡APP043
    private void doBindBank(GDoBindBank model) {
        if (model == null) {
            return;
        }
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doBindBank(model, new JsonCallback<Object>() {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                ToastUtil.showToast(App.mContext, "绑定成功");
                // TODO: 2017/4/17 绑定成功后要切换视图到提交订单视图
                hasBindedBank = true;
                showView(hasBindedBank);
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hasBindedBank = false;
                showView(hasBindedBank);
            }
        });
    }

    //获取提现账户信息APP044
    private void doGetWithdrawAccountInfo() {
        showLoadToast(WithdrawCashActivity.this);
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetWithdrawAccountInfo(new JsonCallback<BWithdrawAccountInfo>() {
            @Override
            public void onSuccess(BWithdrawAccountInfo bWithdrawAccountInfo, Call call, Response response) {
                hideLoadToast();
                if (bWithdrawAccountInfo != null) {
                    mBindAccountInfo = bWithdrawAccountInfo;
                    /*String bindedBankName = bWithdrawAccountInfo.getBankName();//已绑定的银行名字
                    String bindedBankNumber = bWithdrawAccountInfo.getAccount();//已绑定的银行卡号
                    String bindedCanWithdrawMoney = bWithdrawAccountInfo.getMoney();//目前账户可提现余额
                    String chargeRate = bWithdrawAccountInfo.getChargeRate();//银行转账手续费率
                    String maxCharge = bWithdrawAccountInfo.getMaxCharge();//（最大手续费（元）
                    String minCharge = bWithdrawAccountInfo.getMinCharge();//最小手续费（元）
                    String prompt = bWithdrawAccountInfo.getPrompt();//"提现金额6小时内到账",（提示）
                    String isTX = bWithdrawAccountInfo.getIsTX();//是否套现
                    */
                    initBindUI();
                } else {
                    if (DevConfig.DEBUG) {
                        initBindUI();
                        ToastUtil.showToast(App.mContext, "获取用户信息失败");
                    }

                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
                initBindUI();
            }
        });
    }

    //提交提现订单APP045
    private void doCommitWithdrawOrderInfo(GDoCommitWithdrawOrderInfo model) {
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doCommitWithdrawOrderInfo(model, new JsonCallback<Object>() {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                if (DevConfig.DEBUG){
                    ToastUtil.showToast(App.mContext, "提交成功");
                }
                WithdrawCashActivity.this.startActivity(new Intent(WithdrawCashActivity.this,WithdrawCashStateActivity.class));
                WithdrawCashActivity.this.finish();
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
            }
        });
    }

    //更改提现账户APP046
    private void doChangeBank(GDoChangeBank model) {
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doChangeBank(model, new JsonCallback<Object>() {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                ToastUtil.showToast(App.mContext, "更改成功");
                // TODO: 2017/4/17 更改绑定成功后要切换视图到提交订单视图
                hasBindedBank = true;
                showView(hasBindedBank);
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
            }
        });
    }

    /**
     * 获取手机验证码
     *
     * @param btnGetCode :按钮
     */
    private void doGetPhoneCode(final Button btnGetCode, @NonNull String getCodeType) {

        final CountDownTimer timer = new CountDownTimer(60000, 1000, btnGetCode, "获取验证码");
        timer.start();
        GGetPhoneCode model = new GGetPhoneCode();
        model.setType(getCodeType);
        if (getCodeType.equals("3")) {//完善资料,只传手机号
            TaskEngine.setTokenUseridPhoneState(1);
            model.setPhoneNo("" + mNoBindPhoneNumber);
        } else if (getCodeType.equals("9")) {//更改绑定
            TaskEngine.setTokenUseridPhoneState(2);
            model.setPhoneNo("");
        }
        model.setUserId("");
        TaskEngine.getInstance().doGetPhoneCode(model, new JsonCallback<Object>() {
            @Override
            public void onSuccess(Object bPhoneCode, Call call, Response response) {
                /*
                * Status 1 发送次数超过限制，请查看手机收到的验证码
                        2 手机号码格式不正确
                        3 该手机号在黑名单中
                        4 该手机号已被禁用
                        5 该用户没有绑定手机号
                * */
                ToastUtil.showToast(App.mContext, "短信验证码已发送至您的手机");

            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                timer.cancel();
                btnGetCode.setEnabled(true);
                btnGetCode.setText("获取验证码");
            }
        });
    }

    //获取用户是否绑定手机号APP058
    private void doGetUserIsBindPhone() {
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetUserIsBindPhone(new JsonCallback<BUserIsBindPhone>() {
            @Override
            public void onSuccess(BUserIsBindPhone bUserIsBindPhone, Call call, Response response) {
                if (bUserIsBindPhone != null) {
                    String isBindPhone = bUserIsBindPhone.getIsBindPhone();
                    if (TextUtils.isEmpty(isBindPhone)) {
                        mNoBindIsBindPhone = false;//未绑定
                    } else {
                        mNoBindIsBindPhone = true;//已绑定
                        mNoBindPhoneNumber = bUserIsBindPhone.getIsBindPhone();
                    }
                    //是否显示手机号输入框
                    if (mNoBindIsBindPhone) {
                        mRlPhoneNumberNoBind.setVisibility(View.GONE);
                    } else {
                        mRlPhoneNumberNoBind.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);

            }
        });
    }
}
