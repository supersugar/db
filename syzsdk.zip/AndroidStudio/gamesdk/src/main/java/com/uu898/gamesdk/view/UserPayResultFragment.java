package com.uu898.gamesdk.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.uu898.gamesdk.core.ListenerCenter;
import com.uu898.gamesdk.core.ResourceUtils;
import com.uu898.gamesdk.model.GBaseModel;
import com.uu898.gamesdk.model.request.GGetOrderStatus;
import com.uu898.gamesdk.model.response.BAliPay;
import com.uu898.gamesdk.model.response.BOrderStatus;
import com.uu898.gamesdk.model.response.BUserInfo;
import com.uu898.gamesdk.network.NetCallback;
import com.uu898.gamesdk.network.TaskEngine;
import com.uu898.gamesdk.support.result.UGPayResult;
import com.uu898.gamesdk.utils.AccountManager;
import com.uu898.gamesdk.utils.FloatViewHelper;

import org.xutils.x;

public class UserPayResultFragment extends BaseFragment {

    private BAliPay mOrderModel;
    private TextView mTvStatus;
    private ImageView mIvStatus;
    private Button mNextBt;

    private BOrderStatus mOrderStatus;

    public static UserPayResultFragment newInstance(BAliPay model) {
        Bundle args = new Bundle();
        args.putSerializable("model", model);
        UserPayResultFragment fragment = new UserPayResultFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        if (args != null) {
            mOrderModel = (BAliPay) args.getSerializable("model");
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        View view = inflater.inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_pay_result"), container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        View titleBar = initTitleBar(view, "支付结果");
        titleBar.findViewById(getId("ug_bt_title_left")).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _mActivity.finish();
            }
        });

        mTvStatus = (TextView) view.findViewById(getId("ug_tv_status"));
        mIvStatus = (ImageView) view.findViewById(getId("ug_iv_status"));
        mNextBt = (Button) view.findViewById(getId("ug_bt_next"));
        mNextBt.setOnClickListener(onClickListener);
        mNextBt.setVisibility(View.GONE);
        showLoadToast();
        x.task().postDelayed(new Runnable() {
            @Override
            public void run() {
                hideLoadToast();
                doGetOrderDetail();
                doGetUserInfo();
            }
        }, 3000);

        mTvStatus.setText("订单处理中...请稍候");
        mTvStatus.setTextColor(x.app().getResources().getColor(ResourceUtils.getColorId(_mActivity, "green")));
        mIvStatus.setImageResource(ResourceUtils.getDrawableId(_mActivity, "ug_ic_waiting"));
    }

    @Override
    public void onResume() {
        super.onResume();
        FloatViewHelper.hideFloatingView();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        FloatViewHelper.showFloatingView();
    }

    @Override
    public boolean onBackPressedSupport() {
        _mActivity.finish();
        return true;
    }

    private void setContent(BOrderStatus result) {
        if(result.ZFstatus.equals("1")){
            mTvStatus.setText("充值成功");
            mTvStatus.setTextColor(x.app().getResources().getColor(ResourceUtils.getColorId(_mActivity, "green")));
            mIvStatus.setImageResource(ResourceUtils.getDrawableId(_mActivity, "ug_ic_success"));
        }else{
            mTvStatus.setText("充值失败");
            mTvStatus.setTextColor(x.app().getResources().getColor(ResourceUtils.getColorId(_mActivity, "pink")));
            mIvStatus.setImageResource(ResourceUtils.getDrawableId(_mActivity, "ug_ic_fail"));
        }
    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v.getId() == getId("ug_bt_next")) {
                _mActivity.finish();
            }
        }
    };



    private void doGetOrderDetail() {
        GGetOrderStatus model = new GGetOrderStatus();
        model.setTradeNo(mOrderModel.tradeOrderNo);
        TaskEngine.getInstance().doGetOrderStatus(model, new NetCallback<BOrderStatus>(this) {
            @Override
            public void _onNext(BOrderStatus result) {
                mOrderStatus = result;
                mNextBt.setVisibility(View.VISIBLE);
                setContent(result);
                UGPayResult payResult = new UGPayResult();
                if(mOrderStatus.ZFstatus.equals("1")){
                    payResult.resultCode = UGPayResult.CODE_SUCCESS;
                    ListenerCenter.getInstance().getPayListener().onPayDone(payResult);
                }else{
                    payResult.resultCode = UGPayResult.CODE_FAIL;
                    ListenerCenter.getInstance().getPayListener().onPayDone(payResult);
                }
            }

            @Override
            public void _onError(String msg) {
                mNextBt.setVisibility(View.VISIBLE);
            }
        });
    }

    private void doGetUserInfo() {
        TaskEngine.getInstance().doGetUserInfo(new GBaseModel(), new NetCallback<BUserInfo>(this) {
            @Override
            public void _onNext(BUserInfo result) {
                AccountManager.getInstance().saveAccountInfo(result);
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }


}
