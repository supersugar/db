package com.uu661.model.response;

import java.io.Serializable;

/**
 * Created by bo on 16/9/14.
 */
public class BBanner implements Serializable {

    public static final String GOTO_SEND_HB = "goToSendHB";

    public String imgUrl;//游图片地址
    public String linkUrl;//链接地址
    public int sortId;//
    public String event;//
}
