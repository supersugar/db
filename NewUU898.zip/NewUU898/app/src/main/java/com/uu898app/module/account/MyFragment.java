package com.uu898app.module.account;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.bumptech.glide.Glide;
import com.uu898app.R;
import com.uu898app.module.base.BaseFragment;
import com.uu898app.module.helper.AccountManager;
import com.uu898app.module.helper.ToolbarHelper;
import com.uu898app.module.pay.PayActivity;
import com.uu898app.util.eventbus.EB;
import com.uu898app.view.CircleImageView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class MyFragment extends BaseFragment {

    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.bt_recharge)
    RelativeLayout btRecharge;
    @BindView(R.id.bt_extract)
    RelativeLayout btExtract;
    @BindView(R.id.bt_funds_detail)
    RelativeLayout btFundsDetail;
    @BindView(R.id.bt_record_buy)
    RelativeLayout btRecordBuy;
    @BindView(R.id.bt_record_sell)
    RelativeLayout btRecordSell;
    @BindView(R.id.bt_logout)
    RelativeLayout btLogout;
    @BindView(R.id.iv_photo)
    CircleImageView ivPhoto;
    @BindView(R.id.tv_account)
    TextView tvAccount;
    @BindView(R.id.tv_detail)
    TextView tvDetail;

    public static MyFragment newInstance() {
        Bundle args = new Bundle();
        MyFragment fragment = new MyFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.my_fragment, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Toolbar toolbar = (Toolbar) view.findViewById(R.id.toolbar);
        new ToolbarHelper.Builder(toolbar,this, _mActivity)
                .title("我的资料")
                .build();

        tvAccount.setText(AccountManager.getInstance().getUserInfo().get_userid());
        tvDetail.setText("帐号余额 : " + AccountManager.getInstance().getUserInfo().get_money());
        //http://d.hiphotos.baidu.com/zhidao/wh%3D600%2C800/sign=295f784cb1de9c82a630f1895cb1ac32/faf2b2119313b07e7187cc7d0ed7912397dd8c89.jpg
        String url = "http://d.hiphotos.baidu.com/zhidao/wh%3D600%2C800/sign=295f784cb1de9c82a630f1895cb1ac32/faf2b2119313b07e7187cc7d0ed7912397dd8c89.jpg";
        Glide.with(_mActivity).load(url).crossFade().into(ivPhoto);
    }



    @OnClick({R.id.bt_recharge, R.id.bt_extract, R.id.bt_funds_detail, R.id.bt_record_buy, R.id.bt_record_sell, R.id.bt_logout})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.bt_recharge://充值
                startActivity(new Intent(_mActivity, PayActivity.class));

                /*
                先判断有没有登陆
                登陆：检查个人资料是否完善
                    不完善：进入完善资料界面
                    完善：充值
                 */
//                GBaseModel model = new GBaseModel();
//                model.setSSID(AccountManager.getInstance().getSSID());
//                TaskEngine.getInstance().queryUserInfoIntegrity(model).subscribe(new Action1<BUserInfoIntegrity>() {
//                    @Override
//                    public void call(BUserInfoIntegrity result) {
//                        if (result.isIntegrity()) {
//                            ToastUtil.showToast(_mActivity, "用户资料完整");
//                            startActivity(new Intent(_mActivity, PayActivity.class));
//                        } else {
//                            start(DataIntegrityFragment.newInstance());
//                        }
//                    }
//                });
                break;
            case R.id.bt_extract:
                break;
            case R.id.bt_funds_detail://资金明细
                start(MyTabFragment.newInstance(MyTabFragment.TYPE_FUNDS_DETAIL));
                break;
            case R.id.bt_record_buy://购买记录
                start(MyTabFragment.newInstance(MyTabFragment.TYPE_RECORD_BUY));
                break;
            case R.id.bt_record_sell://出售记录
                start(MyTabFragment.newInstance(MyTabFragment.TYPE_RECORD_SELL));
                break;
            case R.id.bt_logout://退出登陆
                showLogoutDialog();
                break;
        }
    }

    private void showLogoutDialog() {
        MaterialDialog dialog = new MaterialDialog.Builder(_mActivity).title("确认要退出吗?").positiveText("确定").negativeText("取消").onPositive(new MaterialDialog.SingleButtonCallback() {
            @Override
            public void onClick(@NonNull MaterialDialog materialDialog, @NonNull DialogAction dialogAction) {
                AccountManager.getInstance().clearCurrentUserInfo();
                EB.postEmpty(EB.TAG.LOGOUT_SUCCESS);
            }
        }).show();

    }

}
