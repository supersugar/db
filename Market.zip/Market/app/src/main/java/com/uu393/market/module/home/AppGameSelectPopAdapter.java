package com.uu393.market.module.home;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.response.BGameKind;
import com.uu393.market.module.center.ChargeMoneyActivity;
import com.uu393.market.util.log.L;

import java.util.ArrayList;
import java.util.List;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/31
 * Descrip    :
 * =====================================================
 */

public class AppGameSelectPopAdapter extends RecyclerView.Adapter<AppGameSelectPopAdapter.AppGameSelectViewHolder> {
    private List<String> items = new ArrayList<>();
    private int currentItem = -1;
    List<BGameKind> mGameKinds;
    private Context _mActivity;

    public AppGameSelectPopAdapter(Context _mActivity) {
        this._mActivity = _mActivity;
    }

    public void setData( List<BGameKind> mGameKinds){
        if (mGameKinds != null){
            this.mGameKinds = mGameKinds;
            notifyDataSetChanged();
        }
    }

    public void setRefresh(){
        notifyDataSetChanged();
    }

    public void setPosition(int selectedPosition){
            this.currentItem = selectedPosition;
    }

    @Override
    public AppGameSelectViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_app_game_select_pop, parent, false);
        return new AppGameSelectViewHolder(view);
    }

    @Override
    public void onBindViewHolder(AppGameSelectViewHolder holder, final int position) {
        holder.item.setText(mGameKinds.get(position).typeName);


        if (position == currentItem) {
            holder.itemView.setBackgroundResource(R.drawable.shape_corner_solid_blue_half_circle);
            holder.item.setTextColor(App.mContext.getResources().getColor(R.color.white));
        } else {
            holder.itemView.setBackgroundResource(R.drawable.shape_corner_stroke_grey_half_circle);
            holder.item.setTextColor(App.mContext.getResources().getColor(R.color.text_lv2));
        }
        holder.item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {

                    currentItem = position;
                    notifyDataSetChanged();
                    listener.onItemSelectedListener(mGameKinds.get(position), position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mGameKinds.size();
    }

    public void refresh(List<String> items) {
        if (items != null){
            this.items.clear();
            this.items.addAll(items);
        }
        this.notifyDataSetChanged();
    }


    class AppGameSelectViewHolder extends RecyclerView.ViewHolder {
        private TextView item;

        public AppGameSelectViewHolder(View itemView) {
            super(itemView);
            item = (TextView) itemView.findViewById(R.id.tv_item);
        }
    }

    private OnSelectedListener listener;

    public interface OnSelectedListener {
        void onItemSelectedListener(BGameKind content, int position);
    }

    public void setOnSelectedListener(OnSelectedListener listener) {
        this.listener = listener;
    }
}
