package com.uu393.market.module.login;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import com.uu393.market.Constant;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GDoThirdLogin;
import com.uu393.market.model.response.BUserInfo;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.h5game.H5WebViewActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;

import butterknife.Bind;
import butterknife.ButterKnife;
import okhttp3.Call;
import okhttp3.Response;

public class UU898LoginActivity extends BaseActivity {
    @Bind(R.id.wv_uu898_login)
    WebView mWvUu898Login;
    private String openID;
    private String access_token;
    private String mGameId;
    private String APPID;
    private String mGameUrl;
    private Dialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uu898_login);
        ButterKnife.bind(this);
        mDialog = new Dialog(this, R.style.DialogStyle);
        mDialog.setContentView(R.layout.loading_dialog);
        mDialog.setCancelable(true);
        mDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        TextView message = (TextView) mDialog.findViewById(R.id.tv_dialog_message);
        message.setText("加载中 ···");
        initWebView();
    }
    public void showLoadToast() {
        if (mDialog!=null&&!mDialog.isShowing())
            mDialog.show();
    }

    public void hideLoadToast() {
        if (mDialog!=null&&mDialog.isShowing())
            mDialog.dismiss();
    }

    private void initWebView() {
        mWvUu898Login.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        WebSettings settings = mWvUu898Login.getSettings();
        settings.setJavaScriptEnabled(true);//设置可以与h5交互

        //显示WebView提供的缩放控件
        settings.setDisplayZoomControls(true);
        settings.setBuiltInZoomControls(true);
        mWvUu898Login.setWebChromeClient(new WebChromeClient());
        mWvUu898Login.setWebViewClient(new WebViewClient(){
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                L.d(url);
                if (url.startsWith("http://ddd.cuowuwangzhi.com/?")) {
                    int i = url.indexOf("?");
                    String params = url.substring(i+1) ;
                    String[] strings = params.split("&");
                    for (String s:strings){
                        if (s.contains("openID")){
                            openID = s.substring(s.indexOf("=")+1);
                        }else if (s.contains("access_token")){
                            access_token = s.substring(s.indexOf("=")+1);
                        }
                    }
                    //todo 执行uu手游登录逻辑

                    if (openID==null||TextUtils.isEmpty(openID)){
                        view.loadUrl(url);
                        return super.shouldOverrideUrlLoading(view, url);
                    }else {
                        doLogin(openID,access_token);
                    }

                    return true;
                }
                view.loadUrl(url);
                return super.shouldOverrideUrlLoading(view, url);
            }
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                hideLoadToast();
            }
            @Override
            public void onPageFinished(WebView view, String url) {
               super.onPageFinished(view, url);
                hideLoadToast();
            }
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                showLoadToast();
            }
        });
        mWvUu898Login.loadUrl(Constant.UU898_LOGIN_URL);
    }
    private void doLogin(String uid,String token) {
        GDoThirdLogin model = new GDoThirdLogin();
        model.setOpenId(uid);
        model.setToken(token);
        model.setType("3");
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doThirdLogin(model, new JsonCallback<BUserInfo>() {
            @Override
            public void onSuccess(BUserInfo userInfo, Call call, Response response) {
                SPUtil.put(App.mContext, "isLogin", true);
                SPUtil.put(App.mContext, "thirdUserId", "");//uu898没有用户名返回
                SPUtil.put(App.mContext, "loginType", "4");
                SPUtil.put(App.mContext, "token", userInfo.getToken());
                SPUtil.put(App.mContext, "userId", userInfo.getUserId());
                SPUtil.put(App.mContext, "uId", userInfo.getUId());
                SPUtil.put(App.mContext, "chkMobile", userInfo.getChkMobile());
                ToastUtil.showToast(App.mContext, "登录成功");
                EB.postEmpty(EB.TAG.LOGIN_SUCCESS);
                mGameId = (String) SPUtil.get(App.mContext,"GameId","");
                APPID = (String) SPUtil.get(App.mContext,"APPID","");
                mGameUrl = (String) SPUtil.get(App.mContext,"GameUrl","");
                if (!TextUtils.isEmpty(mGameId)){
                    Intent intent = new Intent();
                    intent.putExtra("gameId",mGameId);
                    intent.putExtra("APPID",APPID);
                    intent.putExtra("url",mGameUrl);
                    intent.setClass(UU898LoginActivity.this,H5WebViewActivity.class);
                    startActivity(intent);
                    SPUtil.put(App.mContext, "GameId", "");
                    SPUtil.put(App.mContext, "APPID", "");
                    SPUtil.put(App.mContext, "GameUrl", "");
                }/*else {
                    startActivity(new Intent(UU898LoginActivity.this, UserCenterActivity.class));
                }*/
                UU898LoginActivity.this.finish();//退出界面
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mDialog=null;
        if (mWvUu898Login!=null){
            mWvUu898Login.destroy();
        }
    }
}
