package com.uu898.gamesdk.utils;

import com.uu898.gamesdk.model.response.BUserInfo;

import static com.uu898.gamesdk.utils.AccountManager.Status.NOT_LOGIN;

/**
 * Created by zhangbo on 2016/7/1.
 */
public class AccountManager {

    /**
     * 未登陆(初始状态)
     * 登陆
     * 登出
     * 注册后未登陆(保存有ssid和userid,但是是未登陆状态)
     */
    public enum Status {
        NOT_LOGIN, LOGIN, LOGOUT, REGISTER_DONE_NOT_LOGIN
    }

    private final static AccountManager INSTANCE = new AccountManager();

    private Status mStatus = NOT_LOGIN;

    private String mCurrentUserID;

    private BUserInfo userInfo;

    public AccountManager() {
    }

    public static AccountManager getInstance() {
        return INSTANCE;
    }

    public Status getStatus() {
        return mStatus;
    }

    /**
     * 登陆成功
     * 登出
     * 调用
     *
     * @param mStatus
     */
    public void setStatus(Status mStatus, String userId) {
        this.mStatus = mStatus;
        if (mStatus == Status.LOGIN || mStatus == Status.REGISTER_DONE_NOT_LOGIN) {
            mCurrentUserID = userId;
        } else if (mStatus == Status.LOGOUT) {
            mCurrentUserID = "";
        }
    }

    /**
     * 获取当前登陆的用户id
     *
     * @return
     */
    public String getCurrentUserID() {
        if (null != mStatus && (mStatus == Status.LOGIN || mStatus == Status.REGISTER_DONE_NOT_LOGIN) && !StringUtils.isEmpty
                (mCurrentUserID)) {
            return mCurrentUserID;
        } else {
            return "";
        }
    }

    /**
     * 获取token,如果是登陆状态,根据当前登陆用户,查询对应token
     * 如果是非登陆状态,传""
     *
     * @return
     */
    public String getSSID() {
        if (null != mStatus && (mStatus == Status.LOGIN || mStatus == Status.REGISTER_DONE_NOT_LOGIN) && !StringUtils.isEmpty
                (mCurrentUserID)) {
            return CommonUtils.getTokenByUserName(mCurrentUserID);
        } else {
            return "";
        }
    }

    /**
     * 保存用户登陆信息
     *
     * @param ssid
     * @param userId
     */
    public void saveLoginInfo(String ssid, String userId, Status status) {
        setStatus(status, userId);
        CommonUtils.updateUserNameList(userId);
        CommonUtils.saveUserToken(userId, ssid);
    }

    /**
     * 保存用户信息
     */
    public void saveAccountInfo(BUserInfo userInfo) {
        this.userInfo = userInfo;
    }

    /**
     * 获取保存的用户信息
     *
     * @return
     */
    public BUserInfo getUserInfo() {
        //        if (null != userInfo && null != mCurrentUserID && userInfo._userid.equals(mCurrentUserID)) {
        if (null != userInfo && null != mCurrentUserID) {
            return userInfo;
        } else {
            return null;
        }
    }
}
