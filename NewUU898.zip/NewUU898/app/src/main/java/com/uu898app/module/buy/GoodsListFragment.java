package com.uu898app.module.buy;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.lapism.searchview.SearchView;
import com.uu898app.R;
import com.uu898app.adapter.GoodsListAdapter;
import com.uu898app.model.request.GGoods;
import com.uu898app.model.response.BGoods;
import com.uu898app.module.base.BaseFragment;
import com.uu898app.module.helper.AccountManager;
import com.uu898app.module.helper.BuyHelper;
import com.uu898app.module.helper.ToolbarHelper;
import com.uu898app.network.TaskEngine;
import com.uu898app.util.dropdownmenu.DropMenuAdapter;
import com.uu898app.util.log.L;
import com.uu898app.view.dropdownmenu.DropDownMenu;
import com.uu898app.view.dropdownmenu.interfaces.OnFilterDoneListener;

import java.util.List;

import rx.functions.Action1;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class GoodsListFragment extends BaseFragment {

    private SwipeRefreshLayout mSwipeRefreshLayout;
    private RecyclerView mRecyclerView;
    private GoodsListAdapter mAdapter;
    private boolean mInAtTop = true;
    private int mScrollTotal;
    private DropDownMenu mDropDownMenu;

    private int mCurrentPage = 1;
    private SearchView mSearchView;
    private String mSearchKeyword = "";


    public static GoodsListFragment newInstance() {
        Bundle args = new Bundle();
        GoodsListFragment fragment = new GoodsListFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.buy_goods_result, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Toolbar toolbar = (Toolbar) view.findViewById(R.id.toolbar);
        new ToolbarHelper.Builder(toolbar, this, _mActivity)
                .title("商品列表")
                .showBack(true)
                .build();

        toolbar.inflateMenu(R.menu.menu_search);
        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.search://搜索
                        mSearchView.open(true);
                        break;
                    default:
                        break;
                }
                return true;
            }
        });

        setSearchView(view);

        mDropDownMenu = (DropDownMenu) view.findViewById(R.id.dropDownMenu);
        String[] titleList = new String[]{"排序", "商品类型", "游戏区服", "筛选"};
        mDropDownMenu.setMenuAdapter(new DropMenuAdapter(_mActivity, titleList, new OnFilterDoneListener() {
            @Override
            public void onFilterDone(int position, String positionTitle, String urlValue) {
                L.d("position = " + position + "positionTitle = " + positionTitle + "urlValue = " + urlValue);
                mDropDownMenu.close();
                mCurrentPage = 1;
                doGetGoodsList();
            }
        }));

        mRecyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        mSwipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.mFilterContentView);

        mSwipeRefreshLayout.setColorSchemeResources(R.color.colorAccent);
        mSwipeRefreshLayout.setOnRefreshListener(onRefreshListener);

        LinearLayoutManager manager = new LinearLayoutManager(_mActivity);
        mRecyclerView.setLayoutManager(manager);
        mAdapter = new GoodsListAdapter(null);
        mAdapter.openLoadAnimation();
        mRecyclerView.setAdapter(mAdapter);

        mAdapter.openLoadMore(20);
        mAdapter.setOnLoadMoreListener(new BaseQuickAdapter.RequestLoadMoreListener() {
            @Override
            public void onLoadMoreRequested() {
                doGetGoodsList();
            }
        });
        mRecyclerView.addOnItemTouchListener(new OnItemClickListener() {
            @Override
            public void SimpleOnItemClick(BaseQuickAdapter baseQuickAdapter, View view, int i) {
//                start(GoodsDetailFragment.newInstance(mAdapter.getItem(i).getCommodityNo()));
            }
        });

        doGetGoodsList();
    }

    protected void setSearchView(View view) {
        mSearchView = (SearchView) view.findViewById(R.id.searchView);
        if (mSearchView != null) {
            mSearchView.setVersion(SearchView.VERSION_MENU_ITEM);
            mSearchView.setVersionMargins(SearchView.VERSION_MARGINS_MENU_ITEM);
            mSearchView.setTheme(SearchView.THEME_LIGHT, true);
            mSearchView.setTextSize(16);
            mSearchView.setHint("Search");
            mSearchView.setDivider(false);
            mSearchView.setVoice(false);
//            mSearchView.setVoiceText("Set permission on Android 6+ !");
            mSearchView.setAnimationDuration(SearchView.ANIMATION_DURATION);
            mSearchView.setShadowColor(ContextCompat.getColor(_mActivity, R.color.search_shadow_layout));
            mSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    mCurrentPage = 1;
                    mSearchKeyword = query;
                    doGetGoodsList();
                    mSearchView.close(false);
                    return true;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    return false;
                }
            });

        }
    }

    SwipeRefreshLayout.OnRefreshListener onRefreshListener = new SwipeRefreshLayout.OnRefreshListener() {
        @Override
        public void onRefresh() {
            doGetGoodsList();
        }
    };

    private void doGetGoodsList() {
        mSwipeRefreshLayout.post(new Runnable() {
            @Override
            public void run() {
                mSwipeRefreshLayout.setRefreshing(true);
                GGoods gGoods = new GGoods();
                BuyHelper instance = BuyHelper.getInstance();
                String tempID = "";
                gGoods.setGameid(null == instance.getChooseGame() ? tempID : String.valueOf(instance.getChooseGame().getID()));
                gGoods.setKindid(null == instance.getChooseGameKind() ? tempID : String.valueOf(instance.getChooseGameKind().getID()));
                gGoods.setServerid(null == instance.getChooseGameService() ? tempID : String.valueOf(instance.getChooseGameService().getID()));
                gGoods.setAreaid(null == instance.getChooseGameArea() ? tempID : String.valueOf(instance.getChooseGameArea().getID()));
                gGoods.setSSID(AccountManager.getInstance().getSSID());
                gGoods.setKeyword(mSearchKeyword);
                gGoods.setTradeid("");
                gGoods.setOrderIndex(instance.getOrderIndex());
                gGoods.setPage(mCurrentPage);
                TaskEngine.getInstance().getGoodsList(gGoods).subscribe(new Action1<List<BGoods>>() {
                    @Override
                    public void call(List<BGoods> result) {
                        Log.d("xx", result.size() + "");
                        mSwipeRefreshLayout.setRefreshing(false);
                        if (mCurrentPage == 1) {
                            mAdapter.setNewData(result);
                            mRecyclerView.smoothScrollToPosition(0);
                        } else {
                            mAdapter.addData(result);
                        }
                        mCurrentPage++;
                    }
                });
            }
        });
    }
}
