package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/7
 * Descrip    : 搜索返回数据类型
 * =====================================================
 */

public class BGameSearch implements Serializable {
    /**
     {
     "id": "123456",(游戏的唯一ID)
     "icon": "kjkjjk.jpg",(游戏图标)
     "gameName": "御剑情缘",(游戏名称)
     "typeName": "策略",(游戏类型)
     "size": "520.3",(游戏大小)
     "describe": "最好玩的游戏",(游戏描述)
     "versionCode": "1”,(游戏版本编号)
     "versionName": "1.0.2”,(游戏版本名称)
     "discount": "1”,(游戏折扣)
     "androidPackage": "1”,(安卓下载包地址)
     "packageName": "1”,(包名)
     "isBt": "true”,(是否是BT版游戏)
     "platForm": "0”,(0app游戏  1h5游戏)
     }

     */

    private String id;
    private String icon;
    private String gameName;
    private String typeName;
    private String size;
    private String describe;
    private String versionCode;
    private String versionName;
    private String discount;
    private String androidPackage;
    private String packageName;
    private String isBt;
    private String platForm;

    public String getAPPID() {
        return APPID;
    }

    public void setAPPID(String APPID) {
        this.APPID = APPID;
    }

    private String APPID;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {
        this.describe = describe;
    }

    public String getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(String versionCode) {
        this.versionCode = versionCode;
    }

    public String getVersionName() {
        return versionName;
    }

    public void setVersionName(String versionName) {
        this.versionName = versionName;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    public String getAndroidPackage() {
        return androidPackage;
    }

    public void setAndroidPackage(String androidPackage) {
        this.androidPackage = androidPackage;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getIsBt() {
        return isBt;
    }

    public void setIsBt(String isBt) {
        this.isBt = isBt;
    }

    public String getPlatForm() {
        return platForm;
    }

    public void setPlatForm(String platForm) {
        this.platForm = platForm;
    }
}
