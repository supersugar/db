package com.uu661.module.my;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uu661.R;
import com.uu661.model.request.GGetOrderList;
import com.uu661.module.base.BaseFragment;
import com.uu661.module.base.BaseViewPagerFragment;
import com.uu661.view.lazyviewpager.LazyFragmentPagerAdapter;

import java.util.HashMap;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;


/**
 * Created by zhangbo on 2016/6/23.
 */
public class MyOrderFragment extends BaseFragment {


    @BindView(R.id.tabs) TabLayout mTabs;
    @BindView(R.id.tabs_viewpager) ViewPager mTabsViewpager;

    private Map<Integer, BaseViewPagerFragment> fragmentsMap = new HashMap<>();
    private int mCurrentFragmentIndex = 0;

    public static MyOrderFragment newInstance() {
        Bundle args = new Bundle();
        MyOrderFragment fragment = new MyOrderFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.my_order_fragment, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "夺钻记录", true);
        initViewPager();
    }


    private void initViewPager() {
        mTabsViewpager.setAdapter(new MyPagerAdapter(getChildFragmentManager()));
        mTabs.setupWithViewPager(mTabsViewpager);
    }

    public class MyPagerAdapter extends LazyFragmentPagerAdapter {

        private String[] titles = new String[]{"参与成功", "夺钻成功"};

        public MyPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public int getCount() {
            return 2;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return titles[position];
        }

        @Override
        protected Fragment getItem(ViewGroup container, int position) {
            int type = position == 0 ? GGetOrderList.TYPE_ALL : GGetOrderList.TYPE_LUCKY;
            MyOrderListFragment fragment = MyOrderListFragment.newInstance(type);
            return fragment;
        }
    }


}
