package com.uu393.market.module.mygame;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.PlayedHelper;
import com.uu393.market.model.request.GGetMultiGameDetail;
import com.uu393.market.model.response.BGame;
import com.uu393.market.module.base.BaseViewPagerFragment;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.log.L;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import butterknife.Bind;
import butterknife.ButterKnife;
import okhttp3.Call;
import okhttp3.Response;


public class MyGamePlayedListFragment extends BaseViewPagerFragment {


    @Bind(R.id.ptf_mygame_played_list)
    PullLoadMoreRecyclerView mRecyclerView;
    @Bind(R.id.mygame_no_result_view)
    LinearLayout mMygameNoResultView;

    private List<BGame> mGameList;
    private List<String> mPlayedGames;
    private MyPlayedGameAdapter myPlayedGameAdapter;

    public static MyGamePlayedListFragment newInstance() {
        MyGamePlayedListFragment fragment = new MyGamePlayedListFragment();
        Bundle bundle = new Bundle();
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_mygame_played_list, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mPlayedGames = new ArrayList<>();
        mGameList = new ArrayList<>();
        initRecyclerView();
    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart("MyGamePlayedListFragment");
        mPlayedGames.clear();
        Map<Object,Object> allPlayedRecord = PlayedHelper.getInstance(App.mContext).getAllPlayedRecord();
        for (Map.Entry<Object,Object> entry : allPlayedRecord.entrySet()){
            String gameId = (String) entry.getValue();
            mPlayedGames.add(gameId);
            Log.d("---------------","---------------mPlayedGames="+mPlayedGames);
            doGetGameList(mPlayedGames);
        }
        myPlayedGameAdapter.refresh();
    }
    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("MyGamePlayedListFragment");
    }

    private void initRecyclerView() {
        mRecyclerView.setLinearLayout();
        myPlayedGameAdapter = new MyPlayedGameAdapter(_mActivity, mPlayedGames);
        mRecyclerView.setPullRefreshEnable(false);
        mRecyclerView.setPushRefreshEnable(false);
        mRecyclerView.setAdapter(myPlayedGameAdapter);
        showResult(mPlayedGames!=null&&mPlayedGames.size()!=0);
    }

    @Override
    public void refresh() {
        myPlayedGameAdapter.refresh();
        showResult(mPlayedGames!=null&&mPlayedGames.size()!=0);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }

    private void showResult(boolean hasResult) {
        if (hasResult) {
            mRecyclerView.setVisibility(View.VISIBLE);
            mMygameNoResultView.setVisibility(View.GONE);
        } else {
            mRecyclerView.setVisibility(View.GONE);
            mMygameNoResultView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        L.d("onDestroy");
    }

    private void doGetGameList(List<String> ids) {
        if (ids == null || ids.isEmpty()) {
            showResult(false);
            return;
        }
        GGetMultiGameDetail model = new GGetMultiGameDetail();
        model.setId("" + ids.toString().replace("[", "").replace("]", "").trim());//多个ID
        showLoadToast();
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetMultiGameDetail(model, new JsonCallback<List<BGame>>() {
            @Override
            public void onSuccess(List<BGame> bGames, Call call, Response response) {
                hideLoadToast();
                if (null == bGames || bGames.isEmpty()) {
                    showResult(false);
                } else {
                    mGameList.clear();
                    mGameList.addAll(bGames);
                    showResult(true);
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
                showResult(false);
            }

            @Override
            public void onAfter(List<BGame> bGames, Exception e) {
                super.onAfter(bGames, e);
                hideLoadToast();
                mRecyclerView.setPullLoadMoreCompleted();
                myPlayedGameAdapter.setData(mGameList);
            }
        });
    }
}
