package com.uu661.core;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.TextView;

import com.afollestad.materialdialogs.MaterialDialog;
import com.uu661.R;
import com.uu661.model.response.BCoupon;
import com.uu661.module.home.DiamondDetailActivity;
import com.uu661.util.CommonUtils;

/**
 * Created by bo on 17/3/27.
 */

public class DialogCenter {

    /**
     * {
     * "id": "10418",
     * "title": "仅限3元夺5U钻面值使用",
     * "validTime": "长期有效",
     * "remark": "体验完可到UU898商品列表页领取4U钻",
     * "money": "300",
     * "status": "1",
     * "useCondition": "3.00元起用",
     * "voucherMoney": "300"
     * }
     *
     * @param activity
     */
    public static void showLoginCouponPopDialog(final Activity activity, final BCoupon coupon) {
        final MaterialDialog dialog = new MaterialDialog.Builder(activity).customView(R.layout.dialog_pop_diamond, true).build();

        final TextView mTitle = (TextView) dialog.getCustomView().findViewById(R.id.title_tv);
        final TextView mContent = (TextView) dialog.getCustomView().findViewById(R.id.content_tv);
        final TextView mButtonTv = (TextView) dialog.getCustomView().findViewById(R.id.button_tv);
        TextView mDesTv = (TextView) dialog.getCustomView().findViewById(R.id.des_tv);
        Button mButton = (Button) dialog.getCustomView().findViewById(R.id.button);

        String voucherMoney = CommonUtils.fenToYuan(coupon.voucherMoney);
        if (voucherMoney.endsWith(".00")) {
            voucherMoney = voucherMoney.substring(0, voucherMoney.lastIndexOf("."));
        }

        mTitle.setText("恭喜您获得" + voucherMoney + "元红包");
        mContent.setText(coupon.title);
        mButtonTv.setText(voucherMoney + "元夺钻币");
        mDesTv.setText(coupon.remark);
        mButton.setText("立即使用");

        mTitle.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                Shader shader = new LinearGradient(0, 0, mTitle.getWidth(), 0, Color.RED,
                        Color.BLUE, Shader.TileMode.CLAMP);
                mTitle.getPaint().setShader(shader);
            }
        });
        mContent.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                Shader shader = new LinearGradient(0, 0, 0, mContent.getHeight(), Color.parseColor("#ffa703"),
                        Color.parseColor("#fff75c"), Shader.TileMode.CLAMP);
                mContent.getPaint().setShader(shader);
            }
        });
        mButtonTv.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                Shader shader = new LinearGradient(0, 0, mButtonTv.getWidth(), 0, Color.RED,
                        Color.BLUE, Shader.TileMode.CLAMP);
                mButtonTv.getPaint().setShader(shader);
            }
        });
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                if(coupon.commodityNo != -1){
                    Intent intent = new Intent(activity, DiamondDetailActivity.class);
                    intent.putExtra(DiamondDetailActivity.INTENT_KEY_COMMODITY_ID, coupon.commodityNo);
                    intent.putExtra(DiamondDetailActivity.INTENT_KEY_PERIOD_NO, 0);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    activity.startActivity(intent);
                }
            }
        });
        dialog.show();
    }

    /**
     * @param activity
     * @param coupon
     */
    public static void showOverBuyCouponPopDialog(Activity activity, BCoupon coupon) {
        final MaterialDialog dialog = new MaterialDialog.Builder(activity).customView(R.layout.dialog_pop_diamond, true).build();

        final TextView mTitle = (TextView) dialog.getCustomView().findViewById(R.id.title_tv);
        final TextView mContent = (TextView) dialog.getCustomView().findViewById(R.id.content_tv);
        final TextView mButtonTv = (TextView) dialog.getCustomView().findViewById(R.id.button_tv);
        TextView mDesTv = (TextView) dialog.getCustomView().findViewById(R.id.des_tv);
        Button mButton = (Button) dialog.getCustomView().findViewById(R.id.button);

        String voucherMoney = CommonUtils.fenToYuan(coupon.voucherMoney);
        if (voucherMoney.endsWith(".00")) {
            voucherMoney = voucherMoney.substring(0, voucherMoney.lastIndexOf("."));
        }

        mTitle.setText("恭喜您获得" + voucherMoney + "元红包");
        mContent.setText("您夺钻我免费送红包");
        mButtonTv.setText(voucherMoney + "元夺钻币");
        mDesTv.setText("有效期" + coupon.validTime);
        mButton.setText("我记住了，明天使用");

        mTitle.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                Shader shader = new LinearGradient(0, 0, mTitle.getWidth(), 0, Color.RED,
                        Color.BLUE, Shader.TileMode.CLAMP);
                mTitle.getPaint().setShader(shader);
            }
        });
        mContent.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                Shader shader = new LinearGradient(0, 0, 0, mContent.getHeight(), Color.parseColor("#ffa703"),
                        Color.parseColor("#fff75c"), Shader.TileMode.CLAMP);
                mContent.getPaint().setShader(shader);
            }
        });
        mButtonTv.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                Shader shader = new LinearGradient(0, 0, mButtonTv.getWidth(), 0, Color.RED,
                        Color.BLUE, Shader.TileMode.CLAMP);
                mButtonTv.getPaint().setShader(shader);
            }
        });

        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

}
