package com.uu661.model.request;

public class GGetDiamondInfo {

    private int commodityId;//商品编号
    private int periodNo;//期数编号

    public GGetDiamondInfo(int commodityId, int periodNo) {
        this.commodityId = commodityId;
        this.periodNo = periodNo;
    }
}
