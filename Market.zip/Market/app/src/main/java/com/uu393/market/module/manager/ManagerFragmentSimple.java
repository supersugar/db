package com.uu393.market.module.manager;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.module.base.BaseFragment;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;

import org.greenrobot.eventbus.Subscribe;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class ManagerFragmentSimple extends BaseFragment {

    private ImageButton mTitleBarLeft;
    private ToggleButton mTitleBarRight;
    private TextView mTitleBarTitle;

    private DownloadFragment mDownloadFragment;


    public static ManagerFragmentSimple newInstance() {
        Bundle args = new Bundle();
        ManagerFragmentSimple fragment = new ManagerFragmentSimple();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View inflate = inflater.inflate(R.layout.manage_fragment_simple, container, false);
        mTitleBarLeft = (ImageButton) inflate.findViewById(R.id.title_bar_left);
        mTitleBarTitle = (TextView) inflate.findViewById(R.id.title_bar_title);
        mTitleBarRight = (ToggleButton) inflate.findViewById(R.id.title_bar_right);
        return inflate;
    }

    @Override

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mDownloadFragment = DownloadFragment.newInstance();
        initTitleBar();
        if (savedInstanceState == null) {
            loadRootFragment(R.id.fl_container, mDownloadFragment);
        }
    }

    private void initTitleBar() {
        mTitleBarRight.setVisibility(View.GONE);
        mTitleBarTitle.setText("下载管理");
        mTitleBarLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _mActivity.onBackPressedSupport();
            }
        });
    }


    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        L.d("onHiddenChanged" + hidden);
        if(null != mDownloadFragment){
            mDownloadFragment.refresh();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        L.d("onResume");
        MobclickAgent.onPageStart("ManagerFragmentSimple");
        EB.register(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("ManagerFragmentSimple");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        L.d("onDestroy");
        EB.unregister(this);
    }

    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.APP_INSTALL:
                mDownloadFragment.refresh();
                break;
            default:
                break;
        }
    }

}
