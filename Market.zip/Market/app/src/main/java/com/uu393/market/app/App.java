package com.uu393.market.app;

import android.app.Application;
import android.content.Context;
import android.os.Environment;
import android.support.multidex.MultiDex;

import com.bugtags.library.Bugtags;
import com.bugtags.library.BugtagsOptions;
import com.bumptech.glide.Glide;
import com.bumptech.glide.integration.okhttp.OkHttpUrlLoader;
import com.bumptech.glide.load.engine.cache.MemorySizeCalculator;
import com.bumptech.glide.load.model.GlideUrl;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.cache.CacheEntity;
import com.lzy.okgo.cache.CacheMode;
import com.lzy.okserver.download.DownloadInfo;
import com.lzy.okserver.download.DownloadManager;
import com.lzy.okserver.download.DownloadService;
import com.lzy.okserver.listener.DownloadListener;
//import com.sina.weibo.sdk.WbSdk;
import com.sina.weibo.sdk.auth.AuthInfo;
import com.squareup.okhttp.OkHttpClient;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import com.umeng.analytics.MobclickAgent;
import com.umeng.message.IUmengRegisterCallback;
import com.umeng.message.PushAgent;
import com.uu393.market.BuildConfig;
import com.uu393.market.Constant;
import com.uu393.market.core.DevConfig;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.log.L;

import java.io.File;
import java.io.InputStream;

import cn.xiaoneng.uiapi.Ntalker;

/**
 * 全局配置信息
 */
public class App extends Application {

    private static final int DEFAULT_TIMEOUT = 10000;       //默认的超时时间 10秒
    private static final int DEFAULT_DOWNLOAD_SIZE = 2;       //默认同时可下载数量

    public static Context mContext;
    private IWXAPI iwxapi;

    public static StringBuffer EXCEPTION_URL = new StringBuffer();
//    private RefWatcher refWatcher;
    @Override
    public void onCreate() {
        super.onCreate();
        mContext = this;
        DevConfig.getInstance().init();
        OkGo.init(this);//
        configOkGo();//网络访问库
        configDownloadManager();//下载sdk
        //configUmengAnalytics(DevConfig.DEBUG);//友盟统计
        initNtalker();//客服sdk
        //initBugtags();//bug跟踪
        initUmengPush();//友盟推送
//        initLeakCanary();//内存泄漏检测工具
        //initLog();
//        WbSdk.install(App.mContext,new AuthInfo(App.mContext, Constant.WB_APP_KEY, Constant.WB_REDIRECT_URL, Constant.WB_SCOPE));

    }
//    public static RefWatcher getRefWatcher(Context context) {
//        App application = (App) context.getApplicationContext();
//        return application.refWatcher;
//    }

    private void initNtalker() {
        /**小能配置信息
         *  @params appContext
         *  @params siteid: 企业id，即企业唯一标识。格式示例：kf_9979【必填】
         *  @params sdkkey: 企业key，即小能通行密钥【必填】
         *  @return int  0 表示初始化成功, 其他值请查看错误码
         */
        Ntalker.getInstance().initSDK(mContext, Constant.XN_SITEID, Constant.XN_SDKKEY);//初始化小能
        Ntalker.getInstance().enableDebug(DevConfig.DEBUG);
    }


    private void initBugtags() {
        BugtagsOptions options = new BugtagsOptions.Builder().
                trackingLocation(true).       //是否获取位置，默认 true
                trackingCrashLog(true).       //是否收集闪退，默认 true
                trackingConsoleLog(true).     //是否收集控制台日志，默认 true
                trackingUserSteps(false).      //是否跟踪用户操作步骤，默认 true
                crashWithScreenshot(true).    //收集闪退是否附带截图，默认 true
                trackingAnr(true).              //收集 ANR，默认 false
                trackingBackgroundCrash(false).  //收集 独立进程 crash，默认 false
                versionName(BuildConfig.VERSION_NAME).         //自定义版本名称，默认 app versionName
                versionCode(BuildConfig.VERSION_CODE).              //自定义版本号，默认 app versionCode
                //trackingNetworkURLFilter("(.*)").//自定义网络请求跟踪的 url 规则，默认 null
                        enableUserSignIn(true).            //是否允许显示用户登录按钮，默认 true
                startAsync(true).    //设置 为 true 则 SDK 会在异步线程初始化，节省主线程时间，默认 false
                startCallback(null).            //初始化成功回调，默认 null
                remoteConfigDataMode(Bugtags.BTGDataModeProduction).//设置远程配置数据模式，默认Bugtags.BTGDataModeProduction 参见[文档](https://docs.bugtags.com/zh/remoteconfig/android/index.html)
                remoteConfigCallback(null).//设置远程配置的回调函数，详见[文档](https://docs.bugtags.com/zh/remoteconfig/android/index.html)
                enableCapturePlus(false).        //是否开启手动截屏监控，默认 false，参见[文档](https://docs.bugtags.com/zh/faq/android/capture-plus.html)
                //extraOptions(Bugtags.BTGConsoleLogCapacityKey, 500).//设置控制台日志行数的控制 value > 0，默认500
                //extraOptions(Bugtags.BTGBugtagsLogCapacityKey, 1000).//控制 Bugtags log 行数的控制 value > 0，默认1000
                //extraOptions(Bugtags.BTGUserStepLogCapacityKey, 1000).//控制用户操作步骤行数的控制 value > 0，默认1000
                //extraOptions(Bugtags.BTGNetworkLogCapacityKey, 20).//控制网络请求数据行数的控制 value > 0，默认20
                        build();
        /**
         * Bugtags 有三种调用模式：
         BTGInvocationEventNone    // 静默模式，只收集 Crash 信息（如果允许）
         BTGInvocationEventShake   // 通过摇一摇呼出 Bugtags
         BTGInvocationEventBubble  // 通过悬浮小球呼出 Bugtags
         * */
        Bugtags.start(Constant.BUG_TAG_APP_ID, this, Bugtags.BTGInvocationEventNone, options);
    }

    private void initWX() {
        iwxapi = WXAPIFactory.createWXAPI(App.mContext, Constant.WX_APP_ID, true);//微信登录
    }

    private void initUmengPush() {
        PushAgent mPushAgent = PushAgent.getInstance(this);
        //注册推送服务，每次调用register方法都会回调该接口
        mPushAgent.register(new IUmengRegisterCallback() {

            @Override
            public void onSuccess(String deviceToken) {
                //注册成功会返回device token
                L.d("友盟推送设置token-->" + deviceToken);
            }

            @Override
            public void onFailure(String s, String s1) {
            }
        });
        mPushAgent.setDebugMode(DevConfig.DEBUG);//todo 正式时需要改
    }

    public static boolean getIsFirstAppLaunch() {
        return (boolean) SPUtil.get(mContext, "isFirstLaunch", true);//默认是第一次
    }

    public static void setIsFirstAppLaunch(boolean isFirstLaunch) {
        SPUtil.put(mContext, "isFirstLaunch", isFirstLaunch);
    }

    /**
     * 配置友盟统计
     *
     * @param debug
     */
    private void configUmengAnalytics(boolean debug) {
        //        String channel = ChannelUtil.getChannel(this);
        //        String appKey = "53bb958056240bfb270d067a";
        //        MobclickAgent.UMAnalyticsConfig config = new MobclickAgent.UMAnalyticsConfig(this, appKey, channel);
        //        MobclickAgent.startWithConfigure(config);
        MobclickAgent.openActivityDurationTrack(false);//禁止默认的页面统计方式，这样将不会再自动统计Activity
        //使用集成测试之后，所有测试数据不会进入应用正式的统计后台，只能在“管理--集成测试--实时日志”里查看
        MobclickAgent.setDebugMode(DevConfig.DEBUG);//todo 正式时需要改
        MobclickAgent.setScenarioType(this, MobclickAgent.EScenarioType.E_UM_NORMAL);//普通统计场景类型
        MobclickAgent.setCatchUncaughtExceptions(false);//SDK通过Thread.UncaughtExceptionHandler  捕获程序崩溃日志，并在程序下次启动时发送到服务器。 如不需要错误统计功能，可通过此方法关闭
        MobclickAgent.enableEncrypt(true);//SDK会对日志进行加密。加密模式可以有效防止网络攻击，提高数据安全性。
    }

    /**
     * 配置下载管理器
     * 下载路径:/storage/sdcard0/download/uu393/
     */
    private void configDownloadManager() {
        DownloadManager downloadManager = DownloadService.getDownloadManager();
        downloadManager.setTargetFolder(Environment.getExternalStorageDirectory().getAbsolutePath() +
                File.separator + "download" + File.separator + "uu393" + File.separator);
        L.d("下载路径 : " + downloadManager.getTargetFolder());
        downloadManager.getThreadPool().setCorePoolSize(DEFAULT_DOWNLOAD_SIZE);
        downloadManager.getHandler().setGlobalDownloadListener(new DownloadListener() {
            @Override
            public void onProgress(DownloadInfo downloadInfo) {

            }

            @Override
            public void onFinish(DownloadInfo downloadInfo) {

            }

            @Override
            public void onError(DownloadInfo downloadInfo, String errorMsg, Exception e) {
                StringBuffer message = new StringBuffer();
                if ((boolean) SPUtil.get(App.mContext, "isLogin", false)) {
                    message.append("\nuserId = ")
                            .append((String) SPUtil.get(App.mContext, "userId", ""))
                            .append("\nuId = ")
                            .append((String) SPUtil.get(App.mContext, "uId", ""))
                            .append("\nchkMobile = ")
                            .append((String) SPUtil.get(App.mContext, "chkMobile", ""));
                }
                if (downloadInfo != null) {
                    if (downloadInfo.getData() != null) {
                        message.append("\n游戏信息：")
                                .append(downloadInfo.getData().toString());
                    }
                    message
                            .append("\nAPP游戏下载地址：")
                            .append(downloadInfo.getUrl());
                }
                message
                        .append("\n错误信息：")
                        .append(errorMsg);
                AppException exception = new AppException("异常--->", message.toString());
                Bugtags.sendException(exception);
            }
        });
    }

    /**
     * 配置okgo
     */
    private void configOkGo() {
        //以下设置的所有参数是全局参数,同样的参数可以在请求的时候再设置一遍,那么对于该请求来讲,请求中的参数会覆盖全局参数
        //好处是全局参数统一,特定请求可以特别定制参数
        try {
            //以下都不是必须的，根据需要自行选择,一般来说只需要 debug,缓存相关,cookie相关的 就可以了
            OkGo.getInstance()

                    // 打开该调试开关,打印级别INFO,并不是异常,是为了显眼,不需要就不要加入该行
                    // 最后的true表示是否打印okgo的内部异常，一般打开方便调试错误
                    //  .debug("uu393", Level.INFO, DevConfig.DEBUG)

                    .setConnectTimeout(DEFAULT_TIMEOUT)  //全局的连接超时时间
                    .setReadTimeOut(DEFAULT_TIMEOUT)     //全局的读取超时时间
                    .setWriteTimeOut(DEFAULT_TIMEOUT)    //全局的写入超时时间

                    //可以全局统一设置缓存模式,默认是不使用缓存,可以不传,具体其他模式看 github 介绍 https://github.com/jeasonlzy/
                    .setCacheMode(CacheMode.NO_CACHE)

                    //可以全局统一设置缓存时间,默认永不过期,具体使用方法看 github 介绍
                    .setCacheTime(CacheEntity.CACHE_NEVER_EXPIRE)

                    //可以全局统一设置超时重连次数,默认为三次,那么最差的情况会请求4次(一次原始请求,三次重连请求),不需要可以设置为0
                    .setRetryCount(1);

            //如果不想让框架管理cookie（或者叫session的保持）,以下不需要
            //.setCookieStore(new MemoryCookieStore())            //cookie使用内存缓存（app退出后，cookie消失）
            //.setCookieStore(new PersistentCookieStore())        //cookie持久化存储，如果cookie不过期，则一直有效

            //可以设置https的证书,以下几种方案根据需要自己设置
            //.setCertificates()                                  //方法一：信任所有证书,不安全有风险
            //.setCertificates(new SafeTrustManager())            //方法二：自定义信任规则，校验服务端证书
            //.setCertificates(getAssets().open("srca.cer"))      //方法三：使用预埋证书，校验服务端证书（自签名证书）
            // 方法四：使用bks证书和密码管理客户端证书（双向认证），使用预埋证书，校验服务端证书（自签名证书）
            //.setCertificates(getAssets().open("xxx.bks"), "123456", getAssets().open("yyy.cer"))//

            //配置https的域名匹配规则，详细看demo的初始化介绍，不需要就不要加入，使用不当会导致https握手失败
            //.setHostnameVerifier(new SafeHostnameVerifier())

            //可以添加全局拦截器，不需要就不要加入，错误写法直接导致任何回调不执行
            //                .addInterceptor(new Interceptor() {
            //                    @Override
            //                    public Response intercept(Chain chain) throws IOException {
            //                        return chain.proceed(chain.request());
            //                    }
            //                })

            //这两行同上，不需要就不要加入
            //.addCommonHeaders(headers)  //设置全局公共头
            //.addCommonParams(params);   //设置全局公共参数
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
//        进程结束时回调
    }

    private void initGlide() {
        //设置网络访问方式
        //**Glide默认使用HttpUrlConnection访问网络，可以设置为OkHttp或者Volley**
        //**顺便一提Picasso默认的也是HttpUrlConnection访问网络**

        Glide.get(this)//get()方法返回的是Glide的对象
                .register(GlideUrl.class, InputStream.class,
                        new OkHttpUrlLoader.Factory(new OkHttpClient()));//参数中传入一个okhttpclient对象
        //注册网络加载器
        //OkHttpUrlLoader类，这里要导集成Okhttp的glide包：compile 'com.github.bumptech.glide:okhttp-integration:1.4.0'

        //获取Glide默认缓存位置
        File photoCacheDir = Glide.getPhotoCacheDir(this);
        L.d("", "-->>Glide默认缓存位置：" + photoCacheDir.getAbsolutePath());

        //获取默认分配的磁盘缓存空间的大小
        MemorySizeCalculator calculator = new MemorySizeCalculator(this);
        int defaultMemoryCacheSize = calculator.getMemoryCacheSize();
        int defaultBitmapPoolSize = calculator.getBitmapPoolSize();
        L.d("-->>defaultMemoryCacheSize: " + defaultMemoryCacheSize);
        L.d("-->>defaultBitmapPoolSize: " + defaultBitmapPoolSize);
    }

//    private void initLeakCanary() {
//        if (LeakCanary.isInAnalyzerProcess(this)) {
//            return;
//        }
//        refWatcher = LeakCanary.install(this);
//    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);//分包
    }

    public static class AppException extends Exception {
        public String code;
        public String message;

        public AppException(String code, String message) {
            this.code = code;
            this.message = message;
        }

        @Override
        public String getMessage() {
            return message;
        }

        public String getCode() {
            return code;
        }
    }
}
