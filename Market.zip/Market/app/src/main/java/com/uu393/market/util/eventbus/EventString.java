package com.uu393.market.util.eventbus;

/**
 * Created by zhangbo on 2016/6/27.
 */
public class EventString extends BaseEvent{

    public String result;

    public EventString(int t, String r) {
        tag = t;
        result = r;
    }
}
