package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    :
 * =====================================================
 */

public class GGetWalletFundRecord {
    /**
     *  {
     "type":"-1",（-1全部   0充值   1提现   3收入   30支出）
     }
     */

    private String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
