package com.uu898app.third.umeng;

import android.app.Activity;
import android.graphics.BitmapFactory;

import com.umeng.socialize.PlatformConfig;
import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMAuthListener;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.UMImage;
import com.umeng.socialize.utils.Log;
import com.uu898app.R;
import com.uu898app.util.ToastUtil;

import java.util.Map;

/**
 * Created by zhangbo on 2016/6/27.
 */
public class UUUmeng {

    private static final String SHARE_TITLE = "UU898";
    private static final String SHARE_URL = "http://www.uu898.com/m/";
    private static final String SHARE_CONTENT = "uu898提供安全方便的话费、QQ币、QQ会员、网游点卡、游戏币、游戏装备、道具等手机购物服务，" +
            "您可以随时随地的浏览商品、查看订单、充值支付、上架下架货品等。http://www.uu898.com/m/";

    final SHARE_MEDIA[] DISPLAYLIST = new SHARE_MEDIA[]{
            SHARE_MEDIA.WEIXIN,
            SHARE_MEDIA.WEIXIN_CIRCLE,
            SHARE_MEDIA.SINA,
            SHARE_MEDIA.QQ,
            SHARE_MEDIA.QZONE,
            SHARE_MEDIA.DOUBAN
    };

    private static UUUmeng mUmeng;
    private Activity mActivity;
    private UMShareAPI mShareAPI;

    private UUUmeng(Activity activity) {
        mActivity = activity;
        mShareAPI = UMShareAPI.get(activity);
    }

    public static UUUmeng getInstance(Activity activity) {
        if (null == mUmeng) {
            mUmeng = new UUUmeng(activity);
        }
        return mUmeng;
    }

    public static void init(boolean debug) {
        Log.LOG = debug;
        PlatformConfig.setWeixin("wx564016c8e10fc067", "c2a6308fcf0952887fd6b1ee0fa3c86d");
        PlatformConfig.setQQZone("1102096350", "Q0vMNxWPLjvrM2rX");
        PlatformConfig.setSinaWeibo("3389906699", "554f9e812e220f791a369537f6dadfea");
    }

    /**
     * title参数对新浪、人人、豆瓣不生效
     */
    public void startShare() {
        UMImage image = new UMImage(mActivity,
                BitmapFactory.decodeResource(mActivity.getResources(), R.drawable.ic_launcher));
        new ShareAction(mActivity)
                .setDisplayList(DISPLAYLIST)
                .withText(SHARE_CONTENT)
                .withTitle(SHARE_TITLE)
                .withTargetUrl(SHARE_URL)
                .withMedia( image )
                .setListenerList(shareListener)

                .open();

    }

    UMShareListener shareListener = new UMShareListener() {
        @Override
        public void onResult(SHARE_MEDIA platform) {
            ToastUtil.showToast(mActivity, "分享成功啦");
        }

        @Override
        public void onError(SHARE_MEDIA platform, Throwable t) {
            ToastUtil.showToast(mActivity, "分享失败 \n " + t.getMessage());
        }

        @Override
        public void onCancel(SHARE_MEDIA platform) {
            ToastUtil.showToast(mActivity, "分享取消");
        }
    };


    /**
     * 新浪授权
     */
    public void sinaOauth(){
        mShareAPI.doOauthVerify(mActivity, SHARE_MEDIA.SINA, doAuthListener);
    }

    public void sinaOauthClear(){
        mShareAPI.deleteOauth(mActivity, SHARE_MEDIA.SINA, clearAuthListener);
    }

    public void sinaOauthInfo(){
        mShareAPI.getPlatformInfo(mActivity, SHARE_MEDIA.SINA, getInfoListener);
    }


    /**
     * QQ授权
     */
    public void qqOauth(){
        mShareAPI.doOauthVerify(mActivity, SHARE_MEDIA.QQ, doAuthListener);
    }

    public void qqOauthClear(){
        mShareAPI.deleteOauth(mActivity, SHARE_MEDIA.QQ, clearAuthListener);
    }

    public void qqOauthInfo(){
        mShareAPI.getPlatformInfo(mActivity, SHARE_MEDIA.QQ, getInfoListener);
    }

    private UMAuthListener doAuthListener = new UMAuthListener() {
        @Override
        public void onComplete(SHARE_MEDIA platform, int action, Map<String, String> data) {
            ToastUtil.showToast(mActivity,"授权成功");
        }

        @Override
        public void onError(SHARE_MEDIA platform, int action, Throwable t) {
            ToastUtil.showToast(mActivity,"授权失败 \n " + t.getMessage());
        }

        @Override
        public void onCancel(SHARE_MEDIA platform, int action) {
            ToastUtil.showToast(mActivity,"授权cancle");
        }
    };

    private UMAuthListener clearAuthListener = new UMAuthListener() {
        @Override
        public void onComplete(SHARE_MEDIA platform, int action, Map<String, String> data) {
            ToastUtil.showToast(mActivity,"取消授权成功");
        }

        @Override
        public void onError(SHARE_MEDIA platform, int action, Throwable t) {
            ToastUtil.showToast(mActivity,"取消授权失败 \n " + t.getMessage());
        }

        @Override
        public void onCancel(SHARE_MEDIA platform, int action) {
            ToastUtil.showToast(mActivity,"取消授权cancle");
        }
    };

    private UMAuthListener getInfoListener = new UMAuthListener() {
        @Override
        public void onComplete(SHARE_MEDIA platform, int action, Map<String, String> data) {
            ToastUtil.showToast(mActivity,"获取info成功 \n " + data.toString());
        }

        @Override
        public void onError(SHARE_MEDIA platform, int action, Throwable t) {
            ToastUtil.showToast(mActivity,"获取info \n " + t.getMessage());
        }

        @Override
        public void onCancel(SHARE_MEDIA platform, int action) {
            ToastUtil.showToast(mActivity,"获取info cancle");
        }
    };

}
