package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/16
 * Descrip    :
 * =====================================================
 */

public class BUserToken implements Serializable{

    /**
     * token : 98A6F5470454F0DB5619AC50808ACAA8
     */

    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
