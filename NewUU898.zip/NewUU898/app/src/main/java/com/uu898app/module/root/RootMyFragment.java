package com.uu898app.module.root;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uu898app.R;
import com.uu898app.module.account.LoginFragment;
import com.uu898app.module.account.MyFragment;
import com.uu898app.module.base.BaseLazyFragment;
import com.uu898app.module.helper.AccountManager;
import com.uu898app.util.eventbus.EB;
import com.uu898app.util.eventbus.EventEmpty;
import com.uu898app.util.log.L;

import org.greenrobot.eventbus.Subscribe;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class RootMyFragment extends BaseLazyFragment {

    public static RootMyFragment newInstance() {
        Bundle args = new Bundle();
        RootMyFragment fragment = new RootMyFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.root_fragment, container, false);
    }

    @Override
    protected void initLazyView(@Nullable Bundle savedInstanceState) {
        L.d("MyRootFragment.initLazyView");
        if (null == savedInstanceState) {
            if (AccountManager.getInstance().getStatus() == AccountManager.Status.LOGIN) {
                loadRootFragment(R.id.fl_container, MyFragment.newInstance());
            } else {
                loadRootFragment(R.id.fl_container, LoginFragment.newInstance());
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        EB.register(this);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        EB.unregister(this);
    }

    @Subscribe
    public void onEvent(EventEmpty event) {
        switch (event.tag) {
            case EB.TAG.LOGIN_SUCCESS:
                //接受登陆成功event，登陆成功后加载登陆后页面
                replaceLoadRootFragment(R.id.fl_container, MyFragment.newInstance(), false);
                break;
            case EB.TAG.LOGOUT_SUCCESS://取消登陆
                replaceLoadRootFragment(R.id.fl_container, LoginFragment.newInstance(), false);
                break;
            default:
                break;
        }
    }
}
