package com.uu393.market.module.center.slider;

/**
 * Created by zhan on 2017/2/6.
 */

public interface ISlide {

   void slideOpen();
   void slideClose();
}
