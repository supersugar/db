package com.uu898.gamesdk.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.uu898.gamesdk.R;
import com.uu898.gamesdk.core.ResourceUtils;
import com.uu898.gamesdk.model.request.GAddSubAccount;
import com.uu898.gamesdk.utils.ToastUtil;

/**
 * 添加小号界面
 */
public class UserSubAccountAddFragment extends BaseFragment {

    private EditText mName;

    public static UserSubAccountAddFragment newInstance() {
        Bundle args = new Bundle();
        UserSubAccountAddFragment fragment = new UserSubAccountAddFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        View view = inflater.inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_sub_account_add"), container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "添加小号");

        mName = (EditText) view.findViewById(R.id.name);

        view.findViewById(getId("ug_bt_add")).setOnClickListener(new View.OnClickListener() {
            @Override
           public void onClick(View v) {
                GAddSubAccount model = new GAddSubAccount();
//                model.name =
                ToastUtil.showToast(_mActivity, "立即添加");
            }
        });

    }

}
