package com.uu661.model.request;

public class GLogin {

    public String userId;//
    public String password;//
    public String clientIP;//

}
