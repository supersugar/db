package com.uu393.market.module.home;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uu393.market.R;
import com.uu393.market.model.PageModel;
import com.uu393.market.model.request.GGetServerListByGameId;
import com.uu393.market.model.response.BGame;
import com.uu393.market.model.response.BServerListInGameDetail;
import com.uu393.market.module.base.BaseViewPagerFragment;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import okhttp3.Call;
import okhttp3.Response;


public class OpenServiceFragment extends BaseViewPagerFragment {


    @Bind(R.id.rv_open_service)
    PullLoadMoreRecyclerView rvOpenService;
    private String mGameId;
    private int mPageIndex = 1;

    private ArrayList<BServerListInGameDetail> mGameList;


    OpenServiceRecyclerAdapter adapter;

    public OpenServiceFragment() {
    }


    public static OpenServiceFragment newInstance(String param1) {
        OpenServiceFragment fragment = new OpenServiceFragment();
        Bundle args = new Bundle();
        args.putString("gameId", param1);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mGameId = getArguments().getString("gameId");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        mGameList = new ArrayList<>();
        View view = inflater.inflate(R.layout.fragment_open_service, container, false);
        ButterKnife.bind(this, view);
        rvOpenService.setGridLayout(2);
        adapter = new OpenServiceRecyclerAdapter(_mActivity);
        rvOpenService.setAdapter(adapter);

        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initRecyclerView();
    }

    private void initRecyclerView() {
        rvOpenService.setRefreshing(false);

        doGetServerListByGameId(false);
        rvOpenService.setOnPullLoadMoreListener(new PullLoadMoreRecyclerView.PullLoadMoreListener() {
            @Override
            public void onRefresh() {
                doGetServerListByGameId(false);
            }
            @Override
            public void onLoadMore() {
                doGetServerListByGameId(true);
            }
        });

    }

    @Override
    public void onResume() {
        super.onResume();
        adapter.refresh();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }

    @Override
    public void refresh() {

    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);

    }

    public void doGetServerListByGameId(final boolean loadMore) {
        GGetServerListByGameId model = new GGetServerListByGameId(mGameId);
        if (loadMore){
            mPageIndex = 1;
        }
        PageModel page = new PageModel(mPageIndex);
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetServerListByGameId(model, page, new JsonCallback<List<BServerListInGameDetail>>() {
            @Override
            public void onSuccess(List<BServerListInGameDetail> bGames, Call call, Response response) {
                if (null == bGames || bGames.isEmpty()) {
                    //无返回结果,需要根据当前页码判断是无结果,还是无更多
                    if (mPageIndex == 1) {
                        changeView(false);
                    } else {
                        ToastUtil.showToast(_mActivity, "没有更多了~");
                    }
                } else {
                    changeView(true);
                    mPageIndex++;
                    if (loadMore == false) {//非增量加载
                        mGameList.clear();
                    }
                    mGameList.addAll(bGames);
                }
            }

            @Override
            public void onAfter(List<BServerListInGameDetail> bGames, Exception e) {
                super.onAfter(bGames, e);
                rvOpenService.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        adapter.updateData(mGameList);
                        rvOpenService.setPullLoadMoreCompleted();
                    }
                }, 100);
            }
        });
    }

    private void changeView(boolean hasData) {
//        rvOpenService.setVisibility(hasData ? View.VISIBLE : View.GONE);
//        rvOpenService.setVisibility(hasData ? View.GONE : View.VISIBLE);
    }

}
