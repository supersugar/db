package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/26
 * Description    : 参加分享赚bean
 * 注意：如果用户本来已经绑定手机号，则不传手机号和验证码，
 * 如果用户本来没有绑定手机，则传手机号和验证码
 * =====================================================
 */

public class GDoJoinShareEarn {
    /**
     {
     "phoneNo":"155555555",（手机号码）
     "code":"adfdsfd",（手机验证码）
     "ip":"192.168.5.52",（ip地址）
     }
     */

    private String phoneNo;
    private String code;
    private String ip;

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }
}
