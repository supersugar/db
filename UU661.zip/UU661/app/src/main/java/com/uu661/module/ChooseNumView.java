package com.uu661.module;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.flipboard.bottomsheet.BottomSheetLayout;
import com.github.florent37.viewanimator.ViewAnimator;
import com.lzy.okgo.request.BaseRequest;
import com.uu661.R;
import com.uu661.model.request.GCreateUUOrder;
import com.uu661.model.request.GGetDiamondInfo;
import com.uu661.model.response.BDiamond;
import com.uu661.model.response.BDiamondInfo;
import com.uu661.model.response.BUUOrder;
import com.uu661.module.common.PayActivity;
import com.uu661.network.JsonCallback;
import com.uu661.network.TaskEngine;
import com.uu661.util.LoadingUtil;
import com.uu661.util.NoDoubleClickUtils;
import com.uu661.util.StringUtils;
import com.uu661.util.ToastUtil;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;


/**
 * Created by bo on 17/1/20.
 */

public class ChooseNumView extends FrameLayout {


    @BindView(R.id.choose_bt_reduce) ImageButton mChooseBtReduce;
    @BindView(R.id.choose_bt_add) ImageButton mChooseBtAdd;
    @BindView(R.id.choose_tv_num) TextView mChooseTvNum;
    @BindView(R.id.choose_bt_one) Button mChooseBtOne;
    @BindView(R.id.choose_bt_two) Button mChooseBtTwo;
    @BindView(R.id.choose_bt_three) Button mChooseBtThree;
    @BindView(R.id.choose_bt_four) Button mChooseBtFour;
    @BindView(R.id.choose_view_four_bt) LinearLayout mChooseViewFourBt;
    @BindView(R.id.choose_tv_money) TextView mChooseTvMoney;
    @BindView(R.id.choose_bt_submit) Button mChooseBtSubmit;
    @BindView(R.id.info_bottom_view_can_buy) RelativeLayout mInfoBottomViewCanBuy;
    @BindView(R.id.choose_tv_explain) TextView mChooseTvExplain;
    @BindView(R.id.img_close) ImageView mImgClose;
    @BindView(R.id.choose_can_edit_view) RelativeLayout mChooseCanEditView;
    @BindView(R.id.choose_tv_num_can_not_edit) TextView mChooseTvNumCanNotEdit;
    @BindView(R.id.choose_can_not_edit_view) RelativeLayout mChooseCanNotEditView;
    @BindView(R.id.pay_support_tv_title) TextView mPaySupportTvTitle;

    //先inflat布局
    //设置数据
    //触发输入框dialog
    //callback返回结果
    private Context mContext;
    private View mView;
    private BottomSheetLayout mBottomSheetLayout;
    private BDiamondInfo mDiamondInfo;
    private BDiamond mDiamond;

    private int mCurrentCount = 1;//当前选择数量/人次
    private int mCanBuyMaxCount = -1;//可买最大数量
    private OnChooseDoneListener mListener;

    public interface OnChooseDoneListener {
        void onChooseDone(int num);

        void showOrHideSoftInput(boolean show, View v);
    }

    public ChooseNumView(Context context, @Nullable BottomSheetLayout root) {
        this(context, null, root);
    }

    public ChooseNumView(Context context, AttributeSet attrs, @Nullable BottomSheetLayout root) {
        this(context, attrs, 0, root);
    }

    public ChooseNumView(Context context, AttributeSet attrs, int defStyleAttr, @Nullable BottomSheetLayout root) {
        super(context, attrs, defStyleAttr);
        init(context, root);
    }

    private void init(Context context, BottomSheetLayout root) {
        this.mContext = context;
        this.mBottomSheetLayout = root;
        mView = LayoutInflater.from(context).inflate(R.layout.choose_diamond_num, root, false);
        ButterKnife.bind(this, mView);//用butterKnife绑定

        addView(mView, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    public void updateData(BDiamondInfo data) {
        this.mDiamondInfo = data;
        this.mDiamond = data.getCommodityInfo();
        refreshView();
    }

    public void setOnChooseDoneListener(OnChooseDoneListener listener) {
        mListener = listener;
    }

    public OnChooseDoneListener getOnChooseDoneListener() {
        return mListener;
    }

    /**
     * 业务逻辑相关
     * totalCount : 2 //总需人次   5(1-4)   多人()
     * alreadySold : 0 //以买人次
     * leftCount : 2 // 剩余次数   =2
     */
    private void refreshView() {
        //默认选择数量为1
        setNumAndMoney(1);
        if (mDiamond.getTotalCount() == 2) {
            mChooseCanEditView.setVisibility(View.GONE);
            mChooseCanNotEditView.setVisibility(View.VISIBLE);
            //            mPaySupportTvTitle.setText("【两人夺钻】开奖速度快，中奖概率极高");
            mPaySupportTvTitle.setText(Html.fromHtml("<font color='#0fabff'>【两人夺钻】</font>" + "<font color='#fc5669'>开奖速度快，中奖概率极高</font>"));
        } else {
            mChooseCanEditView.setVisibility(View.VISIBLE);
            mChooseCanNotEditView.setVisibility(View.GONE);
            mPaySupportTvTitle.setText("购买多人次，夺钻成功率更高");
        }
        //先计算出当前可以买的最大数量
        if (mDiamondInfo.getMyCodeCount() >= 0) {//MyCodeCount默认值为-1
            //如果 等于 0,说明没买过,要看其他人有没有买过
            // (totalCount 是否等于 leftCount)
            //如果等于     说明其他人没买过,当前能买的最大数量为leftCount - 1
            //如果不等于   说明其他人买过,当前能买的最大数量为leftCount
            if (mDiamondInfo.getMyCodeCount() == 0) {
                if (mDiamond.getTotalCount() == mDiamond.getLeftCount()) {
                    mCanBuyMaxCount = mDiamond.getLeftCount() - 1;
                } else {
                    mCanBuyMaxCount = mDiamond.getLeftCount();
                }
            } else {
                //如果 不等于 0,说明买过,要看看其他人有没有买过
                // (totalCount - leftCount 是否等于 MyCodeCount)
                //如果等于,说明其他人没买过,当前能买的最大数量为leftCount - 1
                //如果不等于,说明其他人买过,当前能买的最大数量为leftCount
                if (mDiamond.getTotalCount() - mDiamond.getLeftCount() == mDiamondInfo.getMyCodeCount()) {
                    mCanBuyMaxCount = mDiamond.getLeftCount() - 1;
                } else {
                    mCanBuyMaxCount = mDiamond.getLeftCount();
                }
            }

        } else {
            mCanBuyMaxCount = mDiamond.getLeftCount();
        }

        if (mDiamond.getTotalCount() > 5) {
            //总需人数>5,根据数量判断怎么显示按钮
            mChooseViewFourBt.setVisibility(View.VISIBLE);
            if (mCanBuyMaxCount < 5) {
                mChooseViewFourBt.setVisibility(View.GONE);
            } else if (mCanBuyMaxCount >= 5 && mCanBuyMaxCount < 10) {
                mChooseBtOne.setVisibility(View.VISIBLE);
                mChooseBtTwo.setVisibility(View.INVISIBLE);
                mChooseBtThree.setVisibility(View.INVISIBLE);
                mChooseBtFour.setVisibility(View.INVISIBLE);
            } else if (mCanBuyMaxCount >= 10 && mCanBuyMaxCount < 20) {
                mChooseBtOne.setVisibility(View.VISIBLE);
                mChooseBtTwo.setVisibility(View.VISIBLE);
                mChooseBtThree.setVisibility(View.INVISIBLE);
                mChooseBtFour.setVisibility(View.INVISIBLE);
            } else if (mCanBuyMaxCount >= 20 && mCanBuyMaxCount < 50) {
                mChooseBtOne.setVisibility(View.VISIBLE);
                mChooseBtTwo.setVisibility(View.VISIBLE);
                mChooseBtThree.setVisibility(View.VISIBLE);
                mChooseBtFour.setVisibility(View.INVISIBLE);
            } else if (mCanBuyMaxCount >= 50) {
                mChooseBtOne.setVisibility(View.VISIBLE);
                mChooseBtTwo.setVisibility(View.VISIBLE);
                mChooseBtThree.setVisibility(View.VISIBLE);
                mChooseBtFour.setVisibility(View.VISIBLE);
            }
        } else {
            //总需人数<=5,不显示4个按钮
            mChooseViewFourBt.setVisibility(View.GONE);
        }

        //设置说明textview
        mChooseTvExplain.setText(mDiamond.getUnitPrice() + "元/人次");
        if (mCanBuyMaxCount == 0) {
            ToastUtil.showToast(mContext, "您已经购买过本期商品 请等待揭晓后再次购买");
        } else {
            mBottomSheetLayout.showWithSheetView(this);
        }
    }

    /**
     * 设置要买的总人次,并且计算价格
     *
     * @param num
     */
    private void setNumAndMoney(int num) {
        mCurrentCount = num;
        mChooseTvNum.setText(String.valueOf(mCurrentCount));//设置数量
        ViewAnimator.animate(mChooseTvNum).scale(1f, 2f, 1f).accelerate().duration(200).start();
        int money = mCurrentCount * mDiamond.getUnitPrice();
        mChooseTvMoney.setText(Html.fromHtml("共 <font color='#fc5669'> " + String.valueOf(money) + " </font> 元"));
    }

    /**
     * 减少一个
     * 如果当前数量为1,则不予执行
     * 如果当前数量大于1,则修改当前数量 -1
     */
    private void doReduceOne() {
        if (mCurrentCount <= 1) {
            ToastUtil.showToast(mContext, "至少需要购买1人次");
            return;
        }
        int temp = mCurrentCount - 1;
        setNumAndMoney(temp);
    }

    /**
     * 增加1个
     * 如果当前的数量>最大可买数量,则不执行
     * 如果当前的数量<= 最大可买数量,则 +1
     */
    private void doAddOne() {
        if (mCurrentCount >= mCanBuyMaxCount) {
            ToastUtil.showToast(mContext, "购买人次已达到最大值");
            return;
        }
        int temp = mCurrentCount + 1;
        setNumAndMoney(temp);
    }

    @OnClick({R.id.img_close, R.id.choose_bt_reduce, R.id.choose_bt_add, R.id.choose_tv_num, R.id.choose_bt_one, R.id.choose_bt_two, R.id
            .choose_bt_three, R.id.choose_bt_four, R.id.choose_bt_submit})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.img_close:
                if (mBottomSheetLayout.isSheetShowing()) {
                    mBottomSheetLayout.dismissSheet();
                }
                break;
            case R.id.choose_bt_reduce:
                doReduceOne();
                break;
            case R.id.choose_bt_add:
                doAddOne();
                break;
            case R.id.choose_tv_num:
                //弹出dialog
                showOrHideSoftInput(true, showCustomView());
                break;
            case R.id.choose_bt_one:
                setNumAndMoney(5);
                break;
            case R.id.choose_bt_two:
                setNumAndMoney(10);
                break;
            case R.id.choose_bt_three:
                setNumAndMoney(20);
                break;
            case R.id.choose_bt_four:
                setNumAndMoney(50);
                break;
            case R.id.choose_bt_submit://提交
                if (NoDoubleClickUtils.isDoubleClick()) {
                    return;
                }
                if (null != mListener) {
                    mListener.onChooseDone(mCurrentCount);
                }

                //再请求一次该商品剩余人次是否>=提交的人次
                TaskEngine.getInstance().doGetDiamondInfo(new GGetDiamondInfo(mDiamond.getId(), 0), new JsonCallback<BDiamondInfo>() {

                    @Override
                    public void onBefore(BaseRequest request) {
                        super.onBefore(request);
                        LoadingUtil.showLoading((Activity) mContext);
                    }

                    @Override
                    public void onSuccess(BDiamondInfo result, Call call, Response response) {
                        mDiamond = result.getCommodityInfo();
                        if (mDiamond.getLeftCount() < mCurrentCount) {//剩余的不够了
                            updateData(result);
                            ToastUtil.showToast(mContext, "剩余人次不足，请重新选择");
                            LoadingUtil.hideLoading((Activity) mContext);
                        } else {
                            doCreateUUOrder();
                        }
                    }
                });

                break;
        }
    }

    private void doCreateUUOrder() {
        GCreateUUOrder model = new GCreateUUOrder();
        model.buyNum = mCurrentCount;
        model.commodityId = mDiamond.getId();
        TaskEngine.getInstance().doCreateUUOrder(model, new JsonCallback<BUUOrder>() {

            @Override
            public void onBefore(BaseRequest request) {
                super.onBefore(request);
                LoadingUtil.showLoading((Activity) mContext);
            }

            @Override
            public void onSuccess(final BUUOrder result, Call call, Response response) {
                //成功会返回订单号
                Intent intent = new Intent(mContext, PayActivity.class);
                intent.putExtra(PayActivity.INTENT_KEY_UU_ORDER, result);
                intent.putExtra(PayActivity.INTENT_KEY_DIAMOND, mDiamond);
                intent.putExtra(PayActivity.INTENT_KEY_BUY_NUM, mCurrentCount);
                mContext.startActivity(intent);
            }

            @Override
            public void onAfter(BUUOrder order, Exception e) {
                super.onAfter(order, e);
                mBottomSheetLayout.dismissSheet();
                LoadingUtil.hideLoading((Activity) mContext);
            }
        });
    }

    /**
     * 通过接口回调控制软键盘的展示/隐藏
     *
     * @param show
     * @param v
     */
    private void showOrHideSoftInput(boolean show, View v) {
        if (null != mListener) {
            mListener.showOrHideSoftInput(show, v);
        }
    }

    private ImageButton mChooseDialogBtReduce;
    private ImageButton mChooseDialogBtAdd;
    private EditText mChooseDialogEdtNum;

    /**
     * 弹出加减数量dialog
     * Edittext中要显示当前选择好的数量
     */
    public View showCustomView() {
        MaterialDialog dialog = new MaterialDialog.Builder(mContext).customView(R.layout.choose_diamond_num_dialog, true).positiveText
                ("确定").negativeText("取消").onPositive(new MaterialDialog.SingleButtonCallback() {
            @Override
            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                String temp = mChooseDialogEdtNum.getText().toString();
                if (StringUtils.isEmpty(temp)) {
                    ToastUtil.showToast(mContext, "请输入正确的数量");
                } else {
                    try {
                        setNumAndMoney(Integer.parseInt(temp));
                    } catch (NumberFormatException e) {
                        ToastUtil.showToast(mContext, "请输入正确的数量");
                    }
                }
            }
        }).build();

        mChooseDialogBtReduce = (ImageButton) dialog.getCustomView().findViewById(R.id.choose_dialog_bt_reduce);
        mChooseDialogBtAdd = (ImageButton) dialog.getCustomView().findViewById(R.id.choose_dialog_bt_add);
        mChooseDialogEdtNum = (EditText) dialog.getCustomView().findViewById(R.id.choose_dialog_edt_num);

        mChooseDialogEdtNum.setText(String.valueOf(mCurrentCount));
        mChooseDialogEdtNum.setSelection(String.valueOf(mCurrentCount).length());
        mChooseDialogEdtNum.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                //当输入框中的数量有变化时,需要检验,最终返回的是合法数量
                if (StringUtils.isEmpty(s.toString())) {
                    return;
                }
                int temp = Integer.parseInt(s.toString());
                if (temp < 1) {
                    ToastUtil.showToast(mContext, "至少需要购买1人次");
                    mChooseDialogEdtNum.setText(String.valueOf(1));
                } else if (temp > mCanBuyMaxCount) {
                    ToastUtil.showToast(mContext, "购买人次已达到最大值");
                    mChooseDialogEdtNum.setText(String.valueOf(mCanBuyMaxCount));
                }
                mChooseDialogEdtNum.setSelection(mChooseDialogEdtNum.getText().length());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mChooseDialogBtReduce.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                int temp = Integer.parseInt(mChooseDialogEdtNum.getText().toString());
                if (temp <= 1) {
                    return;
                } else {
                    mChooseDialogEdtNum.setText(String.valueOf(temp - 1));
                }
            }
        });

        mChooseDialogBtAdd.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                int temp = Integer.parseInt(mChooseDialogEdtNum.getText().toString());
                if (temp >= mCanBuyMaxCount) {
                    return;
                } else {
                    mChooseDialogEdtNum.setText(String.valueOf(temp + 1));
                }
            }
        });

        dialog.show();
        return mChooseDialogEdtNum;
    }

}
