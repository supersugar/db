package com.uu393.market.module.newgame;

import android.Manifest;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.R;
import com.uu393.market.model.PageModel;
import com.uu393.market.model.request.GGetGameList;
import com.uu393.market.model.response.BGame;
import com.uu393.market.model.response.BGameKind;
import com.uu393.market.model.response.BGameTheme;
import com.uu393.market.module.MainActivity;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.home.ApkListAdapter;
import com.uu393.market.module.home.AppGameSelectPopAdapter;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;

import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;
import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.EasyPermissions;

/**
 * Created by Administrator on 2017/4/20.
 */

public class NewGameActivity  extends BaseActivity implements View.OnClickListener,EasyPermissions.PermissionCallbacks{


    @Bind(R.id.title_bar_left)
    ImageButton titleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton titleBarRight;
    @Bind(R.id.title_bar_title)
    TextView titleBarTitle;
    @Bind(R.id.tab_layout_home_new)
    TabLayout mTabLayoutSelected;
    @Bind(R.id.tabs_recycleview)
    PullLoadMoreRecyclerView mRecyclerView;

    //去掉类型全部
    List<BGameKind> mGameKindsPop = new ArrayList<>();
    //游戏题材
    List<BGameKind> mGameThemes = new ArrayList<>();
    //智能排序
    List<BGameKind> mSort = new ArrayList<>();
    //游戏题材
    List<BGameKind> mGameKinds = new ArrayList<>();
    //记录每个Pop被点击的item
    HashMap<String, Integer> tabRVposion = new HashMap<>();
    //三个界面的pop数据源
    HashMap<String, List<BGameKind>> mPopData = new HashMap<>();
    //当前的popData;
    List<BGameKind> mNewPopData = new ArrayList<>();
    //保存刷选后的molde的参数
    HashMap<String, String> mMolde = new HashMap<>();

    private ApkListAdapter adapter;

    private int mPageIndex = 1;



    private Button mBtFirstVolume;
    private View mNoResultView;
    private TextView mDataStatus;

    private ArrayList<BGame> mGameList = new ArrayList<>();

    private String GameType = "1";
    private String GameTheme = "2";
    private String Intelligent = "3";


    //pop内部的xml
    RecyclerView mRvSelect;
    LinearLayout mRvNoData;
    Button mGetDataAgain;
    View inflate;


    private AppGameSelectPopAdapter selectPopAdapter;

    private String[] tabTitles = {"游戏类型", "游戏题材", "智能排序"};

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_btgame);
        ButterKnife.bind(this);
        titleBarTitle.setText("新游首发");
        titleBarRight.setVisibility(View.GONE);

        mDataStatus = (TextView)findViewById(R.id.tv_no_result_hint_text);
        mNoResultView = findViewById(R.id.no_result_view2);
        mNoResultView.setVisibility(View.GONE);
        mBtFirstVolume = (Button) findViewById(R.id.bt_no_result);
        adapter = new ApkListAdapter(NewGameActivity.this);

        selectPopAdapter = new AppGameSelectPopAdapter(this);
        inflate = LayoutInflater.from(this).inflate(R.layout.home_select_popup, null, false);
        mRvSelect = (RecyclerView) inflate.findViewById(R.id.rv_home_select_popup);
        mRvNoData = (LinearLayout) inflate.findViewById(R.id.no_result_view);
        mGetDataAgain = (Button) inflate.findViewById(R.id.bt_no_resultpop);

        mPopData.put(GameType, mGameKindsPop);
        mPopData.put(GameTheme, mGameKindsPop);
        mPopData.put(Intelligent, mGameKindsPop);

        tabRVposion.put(GameType, -1);
        tabRVposion.put(GameTheme, -1);
        tabRVposion.put(Intelligent, -1);

        mMolde.put(GameType,"-1");
        mMolde.put(GameTheme,"-1");
        mMolde.put(Intelligent,"-1");

        mRecyclerView.setLinearLayout();
        adapter = new ApkListAdapter(NewGameActivity.this);
        mRecyclerView.setAdapter(adapter);

        mRecyclerView.setRefreshing(true);

        mRecyclerView.setOnPullLoadMoreListener(new PullLoadMoreRecyclerView.PullLoadMoreListener() {
            @Override
            public void onRefresh() {
                doGetGameList(false);
            }

            @Override
            public void onLoadMore() {
                doGetGameList(true);
            }
        });

        mGetDataAgain.setOnClickListener(this);
        mBtFirstVolume.setOnClickListener(this);
        initTabLayoutSelect();
        doGetGameThemes();
    }

    @Override
    protected void onResume() {
        super.onResume();
        EB.register(this);
        adapter.setrefresh();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EB.unregister(this);
    }

    private View getTabItem(String title) {
        View tab_item = LayoutInflater.from(NewGameActivity.this).inflate(R.layout.item_tab_tablayout, null, false);
        TextView tabTitle = (TextView) tab_item.findViewById(R.id.tv_tab_title);
        tabTitle.setText(title);
        return tab_item;
    }

    private void initTabLayoutSelect() {
        TabLayout.Tab tab1 = mTabLayoutSelected.newTab();
        tab1.setText("新游首发");
        mTabLayoutSelected.addTab(tab1);

        for (int i = 0; i < tabTitles.length; i++) {
            TabLayout.Tab tab2 = mTabLayoutSelected.newTab();
            tab2.setCustomView(getTabItem(tabTitles[i]));
            mTabLayoutSelected.addTab(tab2);
        }


        mTabLayoutSelected.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getCustomView() != null) {
                    View customView = tab.getCustomView();
                    TextView title = (TextView) customView.findViewById(R.id.tv_tab_title);
                    title.setTextColor(getResources().getColor(R.color.blue));
                    showSelectPopup(mTabLayoutSelected, title, tab.getPosition() + "");
                }
                if(tab.getPosition() == 0){
                    mMolde.put(GameType,"-1");
                    mMolde.put(GameTheme,"-1");
                    mMolde.put(Intelligent,"-1");
                    doGetGameList(false);
                }

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                if (tab.getCustomView() != null) {
                    View customView = tab.getCustomView();
                    TextView title = (TextView) customView.findViewById(R.id.tv_tab_title);
                    title.setTextColor(getResources().getColor(R.color.grey_666));
                }
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                if (tab.getCustomView() != null) {
                    View customView = tab.getCustomView();
                    TextView title = (TextView) customView.findViewById(R.id.tv_tab_title);
                    title.setTextColor(getResources().getColor(R.color.blue));
                    showSelectPopup(mTabLayoutSelected, title, tab.getPosition() + "");
                }
                if(tab.getPosition() == 0){
                    mMolde.put(GameType,"-1");
                    mMolde.put(GameTheme,"-1");
                    mMolde.put(Intelligent,"-1");
                    doGetGameList(false);
                }

            }
        });
    }

    private void showSelectPopup(View show, final TextView change, final String tabPosition) {

        final PopupWindow popupWindow = new PopupWindow(inflate, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popupWindow.setAnimationStyle(android.R.style.Animation_InputMethod);

        mRvSelect.setLayoutManager(new GridLayoutManager(this, 4, LinearLayoutManager.VERTICAL, false));
        selectPopAdapter.setPosition(tabRVposion.get(tabPosition));
        mNewPopData = mPopData.get(tabPosition);

        if (mNewPopData.isEmpty()) {
            mRvNoData.setVisibility(View.VISIBLE);
            mRvSelect.setVisibility(View.GONE);
            mGetDataAgain.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    doGetGameThemes();
                    popupWindow.dismiss();
                }
            });
        }

        selectPopAdapter.setData(mNewPopData);
        mRvSelect.setAdapter(selectPopAdapter);//todo 修改弹出框单项界面
        popupWindow.showAsDropDown(show);
        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {

            }
        });
        selectPopAdapter.setOnSelectedListener(new AppGameSelectPopAdapter.OnSelectedListener() {
            @Override
            public void onItemSelectedListener(BGameKind mBGameKind, int position) {
                change.setText(mBGameKind.typeName);
                change.setTextColor(getResources().getColor(R.color.blue));
                mNewPopData.get(position);
                mMolde.put(tabPosition, mNewPopData.get(position).id);
                tabRVposion.put(tabPosition, position);
                doGetGameList(false);
                popupWindow.dismiss();
            }
        });
    }

    private void doGetGameThemes(){
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetGameThemes(new JsonCallback<List<BGameTheme>>() {
            @Override
            public void onSuccess(List<BGameTheme> bGameThemes, Call call, Response response) {
                mGameThemes.clear();

                if(bGameThemes != null && !bGameThemes.isEmpty()){
                    if(null == bGameThemes || bGameThemes.isEmpty()){
                        ToastUtil.showToast(NewGameActivity.this,"获取游戏类别失败");
                        return;
                    }

                    //数据类型转换
                    for (int i =0; i<bGameThemes.size();i++){
                        BGameKind bGameKind = new BGameKind();
                        bGameKind.typeName = bGameThemes.get(i).getThemeName();
                        bGameKind.id = bGameThemes.get(i).getId();
                        mGameThemes.add(bGameKind);
                    }
                    mPopData.put(GameTheme, mGameThemes);


                }

            }

            @Override
            public void onAfter(List<BGameTheme> bGameKinds, Exception e) {
                super.onAfter(bGameKinds, e);
                doGetGameKinds();
            }
        });
    }


    private void doGetGameKinds() {

        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetGameKinds(new JsonCallback<List<BGameKind>>() {
            @Override
            public void onSuccess(List<BGameKind> gameKinds, Call call, Response response) {
                mGameKinds.clear();
                mSort.clear();
                if (null != gameKinds || !gameKinds.isEmpty()) {
                    if(null == gameKinds || gameKinds.isEmpty()){
                        ToastUtil.showToast(NewGameActivity.this,"获取游戏类别失败");
                        return;
                    }
                    mGameKinds = gameKinds;
                    mPopData.put(GameType, mGameKinds);
                    //智能排序参数
                    BGameKind bSort = new BGameKind();
                    bSort.typeName = "默认排序";
                    bSort.id = "-1";

                    BGameKind bSort2 = new BGameKind();
                    bSort2.typeName = "折扣从低到高";
                    bSort2.id = "1";

                    BGameKind bSort3 = new BGameKind();
                    bSort3.typeName = "折扣从高到低";
                    bSort3.id = "2";

                    mSort.add(bSort);
                    mSort.add(bSort2);
                    mSort.add(bSort3);

                    mPopData.put(Intelligent, mSort);

                }
            }

            @Override
            public void onAfter(List<BGameKind> bGameKinds, Exception e) {
                super.onAfter(bGameKinds, e);
                doGetGameList(false);
            }
        });
    }

    private void doGetGameList(final boolean loadMore) {
        GGetGameList model = new GGetGameList();
        model.gameType = mMolde.get(GameType);
        model.theme = mMolde.get(GameTheme);
        model.sort = mMolde.get(Intelligent);
        model.platForm = "0";
        model.isBT = "0";
        model.isFirst = "1";
        if(loadMore == false){
            mGameList.clear();
            mPageIndex = 1;
            showLoadToast(NewGameActivity.this);
        }
        PageModel page = new PageModel(mPageIndex);
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetGameList(model, page, new JsonCallback<List<BGame>>() {
            @Override
            public void onSuccess(List<BGame> bGames, Call call, Response response) {
                if (null == bGames || bGames.isEmpty()) {
                    //无返回结果,需要根据当前页码判断是无结果,还是无更多
                    if(mPageIndex == 1){
                        mDataStatus.setText("暂无数据");
                        mBtFirstVolume.setVisibility(View.GONE);
                        changeView(false);
                    }else{
                        ToastUtil.showToast(NewGameActivity.this,"没有更多了~");
                    }
                } else {
                    changeView(true);
                    mPageIndex++;
                    if (loadMore == false) {//非增量加载
                        mGameList.clear();
                    }
                    mGameList.addAll(bGames);
                }
            }

            @Override
            public void onAfter(List<BGame> bGames, Exception e) {
                super.onAfter(bGames, e);
                mRecyclerView.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        adapter.updateData(mGameList);
                        mRecyclerView.setPullLoadMoreCompleted();
                    }
                }, 100);
                hideLoadToast();
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                if (mPageIndex == 1){
                    mDataStatus.setText("请求数据失败");
                    mBtFirstVolume.setVisibility(View.VISIBLE);
                    changeView(false);
                }else {
                    changeView(true);
                }
                hideLoadToast();

            }
        });
    }



    @OnClick({R.id.title_bar_left, R.id.title_bar_right, R.id.tab_layout_home_new})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                super.onBackPressedSupport();
                break;
            case R.id.title_bar_right:
                break;
            case R.id.tab_layout_home_new:
                break;
            case R.id.bt_no_result:
                doGetGameThemes();
                break;
            case R.id.bt_no_resultpop:
                doGetGameThemes();
                break;
        }
    }

    private void changeView(boolean hasData) {
        mRecyclerView.setVisibility(hasData ? View.VISIBLE : View.GONE);
        mNoResultView.setVisibility(hasData ? View.GONE : View.VISIBLE);
    }

    @AfterPermissionGranted(100)
    private void requestPermissions() {
        String[] mPermissionList = new String[]{
                //                Manifest.permission.ACCESS_FINE_LOCATION,       //位置信息
                //                Manifest.permission.CALL_PHONE,                 //电话相关
                //                Manifest.permission.READ_LOGS,
                //                Manifest.permission.READ_PHONE_STATE,           //电话相关
                //                Manifest.permission.GET_ACCOUNTS,//联系人,通讯录
                //                Manifest.permission.SET_DEBUG_APP,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,};
        if (!EasyPermissions.hasPermissions(NewGameActivity.this, mPermissionList)) {
            EasyPermissions.requestPermissions(NewGameActivity.this,
                    "应用下载时需要保存到本地，为了保证核心功能的稳定性，请您同意授权权限", 100, mPermissionList);
        }

    }

    @Override
    public void onPermissionsGranted(int requestCode, List<String> perms) {
        //同意授权

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    @Override
    public void onPermissionsDenied(int requestCode, List<String> perms) {
        //取消授权时
    }


    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.REQUEST_SD_CARD://点击下载时申请sd卡权限
                requestPermissions();
                break;
        }
    }

}

