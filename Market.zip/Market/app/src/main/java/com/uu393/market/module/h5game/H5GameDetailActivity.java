package com.uu393.market.module.h5game;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GDoAddPlayedGame;
import com.uu393.market.model.request.GGetGameDetail;
import com.uu393.market.model.response.BH5Game;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.home.AppImageAdapter;
import com.uu393.market.module.login.LoginActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.Base64Helper;
import com.uu393.market.util.GlideRoundTransform;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.log.L;

import java.util.HashMap;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import ezy.ui.layout.LoadingLayout;
import okhttp3.Call;
import okhttp3.Response;

import static com.uu393.market.Constant.UMENG_EVENT_ID_PLAY_H5;
import static com.uu393.market.app.App.mContext;

public class H5GameDetailActivity extends BaseActivity {

    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.app_icon)
    ImageView mAppIcon;
    @Bind(R.id.name)
    TextView mName;
    @Bind(R.id.tv_discount)
    TextView mTvDiscount;
    @Bind(R.id.name_layout)
    LinearLayout mNameLayout;
    @Bind(R.id.tv_type_size)
    TextView mTvTypeSize;
    @Bind(R.id.play_bt)
    Button mPlayBt;
    @Bind(R.id.download_bt_layout)
    RelativeLayout mDownloadBtLayout;
    @Bind(R.id.hor_center_recycle_rview)
    RecyclerView mRecyclerView;
    @Bind(R.id.viewpager_layout)
    RelativeLayout mViewpagerLayout;
    @Bind(R.id.tv_game_info)
    TextView mTvGameInfo;
    private String mGameId;
    private LoadingLayout mLoadingLayout;
    private BH5Game mGame;

    AppImageAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_h5_game_detail);
        ButterKnife.bind(this);
        Intent intent = getIntent();
        mGameId = intent.getStringExtra("gameId");
        adapter = new AppImageAdapter(H5GameDetailActivity.this);
        mLoadingLayout = LoadingLayout.wrap(this);
        mLoadingLayout.showLoading();
        mLoadingLayout.setRetryListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getGameInfo();
            }
        });
        getGameInfo();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mGame != null )
            if (mGame.getImageUrl()!=null){
                if ( !mGame.getImageUrl().isEmpty()){
                    adapter.setRefrsh(mGame.getImageUrl());
                }
            }
    }

    private void getGameInfo() {
        GGetGameDetail model = new GGetGameDetail(mGameId);
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetH5GameDetailNew(model, new JsonCallback<BH5Game>() {
            @Override
            public void onSuccess(BH5Game bh5Game, Call call, Response response) {
                mLoadingLayout.showContent();
                if (bh5Game != null) {
                    mGame = bh5Game;
                    int defaultAndError = ImageHelper.randomImage();
                    Glide.with(mContext).load(mGame.getIcon())
                            .error(defaultAndError)
                            .placeholder(defaultAndError)
                            .transform(new GlideRoundTransform(mContext, 10))
                            .into(mAppIcon);
                    mName.setText(mGame.getGameName());
                    if (mGame.getDiscount().equals("10")) {
                        mTvDiscount.setVisibility(View.GONE);
                    } else {
                        mTvDiscount.setVisibility(View.VISIBLE);
                        mTvDiscount.setText(mGame.getDiscount() + "折");
                    }
                    mTvTypeSize.setText(mGame.getTypeName());
                    mTvGameInfo.setText(Base64Helper.decodeToHtml(mGame.getGameInfo()));

                    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(H5GameDetailActivity.this);
                    linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
                    mRecyclerView.setLayoutManager(linearLayoutManager);
                    //这句代码是让图片居中显示
//                new LinearSnapHelper().attachToRecyclerView(mRecyclerView);
                    adapter.setRefrsh(mGame.getImageUrl());
                    mRecyclerView.setAdapter(adapter);
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                mLoadingLayout.showError();
            }
        });
    }

    @OnClick({R.id.title_bar_left, R.id.play_bt})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                super.onBackPressedSupport();
                break;
            case R.id.play_bt:
                Intent intent = new Intent();
                if ((boolean) SPUtil.get(App.mContext, "isLogin", false)) {
                    HashMap<String, String> map = new HashMap<>();
                    map.put("H5GameName", mGame.getGameName());
                    MobclickAgent.onEvent(mContext, UMENG_EVENT_ID_PLAY_H5, map);//友盟统计下载事件

                    intent.putExtra("gameId", mGame.getId());
                    intent.putExtra("APPID", mGame.getAPPID());
                    intent.putExtra("url", mGame.getAndroidPackage());
                    intent.setClass(H5GameDetailActivity.this, H5WebViewActivity.class);
                    startActivity(intent);
                    break;
                } else {
                    SPUtil.put(App.mContext, "GameId", mGame.getId());
                    SPUtil.put(App.mContext, "APPID", mGame.getAPPID());
                    SPUtil.put(App.mContext, "GameUrl", mGame.getAndroidPackage());
                    intent.setClass(this, LoginActivity.class);
                    startActivity(intent);
                }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (adapter!=null){
            adapter.removeImageLoader();
        }
        adapter=null;
    }
}
