package com.uu898app.view.dropdownmenu.util;

import android.view.animation.Animation;

/**
 * author: baiiu
 * date: on 15/12/17 13:48
 * description:
 */
public class SimpleAnimationListener implements Animation.AnimationListener {
    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {

    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }
}
