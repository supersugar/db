package com.uu393.market.module.home;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.lzy.ninegrid.ImageInfo;
import com.lzy.ninegrid.NineGridView;
import com.lzy.ninegrid.preview.ImagePreviewActivity;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.util.GlideRoundTransform;
import com.uu393.market.util.ImageHelper;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AppImageAdapter extends RecyclerView.Adapter<AppImageAdapter.ViewHolder> {

    private List<String> data;
    private ArrayList<ImageInfo> imageInfo = new ArrayList<>();
    private int statusHeight;
    private Context mContext;

    public AppImageAdapter(Context context) {

        this.mContext = context;

        statusHeight = getStatusHeight(context);
        NineGridView.setImageLoader(new GlideImageLoader());
    }
    public void removeImageLoader(){
        NineGridView.setImageLoader(null);
    }

    public  void setRefrsh( List<String> data){
        this.data = data;
        if (data != null) {
            imageInfo.clear();
            for (String url : data) {
                ImageInfo info = new ImageInfo();
                info.setThumbnailUrl(url);
                info.setBigImageUrl(url);
                imageInfo.add(info);
            }
        }
        notifyDataSetChanged();
    }

    public  void setRefrsh( ){

        notifyDataSetChanged();
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_app_image, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.bindItem(data.get(position));
    }

    @Override
    public int getItemCount() {
        return data==null?0:data.size();
    }


    private void goPreview(ImageView imageView, int index) {
        for (int i = 0; i < imageInfo.size(); i++) {
            ImageInfo info = imageInfo.get(i);
            info.imageViewWidth = imageView.getWidth();
            info.imageViewHeight = imageView.getHeight();
            int[] points = new int[2];
            imageView.getLocationInWindow(points);
            info.imageViewX = points[0];
            info.imageViewY = points[1] - statusHeight;
        }

        Intent intent = new Intent(mContext, ImagePreviewActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable(ImagePreviewActivity.IMAGE_INFO, (Serializable) imageInfo);
        bundle.putInt(ImagePreviewActivity.CURRENT_ITEM, index);
        intent.putExtras(bundle);
        mContext.startActivity(intent);
        ((Activity) mContext).overridePendingTransition(0, 0);
    }

    /**
     * 获得状态栏的高度
     */
    public int getStatusHeight(Context context) {
        int statusHeight = -1;
        try {
            Class<?> clazz = Class.forName("com.android.internal.R$dimen");
            Object object = clazz.newInstance();
            int height = Integer.parseInt(clazz.getField("status_bar_height").get(object).toString());
            statusHeight = context.getResources().getDimensionPixelSize(height);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return statusHeight;
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView image;

        ViewHolder(View itemView) {
            super(itemView);
            image = (ImageView) itemView.findViewById(R.id.app_image);

            int defaultAndError = ImageHelper.randomImage();
            image.setImageResource(defaultAndError);
        }

        void bindItem(String url) {

            int defaultAndError = ImageHelper.randomImage();
            Glide.with(mContext).load(url)
                    .placeholder(defaultAndError)
                    .error(defaultAndError)
                    .transform(new GlideRoundTransform(App.mContext, 10))//                    .listener(new RequestListener<String, GlideDrawable>() {
//                        @Override
//                        public boolean onException(Exception e, String model, Target<GlideDrawable> target, boolean isFirstResource) {
//                            return false;
//                        }
//
//                        @Override
//                        public boolean onResourceReady(GlideDrawable resource, String model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
//                            L.d("onResourceReady");
//                            return false;
//                        }
//                    })

                    .into(image);
            image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    goPreview(image, getLayoutPosition());
                }
            });
        }
    }


    /**
     * Glide 加载
     */
    private class GlideImageLoader implements NineGridView.ImageLoader {
        @Override
        public void onDisplayImage(Context context, ImageView imageView, String url) {
            int defaultAndError = ImageHelper.randomImage();
            Glide.with(context).load(url)//
                    .placeholder(defaultAndError)//
                    .error(defaultAndError)//
//                    .diskCacheStrategy(DiskCacheStrategy.ALL)//
                    .into(imageView);
        }

        @Override
        public Bitmap getCacheImage(String url) {
            return null;
        }
    }

}
