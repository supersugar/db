package com.uu898app.module.account;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uu898app.R;
import com.uu898app.module.base.BaseFragment;
import com.uu898app.module.helper.ToolbarHelper;
import com.uu898app.module.order.OrderListFragment;

import butterknife.ButterKnife;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class MyTabFragment extends BaseFragment {

    private final static String TYPE = "type";//类型

    public static final int TYPE_FUNDS_DETAIL = 0;//资金明细
    public static final int TYPE_RECORD_BUY = 1;//购买记录
    public static final int TYPE_RECORD_SELL = 2;//出售记录

    private Toolbar toolbar;
    private TabLayout mTab;
    private ViewPager mViewPager;
    private String[] mTitlesFundsDetail = new String[]{"充值记录", "提现记录", "售得记录", "支付记录"};
    private String[] mTitlesRecordBuy = new String[]{"寄售\r\n担保、账号", "点卡订单", "QQ充值\r\n手机充值"};
    private String[] mTitlesRecordSell = new String[]{"出售中", "出售完成"};

    private int type;
    private String[] mCurrentTitles;

    public static MyTabFragment newInstance(int type) {
        Bundle args = new Bundle();
        args.putInt(TYPE, type);
        MyTabFragment fragment = new MyTabFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        if (args != null) {
            type = args.getInt(TYPE);
            if (type == TYPE_FUNDS_DETAIL) {
                mCurrentTitles = mTitlesFundsDetail;
            } else if (type == TYPE_RECORD_BUY) {
                mCurrentTitles = mTitlesRecordBuy;
            } else if (type == TYPE_RECORD_SELL) {
                mCurrentTitles = mTitlesRecordSell;
            }
        }
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.my_tab_fragment_layout, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        toolbar = (Toolbar) view.findViewById(R.id.toolbar);
        new ToolbarHelper.Builder(toolbar,this, _mActivity)
                .title("购买记录")
                .showBack(true)
                .build();
        mTab = (TabLayout) view.findViewById(R.id.tab);
        mViewPager = (ViewPager) view.findViewById(R.id.viewPager);
        mViewPager.setAdapter(new MyAdapter(getChildFragmentManager()));
        mTab.setupWithViewPager(mViewPager);
    }


    private class MyAdapter extends FragmentPagerAdapter {

        public MyAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            BaseFragment fragment = null;
            switch (type) {
                case TYPE_RECORD_BUY:
                    if (position == 0) {
                        fragment = OrderListFragment.newInstance(OrderListFragment.TYPE_COMMON);
                    } else if (position == 1) {
                        fragment = OrderListFragment.newInstance(OrderListFragment.TYPE_GAME_DK);
                    } else if (position == 2) {
                        fragment = OrderListFragment.newInstance(OrderListFragment.TYPE_PHONEQQ);
                    }
                    break;
                case TYPE_RECORD_SELL:
                    fragment = OrderListFragment.newInstance(OrderListFragment.TYPE_PHONEQQ);
                    break;
                case TYPE_FUNDS_DETAIL:
                    fragment = OrderListFragment.newInstance(OrderListFragment.TYPE_PHONEQQ);
                    break;
            }
            return fragment;
        }

        @Override
        public int getCount() {
            return mCurrentTitles.length;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mCurrentTitles[position];
        }
    }
}
