package com.uu898.gamesdk.fragmentation.anim;

import android.os.Parcel;
import android.os.Parcelable;

import com.uu898.gamesdk.core.ResourceUtils;

import org.xutils.x;

/**
 * Created by YoKeyword on 16/2/5.
 */
public class DefaultVerticalAnimator extends FragmentAnimator implements Parcelable{

    public DefaultVerticalAnimator() {
        enter = ResourceUtils.getAnimId(x.app(),"ug_fmt_v_fragment_enter");
        exit = ResourceUtils.getAnimId(x.app(),"ug_fmt_v_fragment_exit");
        popEnter = ResourceUtils.getAnimId(x.app(),"ug_fmt_v_fragment_pop_enter");
        popExit = ResourceUtils.getAnimId(x.app(),"ug_fmt_v_fragment_pop_exit");
    }

    protected DefaultVerticalAnimator(Parcel in) {
        super(in);
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<DefaultVerticalAnimator> CREATOR = new Creator<DefaultVerticalAnimator>() {
        @Override
        public DefaultVerticalAnimator createFromParcel(Parcel in) {
            return new DefaultVerticalAnimator(in);
        }

        @Override
        public DefaultVerticalAnimator[] newArray(int size) {
            return new DefaultVerticalAnimator[size];
        }
    };
}
