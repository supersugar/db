package com.uu898app.model.request;

import com.uu898app.model.GBaseModel;

/**
 * Created by zhangbo on 2016/6/20.
 */
public class GGameList extends GBaseModel {

    /**
     * ssid : 6e3ff7a3df63c5eab8b28d67c662a25b
     * ishot : 1
     */

    private String ishot;

    public String getIshot() {
        return ishot;
    }

    public void setIshot(String ishot) {
        this.ishot = ishot;
    }
}
