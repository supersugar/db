package com.uu393.market.module.center;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GGetShareOrderList;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.center.timepicker.view.TimePickerView;
import com.uu393.market.util.DateUtils;
import com.uu393.market.util.ScreenUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.eventbus.EventAnything;
import com.uu393.market.util.log.L;
import com.uu393.market.view.lazyviewpager.LazyFragmentPagerAdapter;

import org.greenrobot.eventbus.Subscribe;

import java.text.SimpleDateFormat;
import java.util.Date;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.finalteam.toolsfinal.DeviceUtils;

/**
 * Created by Administrator on 2017/4/12.
 * 分享赚订单明细
 */

public class ShareActivity extends BaseActivity {

    @Bind(R.id.title_bar_left)
    ImageView mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ImageView mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    @Bind(R.id.tab_layout_wallet_detail)
    TabLayout mTabLayoutWalletDetail;
    @Bind(R.id.vp_wallet_detail)
    ViewPager mVpWalletDetail;

    private GGetShareOrderList mGetShareOrderListModel;
    private ShareImgPopWindow mSelectSearchConditionPopupWindow;

    private Date mSearchStartDate;//搜索起始时间
    private Date mSearchEndDate;//搜索截止时间
    private String mSearchAccountOrPhone="";//搜索账户名或者手机号
    private String mSearchGameName="";//搜索游戏名

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_layout);
        ButterKnife.bind(this);
        mSelectSearchConditionPopupWindow = new ShareImgPopWindow(ShareActivity.this);//搜索条件选择弹窗
        mGetShareOrderListModel = new GGetShareOrderList();
        initTitle();
        initViewPager();
    }

    @Override
    protected void onResume() {
        super.onResume();
        EB.register(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EB.unregister(this);
    }

    private void initTitle() {
        mTitleBarTitle.setText("订单明细");
    }

    private void initViewPager() {
        // 初始化时传默认选择时间：当天-明天
        String nowTime = DateUtils.getNowTime(DateUtils.DATE_SMALL_STR);
        mGetShareOrderListModel.setBeginTime(nowTime);
        mGetShareOrderListModel.setEndTime(nowTime);
        mGetShareOrderListModel.setGameName("");
        mGetShareOrderListModel.setUserID("");
        mVpWalletDetail.setAdapter(new ShareActivity.MyPagerAdapter(getSupportFragmentManager(), mGetShareOrderListModel));
        mTabLayoutWalletDetail.setupWithViewPager(mVpWalletDetail);
    }

    @OnClick({R.id.title_bar_left, R.id.title_bar_right, R.id.title_bar_title})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left://返回
                super.onBackPressedSupport();
                if (mSelectSearchConditionPopupWindow != null) {
                    mSelectSearchConditionPopupWindow.hideSelectWindow();
                }
                break;
            case R.id.title_bar_right://选择查询条件-->弹出框
                if (mSelectSearchConditionPopupWindow == null) {
                    mSelectSearchConditionPopupWindow = new ShareImgPopWindow(ShareActivity.this);
                }
                mSelectSearchConditionPopupWindow.showSelectWindowFromTop();
                break;
        }
    }

    public class MyPagerAdapter extends LazyFragmentPagerAdapter {
        private String[] titles = {"安卓", "H5游戏"};
        private GGetShareOrderList mGetShareOrderListModel;

        public MyPagerAdapter(FragmentManager fm, @NonNull GGetShareOrderList getShareOrderListModel) {
            super(fm);
            if (getShareOrderListModel != null) {
                mGetShareOrderListModel = getShareOrderListModel;
            }
        }

        @Override
        public int getCount() {
            return titles.length;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return titles[position];
        }

        @Override
        protected Fragment getItem(ViewGroup container, int position) {
            ShareAllFragment fragment = ShareAllFragment.newInstance(titles[position], mGetShareOrderListModel);
            return fragment;
        }
    }
    //条件选择弹窗
    public class ShareImgPopWindow implements View.OnClickListener {
        private Activity mActivity;
        private final View view;//弹框主视图
        private PopupWindow popupWindow;
        private EditText mEtAccountOrPhone;
        private EditText mEtGameName;
        private TextView mTvStartDate;
        private TextView mTvEndDate;
        private Button mBtnQuery;
        private ImageView mIvStartClear;//清理起始日期
        private ImageView mIvEndClear;//清理截止日期

        private Date mStartDate;
        private Date mEndDate;

        public ShareImgPopWindow(Activity context) {
            this.mActivity = context;
            //禁止弹出软键盘
            mActivity.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
            view = LayoutInflater.from(mActivity).inflate(R.layout.popwindow_share_select, null, false);

            mEtAccountOrPhone = (EditText) view.findViewById(R.id.et_account_or_phone);
            mTvStartDate = (TextView) view.findViewById(R.id.et_begin_date);
            mTvEndDate = (TextView) view.findViewById(R.id.et_end_date);
            mEtGameName = (EditText) view.findViewById(R.id.et_game_name);
            mBtnQuery = (Button) view.findViewById(R.id.btn_query);
            mIvStartClear = (ImageView) view.findViewById(R.id.iv_edit_text_start_clear);
            mIvEndClear = (ImageView) view.findViewById(R.id.iv_edit_text_end_clear);

            mEtAccountOrPhone.setOnClickListener(this);
            mTvEndDate.setOnClickListener(this);
            mTvStartDate.setOnClickListener(this);
            mBtnQuery.setOnClickListener(this);
            mIvStartClear.setOnClickListener(this);
            mIvEndClear.setOnClickListener(this);
        }

        //底部弹出
        public void showSelectWindowFromTop() {
            int screenHeight = ScreenUtils.getScreenHeight(mActivity);
            popupWindow = new PopupWindow(view, ViewGroup.LayoutParams.MATCH_PARENT, screenHeight * 2 / 3);

            popupWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            popupWindow.setAnimationStyle(android.R.style.Animation_InputMethod);
            popupWindow.setOutsideTouchable(true);
            popupWindow.setFocusable(true);
            WindowManager.LayoutParams lp = mActivity.getWindow().getAttributes();
            lp.alpha = 0.5f;
            mActivity.getWindow().setAttributes(lp);
            popupWindow.showAtLocation(mActivity.getWindow().getDecorView(), Gravity.CENTER | Gravity.TOP, 0, 0);
            popupWindow.update();
            popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
                @Override
                public void onDismiss() {
                    WindowManager.LayoutParams lp = mActivity.getWindow().getAttributes();
                    lp.alpha = 1.0f;
                    mActivity.getWindow().setAttributes(lp);
                }
            });

        }

        //隐藏弹窗
        public void hideSelectWindow() {
            if (popupWindow != null && popupWindow.isShowing()) {
                popupWindow.dismiss();
                popupWindow = null;
            }
        }


        @Override
        public void onClick(View v) {
            int id = v.getId();
            switch (id) {
                case R.id.et_account_or_phone://输入账户名或者手机号
                    if (!DeviceUtils.isActiveSoftInput(App.mContext)) {
                        DeviceUtils.showInputSoftFromWindowMethod(App.mContext, mEtAccountOrPhone);
                    }
                    break;
                case R.id.et_begin_date://选择开始日期
                    if (DeviceUtils.isActiveSoftInput(App.mContext)) {
                        DeviceUtils.hideInputSoftFromWindowMethod(App.mContext, mEtAccountOrPhone);
                    }
                    //传过去时间
                    Intent intent1 = new Intent(mActivity, TimePickerPopActivity.class);
                    intent1.putExtra(TimePickerPopActivity.INTENT_KEY_SELECT_DATE,mStartDate);
                    intent1.putExtra(TimePickerPopActivity.INTENT_KEY_SELECT_START_OR_END,TimePickerPopActivity.SEND_START_DATE);
                    mActivity.startActivity(intent1);

                    break;
                case R.id.et_end_date://选择结束日期
                    if (DeviceUtils.isActiveSoftInput(App.mContext)) {
                        DeviceUtils.hideInputSoftFromWindowMethod(App.mContext, mEtAccountOrPhone);
                    }

                    //传过去时间
                    Intent intent2 = new Intent(mActivity, TimePickerPopActivity.class);
                    intent2.putExtra(TimePickerPopActivity.INTENT_KEY_SELECT_DATE,mEndDate);
                    intent2.putExtra(TimePickerPopActivity.INTENT_KEY_SELECT_START_OR_END,TimePickerPopActivity.SEND_END_DATE);
                    mActivity.startActivity(intent2);
                    break;
                case R.id.et_game_name://输入游戏名
                    if (DeviceUtils.isActiveSoftInput(App.mContext)) {
                        DeviceUtils.hideInputSoftFromWindowMethod(App.mContext, mEtAccountOrPhone);
                    }

                    if (!DeviceUtils.isActiveSoftInput(App.mContext)) {
                        DeviceUtils.showInputSoftFromWindowMethod(App.mContext, mEtAccountOrPhone);
                    }
                    break;
                case R.id.btn_query:// TODO: 2017/4/21 点击立即查询，逻辑判断
                    if (DeviceUtils.isActiveSoftInput(App.mContext)) {
                        DeviceUtils.hideInputSoftFromWindowMethod(App.mContext, mEtAccountOrPhone);
                    }
                    String startDateInPop = mTvStartDate.getText().toString().trim();//弹窗中起始时间
                    String endDateInPop = mTvEndDate.getText().toString().trim();//弹窗中截止时间
                    Date parseStart = DateUtils.parse(startDateInPop, "yyyy-MM-dd");
                    Date parseEnd = DateUtils.parse(endDateInPop, "yyyy-MM-dd");
                    mSearchStartDate = parseStart;
                    mSearchEndDate = parseEnd;

                    String accountOrPhoneInPop = mEtAccountOrPhone.getText().toString().trim();//账户名或者手机号
                    String gameNameInPop = mEtGameName.getText().toString().trim();//游戏名
                    if (TextUtils.isEmpty(accountOrPhoneInPop)&&TextUtils.isEmpty(gameNameInPop)){//三项全为空
                        if ((parseStart==null||parseEnd==null)){
                            ToastUtil.showToast(App.mContext,"至少输入一项查询条件");
                            return;
                        }
                    }
                    if (parseStart!=null&&parseEnd!=null){
                        if (parseStart.compareTo(parseEnd)>0){
                            ToastUtil.showToast(App.mContext,"起始日期不能大于结束日期");
                            return;
                        }
                    }
                    mSearchAccountOrPhone = accountOrPhoneInPop;
                    mSearchGameName = gameNameInPop;

                    this.hideSelectWindow();

                    GGetShareOrderList gGetShareOrderList = new GGetShareOrderList();
                    gGetShareOrderList.setUserID(mSearchAccountOrPhone);
                    gGetShareOrderList.setGameName(mSearchGameName);
                    if (parseStart==null||parseEnd==null){
                        gGetShareOrderList.setBeginTime("");
                        gGetShareOrderList.setEndTime("");
                    }else {
                        gGetShareOrderList.setBeginTime(""+ cn.finalteam.toolsfinal.DateUtils.format(parseStart,"yyyy-MM-dd"));
                        gGetShareOrderList.setEndTime(""+cn.finalteam.toolsfinal.DateUtils.format(parseEnd,"yyyy-MM-dd"));
                    }
                    EB.postAnything(EB.TAG.REFRESH_IN_SHARE_ORDER_ALL_FRAGMENT,gGetShareOrderList);
                    break;
                case R.id.iv_edit_text_end_clear:
                    mTvEndDate.setText("");
                    break;
                case R.id.iv_edit_text_start_clear:
                    mTvStartDate.setText("");
                    break;
            }
        }
    }
    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.SEND_SELECT_DATE_IN_SHARE_POP:
                Date date = null ;
                Integer typeSelect =0;
                if (event instanceof EventAnything){
                    Object[] objects = ((EventAnything) event).result;
                    for (Object object:objects){
                        if (object instanceof Date){
                            date = (Date) object;
                        }
                        if (object instanceof Integer){
                            typeSelect = (Integer) object;
                        }
                    }
                }
                if (mSelectSearchConditionPopupWindow!=null){
                    if (typeSelect ==TimePickerPopActivity.SEND_START_DATE){
                        mSelectSearchConditionPopupWindow.mTvStartDate.setText(cn.finalteam.toolsfinal.DateUtils.format(date,"yyyy-MM-dd"));
                    }else if (typeSelect ==TimePickerPopActivity.SEND_END_DATE){
                        mSelectSearchConditionPopupWindow.mTvEndDate.setText(cn.finalteam.toolsfinal.DateUtils.format(date,"yyyy-MM-dd"));
                    }
                }

                break;
        }
    }
}
