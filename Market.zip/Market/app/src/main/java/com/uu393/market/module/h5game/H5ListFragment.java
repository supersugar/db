package com.uu393.market.module.h5game;

import android.annotation.TargetApi;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.PageModel;
import com.uu393.market.model.request.GGetH5GameList;
import com.uu393.market.model.response.BH5Game;
import com.uu393.market.module.base.BaseViewPagerFragment;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.log.L;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;

import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/14
 * Descrip    : 单个H5游戏列表页面
 * =====================================================
 */

public class H5ListFragment extends BaseViewPagerFragment {
    private String mGameType;
    public PullLoadMoreRecyclerView mRecyclerView;
    private View mNoResultView;
    private H5ApkListAdapter adapter;
    private int mPageIndex = 1;//List的加载页面
    private List<BH5Game> mH5Games;
    int downY = -1;
    public static H5ListFragment newInstance(String id) {
        H5ListFragment fragment = new H5ListFragment();
        Bundle args = new Bundle();
        args.putString("id", id);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // TODO: 2017/2/14 根据传入的游戏类型，下载列表数据
        mGameType = getArguments().getString("id", "1");
        LinearLayout inflate = (LinearLayout) inflater.inflate(R.layout.fragment_h5_item_list, container, false);
        return inflate;
    }

    @TargetApi(Build.VERSION_CODES.M)
    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mNoResultView = view.findViewById(R.id.h5_no_result_view);
        mRecyclerView = (PullLoadMoreRecyclerView) view.findViewById(R.id.h5_recycler_view);

        mH5Games = new ArrayList<>();
        mRecyclerView.setLinearLayout();//todo 向下滑动事件 需要进一步处理
        adapter = new H5ApkListAdapter(_mActivity);
        mRecyclerView.setAdapter(adapter);
        mRecyclerView.setPullRefreshEnable(true);
        mRecyclerView.setPushRefreshEnable(true);
        getH5GameList(false);
        mRecyclerView.setOnPullLoadMoreListener(new PullLoadMoreRecyclerView.PullLoadMoreListener() {
            @Override
            public void onRefresh() {
                mRecyclerView.setIsRefresh(true);
                getH5GameList(false);//刷新
            }

            @Override
            public void onLoadMore() {
                mRecyclerView.setIsLoadMore(true);
                getH5GameList(true);//加载更多
            }
        });

    }

    //TODO 网络获取H5游戏列表数据

    private void getH5GameList(final boolean isLoadMore) {
        if (!isLoadMore) {
            mPageIndex = 1;//加载第一页
        } else {
            mPageIndex += 1;
        }
        PageModel pageModel = new PageModel(mPageIndex);
        GGetH5GameList model = new GGetH5GameList();
        TaskEngine.setTokenUseridPhoneState(2);

        if (mGameType.equals("全部游戏")) {
            model.setGameName("");
            model.setGameType("-1");
            model.setIsTopSearch("-1");
            TaskEngine.setTokenUseridPhoneState(1);
            TaskEngine.getInstance().doGetH5GameList(model, pageModel, new JsonCallback<List<BH5Game>>() {
                @Override
                public void onSuccess(List<BH5Game> h5Games, Call call, Response response) {
                    mRecyclerView.setPullLoadMoreCompleted();
                    if (h5Games == null || h5Games.isEmpty()) {
                        if (mPageIndex == 1) {
                            changeView(false);
                        } else {
                            ToastUtil.showToast(App.mContext, "没有更多了~");
                        }
                    } else {
                        changeView(true);
                        if (!isLoadMore) {
                            mH5Games.clear();//下拉刷新时，清空
                            mH5Games.addAll(h5Games);
                            adapter.updateData(mH5Games);
                        } else {
                            mH5Games.addAll(h5Games);
                            adapter.updateData(mH5Games);
                        }
                    }
                }
            });

        } else if (mGameType.equals("热门游戏")) {
            model.setGameName("");
            model.setGameType("-1");
            model.setIsTopSearch("0");
            TaskEngine.setTokenUseridPhoneState(1);
            TaskEngine.getInstance().doGetH5GameList(model, pageModel, new JsonCallback<List<BH5Game>>() {
                @Override
                public void onSuccess(List<BH5Game> h5Games, Call call, Response response) {
                    mRecyclerView.setPullLoadMoreCompleted();
                    if (h5Games == null || h5Games.isEmpty()) {
                        if (mPageIndex == 1) {
                            changeView(false);
                        } else {
                            ToastUtil.showToast(App.mContext, "没有更多了~");
                        }
                    } else {
                        changeView(true);
                        if (!isLoadMore) {
                            mH5Games.clear();//下拉刷新时，清空
                            mH5Games.addAll(h5Games);
                            adapter.updateData(mH5Games);
                        } else {
                            mH5Games.addAll(h5Games);
                            adapter.updateData(mH5Games);
                        }
                    }
                }
            });
        }
    }

    @Override
    public void refresh() {
        if (null != adapter) {
            mRecyclerView.setIsRefresh(true);
            getH5GameList(false);
        }
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        L.d("onHiddenChanged");
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("H5ListFragment");
        L.d("onPause");
    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart("H5ListFragment");
        L.d("onResume");
    }

    private void changeView(boolean hasData) {
        mRecyclerView.setVisibility(hasData ? View.VISIBLE : View.GONE);
        mNoResultView.setVisibility(hasData ? View.GONE : View.VISIBLE);
    }
}
