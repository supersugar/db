package com.uu393.market.module.center;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.Constant;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GDoChangeBank;
import com.uu393.market.model.request.GDoChangeWithdrawPassword;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ContactCustomerServicesUtils;
import com.uu393.market.util.ToastUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.xiaoneng.uiapi.Ntalker;
import okhttp3.Call;
import okhttp3.Response;

public class NewWithdrawPasswordActivity extends BaseActivity {

    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    @Bind(R.id.et_new_withdraw_password)
    EditText mEtNewWithdrawPassword;
    @Bind(R.id.et_new_withdraw_verify_password)
    EditText mEtNewWithdrawVerifyPassword;
    @Bind(R.id.bt_new_withdraw_go)
    Button mBtNewWithdrawGo;
    @Bind(R.id.tv_contact)
    TextView mTvContact;

    private String mPasswordFirst;
    private String mPasswordVerify;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_withdraw_password);
        ButterKnife.bind(this);
        mTitleBarRight.setVisibility(View.GONE);
        mTitleBarTitle.setText("输入新密码");
    }

    @OnClick({R.id.title_bar_left, R.id.bt_new_withdraw_go, R.id.tv_contact})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                super.onBackPressedSupport();//返回
                break;
            case R.id.bt_new_withdraw_go://提交修改密码
                String passwordFirst = mEtNewWithdrawPassword.getText().toString().trim();
                if (TextUtils.isEmpty(passwordFirst)) {
                    ToastUtil.showToast(App.mContext, "请输入新密码");
                    return;
                } else {
                    mPasswordFirst = passwordFirst;
                }
                String passwordVerify = mEtNewWithdrawVerifyPassword.getText().toString().trim();
                if (TextUtils.isEmpty(passwordVerify)) {
                    ToastUtil.showToast(App.mContext, "请确认您的新密码");
                    return;
                } else {
                    mPasswordVerify = passwordVerify;
                }
                if (!mPasswordFirst.equals(mPasswordVerify)) {
                    ToastUtil.showToast(App.mContext, "密码不一致");
                    return;
                } else {
                    GDoChangeWithdrawPassword newWithdrawPasswordModel = new GDoChangeWithdrawPassword();
                    doChangeWithdrawPassword(newWithdrawPasswordModel);
                }
                break;
            case R.id.tv_contact://联系客服
                ContactCustomerServicesUtils.doXiaoNeng();
                break;
        }
    }

    //更改提现密码APP047
    private void doChangeWithdrawPassword(GDoChangeWithdrawPassword model) {
        if (model == null) return;
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doChangeWithdrawPassword(model, new JsonCallback<Object>() {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                String result = null;
                try {
                    result = response.body().string();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                JSONObject jsonObject = null;
                String message = "";
                String status = "";
                try {
                    jsonObject = new JSONObject(result);
                    status = jsonObject.getString("status");
                    message = jsonObject.getString("message");
                    if (status.equals("0")) {
                        ToastUtil.showToast(App.mContext, "更改成功");
                        // TODO: 2017/4/18  更改提现密码成功后？？？
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                ToastUtil.showToast(App.mContext, "更改密码失败，请重试");
            }
        });
    }
}
