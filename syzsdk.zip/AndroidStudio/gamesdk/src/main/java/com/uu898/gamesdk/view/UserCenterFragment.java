package com.uu898.gamesdk.view;

import android.graphics.Point;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Html;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu898.gamesdk.core.ResourceUtils;
import com.uu898.gamesdk.model.GBaseModel;
import com.uu898.gamesdk.model.response.BUserInfo;
import com.uu898.gamesdk.network.NetCallback;
import com.uu898.gamesdk.network.TaskEngine;
import com.uu898.gamesdk.utils.AccountManager;
import com.uu898.gamesdk.utils.CommonUtils;
import com.uu898.gamesdk.utils.FloatViewHelper;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class UserCenterFragment extends BaseFragment {

    private ToggleButton mToggleButton;

    private TextView mTvAccount;
    private TextView mTvMoney;

    public static UserCenterFragment newInstance() {
        Bundle args = new Bundle();
        UserCenterFragment fragment = new UserCenterFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_center"), container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.findViewById(getId("ug_bt_title_left")).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _mActivity.onBackPressed();
            }
        });

        mTvAccount = (TextView) view.findViewById(getId("ug_tv_account"));
        mTvMoney = (TextView) view.findViewById(getId("ug_tv_money"));
        mToggleButton = (ToggleButton) view.findViewById(getId("ug_toggle_bt"));
        mToggleButton.setChecked(CommonUtils.getAutoLogin());
        mToggleButton.setOnCheckedChangeListener(onCheckedChangeListener);


        view.findViewById(getId("parent_view")).setOnClickListener(onClickListener);
        view.findViewById(getId("content_view")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_user_view_more")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_bt_my_message")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_bt_kefu")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_bt_gift")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_bt_hot")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_bt_exit")).setOnClickListener(onClickListener);

        contentAsDialog(view.findViewById(getId("content_view")));

    }

    private void setContent() {
        mTvAccount.setText("ID : " + AccountManager.getInstance().getCurrentUserID());
        //两次加大字体，设置字体为红色（big会加大字号，font可以定义颜色）
        mTvMoney.setText(Html.fromHtml("钱包 : " + " <font color='#ff0000'>" + CommonUtils.fenToYuan(AccountManager.getInstance().getUserInfo().money) + "</font>     元"));
    }

    CompoundButton.OnCheckedChangeListener onCheckedChangeListener = new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            CommonUtils.saveAutoLogin(isChecked);
        }
    };

    @Override
    public void onResume() {
        super.onResume();
        FloatViewHelper.hideFloatingView();
        setContent();
        doGetUserInfo();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        FloatViewHelper.showFloatingView();
    }

    private void contentAsDialog(View v) {
        int[] point = onLayoutCallBack();
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(point[0], point[1]);
        v.setLayoutParams(params);
    }

    public int[] onLayoutCallBack() {
        int space = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 40F, _mActivity.getResources()
                .getDisplayMetrics());
        Point point = CommonUtils.getScreenSize(_mActivity);
        int width = Math.min(point.x, point.y);
        int height = Math.max(point.x, point.y);
        return new int[]{width - space, height / 2};
    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(v.getId() == getId("content_view")) {

            }else if(v.getId() == getId("parent_view")){
                _mActivity.finish();
            }else if(v.getId() == getId("ug_user_view_more")){//更多信息
                start(UserMainFragment.newInstance());
            }else if(v.getId() == getId("ug_bt_my_message")){//消息
                start(UserMessageFragment.newInstance());
            }else if(v.getId() == getId("ug_bt_kefu")){//客服
                start(WebKefuFragment.newInstance());
            }else if(v.getId() == getId("ug_bt_gift")){//礼包福利
                start(UserGiftFragment.newInstance());
            }else if(v.getId() == getId("ug_bt_hot")){//热门活动
                start(UserHotFragment.newInstance());
            }else if(v.getId() == getId("ug_bt_exit")){//退出游戏
//                start(ExitFragment.newInstance());
            }else if(v.getId() == getId("ug_bt_next")){//登陆

            }
        }
    };

    private void doGetUserInfo() {
        TaskEngine.getInstance().doGetUserInfo(new GBaseModel(), new NetCallback<BUserInfo>(this) {
            @Override
            public void _onNext(BUserInfo result) {
                AccountManager.getInstance().saveAccountInfo(result);
                setContent();
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }


}
