package com.uu898app.module.buy;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uu898app.R;
import com.uu898app.module.base.BaseFragment;
import com.uu898app.module.helper.ToolbarHelper;

/**
 * 购买商品前定制查询条件界面
 */
public class BuyCustomFragment extends BaseFragment {

    public static BuyCustomFragment newInstance() {
        Bundle args = new Bundle();
        BuyCustomFragment fragment = new BuyCustomFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.buy_custom_fragment, container, false);
        initView(view, savedInstanceState);
        return view;
    }

    private void initView(View view, Bundle savedInstanceState) {
        Toolbar mToolbar = (Toolbar) view.findViewById(R.id.toolbar);
        new ToolbarHelper.Builder(mToolbar, this, _mActivity)
                .title("选择")
                .showBack(true)
                .build();

        if (savedInstanceState == null) {
            BuyCustomListFragment menuListFragment = BuyCustomListFragment.newInstance();
            loadRootFragment(R.id.fl_list_container, menuListFragment);
            replaceLoadRootFragment(R.id.fl_content_container, BuyCustomContentFragment.newInstance(), false);
        }
    }

}
