package com.uu393.market.model.response;

import java.io.Serializable;
import java.util.List;

/**
 * Created by bo on 16/12/6.
 */

public class BGame implements Serializable {

    /**
     * {
     * "typeName": "角色扮演",
     * "id": "39",
     * "icon": "http:\/\/images.uu898.com\/uploadFiles\/SYAppMarketImgs\/2016\/1217\/636175902320946320-821-52-20.jpg",
     * "androidPackage": "http:\/\/syappmarketapk.oss-cn-hangzhou.aliyuncs.com\/636179151227060893-7.apk",
     * "packageName": "com.netease.onmyoji",
     * "describe": "网易移动游戏公司自主研发的3D日式和风回合制RPG手游！",
     * "isBt": "false",
     * "versionCode": "12",
     * rowId": "10",
     * "versionName": "1.0.13",
     * <p>
     * "gameName": "阴阳师",
     * "discount": "10",
     * "size": "592.00M"
     * "isRecommend": "false"(0 否 1是 )
     * "isFirst": "0”,(是否首发游戏  0：不是首发   1首发游戏)
     * <p>
     * "firstTime": "2017-3-31 00:00:00”,(首发时间)
     * "isQuick": "0”,(是否加速版游戏  0：不是   1是)
     * "isGift": "0”,(是否有礼包  0：没有   1有)
     * "couponPrice": "30.25”,(首充券面额)
     * "totalNum": "300”,(首充券数量)
     * <p>
     * "surplusNum": "30.25”,(首充券剩余数量)
     * "isActivity": "0”,(是否有活动  0：没有   1有)
     * "royaltyRate": "0.05”,(提成比例)
     * "isBT": "0”
     * }
     */

    private String rowId;
    private String id;
    private String gameName;
    private String icon;
    private String typeName;
    private String size;
    private String describe;
    private String versionCode;
    private String versionName;
    private String discount;
    private String androidPackage;
    private String packageName;

    private String gameInfo;
    private String language;
    private String supportSdkVersion;
    private String releaseTime;
    private List<String> imageUrl;
    private String isRecommend;
    private String platForm;
    private String isQuick;
    private String isGift;
    private String couponPrice;
    private String totalNum;
    private String surplusNum;
    private String isFirst;
    private String firstTime;
    private String isActivity;
    private String isBT;

    private String royaltyRate;

    public String getRoyaltyRate() {
        return royaltyRate;
    }

    public void setRoyaltyRate(String royaltyRate) {
        this.royaltyRate = royaltyRate;
    }


    public String getIsActivity() {
        return isActivity;
    }

    public void setIsActivity(String isActivity) {
        this.isActivity = isActivity;
    }

    public String getIsBT() {
        return isBT;
    }

    public void setIsBT(String isBT) {
        this.isBT = isBT;
    }

    public String getIsQuick() {
        return isQuick;
    }

    public void setIsQuick(String isQuick) {
        this.isQuick = isQuick;
    }

    public String getIsGift() {
        return isGift;
    }

    public void setIsGift(String isGift) {
        this.isGift = isGift;
    }

    public String getCouponPrice() {
        return couponPrice;
    }

    public void setCouponPrice(String couponPrice) {
        this.couponPrice = couponPrice;
    }

    public String getTotalNum() {
        return totalNum;
    }

    public void setTotalNum(String totalNum) {
        this.totalNum = totalNum;
    }

    public String getSurplusNum() {
        return surplusNum;
    }

    public void setSurplusNum(String surplusNum) {
        this.surplusNum = surplusNum;
    }

    public String getIsFirst() {
        return isFirst;
    }

    public void setIsFirst(String isFirst) {
        this.isFirst = isFirst;
    }

    public String getFirstTime() {
        return firstTime;
    }

    public void setFirstTime(String firstTime) {
        this.firstTime = firstTime;
    }


    public String getPlatForm() {
        return platForm;
    }

    public void setPlatForm(String platForm) {
        this.platForm = platForm;
    }

    public String getIsRecommend() {
        return isRecommend;
    }

    public void setIsRecommend(String isRecommend) {
        this.isRecommend = isRecommend;
    }


    public String getRowId() {
        return rowId;
    }

    public void setRowId(String rowId) {
        this.rowId = rowId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {
        this.describe = describe;
    }

    public String getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(String versionCode) {
        this.versionCode = versionCode;
    }

    public String getVersionName() {
        return versionName;
    }

    public void setVersionName(String versionName) {
        this.versionName = versionName;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    public String getAndroidPackage() {
        return androidPackage;
    }

    public void setAndroidPackage(String androidPackage) {
        this.androidPackage = androidPackage;
    }

    public String getGameInfo() {
        return gameInfo;
    }

    public void setGameInfo(String gameInfo) {
        this.gameInfo = gameInfo;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getSupportSdkVersion() {
        return supportSdkVersion;
    }

    public void setSupportSdkVersion(String supportSdkVersion) {
        this.supportSdkVersion = supportSdkVersion;
    }

    public String getReleaseTime() {
        return releaseTime;
    }

    public void setReleaseTime(String releaseTime) {
        this.releaseTime = releaseTime;
    }

    public List<String> getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(List<String> imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    @Override
    public String toString() {
        return "游戏名称 : " + getGameName() + "\n"
                + "包名 : " + getPackageName();
    }
}
