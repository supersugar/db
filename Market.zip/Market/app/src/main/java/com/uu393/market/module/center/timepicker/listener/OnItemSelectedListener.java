package com.uu393.market.module.center.timepicker.listener;


public interface OnItemSelectedListener {
    void onItemSelected(int index);
}
