package com.uu898app.util.wavesidebar;

import com.uu898app.model.response.BGame;

import java.util.Comparator;

public class LetterComparator implements Comparator<BGame> {

    @Override
    public int compare(BGame l, BGame r) {
        if (l == null || r == null) {
            return 0;
        }

        String lhsSortLetters = l.getFirstCharactor().toUpperCase();
        String rhsSortLetters = r.getFirstCharactor().toUpperCase();
        if (lhsSortLetters == null || rhsSortLetters == null) {
            return 0;
        }
        return lhsSortLetters.compareTo(rhsSortLetters);
    }
}