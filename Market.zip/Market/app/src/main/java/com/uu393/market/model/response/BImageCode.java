package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/16
 * Descrip    :
 * =====================================================
 */

public class BImageCode implements Serializable {


    /**
     * token : 54ddfdsffd687fdsfdsfd5
     * validateCodeImg : 54dfd687fdsfdsfd5
     */

    private String token;
    private String validateCodeImg;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getValidateCodeImg() {
        return validateCodeImg;
    }

    public void setValidateCodeImg(String validateCodeImg) {
        this.validateCodeImg = validateCodeImg;
    }
}
