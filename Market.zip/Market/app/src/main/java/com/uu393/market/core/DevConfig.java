package com.uu393.market.core;

import com.uu393.market.network.NetConstant;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.log.L;

/**
 * Created by bo on 16/12/28.
 */

public class DevConfig {

    /**
     * 手动修改
     * 开发期 = true; 线上 = false
     */
    public static final boolean DEBUG = false;

    //当前连接服务器地址
    private String mCurrentUrl = NetConstant.URL.URL_TEST;

    private static DevConfig instance = new DevConfig();

    private DevConfig() {
    }

    public static DevConfig getInstance() {
        return instance;
    }

    /**
     * 在application中调用
     */
    public void init(){
        L.init(true);//是否显示log输出
        setURL(DEBUG);//设置链接url
    }

    public String getURL(){
        if(StringUtils.isEmpty(mCurrentUrl)){
            mCurrentUrl = NetConstant.URL.URL_OFFICAL;
        }
        return mCurrentUrl;
    }

    public void setURL(boolean debug){
        if(debug){
            this.mCurrentUrl = NetConstant.URL.URL_TEST;
        }else{
            this.mCurrentUrl = NetConstant.URL.URL_OFFICAL;
        }
    }
}
