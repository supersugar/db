package com.uu393.market.module.login;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.Constant;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GDoBindPhone;
import com.uu393.market.model.request.GGetPhoneCode;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.h5game.H5WebViewActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

public class BindPhoneActivity extends BaseActivity {

    @Bind(R.id.et_bind_phone_number)
    EditText mEtBindPhoneNumber;
    @Bind(R.id.et_bind_phone_code)
    EditText mEtBindPhoneCode;
    @Bind(R.id.tv_bind_phone_get_code)
    Button mTvBindPhoneGetCode;
    @Bind(R.id.btn_bind_phone_bind)
    Button mBtnBindPhoneBind;
    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    private String mPhoneNumber;
    private String mPhoneCode;


    private String mGameId;
    private String APPID;
    private String mGameUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bind_phone);
        ButterKnife.bind(this);
        initTitleBar();
    }
    private void initTitleBar() {
        mTitleBarRight.setVisibility(View.GONE);
        mTitleBarTitle.setText("绑定手机");
    }

    @OnClick({R.id.title_bar_left, R.id.tv_bind_phone_get_code, R.id.btn_bind_phone_bind})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                super.onBackPressedSupport();
                break;
            case R.id.tv_bind_phone_get_code:

                doGetPhoneCode();
                break;
            case R.id.btn_bind_phone_bind:
                doBindPhone();
                break;
        }
    }

    private void doGetPhoneCode() {
        mPhoneNumber = mEtBindPhoneNumber.getText().toString().trim();
        if (StringUtils.isEmpty(mPhoneNumber)) {
            ToastUtil.showToast(App.mContext, "请输入手机号");
            return;
        }
        final CountDownTimer timer = new CountDownTimer(60000, 1000, mTvBindPhoneGetCode, "获取验证码");
        timer.start();
        GGetPhoneCode model = new GGetPhoneCode();
        model.setType(Constant.GET_PHONE_CODE_TYPE_1);//手机注册
        model.setPhoneNo(mPhoneNumber);
        model.setUserId("");
        TaskEngine.setTokenUseridPhoneState(1);//绑定手机的获取验证码不能传token
        TaskEngine.getInstance().doGetPhoneCode(model, new JsonCallback<Object>() {
            @Override
            public void onSuccess(Object bPhoneCode, Call call, Response response) {
                /*
                * Status 1 发送次数超过限制，请查看手机收到的验证码
                        2 手机号码格式不正确
                        3 该手机号在黑名单中
                        4 该手机号已被禁用
                        5 该用户没有绑定手机号
                * */
                ToastUtil.showToast(App.mContext, "短信验证码已发送至您的手机");
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                timer.cancel();
                mTvBindPhoneGetCode.setEnabled(true);
                mTvBindPhoneGetCode.setText("获取验证码");
            }
        });
    }

    private void doBindPhone() {
        mPhoneNumber = mEtBindPhoneNumber.getText().toString().trim();
        mPhoneCode = mEtBindPhoneCode.getText().toString().trim();

        if (StringUtils.isEmpty(mPhoneNumber)) {
            ToastUtil.showToast(App.mContext, "请输入手机号");

            return;
        }
        if (StringUtils.isEmpty(mPhoneCode)) {
            ToastUtil.showToast(App.mContext, "请输入验证码");
            return;
        }
        GDoBindPhone model = new GDoBindPhone();
        model.setPhoneNo(mPhoneNumber);
        model.setCheckCode(mPhoneCode);
        TaskEngine.setTokenUseridPhoneState(2);//绑定手机号码时要传手机号和token
        TaskEngine.getInstance().doBindPhone(model, new JsonCallback<Object>() {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                ToastUtil.showToast(App.mContext, "绑定成功");
                mGameId = (String) SPUtil.get(App.mContext, "GameId", "");
                APPID = (String) SPUtil.get(App.mContext, "APPID", "");
                mGameUrl = (String) SPUtil.get(App.mContext, "GameUrl", "");
                if (!TextUtils.isEmpty(mGameId)) {//如果是从H5游戏跳转直到这里，跳转H5游戏页面
                    Intent intent = new Intent();
                    intent.putExtra("gameId", mGameId);
                    intent.putExtra("APPID", APPID);
                    intent.putExtra("url", mGameUrl);
                    intent.setClass(BindPhoneActivity.this, H5WebViewActivity.class);
                    startActivity(intent);
                    SPUtil.put(App.mContext, "GameId", "");
                    SPUtil.put(App.mContext, "APPID", "");
                    SPUtil.put(App.mContext, "GameUrl", "");
                } else {
                    if ((boolean) SPUtil.get(App.mContext, "isLogin", false)) {
                        SPUtil.put(App.mContext, "chkMobile", mPhoneNumber);
                    } else {
                        startActivity(new Intent(BindPhoneActivity.this, LoginActivity.class));
                    }
                }
                BindPhoneActivity.this.finish();
            }
        });
    }
}
