package com.uu393.market.util;

import com.uu393.market.R;

import java.util.Random;

/**
 * Created by bo on 16/12/22.
 */

public class ImageHelper {

    private static Random random = new Random();

    private static final int[] COLORS = new int[]{
        R.color.colorful_0,
        R.color.colorful_1,
        R.color.colorful_2,
        R.color.colorful_3,
        R.color.colorful_4,
        R.color.colorful_5,
        R.color.colorful_6,
        R.color.colorful_7,
        R.color.colorful_8,
        R.color.colorful_9
    };

    public static int randomImage(){
        return COLORS[random.nextInt(9)];
    }
}
