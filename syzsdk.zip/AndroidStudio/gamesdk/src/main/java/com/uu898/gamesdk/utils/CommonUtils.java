package com.uu898.gamesdk.utils;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Environment;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import com.uu898.gamesdk.core.UGCoreHelper;
import com.uu898.gamesdk.network.NetConstant;

import org.xutils.x;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Desction:
 * Author:pengjianbo
 * Date:15/10/22 下午3:39
 */
public class CommonUtils {

    private static final String ALL_CHAR = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

    private UGCache ugCache = UGCache.get(x.app());

    /**
     * 获取设备唯一id
     *
     * @return
     */
    public static String getDeviceId() {
        String deviceId = "";
        try {
            WifiManager wm = (WifiManager) x.app().getSystemService(x.app().WIFI_SERVICE);
            deviceId = Settings.Secure.getString(x.app().getContentResolver(), Settings.Secure.ANDROID_ID);
            if (deviceId == null) {
                deviceId = wm.getConnectionInfo().getMacAddress();
                if (deviceId != null)
                    deviceId = deviceId.replaceAll(":", "");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return deviceId;
    }

    /**
     * 加密字符串,密码
     * String -> byte[] -> Rsa加密 -> Base64.encode -> UrlEncoder.encode
     *
     * @param original
     * @return
     */
    public static String encryptString(String original) {
        if (StringUtils.isEmpty(original)) {
            return "";
        }
        String result = "";
        byte[] dataByteArray = new byte[0];//
        try {
            dataByteArray = original.getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        byte[] encryptedDataByteArray = RsaHelper.encryptData(dataByteArray, NetConstant.Secret.RSA_PUBLIC_KEY_SYZ);
        result = URLEncoder.encode(Base64Helper.encode(encryptedDataByteArray));
        return result;
    }

    /**
     * 更新用户名列表
     */
    public static void updateUserNameList(String loginUserName) {
        int maxSize = 5;
        String currentList = UGCache.get(x.app()).getAsString(UGConstant.Cache.ACCOUNT_LIST);
        List<String> tempList = new ArrayList<String>();
        if (StringUtils.isEmpty(currentList)) {
            tempList.add(loginUserName);
        } else {
            String[] userList = currentList.split(",");
            if (userList == null || userList.length == 0) {
                tempList.add(loginUserName);
            } else {
                tempList.add(0, loginUserName);
                int temp = 1;
                for (String username : userList) {
                    if (!TextUtils.equals(username, loginUserName) && temp < maxSize) {
                        tempList.add(username);
                        temp++;
                    }
                }
            }
        }

        StringBuilder result = new StringBuilder();
        for (String name : tempList) {
            result.append(name);
            result.append(",");
        }

        result.delete(result.length() - 1, result.length());
        UGCache.get(x.app()).put(UGConstant.Cache.ACCOUNT_LIST, result.toString());
    }

    /**
     * 获取所有登录用户名
     *
     * @return
     */
    public static List<String> getUserNameList() {
        List<String> list = new ArrayList<String>();
        String userNameList = UGCache.get(x.app()).getAsString(UGConstant.Cache.ACCOUNT_LIST);
        if (StringUtils.isEmpty(userNameList)) {
        } else {
            String[] userList = userNameList.split(",");
            if (userList == null || userList.length == 0) {
            } else {
                for (String username : userList) {
                    list.add(username);
                }
            }
        }
        return list;
    }

    /**
     * 存储用户token
     */
    public static void saveUserToken(String username, String token) {
        UGCache.get(x.app()).put(username, token, UGCache.TIME_DAY * 7);
    }

    /**
     * 根据用户获取token
     *
     * @param username
     * @return
     */
    public static String getTokenByUserName(String username) {
        String token = UGCache.get(x.app()).getAsString(username);
        return token;
    }

    /**
     * 保存是否自动登陆状态
     *
     * @param autoLogin
     */
    public static void saveAutoLogin(boolean autoLogin) {
        UGCache.get(x.app()).put(UGConstant.Cache.AUTO_LOGIN, autoLogin);
    }

    /**
     * 获取是否自动登陆状态
     *
     * @return
     */
    public static boolean getAutoLogin() {
        return UGCache.get(x.app()).getBoolean(UGConstant.Cache.AUTO_LOGIN, false);
    }

    /**
     * 功能描述：金额字符串转换：单位分转成单元
     *
     * @return 转换后的金额字符串
     */
    public static String fenToYuan(Object o) {
        if (o == null)
            return "0.00";
        String s = o.toString();
        int len = -1;
        StringBuilder sb = new StringBuilder();
        if (s != null && s.trim().length() > 0 && !s.equalsIgnoreCase("null")) {
            s = removeZero(s);
            if (s != null && s.trim().length() > 0 && !s.equalsIgnoreCase("null")) {
                len = s.length();
                int tmp = s.indexOf("-");
                if (tmp >= 0) {
                    if (len == 2) {
                        sb.append("-0.0").append(s.substring(1));
                    } else if (len == 3) {
                        sb.append("-0.").append(s.substring(1));
                    } else {
                        sb.append(s.substring(0, len - 2)).append(".").append(s.substring(len - 2));
                    }
                } else {
                    if (len == 1) {
                        sb.append("0.0").append(s);
                    } else if (len == 2) {
                        sb.append("0.").append(s);
                    } else {
                        sb.append(s.substring(0, len - 2)).append(".").append(s.substring(len - 2));
                    }
                }
            } else {
                sb.append("0.00");
            }
        } else {
            sb.append("0.00");
        }
        return sb.toString();
    }

    /**
     * 功能描述：金额字符串转换：单位元转成单分
     *
     * @return 转换后的金额字符串
     */
    public static String yuanToFen(Object o) {
        if (o == null)
            return "0";
        String s = o.toString();
        int posIndex = -1;
        String str = "";
        StringBuilder sb = new StringBuilder();
        if (s != null && s.trim().length() > 0 && !s.equalsIgnoreCase("null")) {
            posIndex = s.indexOf(".");
            if (posIndex > 0) {
                int len = s.length();
                if (len == posIndex + 1) {
                    str = s.substring(0, posIndex);
                    if (str == "0") {
                        str = "";
                    }
                    sb.append(str).append("00");
                } else if (len == posIndex + 2) {
                    str = s.substring(0, posIndex);
                    if (str == "0") {
                        str = "";
                    }
                    sb.append(str).append(s.substring(posIndex + 1, posIndex + 2)).append("0");
                } else if (len == posIndex + 3) {
                    str = s.substring(0, posIndex);
                    if (str == "0") {
                        str = "";
                    }
                    sb.append(str).append(s.substring(posIndex + 1, posIndex + 3));
                } else {
                    str = s.substring(0, posIndex);
                    if (str == "0") {
                        str = "";
                    }
                    sb.append(str).append(s.substring(posIndex + 1, posIndex + 3));
                }
            } else {
                sb.append(s).append("00");
            }
        } else {
            sb.append("0");
        }
        str = removeZero(sb.toString());
        if (str != null && str.trim().length() > 0 && !str.trim().equalsIgnoreCase("null")) {
            return str;
        } else {
            return "0";
        }
    }

    /**
     * 功能描述：去除字符串首部为"0"字符
     *
     * @param str 传入需要转换的字符串
     * @return 转换后的字符串
     */
    public static String removeZero(String str) {
        char ch;
        String result = "";
        if (str != null && str.trim().length() > 0 && !str.trim().equalsIgnoreCase("null")) {
            try {
                for (int i = 0; i < str.length(); i++) {
                    ch = str.charAt(i);
                    if (ch != '0') {
                        result = str.substring(i);
                        break;
                    }
                }
            } catch (Exception e) {
                result = "";
            }
        } else {
            result = "";
        }
        return result;

    }

    /**
     * 判断微信是否安装
     * @param context
     * @return
     */
    public static boolean isWeixinInstall(Context context) {
        final PackageManager packageManager = context.getPackageManager();// 获取packagemanager
        List<PackageInfo> pinfo = packageManager.getInstalledPackages(0);// 获取所有已安装程序的包信息
        if (pinfo != null) {
            for (int i = 0; i < pinfo.size(); i++) {
                String pn = pinfo.get(i).packageName;
                if (pn.equals("com.tencent.mm")) {
                    return true;
                }
            }
        }

        return false;
    }

    public static String getIP(Context application) {
        //获取wifi服务
        WifiManager wifiManager = (WifiManager) application.getSystemService(Context.WIFI_SERVICE);
        //判断wifi是否开启
        if (!wifiManager.isWifiEnabled()) {
            try {
                for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements(); ) {
                    NetworkInterface intf = en.nextElement();
                    for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements(); ) {
                        InetAddress inetAddress = enumIpAddr.nextElement();
                        if (!inetAddress.isLoopbackAddress()) {
                            return inetAddress.getHostAddress().toString();
                        }
                    }
                }
            } catch (SocketException e) {
                e.printStackTrace();
            }
        } else {
            WifiInfo wifiInfo = wifiManager.getConnectionInfo();
            int ipAddress = wifiInfo.getIpAddress();
            String ip = intToIp(ipAddress);
            return ip;
        }
        return null;
    }

    private static String intToIp(int i) {

        return (i & 0xFF) + "." +
                ((i >> 8) & 0xFF) + "." +
                ((i >> 16) & 0xFF) + "." +
                (i >> 24 & 0xFF);
    }

    /**
     * 判断SDCard是否可用
     */
    public static boolean existSDCard() {
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 获取UDID
     */
    public static String getUDID(Context context) {
        String udid = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        if (TextUtils.isEmpty(udid) || udid.equals("9774d56d682e549c") || udid.length() < 8) {
            SecureRandom random = new SecureRandom();

            udid = new BigInteger(64, random).toString(16);
        }

        if (TextUtils.isEmpty(udid) || udid.length() < 8 || udid.length() > 16) {
            udid = getRandomString(16);
        }

        return udid;
    }

    /**
     * 随机一个自定长度的字符串
     *
     * @param length 随机字符串长度
     * @return 随机字符串
     */
    public static String getRandomString(int length) {
        StringBuffer sb = new StringBuffer();
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            sb.append(ALL_CHAR.charAt(random.nextInt(length)));
        }
        return sb.toString();
    }

    /**
     * 获取屏幕大小
     */
    public static Point getScreenSize(Context context) {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(dm);
        int screenWidth = dm.widthPixels;
        int screenHeigh = dm.heightPixels;
        return new Point(screenWidth, screenHeigh);
    }

    /**
     * 获得apk版本号
     */
    public static String getVersionName(Context context) {
        String version = "";
        // 获取packagemanager的实例
        PackageManager packageManager = context.getPackageManager();
        // getPackageName()是你当前类的包名，0代表是获取版本信息
        PackageInfo packInfo;
        try {
            packInfo = packageManager.getPackageInfo(context.getPackageName(), 0);
            version = packInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        if (StringUtils.isEmpty(version)) {
            version = "";
        }

        return version;
    }

    public static String md5(String plainText) {
        StringBuffer buf = null;
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(plainText.getBytes());
            byte b[] = md.digest();

            int i;

            buf = new StringBuffer("");
            for (int offset = 0; offset < b.length; offset++) {
                i = b[offset];
                if (i < 0) {
                    i += 256;
                }
                if (i < 16) {
                    buf.append("0");
                }
                buf.append(Integer.toHexString(i));
            }
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return buf.toString();
    }


    public static String getParamsSign(Map<String, String> params) {
        StringBuffer stringBuffer = new StringBuffer();
        Set<String> set = params.keySet();
        List<String> list = new ArrayList<String>();
        list.addAll(set);
        Collections.sort(list);
        for (int i = 0; i < list.size(); i++) {
            stringBuffer.append(list.get(i) + "=" + params.get(list.get(i)));
        }
        stringBuffer.append("mduSfA5TgCe8xxpAqxsIFpPeWWRqCVH4");
        String md5 = md5(stringBuffer.toString());
        return md5;
    }

    public static String getSignByParams(String params) {
        if (params.contains("?") && params.length() > 5) {
            params = params.substring(params.indexOf('?') + 1);
            String str[] = params.split("&");
            if (str.length > 0) {
                List<String> list = new ArrayList<String>();
                Set<String> set = new HashSet<String>();
                for (int i = 0; i < str.length; i++) {
                    set.add(str[i]);
                }
                list.addAll(set);
                Collections.sort(list);
                StringBuffer stringBuffer = new StringBuffer();
                for (String string : list) {
                    stringBuffer.append(string);
                }
                stringBuffer.append("mduSfA5TgCe8xxpAqxsIFpPeWWRqCVH4");
                String md5 = md5(stringBuffer.toString());
                return md5;
            }
        }
        return null;
    }

    public static void install(Context context, File uriFile) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.fromFile(uriFile), "application/vnd.android.package-archive");
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    /**
     * 获取IMEI
     */
    public static String getIMEI(Context context) {
        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        String imei = tm.getDeviceId();
        if (StringUtils.isEmpty(imei)) {
            imei = "";
        }

        return imei;
    }

    public static String getNetType(Context context) {
        String netType = null;
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context
                    .CONNECTIVITY_SERVICE);
            if (connectivityManager == null) {
                netType = "";
            }

            NetworkInfo info = connectivityManager.getActiveNetworkInfo();
            if (info == null) {
                netType = "";
            }

            String type = info.getTypeName();

            if (type.equalsIgnoreCase("WIFI")) {
                // WIFI
                netType = "wifi";
            } else if (type.equalsIgnoreCase("MOBILE")) {
                // GPRS
                String proxyHost = android.net.Proxy.getDefaultHost();
                if (proxyHost != null && !proxyHost.equals("")) {
                    // WAP
                    netType = "wap";
                } else {
                    netType = "net";
                }
            }
        } catch (Exception ex) {
        }
        if (netType == null || netType.length() == 0) {
            netType = "unknown";
        }
        return netType;
    }

    /**
     * 获取MAC地址
     */
    public static String getMac(Context context) {
        WifiManager wifi = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = wifi.getConnectionInfo();
        String mac = info.getMacAddress();
        if (StringUtils.isEmpty(mac)) {
            mac = "";
        }
        return mac;
    }


}
