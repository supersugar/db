package com.uu661.model.response;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by bo on 16/9/14.
 */
public class BOrderDetail implements Serializable {


    /**
     * commodityId : 230            //商品编号
     * imageUrl :                   //图片路径
     * periodNo : 701240145         //期数编号
     * periodStatus : 3             //期数状态
     * orderStatus : 1              //订单状态
     * totalCount : 2               //总需人次
     * leftCount : 0                //剩余人次
     * myCodeList : 1               //我的秒杀码
     * winCode : 2                  //本期中奖码
     * winnerName : 10****57        //中奖用户
     * winnerCodeList : 2           //中奖用户秒杀码
     * isWin : 0                    //是否中奖
     * delay : 30                   //倒计时
     */

    private int commodityId;
    private String imageUrl;
    private int periodNo;
    private int periodStatus;
    private int orderStatus;
    private int totalCount;
    private int leftCount;
    private String myCodeList;
    private String winCode;
    private String winnerName;
    private String winnerCodeList;
    private int isWin;
    private long delay;
    private int myCodeCount;
    private int winnerCodeCount;//获奖者夺钻码数量
    private List<BCoupon> coupon = new ArrayList<>();//

    public int getMyCodeCount() {
        return myCodeCount;
    }

    public void setMyCodeCount(int myCodeCount) {
        this.myCodeCount = myCodeCount;
    }

    public int getCommodityId() {
        return commodityId;
    }

    public void setCommodityId(int commodityId) {
        this.commodityId = commodityId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public int getPeriodNo() {
        return periodNo;
    }

    public void setPeriodNo(int periodNo) {
        this.periodNo = periodNo;
    }

    public int getPeriodStatus() {
        return periodStatus;
    }

    public void setPeriodStatus(int periodStatus) {
        this.periodStatus = periodStatus;
    }

    public int getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(int orderStatus) {
        this.orderStatus = orderStatus;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getLeftCount() {
        return leftCount;
    }

    public void setLeftCount(int leftCount) {
        this.leftCount = leftCount;
    }

    public String getMyCodeList() {
        return myCodeList;
    }

    public void setMyCodeList(String myCodeList) {
        this.myCodeList = myCodeList;
    }

    public String getWinCode() {
        return winCode;
    }

    public void setWinCode(String winCode) {
        this.winCode = winCode;
    }

    public String getWinnerName() {
        return winnerName;
    }

    public void setWinnerName(String winnerName) {
        this.winnerName = winnerName;
    }

    public String getWinnerCodeList() {
        return winnerCodeList;
    }

    public void setWinnerCodeList(String winnerCodeList) {
        this.winnerCodeList = winnerCodeList;
    }

    public int getIsWin() {
        return isWin;
    }

    public void setIsWin(int isWin) {
        this.isWin = isWin;
    }

    public long getDelay() {
        return delay;
    }

    public void setDelay(long delay) {
        this.delay = delay;
    }

    public int getWinnerCodeCount() {
        return winnerCodeCount;
    }

    public void setWinnerCodeCount(int winnerCodeCount) {
        this.winnerCodeCount = winnerCodeCount;
    }

    public List<BCoupon> getCoupon() {
        return coupon;
    }

    public void setCoupon(List<BCoupon> coupon) {
        this.coupon = coupon;
    }
}
