package com.uu393.market.module.center;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.R;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.util.ContactCustomerServicesUtils;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.finalteam.toolsfinal.ResourceUtils;

public class ChargeMoneyStateActivity extends BaseActivity {
    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    @Bind(R.id.iv_charge_state)
    ImageView mIvChargeState;//状态 图标
    @Bind(R.id.tv_charge_state)
    TextView mTvChargeState;//状态文字
    @Bind(R.id.tv_charge_state_hint)
    TextView mTvChargeStateHint;//状态提示语
    @Bind(R.id.tv_contact)
    TextView mTvContact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_charge_money_state);
        ButterKnife.bind(this);

        initTitleBar();
        
        mIvChargeState.setImageResource(R.drawable.ic_charge_state_loading);
        mTvChargeState.setText("正在充值");
        mTvChargeState.setTextColor(getResources().getColor(R.color.green));
        mTvChargeStateHint.setVisibility(View.VISIBLE);
        //// TODO: 2017/4/24 接口获取充值状态
        /*mIvChargeState.setImageResource(R.drawable.ic_charge_state_fail);
        mTvChargeState.setText("充值失败");
        mTvChargeState.setTextColor(getResources().getColor(R.color.red));
        mTvChargeStateHint.setVisibility(View.GONE);

        mIvChargeState.setImageResource(R.drawable.ic_register_success);
        mTvChargeState.setText("充值成功");
        mTvChargeState.setTextColor(getResources().getColor(R.color.green));
        mTvChargeStateHint.setVisibility(View.GONE);*/
    }

    private void initTitleBar() {
        mTitleBarRight.setVisibility(View.GONE);
        mTitleBarTitle.setText("充值结果");
    }

    @OnClick({R.id.title_bar_left, R.id.tv_contact})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left://返回
                super.onBackPressedSupport();
                break;
            case R.id.tv_contact://客服
                ContactCustomerServicesUtils.doXiaoNeng();
                break;
        }
    }
}
