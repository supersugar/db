package com.uu393.market.model.request;

public class GGetBanner {

    public String id = "1";//广告图片位置id，首页广告图片轮换传1

}
