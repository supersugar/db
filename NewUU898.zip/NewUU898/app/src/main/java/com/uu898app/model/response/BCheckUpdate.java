package com.uu898app.model.response;

/**
 * Created by zhangbo on 2016/6/15.
 */
public class BCheckUpdate {
    /**
     * VersionNo : 2.4.7
     * IOSVersionNo : 2.4.5
     * Message : 版本更新为2.4.7
     * IsForced : 0
     * Url : http://www.uu898.com/m/UU898.apk
     * IOSURL : https://itunes.apple.com/cn/app/uu898/id904175349?l=zh&ls=1&mt=8
     * ifShowQQ : 0
     */

    private String VersionNo;
    private String IOSVersionNo;
    private String Message;
    private String IsForced;
    private String Url;
    private String IOSURL;
    private String ifShowQQ;

    public String getVersionNo() {
        return VersionNo;
    }

    public void setVersionNo(String VersionNo) {
        this.VersionNo = VersionNo;
    }

    public String getIOSVersionNo() {
        return IOSVersionNo;
    }

    public void setIOSVersionNo(String IOSVersionNo) {
        this.IOSVersionNo = IOSVersionNo;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String Message) {
        this.Message = Message;
    }

    public String getIsForced() {
        return IsForced;
    }

    public void setIsForced(String IsForced) {
        this.IsForced = IsForced;
    }

    public String getUrl() {
        return Url;
    }

    public void setUrl(String Url) {
        this.Url = Url;
    }

    public String getIOSURL() {
        return IOSURL;
    }

    public void setIOSURL(String IOSURL) {
        this.IOSURL = IOSURL;
    }

    public String getIfShowQQ() {
        return ifShowQQ;
    }

    public void setIfShowQQ(String ifShowQQ) {
        this.ifShowQQ = ifShowQQ;
    }
}
