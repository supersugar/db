package com.uu898app.util.cache;

/**
 * Created by zhangbo on 2016/7/20.
 */
public class UUCacheConstant {

    /**
     * 游戏列表(包含索引)
     */
    public static final String KEY_GAMES_WITH_INDEX = "key_games_with_index";

}
