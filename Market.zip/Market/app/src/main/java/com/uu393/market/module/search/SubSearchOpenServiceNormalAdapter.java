package com.uu393.market.module.search;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.request.GetRequest;
import com.lzy.okserver.download.DownloadInfo;
import com.lzy.okserver.download.DownloadManager;
import com.lzy.okserver.download.DownloadService;
import com.lzy.okserver.listener.DownloadListener;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.DownloadHelper;
import com.uu393.market.model.request.GGetGameDetail;
import com.uu393.market.model.response.BGame;
import com.uu393.market.model.response.BServrerItem;
import com.uu393.market.module.center.ApkListAdapterNew;
import com.uu393.market.module.home.ApkListAdapter;
import com.uu393.market.module.home.AppDetailActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ApkUtils;
import com.uu393.market.util.GlideRoundTransform;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.view.progressbutton.SubmitProcessButton;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

import static com.uu393.market.Constant.UMENG_EVENT_ID_DOWNLOAD;
import static com.uu393.market.app.App.mContext;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/4/1
 * Descrip    :
 * =====================================================
 */

public class SubSearchOpenServiceNormalAdapter extends RecyclerView.Adapter<SubSearchOpenServiceNormalAdapter.SubSearchOpenServiceNormalHolder> {

    private List<BServrerItem> mBServrerItem;
    private Activity mcontext;
    private DownloadManager mDownloadManager;

    public SubSearchOpenServiceNormalAdapter(Activity contect){
            this.mcontext = contect;
        this.mDownloadManager = DownloadService.getDownloadManager();
    }

    public  void updateData(List<BServrerItem> list){
        this.mBServrerItem = list;
        notifyDataSetChanged();
    }



    @Override
    public SubSearchOpenServiceNormalHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_open_service_normal_sub_item, parent, false);
        return new SubSearchOpenServiceNormalHolder(view);
    }

    @Override
    public void onBindViewHolder(SubSearchOpenServiceNormalHolder holder, int position) {
        if (holder!=null &&holder instanceof SubSearchOpenServiceNormalHolder && mBServrerItem.get(position) !=null){
            holder.bindItem(position);
            holder.refresh();
        }
    }

    @Override
    public int getItemCount() {
        return mBServrerItem.size();
    }

    public class SubSearchOpenServiceNormalHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        private BServrerItem bServrerItem;
        private BGame bGame;
        private DownloadInfo downloadInfo;
        private ImageView appIcon;
        private TextView appName;
        private TextView appDiscount;
        private TextView appServiceName;
        private SubmitProcessButton downloadBt;
        private DownloadListener downloadListener;
        private LinearLayout mLvGoDetail;

        public SubSearchOpenServiceNormalHolder(View itemView) {
            super(itemView);
            appIcon = (ImageView) itemView.findViewById(R.id.iv_app_icon);
            appName = (TextView) itemView.findViewById(R.id.tv_one);
            appDiscount = (TextView) itemView.findViewById(R.id.tv_discount);
            appServiceName = (TextView) itemView.findViewById(R.id.tv_two);
            downloadBt = (SubmitProcessButton) itemView.findViewById(R.id.download_button);
            mLvGoDetail = (LinearLayout) itemView.findViewById(R.id.lv_go_detail);
        }

        public void bindItem(int position){
             bServrerItem= mBServrerItem.get(position);

            bGame = new BGame();
            bGame.setVersionCode("0");
            bGame.setGameName(bServrerItem.getGameName());
            bGame.setPackageName(bServrerItem.getPackageName());
            bGame.setId(bServrerItem.getId());
            bGame.setIcon(bServrerItem.getIcon());
            bGame.setTypeName(bServrerItem.getServerName());
            bGame.setAndroidPackage(bServrerItem.getAndroidPackage());

            mLvGoDetail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mcontext, AppDetailActivity.class);
                    intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_ID, bServrerItem.getId());
                    intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_PACKAGENAME, bServrerItem.getPackageName());
                    mcontext.startActivity(intent);
                }
            });



            //更新持有的downloadInfo对象
            downloadInfo = mDownloadManager.getDownloadInfo(bServrerItem.getId());
            if (null != downloadInfo) {
                downloadListener = new SubSearchOpenServiceNormalAdapter.MyDownloadListener();
                downloadListener.setUserTag(this);
                downloadInfo.setListener(downloadListener);
            }

            //固定不变的在这里设置
            int defaultAndError = ImageHelper.randomImage();
            Glide.with(App.mContext)
                    .load("http://images.uu898.com//uploadFiles//SYAppMarketImgs//2017//0408//636272419411598394-114-52-30.png")
                    .error(defaultAndError)
                    .placeholder(defaultAndError)
                    .transform(new GlideRoundTransform(App.mContext, 10))
                    .into(appIcon);


            appName.setText(bServrerItem.getGameName());
            appDiscount.setText(bServrerItem.getDiscount());
            appServiceName.setText(bServrerItem.getServerName());
            downloadBt.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

            if (v.getId() == R.id.download_button) {
                EB.postEmpty(EB.TAG.REQUEST_SD_CARD_SEARCH_OPEN_SERVICE);
                String text = downloadBt.getText().toString();
                if (text.equals("打开")) {
                    EB.postObject(EB.TAG.CLICK_PLAY, bGame);
                    ApkUtils.launchApp(mContext, bGame.getPackageName());
                }
                if (text.equals("安装")) {
                    //先判断安装文件是否存在
                    File temp = new File(downloadInfo.getTargetPath());
                    if (temp.exists()) {
                        ApkUtils.install(mContext, temp);
                        EB.postObject(EB.TAG.CLICK_INSATLL, bGame);
                    } else {
                        mDownloadManager.removeTask(bServrerItem.getId(), true);
                        ToastUtil.showToast(mContext, "安装包可能被删除了，请重新下载");
                        notifyDataSetChanged();
                    }
                }
                if (text.equals("下载") || text.equals("更新")) {
                    //一旦触发下载动作(下载/更新/重试/继续),都要综合判断当前手机情况及设置是否允许下载
                    if (DownloadHelper.checkCanDownload(mContext)) {
                        HashMap<String, String> map = new HashMap<>();
                        map.put("gameName", bServrerItem.getGameName());
                        MobclickAgent.onEvent(mContext, UMENG_EVENT_ID_DOWNLOAD, map);//友盟统计下载事件
                        String url = bServrerItem.getAndroidPackage();

                        if (StringUtils.isEmpty(url)) {
                            ToastUtil.showToast(mContext, "下载链接错误 " + url);
                            return;
                        }
                        GetRequest request = OkGo.get(bServrerItem.getAndroidPackage());
                        mDownloadManager.addTask(bGame.getId(), bGame, request, downloadListener);
                        notifyDataSetChanged();
                    }
                }
                if (text.equals("重试") || text.equals("暂停中")) {
                    if (DownloadHelper.checkCanDownload(mContext)) {
                        mDownloadManager.addTask(bGame.getId(), downloadInfo.getRequest(), downloadInfo.getListener());
                    }
                }
                if (text.contains("%")) {
                    mDownloadManager.pauseTask(downloadInfo.getTaskKey());
                }
                if (text.equals("等待")) {
                    ToastUtil.showToast(mContext, "已经加入下载队列");
                }
            } else if (v.getId() == R.id.layout_one){
//                Intent intent = new Intent(mContext, AppDetailActivity.class);
//                intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_ID, bServrerItem.getId());
//                mContext.startActivity(intent);

            }
        }


        //更新单项内容显示状态
        private void refresh() {
            //先根据包名判断游戏是否安装
            if (ApkUtils.hasInstalled(mContext, bServrerItem.getPackageName())) {
                //InstalledHelper.getInstance(App.mContext).addOneInstalledRecord(gameModel.getPackageName(), gameModel.getId());
                //已安装的,有可能正在升级
                if (null != downloadInfo && downloadInfo.getState() == DownloadManager.DOWNLOADING) {
                    double progress = Math.round(downloadInfo.getProgress() * 10000.00) * 1 / 100.00;
                    downloadBt.setProgress(progress, progress + "%");
                    return;
                }
                //已经安装的,需要判断是否需要升级
                if (ApkUtils.whetherUpdate(mContext, bServrerItem.getPackageName(), "0")) {
                    downloadBt.setProgress("更新");
                } else {
                    downloadBt.setProgress("打开");
                    downloadBt.setTextColor(mContext.getResources().getColor(R.color.white));
                    downloadBt.setBackground(mContext.getResources().getDrawable(R.drawable.third_pb_green));
                }
                return;
            }

            if (null == downloadInfo) {
                downloadBt.setProgress("下载");
                downloadBt.setTextColor(mContext.getResources().getColor(R.color.blue));
                downloadBt.setBackground(mContext.getResources().getDrawable(R.drawable.third_pb_normal));
                return;
            }
            switch (downloadInfo.getState()) {
                case DownloadManager.NONE:
                    downloadBt.setProgress("下载");
                    break;
                case DownloadManager.DOWNLOADING:
                    double progress = Math.round(downloadInfo.getProgress() * 10000.00) * 1 / 100.00;
                    downloadBt.setProgress(progress, progress + "%");
                    break;
                case DownloadManager.PAUSE://当前为暂停状态
                    downloadBt.setProgress(Math.round(downloadInfo.getProgress() * 10000) * 1 / 100.00, "暂停中");
                    break;
                case DownloadManager.WAITING://当前为等待状态
                    downloadBt.setProgress("等待");
                    break;
                case DownloadManager.ERROR://当前为错误状态
                    downloadBt.setProgress("重试");
                    break;
                case DownloadManager.FINISH://当前为完成状态
                    if (ApkUtils.hasInstalled(mContext, new File(downloadInfo.getTargetPath()))) {
                        //这里需要再判断当前已安装的版本号是否为最新的，否，显示为安装
                        downloadBt.setProgress("打开");

                    } else {
                        downloadBt.setProgress("安装");
                        downloadBt.setTextColor(App.mContext.getResources().getColor(R.color.white));
                        downloadBt.setBackground(mContext.getResources().getDrawable(R.drawable.third_pb_pressed));
                    }
                    break;
            }
        }
        
    }

    private class MyDownloadListener extends DownloadListener {

        public MyDownloadListener() {
        }

        @Override
        public void onProgress(DownloadInfo downloadInfo) {
            //需要找到正确的位置刷新
            if (getUserTag() == null) {
                return;
            }
            SubSearchOpenServiceNormalAdapter.SubSearchOpenServiceNormalHolder holder = ( SubSearchOpenServiceNormalAdapter.SubSearchOpenServiceNormalHolder) getUserTag();
            holder.refresh();  //这里不能使用传递进来的 DownloadInfo，否者会出现条目错乱的问题

        }

        @Override
        public void onFinish(DownloadInfo downloadInfo) {
            //BGame game = (BGame) downloadInfo.getData();
            // ToastUtil.showToast(mContext, game.getGameName() + "已经下载完成");
            if (downloadInfo == null)
                return;
            String taskKey = downloadInfo.getTaskKey();
            if (taskKey == null)
                return;
            GGetGameDetail model = new GGetGameDetail(taskKey);
            TaskEngine.setTokenUseridPhoneState(1);
            TaskEngine.getInstance().doGetGameDetail(model, new JsonCallback<BGame>() {
                @Override
                public void onSuccess(BGame bGame, Call call, Response response) {
                    if (bGame != null && bGame.getGameName() != null)
                        ToastUtil.showToast(mContext, bGame.getGameName() + "已经下载完成");
                }
            });
            DownloadHelper.addOneDownloadRecord(mContext, downloadInfo);//todo 向缓存的下载记录中加入一条游戏信息记录
        }

        @Override
        public void onError(DownloadInfo downloadInfo, String errorMsg, Exception e) {
            if (StringUtils.isEmpty(errorMsg)) {
                errorMsg = "下载出错，请重试";
            }
            ToastUtil.showToast(mContext, errorMsg);
        }
    }
}
