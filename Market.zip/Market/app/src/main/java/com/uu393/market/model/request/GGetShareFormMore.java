package com.uu393.market.model.request;

import java.io.Serializable;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/14
 * Description    :
 * =====================================================
 */

public class GGetShareFormMore implements Serializable{
    /**
     {
     "beginTime":"2017-10-25",（开始时间）
     "endTime":"2017-10-25",（结束时间）
     }
     */

    private String beginTime;
    private String endTime;

    public String getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(String beginTime) {
        this.beginTime = beginTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
}
