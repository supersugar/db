package com.uu393.market.module.center.timepicker.listener;


public interface OnDismissListener {
    public void onDismiss(Object o);
}
