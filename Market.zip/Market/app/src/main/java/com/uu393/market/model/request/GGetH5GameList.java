package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/2
 * Descrip    :
 * =====================================================
 */

public class GGetH5GameList {

    /**
     * gameType : -1
     * gameName : -1
     * isTopSearch : 0
     */

    private String gameType;
    private String gameName;
    private String isTopSearch;

    public String getGameType() {
        return gameType;
    }

    public void setGameType(String gameType) {
        this.gameType = gameType;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }

    public String getIsTopSearch() {
        return isTopSearch;
    }

    public void setIsTopSearch(String isTopSearch) {
        this.isTopSearch = isTopSearch;
    }
}
