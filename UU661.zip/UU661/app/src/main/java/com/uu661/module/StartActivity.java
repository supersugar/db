package com.uu661.module;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.jaeger.library.StatusBarUtil;
import com.uu661.R;

import me.yokeyword.fragmentation.SupportActivity;

public class StartActivity extends SupportActivity{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //        官方在Android6.0中提供了亮色状态栏模式,就是说状态栏上的文字和图标都是黑色,比如使用了白色的背景,测试有效
        //        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        //            StatusBarUtil.setColor(this, getResources().getColor(R.color.colorPrimary), 0);
        //            this.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View
        //                    .SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        //        }
//        requestWindowFeature(Window.FEATURE_NO_TITLE);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
//        StatusBarUtil.setColor(this, getResources().getColor(R.color.white), 50);
        StatusBarUtil.setTransparent(this);
        setContentView(R.layout.activity_start);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(StartActivity.this, MainActivity.class);
                intent.putExtra(MainActivity.INTENT_KEY_CHECK_UPDATE, true);
                startActivity(intent);
                finish();
            }
        }, 1000);
    }

}
