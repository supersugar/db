package com.uu661.module;

import android.Manifest;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.MotionEvent;

import com.bugtags.library.Bugtags;
import com.umeng.message.IUmengCallback;
import com.umeng.message.PushAgent;
import com.uu661.R;
import com.uu661.util.CommonUtils;
import com.uu661.util.PushUtil;
import com.uu661.util.log.L;
import com.uu661.view.bottombar.BottomBar;

import me.yokeyword.fragmentation.SupportActivity;
import me.yokeyword.fragmentation.SupportFragment;
import me.yokeyword.fragmentation.anim.DefaultHorizontalAnimator;
import me.yokeyword.fragmentation.anim.FragmentAnimator;
import pub.devrel.easypermissions.EasyPermissions;

public class MainActivity extends SupportActivity {

    public static final String INTENT_KEY_CHECK_UPDATE = "intent_key_check_update";//是否检查更新

    public static final int FIRST = 0;
    public static final int SECOND = 1;
    public static final int THIRD = 2;
    public static final int FOURTH = 3;

    private SupportFragment[] mFragments = new SupportFragment[4];

    public static BottomBar mBottomBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (savedInstanceState == null) {
            loadRootFragment(R.id.fl_container, MainFragment.newInstance());
        }
        PushUtil.onAppStart(this);
        if (null != getIntent() && getIntent().getBooleanExtra(INTENT_KEY_CHECK_UPDATE, false)) {
            CommonUtils.checkUpdate(this, false);
        }
        //        StatusBarUtil.setTransparent(this);
        //        requestPermissions();
    }


    private void requestPermissions() {
        String[] mPermissionList = new String[]{
                //                Manifest.permission.ACCESS_FINE_LOCATION,       //位置信息
                //                Manifest.permission.CALL_PHONE,                 //电话相关
                //                Manifest.permission.READ_LOGS,
                //                Manifest.permission.READ_PHONE_STATE,           //电话相关
                //                Manifest.permission.GET_ACCOUNTS,
                //                Manifest.permission.SET_DEBUG_APP,
                Manifest.permission.WRITE_EXTERNAL_STORAGE};              //联系人,通讯录
        EasyPermissions.requestPermissions(MainActivity.this, "应用下载时需要保存到本地，为了保证核心功能的稳定性，请您同意授权该权限", 100, mPermissionList);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    @Override
    public void onBackPressedSupport() {
        // 对于 4个类别的主Fragment内的回退back逻辑,已经在其onBackPressedSupport里各自处理了
        super.onBackPressedSupport();
    }

    @Override
    public FragmentAnimator onCreateFragmentAnimator() {
        // 设置横向(和安卓4.x动画相同)
        return new DefaultHorizontalAnimator();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Bugtags.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Bugtags.onPause(this);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        Bugtags.onDispatchTouchEvent(this, event);
        return super.dispatchTouchEvent(event);
    }

    /**
     * 是否运行友盟推送,必须放在activity中写,在fragment中写无效
     *
     * @param enable
     */
    public void pushEnable(boolean enable) {
        PushAgent mPushAgent = PushAgent.getInstance(this);
        if (enable) {
            mPushAgent.enable(new IUmengCallback() {
                @Override
                public void onSuccess() {
                    L.d("打开友盟推送成功");
                }

                @Override
                public void onFailure(String s, String s1) {
                    L.d("onFailure" + s + " " + s1);
                }
            });
        } else {
            mPushAgent.disable(new IUmengCallback() {
                @Override
                public void onSuccess() {
                    L.d("关闭友盟推送成功");
                }

                @Override
                public void onFailure(String s, String s1) {
                    L.d("onFailure" + s + " " + s1);
                }
            });
        }
    }
}
