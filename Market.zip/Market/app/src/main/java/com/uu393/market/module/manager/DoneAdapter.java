package com.uu393.market.module.manager;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.lzy.okserver.download.DownloadInfo;
import com.lzy.okserver.download.DownloadManager;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GGetGameDetail;
import com.uu393.market.model.response.BGame;
import com.uu393.market.module.home.AppDetailActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ApkUtils;
import com.uu393.market.util.GlideRoundTransform;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;
import com.uu393.market.view.progressbutton.SubmitProcessButton;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import okhttp3.Call;
import okhttp3.Response;

public class DoneAdapter extends RecyclerView.Adapter<DoneAdapter.ApkHolder> {
    private Activity mContext;
    private List<DownloadInfo> mDoneDownloadInfo = new ArrayList<>();
    private DownloadManager mDownloadManager;

    private List<BGame> mGameList = new ArrayList<>();

    public DoneAdapter(Activity mContext,  DownloadManager mDownloadManager) {
        this.mContext = mContext;

        this.mDownloadManager = mDownloadManager;
    }

    public void setData(List<BGame> mGameList,List<DownloadInfo> mDoneDownloadInfo){
        this.mGameList = mGameList;
        this.mDoneDownloadInfo = mDoneDownloadInfo;
        notifyDataSetChanged();
    }

    @Override
    public ApkHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_manage_download_done, parent, false);
        return new ApkHolder(view);
    }

    @Override
    public void onBindViewHolder(ApkHolder holder, int position) {
        L.d("onBindViewHolder" + position);

        DownloadInfo downloadInfo = mDoneDownloadInfo.get(position);
        //holder更新持有对应的downloadinfo对象
        //感觉有问题
        if (mGameList !=null && !mGameList.isEmpty() && !mDoneDownloadInfo.isEmpty()){
            holder.bind(downloadInfo,mGameList.get(position));
            holder.refresh();
        }


    }

    @Override
    public int getItemCount() {
        return mDoneDownloadInfo.size();
    }

    public class ApkHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private View itemView;
        private DownloadInfo downloadInfo;
        private BGame gameModel;
        private ImageView icon;
        private TextView name;
        private TextView discount;
        private TextView size;
        private SubmitProcessButton downloadBt;

        public ApkHolder(View view) {
            super(view);
            itemView = view.findViewById(R.id.rl_download_done_parent);
            icon = (ImageView) view.findViewById(R.id.app_icon);
            name = (TextView) view.findViewById(R.id.tv_one);
            discount = (TextView) view.findViewById(R.id.tv_discount);
            size = (TextView) view.findViewById(R.id.tv_two);
            downloadBt = (SubmitProcessButton) view.findViewById(R.id.download_bt);
            int defaultAndError = ImageHelper.randomImage();
            icon.setImageResource(defaultAndError);
        }

        public void bind(DownloadInfo downloadInfo,BGame bGame) {
            this.downloadInfo = downloadInfo;

            //根据下载任务对应游戏的唯一标示游戏id从新请求游戏数据
                    gameModel=bGame;
                    int defaultAndError = ImageHelper.randomImage();

                    Glide.with(App.mContext)
                            .load(gameModel.getIcon())
                            .error(defaultAndError)
                            .placeholder(defaultAndError).transform(new GlideRoundTransform(App.mContext, 10))
                            .into(icon);
                    name.setText(gameModel.getGameName());
                    if (gameModel==null||gameModel.getDiscount()==null||gameModel.getDiscount().equals("10")) {
                        discount.setVisibility(View.GONE);
                    } else {
                        discount.setVisibility(View.VISIBLE);
                        discount.setText(gameModel.getDiscount() + "折");
                    }
                    size.setText(gameModel.getTypeName()+"/"+gameModel.getSize());

                    downloadBt.setOnClickListener(ApkHolder.this);
                    itemView.setOnClickListener(ApkHolder.this);

        }

        @Override
        public void onClick(View v) {
            if (v.getId() == R.id.download_bt) {
                String text = downloadBt.getText().toString();
                if (text.equals("打开")) {
                    EB.postObject(EB.TAG.CLICK_PLAY, gameModel);
                    ApkUtils.launchApp(mContext.getApplicationContext(), gameModel.getPackageName());
                }
                if (text.equals("安装")) {
                    //先判断安装文件是否存在
                    File temp = new File(downloadInfo.getTargetPath());
                    if (temp.exists()) {
                        EB.postObject(EB.TAG.CLICK_INSATLL, gameModel);
                        ApkUtils.install(mContext.getApplicationContext(), temp);

                    } else {
                        mDownloadManager.removeTask(gameModel.getId(), true);
                        ToastUtil.showToast(mContext, "安装包可能被删除了，请重新下载");
                        notifyDataSetChanged();
                    }
                }
            } else {//详情页
                Intent intent = new Intent(mContext, AppDetailActivity.class);
                intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_ID, gameModel.getId());
                intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_PACKAGENAME, gameModel.getPackageName());
                mContext.startActivity(intent);
            }
        }

        private void refresh() {
            if (ApkUtils.hasInstalled(mContext.getApplicationContext(), new File(downloadInfo.getTargetPath()))) {
                downloadBt.setProgress("打开");
            } else {
                downloadBt.setProgress("安装");
            }
        }
    }

}