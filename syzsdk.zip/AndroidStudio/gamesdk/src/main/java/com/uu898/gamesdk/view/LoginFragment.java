package com.uu898.gamesdk.view;

import android.graphics.Point;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu898.gamesdk.core.ListenerCenter;
import com.uu898.gamesdk.log.L;
import com.uu898.gamesdk.model.GBaseModel;
import com.uu898.gamesdk.model.request.GLogin;
import com.uu898.gamesdk.model.response.BLogin;
import com.uu898.gamesdk.model.response.BUserInfo;
import com.uu898.gamesdk.network.NetCallback;
import com.uu898.gamesdk.network.TaskEngine;
import com.uu898.gamesdk.support.listener.UGLoginListener;
import com.uu898.gamesdk.utils.AccountManager;
import com.uu898.gamesdk.utils.CommonUtils;
import com.uu898.gamesdk.utils.DevUtil;
import com.uu898.gamesdk.utils.FloatViewHelper;
import com.uu898.gamesdk.utils.StringUtils;
import com.uu898.gamesdk.utils.ToastUtil;
import com.uu898.gamesdk.utils.UGCache;
import com.uu898.gamesdk.utils.UGConstant;
import com.uu898.gamesdk.widget.AccountListPopWindow;

import org.xutils.x;

import java.util.ArrayList;
import java.util.List;

import static com.uu898.gamesdk.utils.CommonUtils.getUserNameList;


/**
 * Created by zhangbo on 2016/6/23.
 */
public class LoginFragment extends BaseFragment {

    private View mParentView;//父布局
    private View mViewLoginDialog;//登陆对话框
    private View mViewAutoLogin;//自动登陆view

    private EditText mEdtAccount;
    private EditText mEdtPassword;
    private ToggleButton mToggleButton;

    private AccountListPopWindow mPopWindow;

    private UGLoginListener mLoginListener;

    public static LoginFragment newInstance() {
        Bundle args = new Bundle();
        LoginFragment fragment = new LoginFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        return inflater.inflate(getLayoutId("ug_login"), container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.findViewById(getId("ug_bt_title_left")).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _mActivity.onBackPressed();
            }
        });
        mLoginListener = ListenerCenter.getInstance().getLoginListener();
        mViewLoginDialog = view.findViewById(getId("ug_login_content"));
        mViewAutoLogin = view.findViewById(getId("ug_login_auto_content"));

        handLastChangePW();
        handAutoLogin();

        contentAsDialog(mViewLoginDialog);

        mEdtAccount = (EditText) view.findViewById(getId("ug_edt_account"));
        mEdtPassword = (EditText) view.findViewById(getId("ug_edt_password"));
        mEdtAccount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (StringUtils.isEmpty(s.toString())) {
                    mEdtPassword.setText("");
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        setAccountInfo();


        view.findViewById(getId("parent_view")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_login_content")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_bt_register_tel")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_bt_register_syz")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_tv_reset_password")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_bt_next")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_bt_down")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_super_bt")).setOnClickListener(onClickListener);
        mToggleButton = (ToggleButton) view.findViewById(getId("ug_toggle_bt"));
        mToggleButton.setChecked(CommonUtils.getAutoLogin());
        mToggleButton.setOnCheckedChangeListener(onCheckedChangeListener);
    }


    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        L.d("onHiddenChanged" + hidden);
        if (hidden == false) {
            setAccountInfo();
        }
    }

    /**
     * 处理上次修改密码的事情
     */
    private void handLastChangePW() {
        boolean changed = UGCache.get(x.app()).getBoolean(UGConstant.Cache.LAST_CHANGE_PW, false);
        if (changed) {
            List<String> list = getUserNameList();
            if (null != list || !list.isEmpty()) {
                String lastAccount = list.get(0);
                CommonUtils.saveUserToken(lastAccount, "");
                UGCache.get(x.app()).put(UGConstant.Cache.LAST_CHANGE_PW, false);
            }
        }
    }

    /**
     * 处理自动登陆
     * 如果设置了自动登陆,且token未过期,则自动登陆
     * 如果设置了自动登陆,但token过期,展示登陆对话框
     * 如果未设置自动登陆,展示登陆对话框
     */
    private void handAutoLogin() {
        List<String> list = getUserNameList();
        if (null == list || list.isEmpty()) {
            showLoginDialog();
            return;
        }
        String token = CommonUtils.getTokenByUserName(list.get(0));
        if (StringUtils.isEmpty(token)) {//没有token值
            showLoginDialog();
            return;
        }
        boolean autoLogin = CommonUtils.getAutoLogin();
        if (autoLogin) {
            showAutoLogin(list.get(0), token);
        } else {
            showLoginDialog();
        }
    }

    /**
     * 展示登陆多画框
     */
    private void showLoginDialog() {
        mViewAutoLogin.setVisibility(View.GONE);
        mViewLoginDialog.setVisibility(View.VISIBLE);

    }

    boolean mIsClickChange = false;

    /**
     * 展示自动登陆框
     */
    private void showAutoLogin(final String account, final String token) {

        mViewAutoLogin.setVisibility(View.VISIBLE);
        mViewLoginDialog.setVisibility(View.GONE);
        TextView tv = (TextView) mViewAutoLogin.findViewById(getId("ug_tv_account"));
        ImageView changeAccount = (ImageView) mViewAutoLogin.findViewById(getId("ug_user_change"));
        tv.setText(account);
        changeAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //点击切换账号后,就不再自动登陆
                mIsClickChange = true;
                showLoginDialog();
            }
        });
        x.task().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mIsClickChange) {
                    return;
                } else {
                    login(account, "", token, true);
                }
            }
        }, 3000);
    }

    private void setAccountInfo() {
        List<String> accountList = getUserNameList();
        if (null != accountList && accountList.size() > 0) {
            String lastAccount = accountList.get(0);
            mEdtAccount.setText(lastAccount);
            mEdtAccount.setSelection(lastAccount.length());
            /*String lastToken = CommonUtils.getTokenByUserName(lastAccount);
            if (!StringUtils.isEmpty(lastToken)) {
                mEdtPassword.setText("******");
            }*/
        }
    }

    /**
     * 计算宽高,缩放view为dialog样式
     *
     * @param v
     */
    private void contentAsDialog(View v) {
        int[] point = onLayoutCallBack();
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(point[0], point[1]);
        params.addRule(RelativeLayout.CENTER_IN_PARENT);
        v.setLayoutParams(params);
    }

    public int[] onLayoutCallBack() {
        int space = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 40F, _mActivity.getResources()
                .getDisplayMetrics());
        Point point = CommonUtils.getScreenSize(_mActivity);
        int width = Math.min(point.x, point.y);
        int height = Math.max(point.x, point.y);
        return new int[]{width - space, height / 2};
    }

    CompoundButton.OnCheckedChangeListener onCheckedChangeListener = new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            CommonUtils.saveAutoLogin(isChecked);
        }
    };

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(v.getId() == getId("ug_login_content")) {

            }else if(v.getId() == getId("parent_view")){
                if(mViewAutoLogin.getVisibility() == View.VISIBLE){
                    //如果自动登陆框可见,点击灰色区域不结束界面
                }else{
                    _mActivity.finish();
                }
            }else if (v.getId() == getId("ug_bt_register_tel")) {
                start(RegisterPhoneFragment.newInstance());
            } else if (v.getId() == getId("ug_bt_register_syz")) {
                start(RegisterSyzFragment.newInstance());
            } else if (v.getId() == getId("ug_tv_reset_password")) {
                start(ResetPasswordFragment.newInstance());
            } else if (v.getId() == getId("ug_bt_down")) {
                showAccountPopWindow();
            } else if (v.getId() == getId("ug_bt_next")) {//登陆
                verifyLoginForm();
            } else if(v.getId() == getId("ug_super_bt")){
                DevUtil.getInstance(_mActivity).open();
            }
        }
    };

    private void showAccountPopWindow() {
        List<String> accountList = getUserNameList();
        if (null != accountList && accountList.size() > 1) {
            accountList.remove(0);
        }
        AccountListPopWindow popWindow = new AccountListPopWindow(_mActivity, mEdtAccount, (ArrayList<String>)
                accountList);
        popWindow.setOnItemClickListener(new AccountListPopWindow.OnItemClickListener() {
            @Override
            public void onItemClick(String s) {
                mEdtAccount.setText(s);
                mEdtAccount.setSelection(s.length());
                String lastToken = CommonUtils.getTokenByUserName(s);
                //切换账户后,要更新当前的ssid
                if (!StringUtils.isEmpty(lastToken)) {
                    mEdtPassword.setText("");
                }
            }
        });
        popWindow.showPopupWindow();
    }

    /**
     * 校验登陆表单信息
     */
    private void verifyLoginForm() {
        String account = mEdtAccount.getText().toString();
        String password = mEdtPassword.getText().toString();

        if (StringUtils.isEmpty(account)) {
            ToastUtil.showToast(_mActivity, "请输入帐号");
            return;
        }
        if (StringUtils.isEmpty(password)) {
            ToastUtil.showToast(_mActivity, "请输入密码");
            return;
        }
       /* //点击了登陆按钮,一种是靠账号密码登陆/一种是靠token登陆
        String currentToken = CommonUtils.getTokenByUserName(account);
        if (!StringUtils.isEmpty(account) && !StringUtils.isEmpty(currentToken)) {
            login(account, "", currentToken, true);
        } else {
            login(account, password, "", false);
        }*/
       //只要点击登录按钮，就是账号密码登录
        login(account, password, "", false);
    }

    /**
     * 登陆请求
     *
     * @param account
     * @param password
     */
    private void login(final String account, String password, String token, boolean autoLogin) {
        GLogin model = new GLogin();
        model.setUserId(account);
        if (autoLogin == false) {//手动填写密码登陆
            model.setPassword(CommonUtils.encryptString(password));
            model.setSSID("");
        } else {//自动登陆
            model.setPassword("");
            model.setSSID(token);
        }
        TaskEngine.getInstance().doLogin(model, new NetCallback<BLogin>(this) {
            @Override
            public void _onNext(BLogin bLogin) {
                AccountManager.getInstance().saveLoginInfo(bLogin.SSID, bLogin.userid, AccountManager.Status.LOGIN);
                doGetUserInfo(bLogin);
            }

            @Override
            public void _onError(String code) {
                //登陆失败
                CommonUtils.updateUserNameList(account);
                if(code.equals("SDKERROR000102")){//你尚未登录或登录已失效
                    List<String> accountList = getUserNameList();
                    if (null != accountList && accountList.size() > 0) {
                        final String lastAccount = accountList.get(0);
                        CommonUtils.saveUserToken(lastAccount, "");
                        _mActivity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                showLoginDialog();
                                mEdtAccount.setText(lastAccount);
                                mEdtAccount.setSelection(lastAccount.length());
                                mEdtPassword.setText("");
                            }
                        });
                    }
                }
            }
        });
    }

    private void doGetUserInfo(final BLogin bLogin) {
        TaskEngine.getInstance().doGetUserInfo(new GBaseModel(), new NetCallback<BUserInfo>(this) {
            @Override
            public void _onNext(BUserInfo result) {
                ToastUtil.showToast(_mActivity, "登陆成功");
                AccountManager.getInstance().saveAccountInfo(result);
                FloatViewHelper.showFloatingView();
                mLoginListener.onSuccess(AccountManager.getInstance().getSSID(), bLogin.uid);
                _mActivity.finish();
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }


}
