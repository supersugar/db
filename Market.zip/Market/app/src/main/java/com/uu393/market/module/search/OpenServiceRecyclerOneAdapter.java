package com.uu393.market.module.search;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.model.response.BServerListInGameDetail;

import java.util.List;

/**
 * Created by Administrator on 2017/4/19.
 */

public class OpenServiceRecyclerOneAdapter  extends RecyclerView.Adapter<OpenServiceRecyclerOneAdapter.OpenServerceHolder> {
    private List<BServerListInGameDetail> mBServerListInGameDetail;

    private Boolean isRefrech =false;

    public void setData(List<BServerListInGameDetail> list){
        this.mBServerListInGameDetail = list;
        notifyDataSetChanged();

    }

    public void setRefrech( Boolean misRefrech){
        isRefrech = misRefrech;
        notifyDataSetChanged();
    }


    @Override
    public OpenServiceRecyclerOneAdapter.OpenServerceHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_open_service, parent, false);
        return new OpenServiceRecyclerOneAdapter.OpenServerceHolder(view);
    }

    @Override
    public void onBindViewHolder(OpenServiceRecyclerOneAdapter.OpenServerceHolder holder, int position) {
        holder.bindItem(position);
    }

    @Override
    public int getItemCount() {


        if (isRefrech){
            return mBServerListInGameDetail.size();
        }
        if (mBServerListInGameDetail.size() == 0){
            return 0;
        }
        if (mBServerListInGameDetail.size() == 1){
            return 1;
        }
            return 2;
    }

    class OpenServerceHolder extends RecyclerView.ViewHolder{
        private TextView serviceName;
        private ImageView serviceAlert;
        private View serviceParent;
        public OpenServerceHolder(View itemView) {
            super(itemView);
            serviceName = (TextView) itemView.findViewById(R.id.tv_item_open_service_name);
            serviceAlert = (ImageView) itemView.findViewById(R.id.iv_item_open_service_alert);
            serviceParent = itemView.findViewById(R.id.item_open_service_parent);
        }

        public void bindItem(int position){
            BServerListInGameDetail BS = mBServerListInGameDetail.get(position);
            if (BS !=null){
                serviceName.setText(BS.getServerName()+" "+BS.getOpenTime());
            }


        }

    }
    public void refresh(){
        this.notifyDataSetChanged();
    }
}
