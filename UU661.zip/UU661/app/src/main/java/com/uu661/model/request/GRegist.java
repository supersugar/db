package com.uu661.model.request;

public class GRegist {

    public String userId;//
    public String password;//
    public String phoneCode;//验证码
    public String clientIP;//

    //以下参数是第三方登陆(如qq登陆)成功后,且无绑定账户时,需要注册新账户且绑定操作时传递
    public String loginType;//
    public String loginThirdId;//
    public String qqUnionid;//
    public String accessToken;//
}
