package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    :
 * =====================================================
 */

public class BUserCenterInfo implements Serializable {
    /**
     *{
     "userID": "123456",(用户名)
     "money": "58",(可用金额)
     "message": "58",(未读消息条数)
     "coupon": "58",(优惠券张数)
     "isShareSale": "True",(是否是分销用户)
     "isTxBank": "True",(是否是有提现银行卡)
     }
     */

    private String userID;
    private String money;
    private String message;
    private String coupon;
    private String isShareSale;
    private String isTxBank;

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCoupon() {
        return coupon;
    }

    public void setCoupon(String coupon) {
        this.coupon = coupon;
    }

    public String getIsShareSale() {
        return isShareSale;
    }

    public void setIsShareSale(String isShareSale) {
        this.isShareSale = isShareSale;
    }

    public String getIsTxBank() {
        return isTxBank;
    }

    public void setIsTxBank(String isTxBank) {
        this.isTxBank = isTxBank;
    }
}
