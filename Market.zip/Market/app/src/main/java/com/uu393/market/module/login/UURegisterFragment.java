package com.uu393.market.module.login;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.umeng.analytics.MobclickAgent;
import com.uu393.market.Constant;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GDoLogin;
import com.uu393.market.model.request.GDoRegister;
import com.uu393.market.model.response.BImageCode;
import com.uu393.market.model.response.BUserInfo;
import com.uu393.market.model.response.BUserToken;
import com.uu393.market.module.base.BaseFragment;
import com.uu393.market.module.h5game.H5WebViewActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.RsaHelper;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/16
 * Descrip    :
 * =====================================================
 */

public class UURegisterFragment extends BaseFragment {

    @Bind(R.id.et_register_uu_name)
    EditText mEtRegisterUuName;
    @Bind(R.id.et_register_uu_set_pass)
    EditText mEtRegisterUuSetPass;
    @Bind(R.id.et_register_uu_verify_pass)
    EditText mEtRegisterUuVerifyPass;
    @Bind(R.id.et_register_uu_code)
    EditText mEtRegisterUuCode;
    @Bind(R.id.iv_register_uu_random_code)
    ImageView mIvRegisterUuRandomCode;
    @Bind(R.id.btn_register_uu)
    Button mBtnRegisterUu;
    private String mUUUserName;
    private String mUUPassWord;
    private String mUUPassWordVerify;
    private String mRandomCode;

    private String mGameId;
    private String APPID;
    private String mGameUrl;
    public static UURegisterFragment newInstance() {
        UURegisterFragment fragment = new UURegisterFragment();
        fragment.setArguments(new Bundle());
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.register_uu_acount, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        doGetImageCode();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }

    @OnClick({R.id.iv_register_uu_random_code, R.id.btn_register_uu})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_register_uu_random_code:
                doGetImageCode();
                break;
            case R.id.btn_register_uu:
                doUURegister();
                break;
        }
    }


    private void doGetImageCode() {
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetImageCode(new JsonCallback<BImageCode>() {
            @Override
            public void onSuccess(BImageCode bImageCode, Call call, Response response) {
                String img = bImageCode.getValidateCodeImg();
                parseImage(mIvRegisterUuRandomCode, img);
                mCheckCodeToken = bImageCode.getToken();
            }
        });
    }

    private void parseImage(ImageView imageView, String pic) {
        Bitmap bitmap = null;
        try {
            byte[] bitmapArray;
            bitmapArray = Base64.decode(pic, Base64.DEFAULT);
            bitmap = BitmapFactory.decodeByteArray(bitmapArray, 0, bitmapArray.length);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (imageView != null) {
            imageView.setImageBitmap(bitmap);
        }
    }

    private String mCheckCodeToken;

    private void doUURegister() {
        mUUUserName = mEtRegisterUuName.getText().toString();
        mUUPassWord = mEtRegisterUuSetPass.getText().toString();
        mUUPassWordVerify = mEtRegisterUuVerifyPass.getText().toString();
        mRandomCode = mEtRegisterUuCode.getText().toString();

        if (StringUtils.isEmpty(mUUUserName)) {
            ToastUtil.showToast(App.mContext, "请输入账号");
            return;
        }
        if (StringUtils.isEmpty(mUUPassWord)) {
            ToastUtil.showToast(App.mContext, "请输入密码");
            return;
        }
        if (StringUtils.isEmpty(mUUPassWordVerify) || (!mUUPassWord.equals(mUUPassWordVerify))) {
            ToastUtil.showToast(App.mContext, "两次密码不一致");
            return;
        }
        if (StringUtils.isEmpty(mRandomCode)) {
            ToastUtil.showToast(App.mContext, "请输入验证码");
            return;
        }
        GDoRegister model = new GDoRegister();
        model.setRegisterType(Constant.REGISTER_TYPE_CUSTOM);//phone手机注册，custom自定义注册）
        model.setPassword(RsaHelper.encryptDataFromStr(mUUPassWordVerify, RsaHelper.RSA_PUBLIC_KEY));//"0"（设备类型：0安卓  1 IOS）
        model.setUserId(mUUUserName);
        model.setCheckCode(mRandomCode);
        model.setCheckCodeToken(mCheckCodeToken);
        model.setDecipheringType("0");
        TaskEngine.getInstance().doRegister(model, new JsonCallback<BUserToken>() {
            @Override
            public void onSuccess(BUserToken bUserToken, Call call, Response response) {
                SPUtil.put(App.mContext, "token", bUserToken.getToken());
                EB.postEmpty(EB.TAG.LOGIN_SUCCESS);
                mGameId = (String) SPUtil.get(App.mContext,"GameId","");
                APPID = (String) SPUtil.get(App.mContext,"APPID","");
                mGameUrl = (String) SPUtil.get(App.mContext,"GameUrl","");
                if (!TextUtils.isEmpty(mGameId)) {
                    //todo 登录请求一次，获取用户数据
                    final GDoLogin model = new GDoLogin();
                    model.setUserId(mUUUserName);
                    model.setPassword(RsaHelper.encryptDataFromStr(mUUPassWordVerify, RsaHelper.RSA_PUBLIC_KEY));
                    model.setDecipheringType("0");
                    TaskEngine.setTokenUseridPhoneState(1);
                    TaskEngine.getInstance().doLogin(model, new JsonCallback<BUserInfo>() {
                        @Override
                        public void onSuccess(BUserInfo bUserInfo, Call call, Response response) {
                            MobclickAgent.onProfileSignIn("uushouyou",bUserInfo.getUserId());//友盟统计用户登录
                            SPUtil.put(App.mContext, "isLogin", true);
                            SPUtil.put(App.mContext, "loginType", "0");
                            SPUtil.put(App.mContext, "thirdUserId", "");
                            SPUtil.put(App.mContext, "token", bUserInfo.getToken());
                            SPUtil.put(App.mContext, "userId", bUserInfo.getUserId());
                            SPUtil.put(App.mContext, "uId", bUserInfo.getUId());
                            SPUtil.put(App.mContext, "chkMobile", bUserInfo.getChkMobile());
                            _mActivity.startActivity(new Intent(_mActivity, RegisterSuccessActivity.class));
                            EB.postEmpty(EB.TAG.REGISTER_SUCCESS);
                        }

                    });
                }else {
                    _mActivity.startActivity(new Intent(_mActivity, RegisterSuccessActivity.class));
                    EB.postEmpty(EB.TAG.REGISTER_SUCCESS);
                }
            }
        });

    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart("UURegisterFragment");
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("UURegisterFragment");
    }
}
