package com.uu898.gamesdk.model.request;

import com.uu898.gamesdk.model.GBaseModel;

/**
 * Created by zhangbo on 2016/6/15.
 */
public class GRegister extends GBaseModel {

    public static final String REGISTER_TYPE_PHONE = "phone";//手机注册
    public static final String REGISTER_TYPE_CUSTOM = "custom";//自定义注册

    private String password;
    private String userId;

    private String registerType;//phone手机注册，custom自定义注册
    private String checkCode;//registerType为phone时为手机验证码，为custom时为图片验证码
    private String token;//如果registerType为custom则传token，token为获取图片验证码接口返回的token
    private int decipheringType = 0;//设备唯一标识码,0是安卓,1是ios

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getRegisterType() {
        return registerType;
    }

    public void setRegisterType(String registerType) {
        this.registerType = registerType;
    }

    public String getCheckCode() {
        return checkCode;
    }

    public void setCheckCode(String checkCode) {
        this.checkCode = checkCode;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
