package com.uu661.model.response;

import java.io.Serializable;

/**
 * Created by bo on 16/9/14.
 */
public class BThirdOrder implements Serializable {

    public String killOrderNo;//
    public String tradeNo;//
    public String signOrderNo;//
    public String status;//
}
