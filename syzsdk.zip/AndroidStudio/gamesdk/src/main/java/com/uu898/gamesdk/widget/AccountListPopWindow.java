package com.uu898.gamesdk.widget;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.uu898.gamesdk.core.ResourceUtils;

import java.util.ArrayList;

/**
 * Created by bo on 16/9/21.
 */

public class AccountListPopWindow extends PopupWindow {

    private ArrayList<String> list = new ArrayList<String>();

    // 用于保存PopupWindow的宽度
    private int width;
    // 用于保存PopupWindow的高度
    private int height;
    private View contentView;

    private ListView mListView;


    private MyAdapter myAdapter;
    private Context mContext;

    private View mAttachView;

    private OnItemClickListener mOnItemClickListener;

    public AccountListPopWindow(Activity context, View parent, ArrayList<String> list) {
        this.mContext = context;
        this.mAttachView = parent;
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        this.contentView = inflater.inflate(ResourceUtils.getLayoutId(context, "ug_account_list_popwindow"), null);
        mListView = (ListView) contentView.findViewById(ResourceUtils.getId(context, "ug_list_view"));
        this.setContentView(contentView);
        // 设置弹出窗体的宽
        this.setWidth(parent.getWidth());
        // 设置弹出窗体的高
        this.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        // 设置弹出窗体可点击
        this.setTouchable(true);
        this.setFocusable(true);
        // 设置点击是否消失
        this.setOutsideTouchable(true);
        //设置弹出窗体动画效果
        //        this.setAnimationStyle(R.style.mypopwindow_anim_style);
        //实例化一个ColorDrawable颜色为半透明
        //        ColorDrawable background = new ColorDrawable(0x4f000000);
        //        //设置弹出窗体的背景
        //        this.setBackgroundDrawable(background);
        // 绘制
        this.mandatoryDraw();

        this.list = list;

        mListView.setAdapter(new MyAdapter());

    }

    /**
     * 强制绘制popupWindowView，并且初始化popupWindowView的尺寸
     */
    private void mandatoryDraw() {
        this.contentView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        /**
         * 强制刷新后拿到PopupWindow的宽高
         */
        this.width = this.contentView.getMeasuredWidth();
        this.height = this.contentView.getMeasuredHeight();
    }


    public void showPopupWindow() {

        if (isShowing()) {
            this.dismiss();
        } else {
            if (null != list || !list.isEmpty()){
                this.showAsDropDown(mAttachView);
            }
        }
    }

    public void refreshList(ArrayList<String> list) {
        this.list = list;
        myAdapter.notifyDataSetChanged();
    }

    public interface OnItemClickListener{

        void onItemClick(String s);
    }

    public OnItemClickListener getOnItemClickListener() {
        return mOnItemClickListener;
    }

    public void setOnItemClickListener(OnItemClickListener mOnItemClickListener) {
        this.mOnItemClickListener = mOnItemClickListener;
    }

    private class MyAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int position) {
            return list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            convertView = LayoutInflater.from(mContext).inflate(ResourceUtils.getLayoutId(mContext, "ug_account_list_item"), null);
            TextView tv = (TextView) convertView.findViewById(ResourceUtils.getId(mContext, "ug_list_item_tv"));
            tv.setText(list.get(position));
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(null != mOnItemClickListener){
                        mOnItemClickListener.onItemClick(list.get(position));
                        AccountListPopWindow.this.dismiss();
                    }
                }
            });
            return convertView;
        }
    }

}
