package com.uu393.market.module.more;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.afollestad.materialdialogs.MaterialDialog;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.core.DevConfig;
import com.uu393.market.network.NetConstant;
import com.uu393.market.util.CommonUtils;
import com.uu393.market.util.ToastUtil;

import me.yokeyword.fragmentation_swipeback.SwipeBackFragment;

public class AboutFragment extends SwipeBackFragment {

    public static AboutFragment newInstance() {
        AboutFragment fragment = new AboutFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return attachToSwipeBack(inflater.inflate(R.layout.more_about_fragment, null));
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "关于", true);
        TextView version = (TextView) view.findViewById(R.id.tv_app_version);
        version.setText("版本号 : v" + CommonUtils.getVersionName(_mActivity));
        debug(view, DevConfig.DEBUG);
    }

    public View initTitleBar(View v, String title, boolean showBack) {
        TextView tvTitle = (TextView) v.findViewById(R.id.title_bar_title);
        tvTitle.setText(title);
        v.findViewById(R.id.title_bar_left).setVisibility(showBack ? View.VISIBLE : View.GONE);
        v.findViewById(R.id.title_bar_left).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _mActivity.onBackPressed();
            }
        });
        return v.findViewById(R.id.title_bar);
    }

    private void debug(View view, boolean debug){
        if(debug == false){
            return;
        }
        final String devVersion = "2016122900";
        final TextView tv = (TextView) view.findViewById(R.id.tv_dev_version);
        tv.setVisibility(View.VISIBLE);
        tv.setText("dev : " + devVersion + "\n url : " + DevConfig.getInstance().getURL());

        view.findViewById(R.id.img_about_logo).setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                new MaterialDialog.Builder(_mActivity)
                        .title("选择连接地址")
                        .items(NetConstant.URL.URL_OFFICAL, NetConstant.URL.URL_TEST)
                        .itemsCallbackSingleChoice(-1, new MaterialDialog.ListCallbackSingleChoice() {
                            @Override
                            public boolean onSelection(MaterialDialog dialog, View view, int which, CharSequence text) {
                                DevConfig.getInstance().setURL(which == 0 ? false : true);
                                ToastUtil.showToast(_mActivity, "当前连接地址 : " + DevConfig.getInstance().getURL());
                                tv.setText("dev : " + devVersion + "\n url : " + DevConfig.getInstance().getURL());
                                return true;
                            }
                        })
                        //                        .positiveText(R.string.choose)
                        .show();
                return false;
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart("AboutFragment");
        MobclickAgent.onResume(_mActivity);
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("AboutFragment");
        MobclickAgent.onPause(_mActivity);
    }
}
