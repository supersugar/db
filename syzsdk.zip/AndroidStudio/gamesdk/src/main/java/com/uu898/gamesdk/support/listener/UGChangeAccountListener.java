package com.uu898.gamesdk.support.listener;

public interface UGChangeAccountListener {
    void onChange();
}
