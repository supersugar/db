package com.uu661.module.discovery;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.uu661.R;
import com.uu661.module.base.BaseFragment;
import com.uu661.util.eventbus.EB;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;


public class DiscoveryDetailFragment extends BaseFragment {


    @BindView(R.id.discovery_bt) ImageView mDiscoveryBt;
    @BindView(R.id.title_bar_left) ImageButton mTitleBarLeft;

    public static DiscoveryDetailFragment newInstance() {
        DiscoveryDetailFragment fragment = new DiscoveryDetailFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.discovery_detail_fragment, null);
        ButterKnife.bind(this, view);
        return view;
    }

    @OnClick({R.id.discovery_bt, R.id.title_bar_left})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.discovery_bt:
                _mActivity.onBackPressed();
                EB.postEmpty(EB.TAG.GO_HOME);
                break;
            case R.id.title_bar_left:
                _mActivity.onBackPressed();
                break;
        }
    }
}
