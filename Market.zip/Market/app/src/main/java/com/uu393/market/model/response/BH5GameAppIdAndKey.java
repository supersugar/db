package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/31
 * Descrip    :
 * =====================================================
 */

public class BH5GameAppIdAndKey implements Serializable {

    /**
     *{
     "channelAPPID": "123456",(实际渠道需要appid)
     "md5Key": "896145ss",(key值)
     }

     */

    private String channelAPPID;
    private String md5Key;

    public String getChannelAPPID() {
        return channelAPPID;
    }

    public void setChannelAPPID(String channelAPPID) {
        this.channelAPPID = channelAPPID;
    }

    public String getMd5Key() {
        return md5Key;
    }

    public void setMd5Key(String md5Key) {
        this.md5Key = md5Key;
    }
}
