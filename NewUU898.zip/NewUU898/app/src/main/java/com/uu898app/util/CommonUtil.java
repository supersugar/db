package com.uu898app.util;

import android.net.wifi.WifiManager;
import android.provider.Settings;

import com.uu898app.app.App;
import com.uu898app.network.NetConstant;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * Created by zhangbo on 2016/7/12.
 */
public class CommonUtil {

    /**
     * 获取设备唯一id
     * @return
     */
    public static String getDeviceId() {
        String deviceId = "";
        try {
            WifiManager wm = (WifiManager) App.mContext.getSystemService(App.mContext.WIFI_SERVICE);
            deviceId = Settings.Secure.getString(App.mContext.getContentResolver(), Settings.Secure.ANDROID_ID);
            if (deviceId == null) {
                deviceId = wm.getConnectionInfo().getMacAddress();
                if (deviceId != null)
                    deviceId = deviceId.replaceAll(":", "");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return deviceId;
    }

    /**
     * 加密字符串
     * String -> byte[] (utf-8格式) -> Rsa加密 -> Base64.encode -> UrlEncoder.encode
     * @param original
     * @return
     */
    public static String encryptString(String original){
        if(StringUtils.isNull(original)){
            return "";
        }
        String result = "";
        byte[] dataByteArray = new byte[0];//
        try {
            dataByteArray = original.getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        byte[] encryptedDataByteArray = RsaHelper.encryptData(dataByteArray, NetConstant.Secret.RSA_PUBLIC_KEY);
        result = URLEncoder.encode(Base64Helper.encode(encryptedDataByteArray));
        return result;
    }
}
