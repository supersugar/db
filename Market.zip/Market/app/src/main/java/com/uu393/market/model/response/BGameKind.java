package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * Created by bo on 16/9/14.
 */
public class BGameKind implements Serializable {

    public String id;//游戏类型的唯一ID
    public String typeName;//类型名称
}
