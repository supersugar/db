package com.uu393.market.module.search;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.request.GetRequest;
import com.lzy.okserver.download.DownloadInfo;
import com.lzy.okserver.download.DownloadManager;
import com.lzy.okserver.download.DownloadService;
import com.lzy.okserver.listener.DownloadListener;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.DownloadHelper;
import com.uu393.market.model.request.GGetGameDetail;
import com.uu393.market.model.response.BGame;
import com.uu393.market.model.response.BServerListByGameName;
import com.uu393.market.model.response.BServerListInGameDetail;
import com.uu393.market.module.home.AppDetailActivity;
import com.uu393.market.module.home.OpenServiceRecyclerAdapter;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ApkUtils;
import com.uu393.market.util.DateUtils;
import com.uu393.market.util.GlideRoundTransform;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.view.progressbutton.SubmitProcessButton;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

import static com.uu393.market.Constant.UMENG_EVENT_ID_DOWNLOAD;
import static com.uu393.market.app.App.mContext;

/**
 * Created by Administrator on 2017/4/19.
 */

public class SearchSomeOneOpenServiceAdapter extends RecyclerView.Adapter<SearchSomeOneOpenServiceAdapter.SearchSomeOneOpenServiceViewHolder>{
    private Activity mContext;
    private DownloadManager mDownloadManager;
    private List<BServerListByGameName> mBServerListByGameName = new ArrayList<>();




    public SearchSomeOneOpenServiceAdapter(Activity mContext){
        this.mContext = mContext;
        this.mDownloadManager = DownloadService.getDownloadManager();
    }

    public void refresh(List<BServerListByGameName> list){
        this.mBServerListByGameName = list;
        notifyDataSetChanged();
    }



    @Override
    public SearchSomeOneOpenServiceAdapter.SearchSomeOneOpenServiceViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.search_someone_item, parent, false);
        return new SearchSomeOneOpenServiceViewHolder(view);
    }

    @Override
    public void onBindViewHolder(SearchSomeOneOpenServiceViewHolder holder, int position) {
        if (holder !=null && holder instanceof SearchSomeOneOpenServiceViewHolder){
            holder.bindItem(position);
            holder.refresh();
        }

    }


    @Override
    public int getItemCount() {
        return mBServerListByGameName.size();
    }

    public class SearchSomeOneOpenServiceViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private BServerListByGameName SByGameName;

        private BGame bGame;
        private ImageView mapp_icon;
        private TextView mtv_one;
        private TextView mtv_discount;
        private TextView mtv_two;
        private TextView mtv_bt;
        private TextView mtv_first;
        private TextView mtv_add;
        private TextView mtv_gift;
        private TextView mtv_three;
        private LinearLayout mlayout_one;
        private LinearLayout mmore_two;
        private LinearLayout mitem_open;
        private View mless_two;
        private SubmitProcessButton downloadBt;
        private RecyclerView mRecycleView;
        private OpenServiceRecyclerOneAdapter adapter;
        private DownloadInfo downloadInfo;
        private DownloadListener downloadListener;
        private List<BServerListInGameDetail> mBServerListInGameDetail;
        //防止点击下载时重复加载数据
        private Boolean mJustFirst = true;


        public SearchSomeOneOpenServiceViewHolder(View itemView) {
            super(itemView);
            if (itemView !=null){
                mapp_icon = (ImageView) itemView.findViewById(R.id.app_icon);
                mtv_one = (TextView) itemView.findViewById(R.id.tv_one);
                mtv_discount = (TextView) itemView.findViewById(R.id.tv_discount);
                mtv_two = (TextView) itemView.findViewById(R.id.tv_two);
                mtv_bt = (TextView) itemView.findViewById(R.id.tv_bt);
                mtv_first = (TextView) itemView.findViewById(R.id.tv_first);
                mtv_add = (TextView) itemView.findViewById(R.id.tv_add);
                mtv_gift = (TextView) itemView.findViewById(R.id.tv_gift);
                mtv_three = (TextView) itemView.findViewById(R.id.tv_three);
                mmore_two = (LinearLayout) itemView.findViewById(R.id.more_two);
                mless_two = (View) itemView.findViewById(R.id.less_two);
                mlayout_one = (LinearLayout) itemView.findViewById(R.id.layout_one);
                downloadBt = (SubmitProcessButton) itemView.findViewById(R.id.download_bt);
                mitem_open = (LinearLayout) itemView.findViewById(R.id.item_open);
                mBServerListInGameDetail = new ArrayList<>();

                mRecycleView = (RecyclerView) itemView.findViewById(R.id.rv_open_service_normal_in_item);
                adapter = new OpenServiceRecyclerOneAdapter();
                mitem_open.setOnClickListener(this);
                mlayout_one.setOnClickListener(this);
                downloadBt.setOnClickListener(this);
            }


        }

        public void bindItem(int position){
             SByGameName = mBServerListByGameName.get(position);

            bGame = new BGame();
            bGame.setVersionCode("0");
            bGame.setGameName(SByGameName.getGameName());
            bGame.setPackageName(SByGameName.getPackageName());
            bGame.setId(SByGameName.getId());
            bGame.setIcon(SByGameName.getIcon());
            bGame.setAndroidPackage(SByGameName.getAndroidPackage());

            //更新持有的downloadInfo对象
            downloadInfo = mDownloadManager.getDownloadInfo(SByGameName.getId());
            if (null != downloadInfo) {
                downloadListener = new SearchSomeOneOpenServiceAdapter.MyDownloadListener();
                downloadListener.setUserTag(this);
                downloadInfo.setListener(downloadListener);
            }

            mRecycleView.setLayoutManager(new GridLayoutManager(mContext,2, LinearLayoutManager.VERTICAL,false));
            mRecycleView.setAdapter(adapter);
            mtv_one.setText(SByGameName.getGameName());
            mtv_discount.setText(SByGameName.getDiscount() +"折");
            mtv_two.setText(SByGameName.getTypeName()+ " / " +SByGameName.getSize());

            //固定不变的在这里设置
            int defaultAndError = ImageHelper.randomImage();
            Glide.with(App.mContext).load(SByGameName.getIcon()).error(defaultAndError).placeholder(defaultAndError).transform(new
                    GlideRoundTransform(App.mContext, 10)).into(mapp_icon);

            
            if (!SByGameName.getTypeName().equals("BT游戏")) {
                mtv_bt.setVisibility(View.GONE);
            } else {
                mtv_bt.setVisibility(View.VISIBLE);
            }

            if (!TextUtils.isEmpty(SByGameName.getIsFirst())){
                if ("1".equals(SByGameName.getIsFirst())){//是首发游戏
                    String mtv_firstTime = SByGameName.getFirstTime();
                    if (TextUtils.isEmpty(mtv_firstTime)){
                        mtv_first.setVisibility(View.GONE);
                    }else {

                        Date date = DateUtils.parse(mtv_firstTime,"yyyy-MM-dd HH:mm:ss");//"mtv_firstTime": "2017-3-31 00:00:00”,(首发时间)
                        SimpleDateFormat format = new SimpleDateFormat("MM-dd");
                        if (date!=null){

                            SimpleDateFormat formatDay = new SimpleDateFormat("d日");
                            String day = formatDay.format(date);
                            Date nextDay = DateUtils.getNextDay(new Date());
                            Calendar calendar = Calendar.getInstance();
                            calendar.setTime(date);
                            calendar.add(Calendar.DAY_OF_MONTH, 7);
                            Date dateAfterSeven  = calendar.getTime();

                            int compareTo = dateAfterSeven.compareTo(new Date());
                            if (format.format(date).equals(format.format(new Date()))){//当天
                                mtv_first.setVisibility(View.VISIBLE);
                                mtv_first.setText("今日首发");
                            }else if (format.format(date).equals(format.format(nextDay))){
                                mtv_first.setVisibility(View.VISIBLE);
                                mtv_first.setText("明日首发");
                            } else if (compareTo<0){//已经超过一周，不显示
                                mtv_first.setVisibility(View.GONE);
                            }else {
                                mtv_first.setVisibility(View.VISIBLE);
                                mtv_first.setText(day+"首发");
                            }

                        }else {
                            mtv_first.setVisibility(View.GONE);
                        }
                    }
                }else {
                    mtv_first.setVisibility(View.GONE);
                    //mtv_first.setText("31日首发");
                }
            }
//            if ("1".equals(SByGameName.getIsQuick())){//是加速版游戏
//                mtv_add.setVisibility(View.VISIBLE);
//            }else{
//                mtv_add.setVisibility(View.GONE);
//            }
//
//            if ("1".equals(SByGameName.getIsGift())){//有礼包
//                mtv_gift.setVisibility(View.VISIBLE);
//            }else{
//                mtv_gift.setVisibility(View.GONE);
//            }

            if (SByGameName.getServerList() !=null && !SByGameName.getServerList().isEmpty() && mJustFirst){
                for (BServerListByGameName.ServerList game: SByGameName.getServerList()) {
                    BServerListInGameDetail gameMolde = new BServerListInGameDetail();
                    gameMolde.setId(game.getId());
                    gameMolde.setServerName(game.getServerName());
                    gameMolde.setOpenTime(game.getOpenTime());
                    mBServerListInGameDetail.add(gameMolde);
                }

                if ( mBServerListInGameDetail.size()>2){
                    mmore_two.setVisibility(View.VISIBLE);
                    mless_two.setVisibility(View.GONE);
                }else{
                    mmore_two.setVisibility(View.GONE);
                    mless_two.setVisibility(View.VISIBLE);
                }
                mJustFirst = false;
                adapter.setData(mBServerListInGameDetail);
            }
        }


        @Override
        public void onClick(View v) {

            if (v.getId() == R.id.item_open){
                adapter.setRefrech(true);
                mless_two.setVisibility(View.VISIBLE);
                mmore_two.setVisibility(View.GONE);
            }else if (v.getId() == R.id.download_bt){
                if (v.getId() == R.id.download_bt) {
                    EB.postEmpty(EB.TAG.REQUEST_SD_CARD_SEARCH_OPEN_SERVICE);
                    String text = downloadBt.getText().toString();
                    if (text.equals("打开")) {
                        EB.postObject(EB.TAG.CLICK_PLAY, bGame);
                        ApkUtils.launchApp(mContext, bGame.getPackageName());
                    }
                    if (text.equals("安装")) {
                        //先判断安装文件是否存在
                        File temp = new File(downloadInfo.getTargetPath());
                        if (temp.exists()) {
                            ApkUtils.install(mContext, temp);
                            EB.postObject(EB.TAG.CLICK_INSATLL, bGame);
                        } else {
                            mDownloadManager.removeTask(SByGameName.getId(), true);
                            ToastUtil.showToast(mContext, "安装包可能被删除了，请重新下载");
                            notifyDataSetChanged();
                        }
                    }
                    if (text.equals("下载") || text.equals("更新")) {
                        //一旦触发下载动作(下载/更新/重试/继续),都要综合判断当前手机情况及设置是否允许下载
                        if (DownloadHelper.checkCanDownload(mContext)) {
                            HashMap<String, String> map = new HashMap<>();
                            map.put("gameName", SByGameName.getGameName());
                            MobclickAgent.onEvent(mContext, UMENG_EVENT_ID_DOWNLOAD, map);//友盟统计下载事件
                            String url = SByGameName.getAndroidPackage();

                            if (StringUtils.isEmpty(url)) {
                                ToastUtil.showToast(mContext, "下载链接错误 " + url);
                                return;
                            }
                            GetRequest request = OkGo.get(SByGameName.getAndroidPackage());
                            mDownloadManager.addTask(bGame.getId(), bGame, request, downloadListener);
                            notifyDataSetChanged();
                        }
                    }
                    if (text.equals("重试") || text.equals("暂停中")) {
                        if (DownloadHelper.checkCanDownload(mContext)) {
                            mDownloadManager.addTask(bGame.getId(), downloadInfo.getRequest(), downloadInfo.getListener());
                        }
                    }
                    if (text.contains("%")) {
                        mDownloadManager.pauseTask(downloadInfo.getTaskKey());
                    }
                    if (text.equals("等待")) {
                        ToastUtil.showToast(mContext, "已经加入下载队列");
                    }
                } else if (v.getId() == R.id.layout_one){
                Intent intent = new Intent(mContext, AppDetailActivity.class);
                intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_ID, SByGameName.getId());
                mContext.startActivity(intent);
                }

            }
        }

        //更新单项内容显示状态
        private void refresh() {
            //先根据包名判断游戏是否安装
            if (ApkUtils.hasInstalled(mContext, SByGameName.getPackageName())) {
                //InstalledHelper.getInstance(App.mContext).addOneInstalledRecord(gameModel.getPackageName(), gameModel.getId());
                //已安装的,有可能正在升级
                if (null != downloadInfo && downloadInfo.getState() == DownloadManager.DOWNLOADING) {
                    double progress = Math.round(downloadInfo.getProgress() * 10000.00) * 1 / 100.00;
                    downloadBt.setProgress(progress, progress + "%");
                    return;
                }
                //已经安装的,需要判断是否需要升级
                if (ApkUtils.whetherUpdate(mContext, SByGameName.getPackageName(), "0")) {
                    downloadBt.setProgress("更新");
                } else {
                    downloadBt.setProgress("打开");
                    downloadBt.setTextColor(mContext.getResources().getColor(R.color.white));
                    downloadBt.setBackground(mContext.getResources().getDrawable(R.drawable.third_pb_green));
                }
                return;
            }

            if (null == downloadInfo) {
                downloadBt.setProgress("下载");
                downloadBt.setTextColor(mContext.getResources().getColor(R.color.blue));
                downloadBt.setBackground(mContext.getResources().getDrawable(R.drawable.third_pb_normal));
                return;
            }
            switch (downloadInfo.getState()) {
                case DownloadManager.NONE:
                    downloadBt.setProgress("下载");
                    break;
                case DownloadManager.DOWNLOADING:
                    double progress = Math.round(downloadInfo.getProgress() * 10000.00) * 1 / 100.00;
                    downloadBt.setProgress(progress, progress + "%");
                    break;
                case DownloadManager.PAUSE://当前为暂停状态
                    downloadBt.setProgress(Math.round(downloadInfo.getProgress() * 10000) * 1 / 100.00, "暂停中");
                    break;
                case DownloadManager.WAITING://当前为等待状态
                    downloadBt.setProgress("等待");
                    break;
                case DownloadManager.ERROR://当前为错误状态
                    downloadBt.setProgress("重试");
                    break;
                case DownloadManager.FINISH://当前为完成状态
                    if (ApkUtils.hasInstalled(mContext, new File(downloadInfo.getTargetPath()))) {
                        //这里需要再判断当前已安装的版本号是否为最新的，否，显示为安装
                        downloadBt.setProgress("打开");

                    } else {
                        downloadBt.setProgress("安装");
                        downloadBt.setTextColor(App.mContext.getResources().getColor(R.color.white));
                        downloadBt.setBackground(mContext.getResources().getDrawable(R.drawable.third_pb_pressed));
                    }
                    break;
            }
        }


    }
    private class MyDownloadListener extends DownloadListener {

        public MyDownloadListener() {
        }

        @Override
        public void onProgress(DownloadInfo downloadInfo) {
            //需要找到正确的位置刷新
            if (getUserTag() == null) {
                return;
            }
            SearchSomeOneOpenServiceAdapter.SearchSomeOneOpenServiceViewHolder holder = (SearchSomeOneOpenServiceAdapter.SearchSomeOneOpenServiceViewHolder) getUserTag();
            holder.refresh();  //这里不能使用传递进来的 DownloadInfo，否者会出现条目错乱的问题

        }

        @Override
        public void onFinish(DownloadInfo downloadInfo) {
            //BGame game = (BGame) downloadInfo.getData();
            // ToastUtil.showToast(mContext, game.getGameName() + "已经下载完成");
            if (downloadInfo == null)
                return;
            String taskKey = downloadInfo.getTaskKey();
            if (taskKey == null)
                return;
            GGetGameDetail model = new GGetGameDetail(taskKey);
            TaskEngine.setTokenUseridPhoneState(1);
            TaskEngine.getInstance().doGetGameDetail(model, new JsonCallback<BGame>() {
                @Override
                public void onSuccess(BGame bGame, Call call, Response response) {
                    if (bGame != null && bGame.getGameName() != null)
                        ToastUtil.showToast(mContext, bGame.getGameName() + "已经下载完成");
                }
            });
            DownloadHelper.addOneDownloadRecord(mContext, downloadInfo);//todo 向缓存的下载记录中加入一条游戏信息记录
        }

        @Override
        public void onError(DownloadInfo downloadInfo, String errorMsg, Exception e) {
            if (StringUtils.isEmpty(errorMsg)) {
                errorMsg = "下载出错，请重试";
            }
            ToastUtil.showToast(mContext, errorMsg);
        }
    }

}
