package com.uu661.module.my;

import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.uu661.R;
import com.uu661.core.DevConfig;
import com.uu661.module.TempTextFragment;
import com.uu661.module.base.BaseFragment;
import com.uu661.module.common.WebActivity;
import com.uu661.util.CommonUtils;
import com.uu661.util.ToastUtil;
import com.uu661.util.log.L;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;


/**
 * Created by zhangbo on 2016/6/23.
 */
public class AboutFragment extends BaseFragment {


    @BindView(R.id.tv_version_name) TextView mTvVersionName;
    @BindView(R.id.tv_version_code) TextView mTvVersionCode;
    @BindView(R.id.bt_check_update) RelativeLayout mBtCheckUpdate;
    @BindView(R.id.bt_fwxy) TextView mBtFwxy;
    @BindView(R.id.bt_yszc) TextView mBtYszc;
    @BindView(R.id.super_bt) TextView mSuperBt;

    private long mLastClickTime;
    private int mSecretNumber = 0;

    public static AboutFragment newInstance() {
        Bundle args = new Bundle();
        AboutFragment fragment = new AboutFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.my_about_fragment, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "关于我们", true);
        devConfig();
        mTvVersionName.setText(CommonUtils.getVersionName(_mActivity));
    }

    private void devConfig(){
        mTvVersionCode.setVisibility(DevConfig.DEBUG ? View.VISIBLE : View.GONE);
        StringBuilder sb = new StringBuilder();
        sb.append(String.valueOf(CommonUtils.getVersionCode(_mActivity)));
        sb.append("\n");
        mTvVersionCode.setText(sb.toString());
        mTvVersionCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start(TempTextFragment.newInstance(""));
            }
        });
    }


    @OnClick({R.id.bt_check_update, R.id.bt_fwxy, R.id.bt_yszc, R.id.super_bt})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.bt_check_update:
                CommonUtils.checkUpdate(_mActivity, true);
                break;
            case R.id.bt_fwxy:
                Intent intent1 = new Intent(_mActivity, WebActivity.class);
                intent1.putExtra(WebActivity.INTENT_KEY_URL, "file:///android_asset/service.html");
                intent1.putExtra(WebActivity.INTENT_KEY_TITLE, "服务协议");
                startActivity(intent1);
                break;
            case R.id.bt_yszc:
                Intent intent2 = new Intent(_mActivity, WebActivity.class);
                intent2.putExtra(WebActivity.INTENT_KEY_URL, "file:///android_asset/policy.html");
                intent2.putExtra(WebActivity.INTENT_KEY_TITLE, "隐私政策");
                startActivity(intent2);
                break;
            case R.id.super_bt:
                long currentClickTime = SystemClock.uptimeMillis();
                long elapsedTime = currentClickTime - mLastClickTime;
                mLastClickTime = currentClickTime;
                if (elapsedTime < 600) {
                    ++mSecretNumber;
                    if (15 == mSecretNumber) {
                        L.init(true);
                        ToastUtil.showToast(_mActivity, "开发模式");
                    }
                } else {
                    mSecretNumber = 0;
                }

                break;
        }
    }


}
