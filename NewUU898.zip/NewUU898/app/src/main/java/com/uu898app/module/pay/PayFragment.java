package com.uu898app.module.pay;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.uu898app.R;
import com.uu898app.model.request.GGenAliPayNo;
import com.uu898app.model.request.GGetPayMoney;
import com.uu898app.model.response.BPayMoney;
import com.uu898app.model.response.BPayNo;
import com.uu898app.module.base.BaseFragment;
import com.uu898app.module.helper.AccountManager;
import com.uu898app.module.helper.ToolbarHelper;
import com.uu898app.network.TaskEngine;
import com.uu898app.network.rxjava.RxSubscriber;
import com.uu898app.third.alipay.UUAliPay;
import com.uu898app.third.wechat.UUWeChat;
import com.uu898app.util.log.L;
import com.uu898app.view.bottomsheet.BottomSheetLayout;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import rx.Observable;
import rx.functions.Func1;


public class PayFragment extends BaseFragment {

    @BindView(R.id.toolbar) Toolbar toolbar;
    @BindView(R.id.tv_userid) TextView tvUserid;
    @BindView(R.id.edt_money) EditText edtMoney;
    @BindView(R.id.bt_recharge_zfb) Button btRechargeZfb;
    @BindView(R.id.bt_recharge_wx) Button btRechargeWx;
    @BindView(R.id.bt_bottom_sheet) Button btBottomSheet;
    @BindView(R.id.bottom_sheet) BottomSheetLayout bottomSheetLayout;

    public static PayFragment newInstance() {

        Bundle args = new Bundle();
        PayFragment fragment = new PayFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.pay_fragment, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        new ToolbarHelper.Builder(toolbar, this, _mActivity).title("充值").showBack(true).build();
    }

    @OnClick({R.id.bt_recharge_zfb, R.id.bt_recharge_wx, R.id.bt_bottom_sheet})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.bt_recharge_zfb://支付宝充值
                //                GGetPayMoney model = new GGetPayMoney();
                //                model.setChargeType(GGetPayMoney.TYPE_ZFB);
                //                model.setChargeMoney("1");
                //                TaskEngine.getInstance().getPayMoney(model).subscribe(new RxSubscriber<BPayMoney>() {
                //                    @Override
                //                    public void _onNext(BPayMoney result) {
                //                        L.d(result.getMoney());
                //                        //生成订单号
                //                        GGenAliPayNo model = new GGenAliPayNo();
                //                        model.setMoney(result.getMoney());
                //                        model.setSSID(AccountManager.getInstance().getSSID());
                //                        final String money = result.getMoney();
                //                        TaskEngine.getInstance().genAliPayNo(model).subscribe(new Action1<BPayNo>() {
                //                            @Override
                //                            public void call(BPayNo result) {
                //                                L.d(result.getOrderNo());
                //                                //充值
                //                                UUAliPay.getInstance(_mActivity).pay(money, result.getOrderNo());
                //                            }
                //                        });
                //                    }
                //
                //                    @Override
                //                    public void _onError(String msg) {
                //
                //                    }
                //                });

                GGetPayMoney model = new GGetPayMoney();
                model.setChargeType(GGetPayMoney.TYPE_ZFB);
                model.setChargeMoney("1");

                final String[] money = {""};
                TaskEngine.getInstance().getPayMoney(model).flatMap(new Func1<BPayMoney, Observable<BPayNo>>() {
                    @Override
                    public Observable<BPayNo> call(BPayMoney bPayMoney) {
                        L.d(bPayMoney.getMoney());
                        //生成订单号
                        GGenAliPayNo model = new GGenAliPayNo();
                        model.setMoney(bPayMoney.getMoney());
                        model.setSSID(AccountManager.getInstance().getSSID());
                        money[0] = bPayMoney.getMoney();
                        return TaskEngine.getInstance().genAliPayNoNew(model);
                    }
                }).subscribe(new RxSubscriber<BPayNo>(PayFragment.this, true) {
                    @Override
                    public void _onNext(BPayNo result) {
                        L.d(result.getOrderNo());
                        //充值
                        //                               String orderNo = "20160905113382983";
                        UUAliPay.getInstance(_mActivity).pay(money[0], result.getOrderNo());
                    }

                    @Override
                    public void _onError(String msg) {
                        AsyncTask
                    }
                });
                break;
            case R.id.bt_recharge_wx://微信充值

                UUWeChat.getInstance(_mActivity).pay();
                /**
                 * 1.   getRechargeMoney
                 * 2.   生成订单号
                 * 3.
                 */
               /* GGetPayMoney model1 = new GGetPayMoney();
                model1.setChargeType(GGetPayMoney.TYPE_WX);
                model1.setChargeMoney("100");
                TaskEngine.getInstance().getPayMoney(model1).subscribe(new RxSubscriber<BPayMoney>() {
                    @Override
                    public void _onNext(BPayMoney result) {
                        L.d(result.getMoney());
                        //生成订单号
                        GGenWxPayNo num = new GGenWxPayNo();
                        num.setMoney(result.getMoney());
                        num.setActMoney(result.getMoney());
                        num.setSSID(AccountManager.getInstance().getSSID());
                        final String money = result.getMoney();
                        TaskEngine.getInstance().genWxPayNo(num).subscribe(new Action1<BPayNo>() {
                            @Override
                            public void call(BPayNo result) {
                                L.d(result.getOrderNo());
                                //充值
                                UUWeChat.getInstance(_mActivity).pay();
                            }
                        });
                    }

                    @Override
                    public void _onError(String msg) {

                    }
                });*/
                break;
            case R.id.bt_bottom_sheet:
                bottomSheetLayout.showWithSheetView(LayoutInflater.from(_mActivity).inflate(R.layout.recharge_mobile_fee_layout, bottomSheetLayout, false));
                break;
        }
    }
}
