package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    :
 * =====================================================
 */

public class BMessage implements Serializable {
    /**
     * id : 123456
     * title : 最新消息
     * addTime : 2017-03-01 00:00:00
     * infoType : 0
     * link : http://www.shouyouzhu.com
     * viewed : false
     * isCollect : false
     * mesType : 0
     */

    private String id;
    private String title;
    private String addTime;
    private String infoType;
    private String link;

    public Boolean getViewed() {
        return viewed;
    }

    public void setViewed(Boolean viewed) {
        this.viewed = viewed;
    }

    public Boolean getCollect() {
        return isCollect;
    }

    public void setCollect(Boolean collect) {
        isCollect = collect;
    }

    private Boolean viewed;
    private Boolean isCollect;
    private String mesType;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }

    public String getInfoType() {
        return infoType;
    }

    public void setInfoType(String infoType) {
        this.infoType = infoType;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }


    public String getMesType() {
        return mesType;
    }

    public void setMesType(String mesType) {
        this.mesType = mesType;
    }
}
