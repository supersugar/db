package com.uu898app.model.response;

/**
 * Created by zhangbo on 2016/7/19.
 */
public class BRechargeDKNoResult {
    private String _sequence;

    public String get_sequence() {
        return _sequence;
    }

    public void set_sequence(String _sequence) {
        this._sequence = _sequence;
    }
}
