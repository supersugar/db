package com.uu393.market.module.center;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.model.response.BShareFormHomeUserInfoTotal;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ContactCustomerServicesUtils;
import com.uu393.market.view.lazyviewpager.LazyFragmentPagerAdapter;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

public class ShareReportFormActivity extends BaseActivity {

    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    TextView mTitleBarRight;
    @Bind(R.id.tv_share_report_form_money)
    TextView mTvShareReportFormMoney;
    @Bind(R.id.bt_share_report_form_withdraw)
    Button mBtShareReportFormWithdraw;
    @Bind(R.id.tv_this_month_income)
    TextView mTvThisMonthIncome;
    @Bind(R.id.tv_last_month_income)
    TextView mTvLastMonthIncome;
    @Bind(R.id.tab_layout_share_report_form)
    TabLayout mTabLayoutShareReportForm;
    @Bind(R.id.view_pager_share_report_form)
    ViewPager mViewPagerShareReportForm;
    @Bind(R.id.layout_share_report_form_more)
    RelativeLayout mLayoutShareReportFormMore;
    @Bind(R.id.tv_contact)
    TextView mTvContact;
    private ShareReportFormViewPagerAdapter mPagerAdapter;

    private BShareFormHomeUserInfoTotal mShareFormHomeUserInfoTotal;
    private boolean mHasBindedBank =false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_report_form);
        ButterKnife.bind(this);
        initTabAndViewPager();
    }

    @Override
    protected void onResume() {
        super.onResume();
        doGetShareFormHomeUserInfoTotal();
    }

    private void initView(BShareFormHomeUserInfoTotal shareFormHomeUserInfoTotal) {
        if (shareFormHomeUserInfoTotal == null) {
            mTvShareReportFormMoney.setText("无数据");//总收入
            mTvThisMonthIncome.setText("无数据");//本月收入
            mTvLastMonthIncome.setText("无数据");//上月收入
            mBtShareReportFormWithdraw.setClickable(false);
        }else {
            mBtShareReportFormWithdraw.setClickable(true);
            mTvShareReportFormMoney.setText(shareFormHomeUserInfoTotal.getTInCome());//总收入
            mTvThisMonthIncome.setText(shareFormHomeUserInfoTotal.getMInCome());//本月收入
            mTvLastMonthIncome.setText(shareFormHomeUserInfoTotal.getLMInCome());//上月收入
            String isTxBank = shareFormHomeUserInfoTotal.getIsTxBank().trim().toLowerCase();
            if (TextUtils.isEmpty(isTxBank)){
                mHasBindedBank = false;
            }else {
                if ("true".equals(isTxBank)){
                    mHasBindedBank = true;
                }else if ("false".equals(isTxBank)){
                    mHasBindedBank = false;
                }
            }
        }
    }

    private void initTabAndViewPager() {
        if (mPagerAdapter == null) {
            mPagerAdapter = new ShareReportFormViewPagerAdapter(getSupportFragmentManager());
        }
        mViewPagerShareReportForm.setAdapter(mPagerAdapter);
        mTabLayoutShareReportForm.setupWithViewPager(mViewPagerShareReportForm);
    }

    @OnClick({R.id.title_bar_left, R.id.title_bar_right, R.id.bt_share_report_form_withdraw, R.id.layout_share_report_form_more, R.id.tv_contact})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                super.onBackPressedSupport();
                break;
            case R.id.title_bar_right://去分享赚订单明细
                Intent intent = new Intent(ShareReportFormActivity.this, ShareActivity.class);
                startActivity(intent);
                break;
            case R.id.bt_share_report_form_withdraw://去提现页
                doGetShareFormHomeUserInfoTotal();
                Intent intentToWithdraw = new Intent(ShareReportFormActivity.this, WithdrawCashActivity.class);
                intentToWithdraw.putExtra(WithdrawCashActivity.INTENT_KEY_TO_WITHDRAW,mHasBindedBank);
                ShareReportFormActivity.this.startActivity(intentToWithdraw);
                break;
            case R.id.layout_share_report_form_more://查看更多
                startActivity(new Intent(this, ShareReportFormMoreActivity.class));
                break;
            case R.id.tv_contact://客服
                ContactCustomerServicesUtils.doXiaoNeng();
                break;
        }
    }


    public class ShareReportFormViewPagerAdapter extends LazyFragmentPagerAdapter {
        private String[] tabTitles = {"今天", "昨天"};

        public ShareReportFormViewPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        protected Fragment getItem(ViewGroup container, int position) {
            ShareReportFormDayRecordFragment fragment = ShareReportFormDayRecordFragment.newInstance(tabTitles[position]);
            return fragment;
        }

        @Override
        public int getCount() {
            return tabTitles.length;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return tabTitles[position];
        }
    }

    //获取分享赚页用户统计信息APP052
    private void doGetShareFormHomeUserInfoTotal() {
        showLoadToast(ShareReportFormActivity.this);
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetShareFormHomeUserInfoTotal(new JsonCallback<BShareFormHomeUserInfoTotal>() {
            @Override
            public void onSuccess(BShareFormHomeUserInfoTotal bShareFormHomeUserInfoTotal, Call call, Response response) {
                hideLoadToast();
                if (bShareFormHomeUserInfoTotal != null) {
                    mShareFormHomeUserInfoTotal = bShareFormHomeUserInfoTotal;
                    initView(mShareFormHomeUserInfoTotal);
                    String isTxBank = mShareFormHomeUserInfoTotal.getIsTxBank().trim().toLowerCase();
                    if (TextUtils.isEmpty(isTxBank)){
                        mHasBindedBank = false;
                    }else {
                        if ("true".equals(isTxBank)){
                            mHasBindedBank = true;
                        }else if ("false".equals(isTxBank)){
                            mHasBindedBank = false;
                        }
                    }
                }else {
                    initView(mShareFormHomeUserInfoTotal);
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
                initView(mShareFormHomeUserInfoTotal);
            }
        });
    }

}
