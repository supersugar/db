package com.uu393.market.module.center;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.Constant;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GDoRemoveBindPhone;
import com.uu393.market.model.request.GGetPhoneCode;
import com.uu393.market.model.response.BUserIsBindPhone;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.login.CountDownTimer;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ContactCustomerServicesUtils;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.ToastUtil;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

public class RemoveBindPhoneActivity extends BaseActivity {

    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    @Bind(R.id.tv_account_name)
    TextView mTvAccountName;
    @Bind(R.id.tv_account_bind_phone_number)
    TextView mTvAccountBindPhoneNumber;
    @Bind(R.id.et_code)
    EditText mEtCode;
    @Bind(R.id.bt_get_code)
    Button mBtGetCode;
    @Bind(R.id.bt_go)
    Button mBtGo;
    @Bind(R.id.tv_contact)
    TextView mTvContact;
    private String mAccountBindPhoneNumber;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_bind_phone);
        ButterKnife.bind(this);
        initTitleBar();

    }

    @Override
    protected void onResume() {
        super.onResume();
        doGetUserIsBindPhone();
    }

    private void initTitleBar() {
        mTitleBarRight.setVisibility(View.GONE);
        mTitleBarTitle.setText("解除绑定");
    }

    private void initView() {
        String userId = (String) SPUtil.get(App.mContext, "userId", "");
        mTvAccountName.setText("当前用户名："+userId);
        String chkMobile = (String) SPUtil.get(App.mContext, "chkMobile", "").toString().trim().replace(" ","");
        mAccountBindPhoneNumber=chkMobile;
        if (mAccountBindPhoneNumber!=null &&mAccountBindPhoneNumber.length()>7){
            String substring = mAccountBindPhoneNumber.substring(3, 7);
            mTvAccountBindPhoneNumber.setText("已绑定过的手机："+mAccountBindPhoneNumber.replace(substring,"****"));
        }else if (TextUtils.isEmpty(mAccountBindPhoneNumber)){
            ToastUtil.showToast(App.mContext,"您未绑定手机");
            RemoveBindPhoneActivity.this.finish();
        }
    }

    @OnClick({R.id.title_bar_left, R.id.bt_get_code, R.id.bt_go, R.id.tv_contact})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                super.onBackPressedSupport();
                break;
            case R.id.bt_get_code:
                doGetPhoneCode(mBtGetCode);
                break;
            case R.id.bt_go:
                // TODO: 2017/4/24  提交解绑，，接口未加，，，解除成功后将SP中清空
                String code = mEtCode.getText().toString().trim();
                if (TextUtils.isEmpty(code)){
                    ToastUtil.showToast(App.mContext,"请输入验证码");
                    return;
                }
                GDoRemoveBindPhone model = new GDoRemoveBindPhone();
                model.setCode(code);
                doRemoveBindPhone(model);
                break;
            case R.id.tv_contact:
                ContactCustomerServicesUtils.doXiaoNeng();
                break;
        }
    }

    //获取手机验证码，传token就行APP009
    private void doGetPhoneCode(final Button button) {
        final CountDownTimer timer = new CountDownTimer(60000, 1000, button, "获取验证码");
        timer.start();
        GGetPhoneCode model = new GGetPhoneCode();
        model.setType(Constant.GET_PHONE_CODE_TYPE_2);//验证身份
        model.setPhoneNo("");
        model.setUserId("");
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetPhoneCode(model,new JsonCallback<Object>() {
            @Override
            public void onSuccess(Object bPhoneCode, Call call, Response response) {
                /*
                * Status 1 发送次数超过限制，请查看手机收到的验证码
                        2 手机号码格式不正确
                        3 该手机号在黑名单中
                        4 该手机号已被禁用
                        5 该用户没有绑定手机号
                * */
                ToastUtil.showToast(App.mContext,"短信验证码已发送至您的手机");

            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                timer.cancel();
                button.setEnabled(true);
                button.setText("获取验证码");
            }
        });
    }
    private int reLoad =0;
    //解除绑定手机号码，传code就行APP060
    private void doRemoveBindPhone(GDoRemoveBindPhone model){
        if (model == null) return;
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doRemoveBindPhone(model, new JsonCallback<Object>() {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                ToastUtil.showToast(App.mContext,"解除成功");
                SPUtil.put(App.mContext,"chkMobile","");
                RemoveBindPhoneActivity.this.finish();
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                if (reLoad<2){
                    doGetUserIsBindPhone();
                }
                reLoad ++;
            }
        });

    }

    //获取用户是否绑定手机号APP058
    private void doGetUserIsBindPhone() {
        showLoadToast(RemoveBindPhoneActivity.this);
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetUserIsBindPhone(new JsonCallback<BUserIsBindPhone>() {
            @Override
            public void onSuccess(BUserIsBindPhone bUserIsBindPhone, Call call, Response response) {
                hideLoadToast();
                if (bUserIsBindPhone != null) {
                    String isBindPhone = bUserIsBindPhone.getIsBindPhone();
                    if (TextUtils.isEmpty(isBindPhone)) {

                    } else {
                        SPUtil.put(App.mContext,"chkMobile",""+bUserIsBindPhone.getIsBindPhone());
                    }

                }
                initView();
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
                initView();
            }
        });
    }
}
