package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/26
 * Description    :
 * =====================================================
 */

public class GDoRemoveBindPhone {
    /**
     {
     "code": "123456",（验证码）
     }
     */

    private String code;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
