package com.uu393.market.module.message;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.R;
import com.uu393.market.model.request.GGetMessageDetail;
import com.uu393.market.model.response.BMessageDetail;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.home.BrowserLayout;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.Base64Helper;

import java.io.UnsupportedEncodingException;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Created by Administrator on 2017/4/21.
 */

public class EventMessageDetailActivity extends BaseActivity {

    @Bind(R.id.title_bar_left)
    ImageButton titleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton titleBarRight;
    @Bind(R.id.title_bar_title)
    TextView titleBarTitle;
    @Bind(R.id.wv_message_detail)
    BrowserLayout browser;


    private TextView mTvTitle;
    private TextView mTvTime;
    private TextView mTvAccount;

    private String link;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message_detail);
        ButterKnife.bind(this);

        mTvTitle = (TextView) findViewById(R.id.tv_hot_item_title);
        mTvTime = (TextView) findViewById(R.id.tv_hot_item_time);
        mTvAccount = (TextView) findViewById(R.id.tv_account);

        Intent intent = getIntent();
        link = intent.getStringExtra("id");

        titleBarRight.setVisibility(View.GONE);
        titleBarTitle.setText("消息详情");
//        initWebViewAndStartWebView(link);

        doGetMessageDetail();
        
    }
    
    
    private void doGetMessageDetail(){
        GGetMessageDetail model = new GGetMessageDetail();
        model.setId(link);
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetMessageDetail(model, new JsonCallback<BMessageDetail>() {

            @Override
            public void onSuccess(BMessageDetail bMessageDetail, Call call, Response response) {
                if (bMessageDetail != null){
                    mTvTitle.setText(bMessageDetail.getTitle());
                    mTvTime.setText(bMessageDetail.getAddTime());
                        String content =  Base64Helper.decodeToHtml(bMessageDetail.getContent());
                        mTvAccount.setText(content);
                }

            }
        });
    }
    
    
    
    
    
    
    
    

    private void initWebViewAndStartWebView(String mlink) {
        String gameUrl = "https://www.baidu.com/";
        browser.loadUrl(gameUrl);
    }



    @OnClick(R.id.title_bar_left)
    public void onClick() {
        super.onBackPressed();
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (browser.canGoBack()) {
                browser.goBack();
            }
            return super.onKeyDown(keyCode, event);
        }
        return super.onKeyDown(keyCode, event);
    }
}
