package com.uu393.market.module.message;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.R;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.home.BrowserLayoutLink;

/**
 * Created by z on 2017/4/27.
 */

public class EventMessageLinkActivity extends BaseActivity implements View.OnClickListener{

    String mLink;

    private BrowserLayoutLink browserLayout;
    private ImageButton mTitleBarLeft;
    private ToggleButton mTitleBarRight;
    private TextView mTitle;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message_link);
        browserLayout = (BrowserLayoutLink) findViewById(R.id.wv_hotactiondetails);
        mTitleBarLeft = (ImageButton) findViewById(R.id.title_bar_left);
        mTitleBarRight = (ToggleButton) findViewById(R.id.title_bar_right);
        mTitle = (TextView) findViewById(R.id.title_bar_title);

        mTitle.setText("消息详情");
        mTitleBarRight.setVisibility(View.GONE);
        mTitleBarLeft.setOnClickListener(this);

        Intent intent = getIntent();
        mLink = intent.getStringExtra("link");
        initWebView(mLink);
    }

    public void initWebView(String url){
        browserLayout.loadUrl(url);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (browserLayout.canGoBack()) {
                browserLayout.goBack();
            }
            return super.onKeyDown(keyCode, event);
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onClick(View v) {
        super.onBackPressed();
    }
}
