package com.uu661.model.response;

import java.io.Serializable;

/**
 * 中奖信息
 * 点击钻石列表item,进入详情后(commodityInfo中的status为3才显示)
 * Created by bo on 16/12/6.
 */

public class BLuckyManDetail implements Serializable {


    /**
     * commodityID : 231
     * periodNo : 701170079
     * code : 2
     * nickName : 修罗殿淡定
     * killTime : 2017-01-17T11:00:03.81
     * city : 广东省湛江市
     * userID : 1000676
     * killOrderNo : 1000838428
     * Name : 1000676
     * avatar :
     * buyNum : 1
     * uu898UserId : 10****76
     * winCodeList : 2
     */

    private int commodityID;
    private int periodNo;
    private int code;
    private String nickName;
    private String killTime;
    private String city;
    private int userID;
    private int killOrderNo;
    private String Name;
    private String avatar;
    private int buyNum;
    private String uu898UserId;
    private String winCodeList;

    public int getCommodityID() {
        return commodityID;
    }

    public void setCommodityID(int commodityID) {
        this.commodityID = commodityID;
    }

    public int getPeriodNo() {
        return periodNo;
    }

    public void setPeriodNo(int periodNo) {
        this.periodNo = periodNo;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getKillTime() {
        return killTime;
    }

    public void setKillTime(String killTime) {
        this.killTime = killTime;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public int getKillOrderNo() {
        return killOrderNo;
    }

    public void setKillOrderNo(int killOrderNo) {
        this.killOrderNo = killOrderNo;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public int getBuyNum() {
        return buyNum;
    }

    public void setBuyNum(int buyNum) {
        this.buyNum = buyNum;
    }

    public String getUu898UserId() {
        return uu898UserId;
    }

    public void setUu898UserId(String uu898UserId) {
        this.uu898UserId = uu898UserId;
    }

    public String getWinCodeList() {
        return winCodeList;
    }

    public void setWinCodeList(String winCodeList) {
        this.winCodeList = winCodeList;
    }
}
