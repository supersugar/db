package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/21
 * Description    : 接口058返回数据，用户的简单信息
 * =====================================================
 */

public class BUserIsBindPhone implements Serializable {

    /**
     {
     "isBindPhone": "15238023343”,(如果绑定了手机号返回手机号，否则传空字符串)
     "isShareSale": "true”,(是否是分销用户)
     }
     */

    private String isBindPhone;
    private String isShareSale;

    public String getIsBindPhone() {
        return isBindPhone;
    }

    public void setIsBindPhone(String isBindPhone) {
        this.isBindPhone = isBindPhone;
    }

    public String getIsShareSale() {
        return isShareSale;
    }

    public void setIsShareSale(String isShareSale) {
        this.isShareSale = isShareSale;
    }
}
