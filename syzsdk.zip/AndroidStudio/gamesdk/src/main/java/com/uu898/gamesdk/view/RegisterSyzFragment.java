package com.uu898.gamesdk.view;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.uu898.gamesdk.model.GBaseModel;
import com.uu898.gamesdk.model.request.GRegister;
import com.uu898.gamesdk.model.response.BImageAuthCode;
import com.uu898.gamesdk.model.response.BRegister;
import com.uu898.gamesdk.network.NetCallback;
import com.uu898.gamesdk.network.TaskEngine;
import com.uu898.gamesdk.utils.AccountManager;
import com.uu898.gamesdk.utils.CommonUtils;
import com.uu898.gamesdk.utils.StringUtils;
import com.uu898.gamesdk.utils.ToastUtil;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class RegisterSyzFragment extends BaseFragment {

    private EditText mEdtAccount;
    private EditText mEdtPassword;
    private EditText mEdtAuthCode;
    private ImageView mIvAuthCode;
    private TextView mTvAgreement;
    private Button mBtNext;

    private BImageAuthCode mBImageAuthCode;

    public static RegisterSyzFragment newInstance() {
        Bundle args = new Bundle();
        RegisterSyzFragment fragment = new RegisterSyzFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        return inflater.inflate(getLayoutId("ug_register_syz"), container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "手游猪帐号注册");
        mEdtAccount = (EditText) view.findViewById(getId("ug_edt_account"));
        mEdtPassword = (EditText) view.findViewById(getId("ug_edt_password"));
        mEdtAuthCode = (EditText) view.findViewById(getId("ug_edt_auth_code"));
        mIvAuthCode = (ImageView) view.findViewById(getId("ug_iv_auth_code"));
        mTvAgreement = (TextView) view.findViewById(getId("tv_agreement"));
        mBtNext = (Button) view.findViewById(getId("ug_bt_next"));

        mIvAuthCode.setOnClickListener(onClickListener);
        mTvAgreement.setOnClickListener(onClickListener);
        mBtNext.setOnClickListener(onClickListener);

        doGetImageAuthCode();
    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v.getId() == getId("ug_iv_auth_code")) {
                doGetImageAuthCode();
            } else if (v.getId() == getId("ug_bt_next")) {
                verifyForm();
            } else if (v.getId() == getId("tv_agreement")) {
                start(WebAgreementFragment.newInstance());
            }
        }
    };

    private void doGetImageAuthCode() {
        TaskEngine.getInstance().doGetImageAuthCode(new GBaseModel(), new NetCallback<BImageAuthCode>(this) {
            @Override
            public void _onNext(BImageAuthCode result) {
                mBImageAuthCode = result;
                parseImage(mIvAuthCode, result.validateCodeImg);
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

    private void parseImage(ImageView mAuthcodeImg, String pic) {
        Bitmap bitmap = null;
        try {
            byte[] bitmapArray;
            bitmapArray = Base64.decode(pic, Base64.DEFAULT);
            bitmap = BitmapFactory.decodeByteArray(bitmapArray, 0, bitmapArray.length);
        } catch (Exception e) {
            e.printStackTrace();
        }
        mAuthcodeImg.setImageBitmap(bitmap);
    }

    /**
     * 校验表单信息
     */
    private void verifyForm() {
        String account = mEdtAccount.getText().toString();
        String password = mEdtPassword.getText().toString();
        String authcode = mEdtAuthCode.getText().toString();


        if (StringUtils.isEmpty(account)) {
            ToastUtil.showToast(_mActivity, "请输入帐号");
            return;
        }
        if (StringUtils.isEmpty(password)) {
            ToastUtil.showToast(_mActivity, "请输入密码");
            return;
        }
        if (StringUtils.isEmpty(authcode)) {
            ToastUtil.showToast(_mActivity, "请输入验证码");
            return;
        }
        doRegister(account, password, authcode);
    }

    private void doRegister(final String account, String password, String authcode) {
        GRegister model = new GRegister();
        model.setUserId(account);
        model.setPassword(CommonUtils.encryptString(password));
        model.setRegisterType(GRegister.REGISTER_TYPE_CUSTOM);
        model.setCheckCode(authcode);
        model.setToken(mBImageAuthCode.token);

        TaskEngine.getInstance().doRegister(model, new NetCallback<BRegister>(this) {

            @Override
            public void _onNext(BRegister result) {
                ToastUtil.showToast(_mActivity, "注册成功");
                AccountManager.getInstance().saveLoginInfo(result.SSID, account, AccountManager.Status.REGISTER_DONE_NOT_LOGIN);
                start(RegisterDoneFragment.newInstance());
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }
}
