package com.uu661.model.response;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by bo on 16/9/14.
 */
public class BLogin implements Serializable {

    public static final int STATUS_UNBIND = 0;//未绑定
    public static final int STATUS_BIND = 1;//绑定

    public String token = "";//
    public String Uid = "";//
    public int status;//绑定或未绑定
    //第三版添加字段
    public int hbStatus;//红包状态
    public List<BCoupon> coupon = new ArrayList<>();//
}
