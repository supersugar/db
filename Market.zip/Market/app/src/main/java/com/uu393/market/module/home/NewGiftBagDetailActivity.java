package com.uu393.market.module.home;

import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GGetGiftBagDetail;
import com.uu393.market.model.response.BGiftBagCode;
import com.uu393.market.model.response.BGiftBagDetail;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.h5game.GiftBagDetailActivity;
import com.uu393.market.module.login.LoginActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.Base64Helper;
import com.uu393.market.util.DateUtils;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;

import java.io.UnsupportedEncodingException;
import java.util.Date;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Created by Administrator on 2017/4/21.
 */

public class NewGiftBagDetailActivity extends BaseActivity {

    @Bind(R.id.ib_gift_bag_detail_go_back)
    ImageButton mIbGiftBagDetailGoBack;
    @Bind(R.id.ib_gift_bag_detail_icon)
    ImageButton mGiftBagIcon;
    @Bind(R.id.tv_gift_bag_detail_name)
    TextView mGiftBagName;
    @Bind(R.id.tv_gift_bag_date)
    TextView mGiftBagDate;
    @Bind(R.id.rl_gift_bag_detail_title2)
    RelativeLayout mGiftBatTitleParent;//隐藏 不隐藏
    @Bind(R.id.tv_gift_bag_detail_name_code)
    TextView mTvGiftBagCodeName;
    @Bind(R.id.tv_gift_bag_detail_code)
    TextView mTvGiftBagCode;
    @Bind(R.id.btn_gift_bag_copy_code)
    Button mBtnGiftBagCopyCode;
    @Bind(R.id.ll_gift_bag_code)
    LinearLayout mGiftBagCodeParent;
    @Bind(R.id.tv_gift_bag_detail_msg)
    TextView mTvGiftBagDetailMsg;
    @Bind(R.id.tv_gift_bag_detail_how_use)
    TextView mTvGiftBagDetailHowUse;
    @Bind(R.id.tv_gift_bag_detail_area)
    TextView mTvGiftBagDetailArea;
    @Bind(R.id.btn_gift_bag_detail_bt)
    Button mBtnGiftBagDetailBt;
    private String mBagId;
    private BGiftBagDetail mGiftDetail;

    private TextView mTv_GetCode_Time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newgift_bag_detail);

        mTv_GetCode_Time = (TextView) findViewById(R.id.tv_getcode_time);
        ButterKnife.bind(this);
        Intent intent = getIntent();
        if (intent!=null){
            mBagId = intent.getStringExtra("bagId");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getGiftBagDetail();
    }

    private void getGiftBagDetail(){
        showLoadToast(NewGiftBagDetailActivity.this);
        GGetGiftBagDetail model = new GGetGiftBagDetail();
        model.setGiftID(mBagId);
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetGiftBagDetailNoH5(model, new JsonCallback<BGiftBagDetail>() {
            @Override
            public void onSuccess(BGiftBagDetail bGiftBagDetail, Call call, Response response) {
                if (bGiftBagDetail!=null){
                    mGiftDetail = bGiftBagDetail;
                    setViewData(bGiftBagDetail,bGiftBagDetail.getCode());
                }
            }

            @Override
            public void onAfter(BGiftBagDetail bGiftBagDetail, Exception e) {
                super.onAfter(bGiftBagDetail, e);
                hideLoadToast();
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
            }
        });
    }
    private void getGiftBagCode(){
        showLoadToast(NewGiftBagDetailActivity.this);
        GGetGiftBagDetail model = new GGetGiftBagDetail();
        model.setGiftID(mBagId);
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetGiftBagCode(model, new JsonCallback<BGiftBagCode>() {
            @Override
            public void onSuccess(BGiftBagCode code, Call call, Response response) {
                if (code!=null&&!StringUtils.isEmpty(code.getCode())){
                    String giftCode = code.getCode();
                    mGiftBatTitleParent.setVisibility(View.GONE);
                    mGiftBagCodeParent.setVisibility(View.VISIBLE);
                    //初始化兑换码框数据
                    mTvGiftBagCodeName.setText(mGiftDetail.getGiftName());
                    mTvGiftBagCode.setText(giftCode);
                    mBtnGiftBagCopyCode.setClickable(true);

                    mBtnGiftBagDetailBt.setText("已领取");
                    mBtnGiftBagDetailBt.setTextColor(getResources().getColor(R.color.grey_1));
                    mBtnGiftBagDetailBt.setBackgroundDrawable(getResources().getDrawable(R.drawable.shape_corner_solid_grey));
                    hideLoadToast();
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                ToastUtil.showToast(App.mContext,"获取失败");
                hideLoadToast();
            }
        });
    }
    //判断获取游戏详情时  有没有返回兑换码
    private void setViewData(BGiftBagDetail giftDetail,String giftCode){
        if (StringUtils.isEmpty(giftCode)){//没有兑换码
            mGiftBatTitleParent.setVisibility(View.VISIBLE);
            mGiftBagCodeParent.setVisibility(View.GONE);
            //初始化标题数据
            int defaultAndError = ImageHelper.randomImage();
            Glide.with(App.mContext).load(giftDetail.getIcon()).error(defaultAndError).placeholder(defaultAndError).into(mGiftBagIcon);
            mGiftBagName.setText(giftDetail.getGiftName());
            mGiftBagDate.setText("剩余："+giftDetail.getSurplusNumber()+"个 / 过期日期："+giftDetail.getExpiredTime());

            mBtnGiftBagDetailBt.setText("立即领取");
            mBtnGiftBagDetailBt.setTextColor(getResources().getColor(R.color.white));
            mBtnGiftBagDetailBt.setBackgroundDrawable(getResources().getDrawable(R.drawable.shape_corner_solid_blue));

        }else {
            mGiftBatTitleParent.setVisibility(View.GONE);
            mGiftBagCodeParent.setVisibility(View.VISIBLE);
            //初始化兑换码框数据
            mTvGiftBagCodeName.setText(giftDetail.getGiftName());
            mTvGiftBagCode.setText(giftCode);
            mBtnGiftBagCopyCode.setClickable(true);
            mTv_GetCode_Time.setText(giftDetail.getReceiverTime());
            mBtnGiftBagDetailBt.setText("已领取");
            mBtnGiftBagDetailBt.setTextColor(getResources().getColor(R.color.grey_1));
            mBtnGiftBagDetailBt.setBackgroundDrawable(getResources().getDrawable(R.drawable.shape_corner_solid_grey));
        }

        Date ExpiredTime = DateUtils.parse(giftDetail.getExpiredTime());

        if("0".equals(giftDetail.getSurplusNumber())){//礼包已领完
            mBtnGiftBagDetailBt.setText("已领完");
            mBtnGiftBagDetailBt.setTextColor(getResources().getColor(R.color.grey_1));
            mBtnGiftBagDetailBt.setBackgroundDrawable(getResources().getDrawable(R.drawable.shape_corner_solid_grey));
        }
        Date date = new Date();
        if (date.after(ExpiredTime)){
            mBtnGiftBagDetailBt.setText("已结束");
            mBtnGiftBagDetailBt.setTextColor(getResources().getColor(R.color.grey_1));
            mBtnGiftBagDetailBt.setBackgroundDrawable(getResources().getDrawable(R.drawable.shape_corner_solid_grey));
        }


        String mGiftInfo = null;
            mGiftInfo = Base64Helper.decodeToHtml(giftDetail.getGiftInfo());
        mTvGiftBagDetailMsg.setText(mGiftInfo);
        mTvGiftBagDetailHowUse.setText(giftDetail.getUseMethod());
        mTvGiftBagDetailArea.setText(giftDetail.getUseScope());
    }

    @OnClick({R.id.ib_gift_bag_detail_go_back, R.id.btn_gift_bag_copy_code, R.id.btn_gift_bag_detail_bt})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ib_gift_bag_detail_go_back:
                this.finish();
                break;
            case R.id.btn_gift_bag_copy_code:
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                // 将文本内容放到系统剪贴板里
                cm.setText(mTvGiftBagCode.getText().toString().trim());
                ToastUtil.showToast(App.mContext,"已成功复制到粘贴板");
                break;
            case R.id.btn_gift_bag_detail_bt:
                String btnStatus = mBtnGiftBagDetailBt.getText().toString();
//                btnStatus = "立即领取";
                if ("立即领取".equals(btnStatus)){
                    if(SPUtil.get(App.mContext,"userId","").equals("") && SPUtil.get(App.mContext,"uId","").equals("")){
                        ToastUtil.showToast(NewGiftBagDetailActivity.this,"您未登入或登入失效。");
                        Intent intent = new Intent(this, LoginActivity.class);
                        startActivity(intent);
                    }else {
                        //当已登入时,领取
                        getGiftBagCode();
                    }
                }
                break;
        }
    }
}

