package com.uu898.gamesdk.model.response;

import java.io.Serializable;

/**
 * Created by bo on 16/9/14.
 */
public class BMessage implements Serializable{

    public static final int TYPE_TEXT = 0;//文本消息
    public static final int TYPE_HTML = 1;//活动消息

    public String ID;
    public String Title;
    public String Content;
    public String Link;
    public boolean viewed;
    public String isCollect;
    public String MesType;
    public String AddTime;
}
