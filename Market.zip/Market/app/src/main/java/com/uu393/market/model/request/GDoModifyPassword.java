package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/20
 * Descrip    :
 * =====================================================
 */

public class GDoModifyPassword {
    /**
     * oldPassWord : 123456
     * newPassWord : 123456
     * decipheringType : 0（设备类型：0安卓  1 IOS）
     */

    private String oldPassWord;
    private String newPassWord;
    private String decipheringType;

    public String getOldPassWord() {
        return oldPassWord;
    }

    public void setOldPassWord(String oldPassWord) {
        this.oldPassWord = oldPassWord;
    }

    public String getNewPassWord() {
        return newPassWord;
    }

    public void setNewPassWord(String newPassWord) {
        this.newPassWord = newPassWord;
    }

    public String getDecipheringType() {
        return decipheringType;
    }

    public void setDecipheringType(String decipheringType) {
        this.decipheringType = decipheringType;
    }
}
