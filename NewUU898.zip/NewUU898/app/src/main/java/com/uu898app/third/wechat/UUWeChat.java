package com.uu898app.third.wechat;

import android.app.Activity;
import android.widget.Toast;

import com.tencent.mm.sdk.modelpay.PayReq;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;

import org.json.JSONObject;

/**
 * Created by zhangbo on 2016/6/27.
 */
public class UUWeChat {

    //请同时修改  androidmanifest.xml里面，.PayActivityd里的属性<data android:scheme="wxb4ba3c02aa476ea1"/>为新设置的appid
    public static final String APP_ID = "wxa8e1c8ac13a8ec59";//微信开放平台的id
    //商户号
    public static final String MCH_ID = "1239562002";
    //  API密钥，在商户平台设置
    public static final  String API_KEY="uu898diaNqualityComappaNdroidiOs";

    private static String test_data = "{\"appid\":\"wxb4ba3c02aa476ea1\",\"partnerid\":\"1305176001\",\"package\":\"Sign=WXPay\",\"noncestr\":\"10b808699fc17d34ed0e78102e6d9676\",\"timestamp\":1472816790,\"prepayid\":\"wx20160902194630e2f3254d850891497132\",\"sign\":\"177E4D57A5E4B3AB21DBCF27DF8CCDF0\"}";


    private static UUWeChat mWeChat;
    private Activity mActivity;

    private final IWXAPI msgApi;

    private UUWeChat(Activity activity) {
        mActivity = activity;
        msgApi = WXAPIFactory.createWXAPI(activity, null);
        msgApi.registerApp("wxd930ea5d5a258f4f");
    }

    public static UUWeChat getInstance(Activity activity) {
        if (null == mWeChat) {
            mWeChat = new UUWeChat(activity);
        }
        return mWeChat;
    }

    public void pay() {
        String url = "http://wxpay.weixin.qq.com/pub_v2/app/app_pay.php?plat=android";
        try {
            JSONObject json = new JSONObject(test_data);
            if (null != json && !json.has("retcode")) {
                PayReq req = new PayReq();
                //req.appId = "wxf8b4f85f3a794e77";  // 测试用appId
                req.appId = json.getString("appid");
                req.partnerId = json.getString("partnerid");
                req.prepayId = json.getString("prepayid");
                req.nonceStr = json.getString("noncestr");
                req.timeStamp = json.getString("timestamp");
                req.packageValue = json.getString("package");
                req.sign = json.getString("sign");
                req.extData = "app data"; // optional
                Toast.makeText(mActivity, "正常调起支付", Toast.LENGTH_SHORT).show();
                // 在支付之前，如果应用没有注册到微信，应该先调用IWXMsg.registerApp将应用注册到微信
                msgApi.sendReq(req);
            } else {
                Toast.makeText(mActivity, "服务器请求错误", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(mActivity, "异常：" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

}
