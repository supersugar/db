package com.uu661.module.my;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.lcodecore.tkrefreshlayout.RefreshListenerAdapter;
import com.lcodecore.tkrefreshlayout.TwinklingRefreshLayout;
import com.uu661.R;
import com.uu661.model.request.GGetCouponList;
import com.uu661.model.response.BCoupon;
import com.uu661.module.base.BaseViewPagerFragment;
import com.uu661.network.JsonCallback;
import com.uu661.network.TaskEngine;
import com.uu661.util.log.L;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import ezy.ui.layout.LoadingLayout;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 钻石列表界面
 */
public class MyCouponListFragment extends BaseViewPagerFragment {

    @BindView(R.id.order_recycler_view) RecyclerView mOrderRecyclerView;
    @BindView(R.id.order_refresh_layout) TwinklingRefreshLayout mOrderRefreshLayout;

    private int mType;//

    private MyCouponListAdapter mAdapter;
    private int mPageIndex = 1;
    private LoadingLayout mLoadingLayout;

    public static MyCouponListFragment newInstance(int type) {
        MyCouponListFragment fragment = new MyCouponListFragment();
        Bundle args = new Bundle();
        args.putInt("type", type);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mType = getArguments().getInt("type");
        View view = inflater.inflate(R.layout.my_order_list, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initRecycleView();
        initRefreshLayout();
        doGetCouponList();
    }

    private void initRefreshLayout() {
        //以下代码是使用黑色转圈Loading
        //        ProgressLayout headerView = new ProgressLayout(_mActivity);
        //        mRefreshLayout.setHeaderView(headerView);
        mOrderRefreshLayout.setEnableLoadmore(false);
        mOrderRefreshLayout.setEnableOverScroll(false);//是否允许越界回弹

        mOrderRefreshLayout.setOnRefreshListener(new RefreshListenerAdapter() {
            @Override
            public void onRefresh(final TwinklingRefreshLayout refreshLayout) {
                doGetCouponList();
            }
        });
    }

    private void initRecycleView() {
        LinearLayoutManager manager = new LinearLayoutManager(_mActivity);
        mOrderRecyclerView.setLayoutManager(manager);
        mAdapter = new MyCouponListAdapter(_mActivity, MyCouponListAdapter.TYPE_SEE);
        mOrderRecyclerView.setAdapter(mAdapter);
    }

    /**
     * 查询红包列表
     */
    private void doGetCouponList() {
        GGetCouponList model = new GGetCouponList();
        model.orderNo = "";
        model.isValid = mType;
        TaskEngine.getInstance().doGetCouponList(model, new JsonCallback<List<BCoupon>>(this) {
            @Override
            public void onSuccess(List<BCoupon> result, Call call, Response response) {
                if(!isVisible()){
                    return;
                }
                if (null != result && !result.isEmpty()) {
                    L.d(result.size());
                    mAdapter.updateData(result);
                }
            }

            @Override
            public void onAfter(List<BCoupon> bMyOrders, Exception e) {
                super.onAfter(bMyOrders, e);
                if(!isVisible()){
                    return;
                }
                mOrderRefreshLayout.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if(null != mOrderRefreshLayout){
                            mOrderRefreshLayout.finishRefreshing();
                        }
                    }
                }, 200);
            }
        });
    }


    @Override
    public void refresh(boolean showLoading) {
        doGetCouponList();
    }



}
