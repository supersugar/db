package com.uu898app.model.response;

/**
 * Created by zhangbo on 2016/6/15.
 */
public class BLogin {


    /**
     * SSID : 98A6F5470454F0DB5619AC50808ACAA8
     * userid : 15890137236
     */

    private String SSID;
    private String userid;

    public String getSSID() {
        return SSID;
    }

    public void setSSID(String SSID) {
        this.SSID = SSID;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }
}
