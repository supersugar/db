package com.uu898app.util.eventbus;

import org.greenrobot.eventbus.EventBus;

/**
 * Created by zhangbo on 2016/6/27.
 */
public class EB {

    private static EventBus mEventBus;

    private static EventBus getDefaultEventBus() {
        if (null == mEventBus) {
            mEventBus = EventBus.getDefault();
        }
        return mEventBus;
    }

    public static void register(Object subscriber) {
        if (!getDefaultEventBus().isRegistered(subscriber)) {
            getDefaultEventBus().register(subscriber);
        }

    }

    public static void unregister(Object subscriber) {
        getDefaultEventBus().unregister(subscriber);
    }

    public static void postEmpty(int tag) {
        getDefaultEventBus().post(new EventEmpty(tag));
    }

    public static void postString(int tag, String result) {
        getDefaultEventBus().post(new EventString(tag, result));
    }

    public static <T> void postObject(int tag, T result) {
        getDefaultEventBus().post(new EventObject(tag, result));
    }

    public static final class TAG {
        public static final int A = 1;
        public static final int LOGIN_SUCCESS = 2;
        public static final int LOGOUT_SUCCESS = 21;

        public static final int LOAD_GAME_LIST = 3;
        public static final int LOAD_GAME_KIND_LIST = 4;
        public static final int LOAD_GAME_AREA_LIST = 5;
        public static final int LOAD_GAME_SERVER_LIST = 6;

        public static final int CHOOSE_GAME_DONE = 7;
        public static final int CHOOSE_GAME_KIND_DONE = 8;
        public static final int CHOOSE_GAME_AREA_DONE = 9;
        public static final int CHOOSE_GAME_SERVER_DONE = 10;

        public static final int SELECT_GAME_DONE = 11;//选择游戏完毕
    }
}
