package com.uu661.model;

/**
 * Created by bo on 16/12/6.
 */

public class PageModel {

    public int pageIndex = 1;
    public int pageSize = -1;//值为-1时返回全部
    public int pageCount;//返回时字段,总页数

    public PageModel(){

    }

    public PageModel(int pageIndex, int pageSize) {
        this.pageIndex = pageIndex;
        this.pageSize = pageSize;
    }
}
