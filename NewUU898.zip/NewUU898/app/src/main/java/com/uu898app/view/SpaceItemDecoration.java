package com.uu898app.view;

import android.graphics.Rect;
import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by bo on 16/8/23.
 */
public class SpaceItemDecoration extends RecyclerView.ItemDecoration {

    private int space;

    public SpaceItemDecoration(int space) {
        this.space = space;
    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        if (parent.getChildLayoutPosition(view) == 1) {
            return;
        }
        outRect.left = space;
        outRect.bottom = space;
        if ((parent.getChildLayoutPosition(view)-1) % 2 == 0) {
            outRect.left = 0;
        }


    }

}
