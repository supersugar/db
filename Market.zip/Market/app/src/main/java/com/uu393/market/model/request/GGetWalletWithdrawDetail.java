package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    :
 * =====================================================
 */

public class GGetWalletWithdrawDetail {

    /**
     {
     "tradeNo":"SDC02154",（订单编号）
     }
     */

    private String tradeNo;

    public String getTradeNo() {
        return tradeNo;
    }

    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }
}
