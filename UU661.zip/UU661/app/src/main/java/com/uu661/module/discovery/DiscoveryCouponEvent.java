package com.uu661.module.discovery;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uu661.R;
import com.uu661.core.AccountManager;
import com.uu661.model.response.BCoupon;
import com.uu661.model.response.BUserInfo;
import com.uu661.module.base.BaseFragment;
import com.uu661.network.JsonCallback;
import com.uu661.network.TaskEngine;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import okhttp3.Call;
import okhttp3.Response;


public class DiscoveryCouponEvent extends BaseFragment {


    @BindView(R.id.coupon_event_recycler_view) RecyclerView mRecyclerView;

    private DiscoveryCouponEventAdapter mAdapter;

    public static DiscoveryCouponEvent newInstance() {
        DiscoveryCouponEvent fragment = new DiscoveryCouponEvent();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.discovery_coupon_event, null);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "您夺钻我送红包", true);
        initRecycleView();
        getCouponEventList();
    }

    private void initRecycleView() {
        LinearLayoutManager manager = new LinearLayoutManager(_mActivity) {
            @Override
            public boolean canScrollVertically() {
                return false;
            }
        };
        mRecyclerView.setLayoutManager(manager);
        mAdapter = new DiscoveryCouponEventAdapter();
        mRecyclerView.setAdapter(mAdapter);
    }


    private void getCouponEventList(){
        TaskEngine.getInstance().doGetCouponEvent(new JsonCallback<ArrayList<BCoupon>>(this) {
            @Override
            public void onSuccess(ArrayList<BCoupon> bCoupons, Call call, Response response) {
                if(null != bCoupons && !bCoupons.isEmpty()){
                    mAdapter.updateData(bCoupons);
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                /*
                 "status": "ERROR000402",
                 "message": "对不起，活动已关闭",
                 */

                if (e instanceof APIException && ((APIException) e).getCode().equals("ERROR000402")) {
                    if(!AccountManager.getInstance().isLogin()){
                        return;
                    }
                    TaskEngine.getInstance().doGetUserInfo(new JsonCallback<BUserInfo>(DiscoveryCouponEvent.this) {
                        @Override
                        public void onSuccess(BUserInfo result, Call call, Response response) {
                            AccountManager accountManager = AccountManager.getInstance();
                            //获取完用户信息以后,要判断regStatus值是否有变化
                            BUserInfo oldUserInfo = accountManager.getUserInfo();
                            if(null == oldUserInfo){
                                accountManager.setIsShowStatusChanged(true);
                            }else{
                                if(result.showStatus != oldUserInfo.showStatus){
                                    accountManager.setIsShowStatusChanged(true);
                                }
                            }
                            accountManager.saveUserInfo(result);
                        }

                        @Override
                        public void onAfter(BUserInfo userInfo, Exception e) {
                            super.onAfter(userInfo, e);
                            pop();
                        }
                    });
                }
            }
        });
    }

}
