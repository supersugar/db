package com.uu393.market.module.home;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.model.request.GGetGameDetail;
import com.uu393.market.model.response.BGame;
import com.uu393.market.module.base.BaseViewPagerFragment;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.Base64Helper;

import java.io.UnsupportedEncodingException;

import okhttp3.Call;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class GameMessageFragment extends BaseViewPagerFragment {

    private RecyclerView mRecyclerView;
    private TextView mGameInfo;
    private TextView mTvSize;
    private TextView mTvVersion;
    private TextView mTvMinSdkVersion;
    private TextView mTvType;
    private TextView mTvLauguage;
    private TextView mTvTime;
    private BGame mGame;

    private String mGameId;

    private AppImageAdapter adapter;

    public GameMessageFragment() {

    }

    public static GameMessageFragment newInstance(@NonNull String gameId) {
        GameMessageFragment fragment = new GameMessageFragment();
        Bundle bundle = new Bundle();
        bundle.putString("gameId", gameId);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mGameId = getArguments().getString("gameId");
        }
        adapter = new AppImageAdapter(_mActivity);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_game_message, container, false);
        mRecyclerView = (RecyclerView) view.findViewById(R.id.hor_center_recycle_rview);
        mGameInfo = (TextView) view.findViewById(R.id.tv_game_info);
        mTvSize = (TextView) view.findViewById(R.id.tv_size);
        mTvVersion = (TextView) view.findViewById(R.id.tv_version);
        mTvMinSdkVersion = (TextView) view.findViewById(R.id.tv_min_sdk_version);
        mTvType = (TextView) view.findViewById(R.id.tv_type);
        mTvLauguage = (TextView) view.findViewById(R.id.tv_language);
        mTvTime = (TextView) view.findViewById(R.id.tv_time);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(_mActivity);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onResume() {
        super.onResume();
        doGetGameDetail();
        adapter.setRefrsh();
    }


    private void doGetGameDetail() {
        GGetGameDetail model = new GGetGameDetail(mGameId);
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetGameDetailNew(model, new JsonCallback<BGame>() {
            @Override
            public void onSuccess(BGame bGame, Call call, Response response) {
                if (bGame != null) {
                    mGame = bGame;
                    mGameInfo.setText(Base64Helper.decodeToHtml(mGame.getGameInfo()));
                    mTvSize.setText("大小: " + mGame.getSize());
                    mTvVersion.setText("版本: " + mGame.getVersionName());
                    mTvMinSdkVersion.setText("系统: " + mGame.getSupportSdkVersion());
                    mTvType.setText("类别: " + mGame.getTypeName());
                    mTvLauguage.setText("语言: " + mGame.getLanguage());
                    mTvTime.setText("时间: " + mGame.getReleaseTime());

                    //这句代码是让图片居中显示
//                new LinearSnapHelper().attachToRecyclerView(mRecyclerView);
                    if (mGame.getImageUrl() != null) {
                        if (!mGame.getImageUrl().isEmpty()) {
                            adapter.setRefrsh(mGame.getImageUrl());
                        }
                    }
                    mRecyclerView.setAdapter(adapter);
                }

            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);

            }

        });

    }

    @Override
    public void refresh() {

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (adapter != null) {
            adapter.removeImageLoader();
        }
        adapter = null;
    }
}
