package com.uu898app.model.response;

/**
 * Created by zhangbo on 2016/7/1.
 */
public class BBanner {
    /**
     * title : 三剑豪2
     * image : http://imglist.img898.com/images/sjh2.png
     * link : http://union.7659.com/wap/index.html?appid=com.windplay.sanjianhao2.ky&channel_id=100394_0000&platform_id=100394
     * action : 0
     */

    private String title;
    private String image;
    private String link;
    private String action;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
}
