package com.uu393.market.module.search;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.util.CommonUtils;
import com.uu393.market.util.eventbus.EB;

import java.util.List;

public class HistoryAdapter extends  RecyclerView.Adapter<HistoryAdapter.ViewHolder> {

    private List<String> data;

    public HistoryAdapter(List<String> data) {
        this.data = data;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_search_history, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        if (data!=null&&data.get(position)!=null){
            holder.bindItem(data.get(position),position);
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = holder.getLayoutPosition(); // 1
                    if(position == data.size() - 1){
                        CommonUtils.clearSearchList();
                        data = CommonUtils.getSearchList();
                        notifyDataSetChanged();
                    }else{
                        EB.postAnything(EB.TAG.CLICK_SEARCH_HISTORY_ITEM, position, data.get(position));
                    }
                }
            });
        }

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView icon;
        private TextView textView;

        ViewHolder(View view) {
            super(view);
            icon = (ImageView) view.findViewById(R.id.left_icon);
            textView = (TextView) view.findViewById(R.id.text_view);
        }

        void bindItem(String key, int position) {
            textView.setText(key);
            if(position == data.size() - 1){
                icon.setImageResource(R.drawable.ic_delete_two);
            }
        }
    }

}
