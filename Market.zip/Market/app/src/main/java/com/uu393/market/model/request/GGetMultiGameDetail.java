package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    :
 * =====================================================
 */

public class GGetMultiGameDetail {
    /**
     * {
     "id": "12,56,36,87",(消息编号,多个中间用逗号分隔)
     }
     */

    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
