package com.uu393.market.core;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.util.Log;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.lzy.okserver.download.DownloadInfo;
import com.lzy.okserver.download.DownloadManager;
import com.uu393.market.R;
import com.uu393.market.model.request.GDoCheckUpdate;
import com.uu393.market.model.response.BGame;
import com.uu393.market.model.response.BServerListByTime;
import com.uu393.market.model.response.BServerListInGameDetail;
import com.uu393.market.model.response.BServrerItem;
import com.uu393.market.model.response.BUpdate;
import com.uu393.market.module.more.MoreFragment;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ApkUtils;
import com.uu393.market.util.CacheUtil;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;

import java.io.File;

import cn.finalteam.toolsfinal.DeviceUtils;
import cn.finalteam.toolsfinal.ManifestUtils;
import okhttp3.Call;
import okhttp3.Response;

import static com.uu393.market.app.App.mContext;


/**
 * Created by bo on 16/12/29.
 */

public class DownloadHelper {

    /**
     * 一旦触发下载动作(下载/更新/重试/继续),都要综合判断当前手机情况及设置是否允许下载
     * 1. 是否存在sd卡,没有的话提示
     * 2. 获取卡的剩余空间,不足的话提示
     * 3. 获取当前网络状态,无网的话提示
     * 4. 获取配置及网络状态,不允许下载的话提示
     *
     * @param context
     */
    public static boolean checkCanDownload(Context context) {
        if (DeviceUtils.existSDCard() == false) {
            ToastUtil.showToast(context, "请先插入SD卡");
            return false;
        }
        if (DeviceUtils.getAvailaleSize() < 100) {
            ToastUtil.showToast(context, "SD卡剩余空间不足");
            return false;
        }
        if (DeviceUtils.isOnline(context) == false) {
            ToastUtil.showToast(context, "请确认手机是否连接网络");
            return false;
        }
        if (DeviceUtils.getNetType(context) != DeviceUtils.NETWORK_WIFI) {
            boolean downloadNotWifi = CacheUtil.get(context, "setting").getBoolean(MoreFragment.SETTING_WHETHER_DOWNLOAD_NOT_WIFI, false);
            if (downloadNotWifi == false) {
                ToastUtil.showToast(context, "当前正处于移动网络下，如您想继续下载请在'更多'选项中打开设置");
                return false;
            }
        }
        return true;
    }

    /**
     * @param context
     * @param downloadInfo
     */

    public static void addOneDownloadRecord(Context context, DownloadInfo downloadInfo) {
        BGame game = (BGame) downloadInfo.getData();
        if (null == game) {
            return;
        }
        CacheUtil.get(context, "download_record").put(game.getPackageName(), downloadInfo.getTargetPath());
        //先判断安装文件是否存在
        File temp = new File(downloadInfo.getTargetPath());
        if (temp.exists()) {
            ApkUtils.install(mContext, temp);
            EB.postObject(EB.TAG.CLICK_INSATLL,game);
        } else {
            DownloadManager.getInstance().removeTask(game.getId(), true);
            ToastUtil.showToast(mContext, "安装包可能被删除了，请重新下载");
        }
        L.d("保存 包名 = " + game.getPackageName() + " 路径 = " + downloadInfo.getTargetPath());
    }




    public static void deleteFileByPackageName(Context context, String packageName) {
        boolean keepApk = CacheUtil.get(context, "setting").getBoolean(MoreFragment.SETTING_WHETHER_KEEP_APK, true);
        if (keepApk == false) {
            String path = CacheUtil.get(context, "download_record").getAsString(packageName);
            if (StringUtils.isEmpty(path)) {
                return;
            }
            File temp = new File(path);
            if (temp.exists()) {
                temp.delete();
                L.d("删除 包名 = " + packageName + " 路径 = " + path);
            }
        }
    }


    /**
     * 检查更新
     * @param context
     */

    public static void checkUpdate(final Context context, final boolean showMessage) {
        GDoCheckUpdate model = new GDoCheckUpdate();
        int versionCode = ManifestUtils.getVersionCode(context);
        model.setVersionCode(String.valueOf(versionCode));

        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doCheckUpdate(model,new JsonCallback<BUpdate>() {
            @Override
            public void onSuccess(final BUpdate result, Call call, Response response) {
                if (null == result) {
                    if(showMessage){
                        ToastUtil.showToast(context, "检查失败");
                    }
                    return;
                }
                int currentVersionCode = ManifestUtils.getVersionCode(context);
                if (currentVersionCode >= result.versionCode) {
                    if(showMessage){
                        ToastUtil.showToast(context, "已经是最新版本");
                    }
                    return;
                }
                if (currentVersionCode < result.versionCode) {

                    MaterialDialog.Builder builder = new MaterialDialog.Builder(context)
                            .title("更新提示")
                            .content(result.updateInfo)
                            .positiveText("马上更新")
                            .negativeText(result.isForceUpdate == 0 ? "稍候再说" : "")
                            .negativeColor(context.getResources().getColor(R.color.text_lv2))
                            .cancelable(result.isForceUpdate == 0 ? true : false)//是否强制更新，0否  1是
                            .onPositive(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            Uri uri = Uri.parse(result.packageUrl);
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(uri);
                            context.startActivity(intent);

                            //                                final MaterialDialog progressDialog = new MaterialDialog.Builder(context)
                            //                                        .progress(false,100,true)
                            //                                        .showListener(new DialogInterface.OnShowListener() {
                            //                                            @Override
                            //                                            public void onShow(DialogInterface dialog) {
                            //
                            //                                            }
                            //                                        })
                            //                                       .show();
                            //
                            //                                String url = result.packageUrl;
                            //                                if (StringUtils.isEmpty(url)) {
                            //                                    ToastUtil.showToast(mContext, "下载链接错误 " + url);
                            //                                    return;
                            //                                }
                            //                                GetRequest request = OkGo.get(result.packageUrl);
                            //                                DownloadManager.getInstance().addTask("update", request, new
                            // DownloadListener() {
                            //                                    @Override
                            //                                    public void onProgress(DownloadInfo downloadInfo) {
                            //                                        int progress = Math.round(downloadInfo.getProgress() * 10000) * 1 /
                            // 100;
                            //                                        progressDialog.setProgress(progress);
                            //                                    }
                            //
                            //                                    @Override
                            //                                    public void onFinish(DownloadInfo downloadInfo) {
                            //
                            //                                    }
                            //
                            //                                    @Override
                            //                                    public void onError(DownloadInfo downloadInfo, String errorMsg,
                            // Exception e) {
                            //
                            //                                    }
                            //                                });
                        }
                    });

                    MaterialDialog dialog = builder.build();
                    dialog.show();
                }


            }
        });
    }


}
