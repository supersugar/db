package com.uu661.util.eventbus;

/**
 * Created by zhangbo on 2016/6/27.
 */
public class EventAnything extends BaseEvent{

    public Object[] result;

    public EventAnything(int t, Object... o) {
        tag = t;
        result = o;
    }
}
