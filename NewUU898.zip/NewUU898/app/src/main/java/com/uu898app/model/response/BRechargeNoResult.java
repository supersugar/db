package com.uu898app.model.response;

/**
 * 获取充值订单返回结果model
 * Created by zhangbo on 2016/7/18.
 */
public class BRechargeNoResult {


    /**
     * _addtime : /Date(-2209017600000+0800)/
     * _cardid : 152099
     * _cardname : 河南联通手机快充10元
     * _completetime : /Date(-2209017600000+0800)/
     * _id : null
     * _inprice : 10.3
     * _ip : 171.8.225.205
     * _ismo : null
     * _kefu : 227
     * _number : 1
     * _orderno : MSJ20160716134523-07425
     * _parvalue : 10
     * _paytime : /Date(-2209017600000+0800)/
     * _paytype : 1
     * _phone : 13203713938
     * _price : 10.36
     * _remark : 河南郑州联通
     * _status : null
     * _type : 1
     * _userid : 13203713938
     * _cancelReason : null
     */

    private String _addtime;
    private String _cardid;
    private String _cardname;
    private String _completetime;
    private Object _id;
    private double _inprice;
    private String _ip;
    private Object _ismo;
    private int _kefu;
    private int _number;
    private String _orderno;
    private int _parvalue;
    private String _paytime;
    private int _paytype;
    private String _phone;
    private double _price;
    private String _remark;
    private Object _status;
    private int _type;
    private String _userid;
    private Object _cancelReason;

    public String get_addtime() {
        return _addtime;
    }

    public void set_addtime(String _addtime) {
        this._addtime = _addtime;
    }

    public String get_cardid() {
        return _cardid;
    }

    public void set_cardid(String _cardid) {
        this._cardid = _cardid;
    }

    public String get_cardname() {
        return _cardname;
    }

    public void set_cardname(String _cardname) {
        this._cardname = _cardname;
    }

    public String get_completetime() {
        return _completetime;
    }

    public void set_completetime(String _completetime) {
        this._completetime = _completetime;
    }

    public Object get_id() {
        return _id;
    }

    public void set_id(Object _id) {
        this._id = _id;
    }

    public double get_inprice() {
        return _inprice;
    }

    public void set_inprice(double _inprice) {
        this._inprice = _inprice;
    }

    public String get_ip() {
        return _ip;
    }

    public void set_ip(String _ip) {
        this._ip = _ip;
    }

    public Object get_ismo() {
        return _ismo;
    }

    public void set_ismo(Object _ismo) {
        this._ismo = _ismo;
    }

    public int get_kefu() {
        return _kefu;
    }

    public void set_kefu(int _kefu) {
        this._kefu = _kefu;
    }

    public int get_number() {
        return _number;
    }

    public void set_number(int _number) {
        this._number = _number;
    }

    public String get_orderno() {
        return _orderno;
    }

    public void set_orderno(String _orderno) {
        this._orderno = _orderno;
    }

    public int get_parvalue() {
        return _parvalue;
    }

    public void set_parvalue(int _parvalue) {
        this._parvalue = _parvalue;
    }

    public String get_paytime() {
        return _paytime;
    }

    public void set_paytime(String _paytime) {
        this._paytime = _paytime;
    }

    public int get_paytype() {
        return _paytype;
    }

    public void set_paytype(int _paytype) {
        this._paytype = _paytype;
    }

    public String get_phone() {
        return _phone;
    }

    public void set_phone(String _phone) {
        this._phone = _phone;
    }

    public double get_price() {
        return _price;
    }

    public void set_price(double _price) {
        this._price = _price;
    }

    public String get_remark() {
        return _remark;
    }

    public void set_remark(String _remark) {
        this._remark = _remark;
    }

    public Object get_status() {
        return _status;
    }

    public void set_status(Object _status) {
        this._status = _status;
    }

    public int get_type() {
        return _type;
    }

    public void set_type(int _type) {
        this._type = _type;
    }

    public String get_userid() {
        return _userid;
    }

    public void set_userid(String _userid) {
        this._userid = _userid;
    }

    public Object get_cancelReason() {
        return _cancelReason;
    }

    public void set_cancelReason(Object _cancelReason) {
        this._cancelReason = _cancelReason;
    }
}