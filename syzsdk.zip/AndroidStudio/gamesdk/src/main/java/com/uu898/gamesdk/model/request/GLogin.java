package com.uu898.gamesdk.model.request;

import com.uu898.gamesdk.model.GBaseModel;

/**
 * Created by zhangbo on 2016/6/15.
 */
public class GLogin extends GBaseModel {


    private String password;
    private String userId;
    private int decipheringType = 0;//设备唯一标识码,0是安卓,1是ios

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getDecipheringType() {
        return decipheringType;
    }

    public void setDecipheringType(int decipheringType) {
        this.decipheringType = decipheringType;
    }
}
