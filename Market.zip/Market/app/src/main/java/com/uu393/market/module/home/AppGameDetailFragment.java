package com.uu393.market.module.home;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.bumptech.glide.Glide;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.request.GetRequest;
import com.lzy.okserver.download.DownloadInfo;
import com.lzy.okserver.download.DownloadManager;
import com.lzy.okserver.download.DownloadService;
import com.lzy.okserver.listener.DownloadListener;
import com.sina.weibo.sdk.api.share.IWeiboShareAPI;
import com.sina.weibo.sdk.api.share.WeiboShareSDK;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.Constant;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.AppCollectRecordHelper;
import com.uu393.market.core.DownloadHelper;
import com.uu393.market.model.request.GGetGameDetail;
import com.uu393.market.model.response.BGame;
import com.uu393.market.model.response.BHotSomeDetail;
import com.uu393.market.model.response.BUserIsBindPhone;
import com.uu393.market.model.response.GGetSomeGameDetail;
import com.uu393.market.module.base.BaseFragment;
import com.uu393.market.module.bt.BTGameActivity;
import com.uu393.market.module.h5game.FullyLinearLayoutManager;
import com.uu393.market.module.share.ShareActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ApkUtils;
import com.uu393.market.util.GlideRoundTransform;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;
import com.uu393.market.view.progressbutton.SubmitProcessButton;

import org.greenrobot.eventbus.Subscribe;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import ezy.ui.layout.LoadingLayout;
import okhttp3.Call;
import okhttp3.Response;

import static com.uu393.market.Constant.UMENG_EVENT_ID_DOWNLOAD;
import static com.uu393.market.app.App.mContext;

/**
 * Created by bo on 16/11/10.
 * 新版游戏详情页
 */

public class AppGameDetailFragment extends BaseFragment implements View.OnClickListener {


    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    @Bind(R.id.download_bt)
    SubmitProcessButton mBtDownload;
    @Bind(R.id.download_bt_layout)
    RelativeLayout mDownloadBtLayout;
    @Bind(R.id.app_icon)
    ImageView mAppIcon;
    @Bind(R.id.name)
    TextView mName;
    @Bind(R.id.tv_discount)
    TextView mTvDiscount;
    @Bind(R.id.tv_type_size)
    TextView mTvTypeSize;
    @Bind(R.id.tv_detail_bt)
    TextView mTvDetailBt;
    @Bind(R.id.bt_app_detail_share)
    TextView mBtAppDetailShare;
    @Bind(R.id.rv_app_detail_events)
    RecyclerView mRvAppDetailEvents;
    @Bind(R.id.vp_app_detail)
    WrapContentHeightViewPager mViewPager;
    @Bind(R.id.tb_app_game_detail)
    TabLayout mTabs;
    private MyListener listener;
    private DownloadInfo downloadInfo;
    private String mGameId;
    private BGame mGame = new BGame();
    private DownloadManager mDownloadManager;
    private List<BHotSomeDetail> mBHotSomeDetail = new ArrayList<>();
    AppGameEventAdapter HotSomeDetailAdapter;
    private String[] titles = {"游戏介绍","开服表","游戏礼包"};
    private String gamePackageName;
    private String noView = "0";
    private boolean mIsShareUser;
    private IWeiboShareAPI mWeiboShareAPI = null;


    public static AppGameDetailFragment newInstance(String gameId, String gamePackageName,String noView) {
        AppGameDetailFragment fragment = new AppGameDetailFragment();
        Bundle args = new Bundle();
        args.putString("gameId", gameId);
        args.putString("gamePackageName", gamePackageName);
        args.putString("noView", noView);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        mGameId = args.getString("gameId");
        gamePackageName= args.getString("gamePackageName");
         noView = args.getString("NoView");

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_app_game_detail_2, container, false);
        ButterKnife.bind(this, view);
        mDownloadManager = DownloadService.getDownloadManager();
        listener = new MyListener();

//        mWeiboShareAPI = WeiboShareSDK.createWeiboAPI(_mActivity, Constant.WB_APP_KEY);


        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        mTitleBarRight.setChecked(false);

        if((boolean)SPUtil.get(App.mContext,"isLogin",false) ){
            doGetUserIsBindPhone();
        }else {
            mBtAppDetailShare.setVisibility(View.INVISIBLE);
        }
        Map<Object, Object> allAppCollectRecord = AppCollectRecordHelper.getInstance(App.mContext).getAllAppCollectRecord();
        if (allAppCollectRecord.isEmpty() || allAppCollectRecord == null) {
            return;
        }
        Set<Map.Entry<Object, Object>> entrySet = allAppCollectRecord.entrySet();
        Iterator<Map.Entry<Object, Object>> iterator = entrySet.iterator();
        Pattern pattern = Pattern.compile("^[1-9]\\d*$");
        while (iterator.hasNext()) {
            Object value = iterator.next().getValue();
            if (value != null) {
                if (value instanceof String) {
                    if (value instanceof String) {
                        if (pattern.matcher((String) value).matches()){//匹配游戏id为正整数
                            if (mGameId.equals(value)){
                                mTitleBarRight.setChecked(true);
                            }
                        }
                    }

                }
            }
        }



//        if("true".equals(SPUtil.get(App.mContext,"isLogin","false").toString().toLowerCase()) ){
//            doGetUserIsBindPhone();
//        }else {
//            mBtAppDetailShare.setVisibility(View.INVISIBLE);
//        }


    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        doGetGameDetail();
        doGetSomeGameDetail();

        /*初始化活动列表*/
        HotSomeDetailAdapter = new AppGameEventAdapter(_mActivity);


        mRvAppDetailEvents.setLayoutManager(new FullyLinearLayoutManager(_mActivity, LinearLayoutManager.VERTICAL, false));
        mRvAppDetailEvents.setAdapter(HotSomeDetailAdapter);

        for (int i = 0; i < titles.length; i++) {
            TabLayout.Tab tab2 = mTabs.newTab();
            tab2.setCustomView(getTabItem(titles[i]));
            mTabs.addTab(tab2);

        }

        /*初始化选项卡*/
        AppGameDetailViewPagerAdapter adapter = new AppGameDetailViewPagerAdapter(getChildFragmentManager(), mGameId);
        mViewPager.setAdapter(adapter);
        mTabs.setupWithViewPager(mViewPager);
    }

    private View getTabItem(String title) {
        View tab_item = LayoutInflater.from(_mActivity).inflate(R.layout.item_tab_tablayout, null, false);
        TextView tabTitle = (TextView) tab_item.findViewById(R.id.tv_tab_title);
        ImageView mimg_open= (ImageView) tab_item.findViewById(R.id.img_open);
        mimg_open.setVisibility(View.GONE);
        tabTitle.setText(title);
        return tab_item;
    }

    private void doGetSomeGameDetail(){
        GGetSomeGameDetail model = new GGetSomeGameDetail(mGameId);
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetSomeGameDetail(model, new JsonCallback<List<BHotSomeDetail>>() {
            @Override
            public void onSuccess(List<BHotSomeDetail> bHotSomeDetails, Call call, Response response) {

                if (bHotSomeDetails !=null && !bHotSomeDetails.isEmpty()){
                    mBHotSomeDetail.addAll(bHotSomeDetails);
                    HotSomeDetailAdapter.setData(mBHotSomeDetail);
                }
            }
        });
        
    }


    //获取用户是否绑定手机号,是否是分享赚用户APP058
    private void doGetUserIsBindPhone() {
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetUserIsBindPhone(new JsonCallback<BUserIsBindPhone>() {
            @Override
            public void onSuccess(BUserIsBindPhone bUserIsBindPhone, Call call, Response response) {
                if (bUserIsBindPhone != null) {
                    String isShareSale = bUserIsBindPhone.getIsShareSale();
                    if (!TextUtils.isEmpty(isShareSale)){
                        if ("true".equals(isShareSale.toLowerCase().trim().replace(" ",""))){
                            mIsShareUser = true;
                            mBtAppDetailShare.setVisibility(View.VISIBLE);
                        }else {
                            mIsShareUser = false;
                            mBtAppDetailShare.setVisibility(View.INVISIBLE);
                        }
                    }
                }
            }
        });
    }

    private void doGetGameDetail() {
        GGetGameDetail model = new GGetGameDetail(mGameId);
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetGameDetailNew(model, new JsonCallback<BGame>() {
            @Override
            public void onSuccess(BGame bGame, Call call, Response response) {
                mGame = bGame;
                if (mGame==null)
                    return;
                int defaultAndError = ImageHelper.randomImage();
                Glide.with(App.mContext).load(mGame.getIcon())
                        .error(defaultAndError)
                        .placeholder(defaultAndError)
                        .transform(new GlideRoundTransform(App.mContext, 10))
                        .into(mAppIcon);

                mName.setText(mGame.getGameName());
                if (mGame.getDiscount() != null && mGame.getDiscount().equals("10")) {
                    mTvDiscount.setVisibility(View.GONE);
                } else {
                    mTvDiscount.setVisibility(View.VISIBLE);
                    mTvDiscount.setText(mGame.getDiscount() + "折");
                }
                mTvTypeSize.setText(mGame.getTypeName() + " / " + mGame.getSize());
                if (mGame.getTypeName().equals("BT游戏")) {
                    mTvDetailBt.setVisibility(View.VISIBLE);
                } else {
                    mTvDetailBt.setVisibility(View.GONE);
                }

                downloadInfo = mDownloadManager.getDownloadInfo(mGame.getId());
                if (null != downloadInfo) {
                    downloadInfo.setListener(listener);
                }
                refreshUi(downloadInfo);

            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
            }


        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @OnClick({R.id.title_bar_left, R.id.title_bar_right, R.id.download_bt, R.id.bt_app_detail_share})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                _mActivity.onBackPressedSupport();
                break;
            case R.id.title_bar_right:
                if (mTitleBarRight.isChecked()) {

                    if (mGame != null) {
                        if (!mGame.getPackageName().equals("")) {
                            AppCollectRecordHelper.getInstance(App.mContext).addOneAppCollectRecord(mGame.getPackageName(), mGame.getId());
                            ToastUtil.showToast(App.mContext, "收藏成功");
                        }
                    }
                }else {
                    if (!mGame.getPackageName().equals("")) {
                        AppCollectRecordHelper.getInstance(App.mContext).removeOneAppCollectRecord(mGame.getPackageName());
                        ToastUtil.showToast(App.mContext, "取消收藏");
                    }

                }
                break;
            case R.id.download_bt:
                EB.postEmpty(EB.TAG.REQUEST_SD_CARD_APP_DETAIL);//获取存储权限
                String text = mBtDownload.getText().toString();
                downloadInfo = mDownloadManager.getDownloadInfo(mGame.getId());
                if (text.equals("打开")) {
                    EB.postObject(EB.TAG.CLICK_PLAY, mGame);
                    ApkUtils.launchApp(mContext, mGame.getPackageName());
                }
                if (text.equals("安装") && downloadInfo != null) {
                    //先判断安装文件是否存在

                    File temp = new File(downloadInfo.getTargetPath());
                    if (temp.exists()) {
                        ApkUtils.install(mContext, temp);
                        EB.postObject(EB.TAG.CLICK_INSATLL, mGame);//todo 2 点击安装了 将游戏对象发送出去
                    } else {
                        mDownloadManager.removeTask(mGame.getId(), true);
                        ToastUtil.showToast(mContext, "安装包可能被删除了，请重新下载");
                    }
                }
                if (text.equals("下载") || text.equals("更新")) {

                    HashMap<String, String> map = new HashMap<>();
                    map.put("gameName", mGame.getGameName());
                    MobclickAgent.onEvent(getActivity(), UMENG_EVENT_ID_DOWNLOAD, map);//友盟统计下载事件
                    //一旦触发下载动作(下载/更新/重试/继续),都要综合判断当前手机情况及设置是否允许下载
                    if (DownloadHelper.checkCanDownload(mContext)) {
                        String url = mGame.getAndroidPackage();
                        if (StringUtils.isEmpty(url)) {
                            ToastUtil.showToast(mContext, "下载链接错误 " + url);
                            return;
                        }
                        GetRequest request = OkGo.get(mGame.getAndroidPackage());
                        mDownloadManager.addTask(mGame.getId(), mGame, request, listener);
                    }
                }

                if (text.contains("%")) {
                    mDownloadManager.pauseTask(mGame.getId());
                }

                if (text.equals("重试") || text.equals("继续")) {
                    if (DownloadHelper.checkCanDownload(mContext)) {
                        mDownloadManager.addTask(mGame.getId(), downloadInfo.getRequest(), downloadInfo.getListener());
                    }
                }
                if (text.equals("等待")) {
                    ToastUtil.showToast(mContext, "已经加入下载队列");
                }
                break;
            case R.id.bt_app_detail_share:
//                mWeiboShareAPI.registerApp();
                Intent intent = new Intent(_mActivity, ShareActivity.class);
                intent.putExtra("gameId",mGameId);
                intent.putExtra("gamePackageName",gamePackageName);

                _mActivity.startActivity(intent);
                break;
        }
    }

    private class MyListener extends DownloadListener {

        @Override
        public void onProgress(DownloadInfo downloadInfo) {
            //进度有更新的时候会把整个downloadInfo回调过来
            refreshUi(downloadInfo);
        }

        @Override
        public void onFinish(DownloadInfo downloadInfo) {
            //BGame game = (BGame) downloadInfo.getData();
            //ToastUtil.showToast(mContext, game.getGameName() + "已经下载完成");
            if (downloadInfo == null)
                return;
            String taskKey = downloadInfo.getTaskKey();
            if (taskKey == null)
                return;
            GGetGameDetail model = new GGetGameDetail(taskKey);
            TaskEngine.setTokenUseridPhoneState(1);
            TaskEngine.getInstance().doGetGameDetail(model, new JsonCallback<BGame>() {
                @Override
                public void onSuccess(BGame bGame, Call call, Response response) {
                    if (bGame != null && bGame.getGameName() != null)
                        ToastUtil.showToast(mContext, bGame.getGameName() + "已经下载完成");
                }
            });
            DownloadHelper.addOneDownloadRecord(mContext, downloadInfo);//todo 向缓存的下载记录中加入一条游戏信息记录
        }

        @Override
        public void onError(DownloadInfo downloadInfo, String errorMsg, Exception e) {
            if (StringUtils.isEmpty(errorMsg)) {
                errorMsg = "下载出错，请重试";
            }
            ToastUtil.showToast(mContext, errorMsg);
        }
    }

    private void refreshUi(DownloadInfo downloadInfo) {

        //先根据包名判断游戏是否安装
        if (ApkUtils.hasInstalled(mContext, mGame.getPackageName())) {
            if (null != downloadInfo && downloadInfo.getState() == DownloadManager.DOWNLOADING) {
                double progress = Math.round(downloadInfo.getProgress() * 10000.00) * 1 / 100.00;
                mBtDownload.setProgress(progress, progress + "%");
                return;
            }
            //已经安装的,需要判断是否需要升级
            if (ApkUtils.whetherUpdate(mContext, mGame.getPackageName(), mGame.getVersionCode())) {
                mBtDownload.setProgress("更新");
            } else {
                mBtDownload.setProgress("打开");
            }
            return;
        }
        if (null == downloadInfo) {
            mBtDownload.setProgress("下载");
            return;
        }

        switch (downloadInfo.getState()) {
            case DownloadManager.NONE:
                mBtDownload.setProgress("下载");
                break;
            case DownloadManager.DOWNLOADING:
                double progress = Math.round(downloadInfo.getProgress() * 10000.00) * 1 / 100.00;
                mBtDownload.setProgress(progress, progress + "%");
                break;
            case DownloadManager.PAUSE://当前为暂停状态
                mBtDownload.setProgress(Math.round(downloadInfo.getProgress() * 10000) * 1 / 100, "继续");
                break;
            case DownloadManager.WAITING://当前为等待状态
                mBtDownload.setProgress("等待");
                break;
            case DownloadManager.ERROR://当前为错误状态
                mBtDownload.setProgress("重试");
                break;
            case DownloadManager.FINISH://当前为完成状态
                if (ApkUtils.hasInstalled(mContext, new File(downloadInfo.getTargetPath()))) {
                    mBtDownload.setProgress("打开");
                } else {
                    mBtDownload.setProgress("安装");
                }
                break;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        L.d("onResume()");
        MobclickAgent.onPageStart("AppDetailFragment");
        EB.register(this);
        if (null != mGame) {
            refreshUi(downloadInfo);
        }

    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("AppDetailFragment");
        if (null != mGame&&downloadInfo!=null) {
            refreshUi(downloadInfo);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        L.d("onDestroy()");
        EB.unregister(this);
    }

    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.APP_INSTALL:
                if (null != mGame) {
                    refreshUi(downloadInfo);
                }
                break;

            default:
                break;
        }
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);

    }


}
