package com.uu898.gamesdk.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.uu898.gamesdk.core.ResourceUtils;
import com.uu898.gamesdk.log.L;
import com.uu898.gamesdk.model.response.BOrder;

import java.util.ArrayList;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class UserPayRecordFragment extends BaseFragment {

    private ViewPager mViewPager;
    private String[] mTitles = new String[]{"所有订单", "消费成功"};
    private ArrayList<TextView> mTextViews;

    private View mTabOneNormal;
    private View mTabOneSelected;
    private View mTabTwoNormal;
    private View mTabTwoSelected;

    public static UserPayRecordFragment newInstance() {
        Bundle args = new Bundle();
        UserPayRecordFragment fragment = new UserPayRecordFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // TODO: 17/4/25  横竖屏相关
        /**
         *
         * if(v == mBtnLandscape){
         setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
         }else{
         setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
         }
         _mActivity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

         context.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT;
         *
         *
         *
         *
         */

        View view = inflater.inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_pay_record"), container, false);
        return view;
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mTabOneNormal = view.findViewById(getId("ug_tab_one_normal"));
        mTabOneSelected = view.findViewById(getId("ug_tab_one_selected"));
        mTabTwoNormal = view.findViewById(getId("ug_tab_two_normal"));
        mTabTwoSelected = view.findViewById(getId("ug_tab_two_selected"));

        mTabOneNormal.setVisibility(View.GONE);
        mTabOneSelected.setVisibility(View.VISIBLE);
        mTabTwoNormal.setVisibility(View.VISIBLE);
        mTabTwoSelected.setVisibility(View.GONE);

        initViewPager(view);

        mTabOneNormal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //选择第一个
                mViewPager.setCurrentItem(0, true);
            }
        });
        mTabTwoNormal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //选择第二个
                mViewPager.setCurrentItem(1, true);
            }
        });

    }


    // TODO: 17/4/26 交易记录接口完成后,切换列表显示
    private void initViewPager(View view) {
        mTextViews = new ArrayList<TextView>();
        for (int i = 0; i < mTitles.length; i++) {
            TextView tv = new TextView(_mActivity);
            tv.setGravity(Gravity.CENTER);
            tv.setText(mTitles[i]);
            mTextViews.add(tv);
        }
        mViewPager = (ViewPager) view.findViewById(getId("ug_viewpager"));
        mViewPager.setAdapter(new MyAdapter(getChildFragmentManager()));

        mViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {
            }

            @Override
            public void onPageSelected(int i) {
                // 0 1
                if (i == 0) {
                    mTabOneNormal.setVisibility(View.GONE);
                    mTabOneSelected.setVisibility(View.VISIBLE);
                    mTabTwoNormal.setVisibility(View.VISIBLE);
                    mTabTwoSelected.setVisibility(View.GONE);
                } else if (i == 1) {
                    mTabOneNormal.setVisibility(View.VISIBLE);
                    mTabOneSelected.setVisibility(View.GONE);
                    mTabTwoNormal.setVisibility(View.GONE);
                    mTabTwoSelected.setVisibility(View.VISIBLE);
                }
                L.d("onPageSelected " + i);
            }

            @Override
            public void onPageScrollStateChanged(int i) {
            }
        });
    }


    private class MyAdapter extends FragmentPagerAdapter {

        public MyAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            BaseFragment fragment = null;
            if (position == 0) {
                fragment = UserPayRecordChildFragment.newInstance("");
            } else if (position == 1) {
                fragment = UserPayRecordChildFragment.newInstance(BOrder.STATUS_SUCCESS);
            }
            return fragment;
        }

        @Override
        public int getCount() {
            return mTitles.length;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mTitles[position];
        }
    }


}
