package com.uu393.market.module;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.util.DensityUtils;
import com.uu393.market.util.ImageHelper;
import com.youth.banner.loader.ImageLoader;

import java.util.ArrayList;
import java.util.List;
/**
 * 折扣页有立即进入键
 *
 * 第一次打开APP从启动页进入这里
 * */
public class ADSActivity extends BaseActivity {
    private ViewPager mViewPager;
    private Button mPlay;
    private LinearLayout indicator;
    private List<View> imageViews;
    private int[] images = {R.drawable.start_1, R.drawable.start_2, R.drawable.start_3};
    private int currentPosetion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ads);
        mViewPager = (ViewPager) findViewById(R.id.vp_ads);
        indicator = (LinearLayout) findViewById(R.id.ll_indicators);
        mPlay = (Button) findViewById(R.id.btn_start_play);
        imageViews = new ArrayList<>();

        initBanner();
        initDots();
        if (Build.VERSION.SDK_INT >= 11) {

        }
    }
    private void initBanner() {
        for (int i=0;i<images.length;i++){
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            ImageView imageView = new ImageView(this);
            imageView.setLayoutParams(params);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);

            int defaultAndError = ImageHelper.randomImage();
            Glide.with(this)
                    .load(images[i])
                    .error(defaultAndError)
                    .placeholder(defaultAndError)
                    .dontAnimate()
                    .skipMemoryCache(true)
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .into(imageView);
            imageViews.add(imageView);
        }
        mViewPager.setAdapter(new MyPagerAdapter());
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                currentPosetion = position;

                for (int i = 0; i < indicator.getChildCount(); i++) {//containerBottom.getChildCount()获取容器中控件的个数
                    //通过container容器和下标position，找到指定的控件ImageView
                    ImageView iv = (ImageView) indicator.getChildAt(i);
                    if(i==position){
                        //如果遍历到的下标是当前选中的page的下标，则设置当前小圆点的图片为选中状态的图片
                        iv.setImageResource(R.drawable.ic_indicator_selected);
                    }else{
                        //否则设置为未选中的状态
                        iv.setImageResource(R.drawable.ic_indicator_unselected);
                    }

                    if (currentPosetion==images.length-1){
                        mPlay.setVisibility(View.VISIBLE);
                        mPlay.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                startActivity(new Intent(ADSActivity.this,MainActivity.class));
                                ADSActivity.this.finish();
                            }
                        });
                    }else {
                        mPlay.setVisibility(View.GONE);
                    }
                }
            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {
                /*if (state == 0&&currentPosetion==images.length-1){
                    mPlay.setVisibility(View.VISIBLE);
                    mPlay.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(ADSActivity.this,MainActivity.class));
                            ADSActivity.this.finish();
                        }
                    });
                }else {
                    mPlay.setVisibility(View.GONE);
                }*/
            }
        });
    }
    private void initDots() {
        for (int i = 0; i < images.length; i++) {
            ImageView iv = new ImageView(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(DensityUtils.dp2px(App.mContext,10), DensityUtils.dp2px(App.mContext,10));
            lp.setMargins(DensityUtils.dp2px(App.mContext,5),0, DensityUtils.dp2px(App.mContext,5),0);
            iv.setLayoutParams(lp);
            //设置图片源(默认没有选择的图片，初始化时候第一张图片对应的小圆点为dot_0)
            if(i==0){
                iv.setImageResource(R.drawable.ic_indicator_selected);
            }else{
                iv.setImageResource(R.drawable.ic_indicator_unselected);
            }
            indicator.addView(iv);
        }
    }
    public class GlideImageLoader extends ImageLoader {
        @Override
        public void displayImage(Context context, Object path, ImageView imageView) {
            /**
             注意：
             1.图片加载器由自己选择，这里不限制，只是提供几种使用方法
             2.返回的图片路径为Object类型，由于不能确定你到底使用的那种图片加载器，
             传输的到的是什么格式，那么这种就使用Object接收和返回，你只需要强转成你传输的类型就行，
             切记不要胡乱强转！
             */
            int defaultAndError = ImageHelper.randomImage();
            Glide.with(context).load((int) path).error(defaultAndError).placeholder(defaultAndError).into(imageView);
        }

    }

    class MyPagerAdapter extends PagerAdapter {

        @Override
        public int getCount() {

            return images.length;
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public Object instantiateItem(ViewGroup container, final int position) {
            container.addView(imageViews.get(position));
            View view = imageViews.get(position);
            return view;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }

    }
}
