package com.uu898app.module.base;

import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.MotionEvent;
import android.view.View;

import com.bugtags.library.Bugtags;
import com.jaeger.library.StatusBarUtil;
import com.uu898app.R;
import com.uu898app.util.permission.EasyPermissions;

import java.util.List;

import me.yokeyword.fragmentation.SupportActivity;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class BaseActivity extends SupportActivity implements EasyPermissions.PermissionCallbacks{

    /**
     * 权限回调接口
     */
    private CheckPermListener mListener;

    public interface CheckPermListener {
        //权限通过后的回调方法
        void superPermission();
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //官方在Android6.0中提供了亮色状态栏模式,就是说状态栏上的文字和图标都是黑色,比如使用了白色的背景,测试有效
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StatusBarUtil.setColor(this, getResources().getColor(R.color.colorPrimary), 0);
            this.getWindow().getDecorView().setSystemUiVisibility( View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        //注：回调 1
        Bugtags.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //注：回调 2
        Bugtags.onPause(this);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        //注：回调 3
        Bugtags.onDispatchTouchEvent(this, event);
        return super.dispatchTouchEvent(event);
    }

    @Override
    public void onPermissionsGranted(int requestCode, List<String> perms) {
        //同意了某些权限可能不是全部

    }

    @Override
    public void onPermissionsDenied(int requestCode, List<String> perms) {
        //不授予权限时,弹出对话框提示用户进入设置页面手动授予权限∂
        EasyPermissions.checkDeniedPermissionsNeverAskAgain(this,
                "没有权限会出问题的",
                R.string.setting,
                R.string.cancle,
                null, perms);
    }

    @Override
    public void onPermissionsAllGranted() {
        if (mListener != null){
            //授予权限之后,回调给调用者,正常处理要做的事情
            mListener.superPermission();//同意了全部权限的回调
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    public void baseCheckPermission(CheckPermListener listener, String resString, String... mPerms) {
        mListener = listener;
        if (EasyPermissions.hasPermissions(this, mPerms)) {
            if (mListener != null)
                mListener.superPermission();
        } else {
            EasyPermissions.requestPermissions(this, resString, 123, mPerms);
        }
    }
}
