package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/31
 * Descrip    :
 * =====================================================
 */

public class GGetH5AppIdAndKey {

    /**
     * APPID : 123456
     */

    private String APPID;

    public String getAPPID() {
        return APPID;
    }

    public void setAPPID(String APPID) {
        this.APPID = APPID;
    }
}
