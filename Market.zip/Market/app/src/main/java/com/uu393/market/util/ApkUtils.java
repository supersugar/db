package com.uu393.market.util;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;

import com.uu393.market.app.App;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Enumeration;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class ApkUtils {

    /**
     * 安装一个apk文件
     */
    public static void install(Context context, File uriFile) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.fromFile(uriFile), "application/vnd.android.package-archive");
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    /**
     * 卸载一个app
     */
    public static void uninstall(Context context, String packageName) {
        //通过程序的包名创建URI
        Uri packageURI = Uri.parse("package:" + packageName);
        //创建Intent意图
        Intent intent = new Intent(Intent.ACTION_DELETE, packageURI);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);//必须加上这个，不然程序会崩溃
        //执行卸载程序
        context.startActivity(intent);
    }


    /**
     * 从apk中获取版本信息
     */
    public static String getChannelFromApk(Context context, String channelPrefix) {
        //从apk包中获取
        ApplicationInfo appinfo = context.getApplicationInfo();
        String sourceDir = appinfo.sourceDir;
        //默认放在meta-inf/里， 所以需要再拼接一下
        String key = "META-INF/" + channelPrefix;
        String ret = "";
        ZipFile zipfile = null;
        try {
            zipfile = new ZipFile(sourceDir);
            Enumeration<?> entries = zipfile.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = ((ZipEntry) entries.nextElement());
                String entryName = entry.getName();
                if (entryName.startsWith(key)) {
                    ret = entryName;
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (zipfile != null) {
                try {
                    zipfile.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        String[] split = ret.split(channelPrefix);
        String channel = "";
        if (split.length >= 2) {
            channel = ret.substring(key.length());
        }
        return channel;
    }

    /**
     * 根据apk文件判断应用是否已经安装
     */
    public static boolean hasInstalled(Context context, File file) {
        String packageName = getPackageName(context, file.getAbsolutePath());
        if (StringUtils.isBlank(packageName)) {
            return false;
        } else {
            if (getPackageInfo(context, packageName) == null) {
                return false;
            } else {
                return true;
            }
        }
    }

    /**
     * 根据包名判断应用是否安装
     *
     * @param context
     * @param packageName
     * @return
     */
    public static boolean hasInstalled(Context context, String packageName) {
        if (StringUtils.isBlank(packageName)) {
            return false;
        } else {
            if (getPackageInfo(context, packageName) == null) {
                return false;
            } else {
                return true;
            }
        }
    }

    public static boolean whetherUpdate(Context context, String packageName, String version) {
        try {
            if (StringUtils.isBlank(packageName) || StringUtils.isBlank(version)) {
                return false;
            } else {
                PackageInfo info = getPackageInfo(context, packageName);
                if (info != null) {
                    if (info.versionCode < Integer.parseInt(version)) {
                        return true;
                    }
                }
            }
            return false;
        } catch (NumberFormatException e) {
            ToastUtil.showToast(App.mContext, "versioncode数值类型有误");
            return false;
        }
    }

    /**
     * 根据文件路径获取包名
     */
    public static String getPackageName(Context context, String filePath) {
        PackageManager packageManager = context.getPackageManager();
        PackageInfo info = packageManager.getPackageArchiveInfo(filePath, PackageManager.GET_ACTIVITIES);
        if (info != null) {
            ApplicationInfo appInfo = info.applicationInfo;
            return appInfo.packageName;  //得到安装包名称
        }
        return null;
    }

    /**
     * 根据包名获取应用信息，如果该包名应用未安装，返回null
     *
     * @Title: getPackageInfo
     */
    public static PackageInfo getPackageInfo(Context context, String packageName) {
        if (StringUtils.isBlank(packageName)) {
            return null;
        } else {
            PackageManager pm = context.getPackageManager();
            try {
                return pm.getPackageInfo(packageName, 0);
            } catch (PackageManager.NameNotFoundException e) {
                return null;
            }
        }
    }

    /**
     * 根据包名启动应用，如果应用已经不存在，则弹出toast提示打开
     *
     * @param @param context
     * @param @param packageName 设定文件
     * @return void 返回类型
     * @Title: launchApp
     * @Description:
     * @author 张博
     * @date 2014-12-16 下午4:16:56
     * @维护人:
     * @version V1.0
     */
    public static boolean launchApp(Context context, File file) {
        String packageName = getPackageName(context, file.getAbsolutePath());
        if (packageName == null || StringUtils.isBlank(packageName)) {
            return false;
        }
        if (packageName.equals(context.getPackageName())) {
            ToastUtil.showToast(context, "程序已经在运行中");
            return true;
        }
        Intent intent = new Intent();
        try {
            intent = context.getPackageManager().getLaunchIntentForPackage(packageName);
            context.startActivity(intent);
            return true;
        } catch (Exception e) {
            ToastUtil.showToast(context, "打开应用失败");
            return false;
        }
    }

    public static boolean launchApp(Context context, String packageName) {
        if (packageName == null || StringUtils.isBlank(packageName)) {
            return false;
        }
        if (packageName.equals(context.getPackageName())) {
            ToastUtil.showToast(context, "程序已经在运行中");
            return true;
        }
        Intent intent = new Intent();
        try {
            intent = context.getPackageManager().getLaunchIntentForPackage(packageName);
            context.startActivity(intent);
            return true;
        } catch (Exception e) {
            ToastUtil.showToast(context, "打开应用失败");
            return false;
        }
    }

    /**
     * 读取comment区域数据
     *
     * @param context
     * @return
     * @author 王弦
     */
    public static String readApk(Context context) {
        // 获取文件路径
        File file = new File(context.getPackageCodePath());
        byte[] bytes = null;
        RandomAccessFile accessFile = null;
        try {
            accessFile = new RandomAccessFile(file, "r");
            long index = accessFile.length();

            bytes = new byte[2];
            // 获取comment文件的位置
            index = index - bytes.length;
            accessFile.seek(index);
            // 获取comment中写入数据的大小byte类型
            accessFile.readFully(bytes);
            // 将byte转换成大小
            int contentLength = stream2Short(bytes, 0);
            // 创建byte[]数据大小来存储写入的数据
            bytes = new byte[contentLength];
            index = index - bytes.length;
            accessFile.seek(index);
            // 读取数据
            accessFile.readFully(bytes);
            return new String(bytes, "utf-8");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (accessFile != null) {
                try {
                    accessFile.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    /**
     * 字节数组转换成short
     *
     * @param stream
     * @param offset
     * @return
     * @author 王弦
     */
    private static short stream2Short(byte[] stream, int offset) {
        ByteBuffer buffer = ByteBuffer.allocate(2);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        buffer.put(stream[offset]);
        buffer.put(stream[offset + 1]);
        return buffer.getShort(0);
    }

    /**
     * @param file    需要写入数据的apk文件
     * @param comment 需要写入的数据
     * @author 王弦
     */
    @TargetApi(Build.VERSION_CODES.KITKAT)
    public static void writeApk(File file, String comment) {
        ZipFile zipFile = null;
        ByteArrayOutputStream outputStream = null;
        RandomAccessFile accessFile = null;
        try {
            zipFile = new ZipFile(file);
            String zipComment = zipFile.getComment();
            // 判断comment区域是否已经有数据了
            if (zipComment != null)
                return;
            byte[] byteComment = comment.getBytes();
            outputStream = new ByteArrayOutputStream();
            // 将数据写入输出流
            outputStream.write(byteComment);
            // 紧接着写入数据大小
            outputStream.write(short2Stream((short) byteComment.length));

            byte[] data = outputStream.toByteArray();
            accessFile = new RandomAccessFile(file, "rw");
            // 跳到comment区域
            accessFile.seek(file.length() - 2);
            // 先写入数据大小
            accessFile.write(short2Stream((short) data.length));
            // 写入数据
            accessFile.write(data);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (zipFile != null)
                    zipFile.close();
                if (outputStream != null)
                    outputStream.close();
                if (accessFile != null)
                    accessFile.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * short转换成字节数组
     *
     * @param data
     * @return
     * @author 王弦
     */
    private static byte[] short2Stream(short data) {
        ByteBuffer buffer = ByteBuffer.allocate(2);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        buffer.putShort(data);
        buffer.flip();
        return buffer.array();
    }
}
