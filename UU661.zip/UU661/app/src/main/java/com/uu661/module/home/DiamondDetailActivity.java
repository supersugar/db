package com.uu661.module.home;

import android.os.Bundle;

import com.uu661.R;
import com.uu661.module.base.BaseSwipeBackActivity;

/**
 * Created by YoKeyword on 16/4/19.
 */
public class DiamondDetailActivity extends BaseSwipeBackActivity {
    //int commodityId = (int) result[0];
    //int peroidNo = (int) result[1];

    public static final String INTENT_KEY_COMMODITY_ID = "intent_key_commodity_id";
    public static final String INTENT_KEY_PERIOD_NO = "intent_key_period_no";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        int commodityId = getIntent().getIntExtra(INTENT_KEY_COMMODITY_ID, 0);
        int periodNo = getIntent().getIntExtra(INTENT_KEY_PERIOD_NO, 0);
        if (savedInstanceState == null) {
            loadRootFragment(R.id.fl_container, DiamondDetailFragment.newInstance(commodityId, periodNo));
        }
    }

}
