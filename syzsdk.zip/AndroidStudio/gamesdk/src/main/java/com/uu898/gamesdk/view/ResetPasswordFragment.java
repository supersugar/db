package com.uu898.gamesdk.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.uu898.gamesdk.model.request.GGetSMSAuthCode;
import com.uu898.gamesdk.model.request.GResetPassword;
import com.uu898.gamesdk.network.NetCallback;
import com.uu898.gamesdk.network.TaskEngine;
import com.uu898.gamesdk.utils.CommonUtils;
import com.uu898.gamesdk.utils.CountDownTimer;
import com.uu898.gamesdk.utils.StringUtils;
import com.uu898.gamesdk.utils.ToastUtil;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class ResetPasswordFragment extends BaseFragment {

    private EditText mEdtAccount;
    private EditText mEdtAuthCode;
    private EditText mEdtPassword;
    private EditText mEdtPasswordConfirm;

    private Button mBtGetSMSCode;
    private Button mBtNext;

    private TextView mBtKefu;

    public static ResetPasswordFragment newInstance() {
        Bundle args = new Bundle();
        ResetPasswordFragment fragment = new ResetPasswordFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(getLayoutId("ug_reset_password"), container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "忘记密码");
        mEdtAccount = (EditText) view.findViewById(getId("ug_edt_account"));
        mEdtAuthCode = (EditText) view.findViewById(getId("ug_edt_auth_code"));
        mEdtPassword = (EditText) view.findViewById(getId("ug_edt_password"));
        mEdtPasswordConfirm = (EditText) view.findViewById(getId("ug_edt_password_confirm"));

        mBtGetSMSCode = (Button) view.findViewById(getId("ug_bt_get_sms_code"));
        mBtNext = (Button) view.findViewById(getId("ug_bt_next"));
        mBtKefu = (TextView) view.findViewById(getId("ug_bt_kefu"));

        mBtGetSMSCode.setOnClickListener(onClickListener);
        mBtNext.setOnClickListener(onClickListener);
        mBtKefu.setOnClickListener(onClickListener);
    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v.getId() == getId("ug_bt_get_sms_code")) {
                verifyAccount();
            } else if (v.getId() == getId("ug_bt_next")) {
                verifyForm();
            } else if (v.getId() == getId("ug_bt_kefu")) {//客服
                start(WebKefuFragment.newInstance());
            }
        }


    };

    /**
     * 校验帐号
     */
    private void verifyAccount() {
        String account = mEdtAccount.getText().toString();

        if (StringUtils.isEmpty(account)) {
            ToastUtil.showToast(_mActivity, "请输入帐号");
            return;
        }
        doGetSMSCode(account);
    }

    /**
     * 校验表单信息
     */
    private void verifyForm() {
        String account = mEdtAccount.getText().toString();
        String authcode = mEdtAuthCode.getText().toString();
        String password = mEdtPassword.getText().toString();
        String passwordConfirm = mEdtPasswordConfirm.getText().toString();


        if (StringUtils.isEmpty(account)) {
            ToastUtil.showToast(_mActivity, "请输入帐号");
            return;
        }
        if (StringUtils.isEmpty(authcode)) {
            ToastUtil.showToast(_mActivity, "请输入验证码");
            return;
        }
        if (StringUtils.isEmpty(password)) {
            ToastUtil.showToast(_mActivity, "请输入新密码");
            return;
        }
        if (StringUtils.isEmpty(passwordConfirm)) {
            ToastUtil.showToast(_mActivity, "请确认新密码");
            return;
        }
        if (!password.equals(passwordConfirm)) {
            ToastUtil.showToast(_mActivity, "两次输入密码不一致");
            return;
        }

        doResetPasswrod(account, password, authcode);
    }

    private void doGetSMSCode(String account) {
        GGetSMSAuthCode model = new GGetSMSAuthCode();
        model.setUserId(account);
        model.setType(GGetSMSAuthCode.type_7);//找回登录密码验证码
        TaskEngine.getInstance().doGetSMSAuthCode(model, new NetCallback(this) {

            @Override
            public void _onNext(Object o) {
                ToastUtil.showToast(_mActivity, "短信验证码已发送至您的手机");
                new CountDownTimer(60000, 1000, mBtGetSMSCode, "获取验证码").start();
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

    private void doResetPasswrod(String account, String password, String authcode) {
        GResetPassword model = new GResetPassword();
        model.setUserId(account);
        model.setPassword(CommonUtils.encryptString(password));
        model.setCheckCode(authcode);
        TaskEngine.getInstance().doResetPassword(model, new NetCallback(this) {
            @Override
            public void _onNext(Object o) {
                ToastUtil.showToast(_mActivity, "修改成功,请重新登录");
                popTo(LoginFragment.class, false);
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

}
