package com.uu898.gamesdk.view;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.uu898.gamesdk.core.ResourceUtils;
import com.uu898.gamesdk.model.response.BAliPay;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class WebWXPayFragment extends BaseFragment {

    private WebView mWebView;
    private BAliPay mModel;

    public static WebWXPayFragment newInstance(BAliPay model) {
        Bundle args = new Bundle();
        args.putSerializable("model", model);
        WebWXPayFragment fragment = new WebWXPayFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        if (args != null) {
            mModel = (BAliPay) args.getSerializable("model");
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_wx_pay"), container, false);
        return view;
    }



    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mWebView = (WebView) view.findViewById(getId("ug_web_view"));

        mWebView.getSettings().setJavaScriptEnabled(true);
        //        webview.addJavascriptInterface(new WebAppInterface(getActivity(), webview), "Android");
        mWebView.setWebChromeClient(new WebChromeClient());
        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                showLoadToast();
            }

            @SuppressLint("DefaultLocale")
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                hideLoadToast();
                // 如下方案可在非微信内部WebView的H5页面中调出微信支付
                if (url.startsWith("weixin://wap/pay?")) {
                    Intent intent = new Intent();
                    intent.setAction(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse(url));
                    startActivity(intent);
                    return true;
                }else if(url.equals("http://ddd.cuowuwangzhi.com/")){//支付成功
                    replaceFragment(UserPayResultFragment.newInstance(mModel),false);
                    return true;
                }
                return super.shouldOverrideUrlLoading(view, url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                hideLoadToast();
                super.onPageFinished(view, url);
            }
        });
        mWebView.loadUrl(mModel.signOrderNo);
    }

}
