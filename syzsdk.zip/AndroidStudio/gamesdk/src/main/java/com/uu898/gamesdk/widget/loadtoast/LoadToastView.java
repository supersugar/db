package com.uu898.gamesdk.widget.loadtoast;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.util.TypedValue;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;

import com.nineoldandroids.animation.ValueAnimator;
import com.uu898.gamesdk.core.ResourceUtils;

import org.xutils.x;


/**
 * Created by Wannes2 on 23/04/2015.
 */
public class LoadToastView extends ImageView {

    private int TOAST_HEIGHT = 48;
    private int LINE_WIDTH = 3;

    private static final float X_OFFSET = 0f;
    private static final float Y_OFFSET = 1.75f;
    private static final float SHADOW_RADIUS = 3.5f;
    private static final int SHADOW_ELEVATION = 4;
    private int mShadowRadius;

    private ValueAnimator va;
    private ValueAnimator cmp;

    private MaterialProgressDrawable spinnerDrawable;

    public LoadToastView(Context context) {
        super(context);
        TOAST_HEIGHT = dpToPx(TOAST_HEIGHT);
        LINE_WIDTH = dpToPx(LINE_WIDTH);

        va = ValueAnimator.ofFloat(0, 1);
        va.setDuration(6000);
        va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                postInvalidate();
            }
        });
        va.setRepeatMode(ValueAnimator.INFINITE);
        va.setRepeatCount(9999999);
        va.setInterpolator(new LinearInterpolator());
        va.start();

        initSpinner();
    }

    private void initSpinner() {
        spinnerDrawable = new MaterialProgressDrawable(getContext(), this);

        spinnerDrawable.setStartEndTrim(0, .5f);
        spinnerDrawable.setProgressRotation(.5f);

        int mDiameter = TOAST_HEIGHT;
        int mProgressStokeWidth = LINE_WIDTH;
        spinnerDrawable.setSizeParameters(mDiameter, mDiameter, (mDiameter - mProgressStokeWidth * 2) / 4, mProgressStokeWidth, mProgressStokeWidth * 4, mProgressStokeWidth * 2);

        spinnerDrawable.setBackgroundColor(Color.TRANSPARENT);
        spinnerDrawable.setColorSchemeColors(getResources().getColor(ResourceUtils.getColorId(x.app(), "pink")));
        spinnerDrawable.setVisible(true, false);
        spinnerDrawable.setAlpha(255);

        setImageDrawable(null);
        setImageDrawable(spinnerDrawable);

        spinnerDrawable.start();
    }

    public void setProgressColor(int color) {
        spinnerDrawable.setColorSchemeColors(color);
    }

    public void show() {
        if (cmp != null)
            cmp.removeAllUpdateListeners();
    }

    public void success() {
        done();
    }

    public void error() {
        done();
    }

    private void done() {
        cmp = ValueAnimator.ofFloat(0, 1);
        cmp.setDuration(0);
        cmp.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                postInvalidate();
            }
        });
        cmp.setInterpolator(new DecelerateInterpolator());
        cmp.start();
    }

    private int dpToPx(int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
    }


    private boolean elevationSupported() {
        return android.os.Build.VERSION.SDK_INT >= 21;
    }

    private ShapeDrawable mBgCircle;


    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        final float density = getContext().getResources().getDisplayMetrics().density;
        final int shadowYOffset = (int) (density * Y_OFFSET);
        final int shadowXOffset = (int) (density * X_OFFSET);
        mShadowRadius = (int) (density * SHADOW_RADIUS);

        mBgCircle = new ShapeDrawable(new OvalShape());
//        if (elevationSupported()) {
//            ViewCompat.setElevation(this, SHADOW_ELEVATION * density);
//        }
        mBgCircle.getPaint().setColor(Color.WHITE);
        setBackgroundDrawable(mBgCircle);

    }


    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        if (elevationSupported() == false) {
            setMeasuredDimension(getMeasuredWidth() + mShadowRadius * 2, getMeasuredHeight()
                    + mShadowRadius * 2);
        }
    }
}
