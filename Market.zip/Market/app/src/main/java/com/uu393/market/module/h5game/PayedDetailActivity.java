package com.uu393.market.module.h5game;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.model.request.GGetOrderDetail;
import com.uu393.market.model.response.BOrderDetail;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

public class PayedDetailActivity extends BaseActivity {

    @Bind(R.id.ib_payed_detail_go_back)
    ImageButton mIbPayedDetailGoBack;
    @Bind(R.id.title)
    RelativeLayout mTitle;
    @Bind(R.id.tv_payed_detail_name)
    TextView mTvPayedDetailName;
    @Bind(R.id.tv_payed_detail_time)
    TextView mTvPayedDetailTime;
    @Bind(R.id.tv_payed_detail_price)
    TextView mTvPayedDetailPrice;
    @Bind(R.id.tv_payed_detail_status)
    TextView mTvPayedDetailStatus;
    @Bind(R.id.tv_payed_detail_number)
    TextView mTvPayedDetailNumber;
    @Bind(R.id.tv_payed_detail_count)
    TextView mTvPayedDetailCount;
    @Bind(R.id.tv_payed_detail_single_price)
    TextView mTvPayedDetailSinglePrice;
    @Bind(R.id.btn_payed_detail_pay)
    Button mBtnPayedDetailPay;
    private String APPID;
    private String mOrederNo;
    private String mOrderStatus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payed_detail);
        ButterKnife.bind(this);
        Intent intent = getIntent();
        if (intent!=null){
            APPID = intent.getStringExtra("APPID");
            mOrederNo = intent.getStringExtra("orderNo");
        }
        getOrederDetail();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getOrederDetail();
    }

    private void getOrederDetail(){
        GGetOrderDetail model = new GGetOrderDetail();
        model.setAPPID(APPID);
        model.setOrderNo(mOrederNo);
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetOrderDetail(model, new JsonCallback<BOrderDetail>() {
            @Override
            public void onSuccess(BOrderDetail bOrderDetail, Call call, Response response) {
                if (bOrderDetail!=null){
                    setViewData(bOrderDetail);
                }
            }
        });
    }

    private void setViewData(BOrderDetail orderDetail){
        mTvPayedDetailName.setText(orderDetail.getTitle());//名字
        mTvPayedDetailTime.setText(orderDetail.getAddTime());//时间
        mTvPayedDetailPrice.setText(orderDetail.getTotalMoney()+"元");//充值金额
        //状态需要判断
        mOrderStatus = orderDetail.getStatus();
        switch (mOrderStatus){
            case "0":
                mTvPayedDetailStatus.setText("已取消");//订单状态
                break;
            case "1":
                mTvPayedDetailStatus.setText("支付完成");//订单状态
                break;
            case "2":
                mTvPayedDetailStatus.setText("订单完成");//订单状态
                break;
            case "3":
                mTvPayedDetailStatus.setText("订单失败");//订单状态
                break;
            case "4":
                mTvPayedDetailStatus.setText("支付超时，已取消");//订单状态
                break;
            default:
                break;
        }
        mTvPayedDetailNumber.setText("订单编号："+orderDetail.getOrderNo());//订单编号
        mTvPayedDetailCount.setText("充值面额："+orderDetail.getDescribe());//充值面额
        mTvPayedDetailSinglePrice.setText(orderDetail.getPrice()+"元");//单价
    }

    @OnClick({R.id.ib_payed_detail_go_back, R.id.btn_payed_detail_pay})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ib_payed_detail_go_back:
                super.onBackPressedSupport();
                break;
            case R.id.btn_payed_detail_pay:
                //APP中不能支付，支付在游戏中进行
                break;
        }
    }
}
