package com.uu393.market.module.home;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Html;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.R;
import com.uu393.market.model.request.GGetHotActivityDetail;
import com.uu393.market.model.response.BHotActivityDetail;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.Base64Helper;
import com.uu393.market.view.progressbutton.SubmitProcessButton;

import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

import static com.uu393.market.module.home.AppDetailActivity.INTENT_KEY_GAME_ID;
import static com.uu393.market.module.home.AppDetailActivity.INTENT_KEY_GAME_PACKAGENAME;

/**
 * Created by Z on 2017/4/20.
 */

public class HotActionDetailsActivity extends BaseActivity {

    @Bind(R.id.title_bar_left)
    ImageButton titleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton titleBarRight;
    @Bind(R.id.title_bar_title)
    TextView titleBarTitle;
    @Bind(R.id.tv_hot_item_title)
    TextView tvHotItemTitle;
    @Bind(R.id.tv_hot_item_time)
    TextView tvHotItemTime;
    @Bind(R.id.layout_hot_item)
    RelativeLayout layoutHotItem;
    @Bind(R.id.wv_hotactiondetails)
    BrowserLayout browser;
    @Bind(R.id.skip_bt)
    SubmitProcessButton skipBt;
    private String mActivityId;
    private String mGameId;
    private String mPackageName;
    private String noView ;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotactiondetails);
        ButterKnife.bind(this);
        Intent intent = getIntent();
        mActivityId = intent.getStringExtra("id");
        noView = intent.getStringExtra("noView");

        if ( noView !=null){
            if (noView.equals("1") )
            skipBt.setVisibility(View.VISIBLE);
        }

        titleBarRight.setVisibility(View.GONE);
        titleBarTitle.setText("热门活动");
        doGetHotActivityDetail();

    }

    public void doGetHotActivityDetail() {
        GGetHotActivityDetail model = new GGetHotActivityDetail();
        model.setId(mActivityId);
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetHotActivityDetail(model, new JsonCallback<BHotActivityDetail>() {
            @Override
            public void onSuccess(BHotActivityDetail bHotActivityDetails, Call call, Response response) {
                if (bHotActivityDetails != null) {
                    String html = null;
                    html = Base64Helper.decodeToHtml(bHotActivityDetails.getInfo());
                    initWebView(html);
                    tvHotItemTitle.setText(bHotActivityDetails.getTitle());
                    tvHotItemTime.setText(bHotActivityDetails.getBeginTime() + "至" + bHotActivityDetails.getEndTime());
                    mGameId = bHotActivityDetails.getGameID();
                    mPackageName = bHotActivityDetails.getPackageName();
                }
            }
        });

    }

    private void initWebView(String gameUrl) {

        browser.loadUrl(gameUrl);
    }


    @OnClick({R.id.title_bar_left, R.id.skip_bt})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                super.onBackPressed();
                break;
            case R.id.skip_bt:
                Intent intent = new Intent(HotActionDetailsActivity.this, AppDetailActivity.class);
                intent.putExtra(INTENT_KEY_GAME_ID, mGameId);
                intent.putExtra(INTENT_KEY_GAME_PACKAGENAME,mPackageName);
                startActivity(intent);

        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (browser.canGoBack()) {
                browser.goBack();
            }
            return super.onKeyDown(keyCode, event);
        }
        return super.onKeyDown(keyCode, event);
    }


}
