package com.uu661.model.response;

import java.io.Serializable;

/**
 * Created by bo on 16/9/14.
 */
public class BUserInfo implements Serializable {

    public String UZuan;//
    public long money;//
    public String userId;//
    public String UId;//
    public String counts;//红包数量
    public int regStatus;//用户注册状态
    public int showStatus;//
}
