package com.uu898.gamesdk.model.response;

import android.text.TextUtils;

import java.io.Serializable;

/**
 * Created by bo on 16/9/14.
 */
public class BOrder implements Serializable{

    public static final String STATUS_CANCLE = "0";
    public static final String STATUS_PAY_ING = "1";
    public static final String STATUS_SUCCESS = "2";
    public static final String STATUS_FAIL = "3";
    public static final String STATUS_TIMEOUT = "4";

    public String OrderNo;
    public String Title;
    public String AddTime;
    public String TotalMoney;
    public String Status;
    public String Price;//单价(元)
    public String Number;//数量
    public String Describe;//描述

    public String getStatusForShow(){
        String show = "";
        if(TextUtils.isEmpty(Status)){
            show = "未知状态";
        }else if(Status.equals(STATUS_CANCLE)){
            show = "已取消";
        }else if(Status.equals(STATUS_PAY_ING)){
            show = "支付中";
        }else if(Status.equals(STATUS_SUCCESS)){
            show = "支付成功";
        }else if(Status.equals(STATUS_FAIL)){
            show = "支付失败";
        }else if(Status.equals(STATUS_TIMEOUT)){
            show = "支付超时";
        }

        return show;
    }

}
