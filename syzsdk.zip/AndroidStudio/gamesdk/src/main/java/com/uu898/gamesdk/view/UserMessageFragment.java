package com.uu898.gamesdk.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.uu898.gamesdk.core.ResourceUtils;
import com.uu898.gamesdk.log.L;
import com.uu898.gamesdk.model.GBaseModel;
import com.uu898.gamesdk.model.request.GDeleteMessages;
import com.uu898.gamesdk.model.response.BMessage;
import com.uu898.gamesdk.network.NetCallback;
import com.uu898.gamesdk.network.TaskEngine;
import com.uu898.gamesdk.utils.ToastUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class UserMessageFragment extends BaseFragment {

    private final int STATUS_EDIT = 0;
    private final int STATUS_DELETE = 1;
    private final int STATUS_DONE = 2;

    private Button mBtTitleRight;

    private int mCurrentStatus = STATUS_EDIT;

    private ListView mListView;
    private MyAdapter mAdapter;
    private List<BMessage> mList = new ArrayList<BMessage>();
    private List<String> mCheckedIds = new ArrayList<String>();

    public static UserMessageFragment newInstance() {
        Bundle args = new Bundle();
        UserMessageFragment fragment = new UserMessageFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        View view = inflater.inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_message"), container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        View titleBar = initTitleBar(view, "我的消息");
        mBtTitleRight = (Button) titleBar.findViewById(getId("ug_bt_title_right"));
        mBtTitleRight.setVisibility(View.GONE);
        mBtTitleRight.setOnClickListener(onClickListener);
        setTitleRight(STATUS_EDIT);

        mListView = (ListView) view.findViewById(getId("ug_list_view"));
        mAdapter = new MyAdapter();
        mListView.setAdapter(mAdapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                start(UserMessageDetailFragment.newInstance(mList.get(position)));
            }
        });

        doGetMessages();
    }

    private void setTitleRight(int status) {
        mCurrentStatus = status;
        String show = "";
        if (status == STATUS_EDIT) {
            show = "编辑";
        } else if (status == STATUS_DONE) {
            show = "完成";
        } else if (status == STATUS_DELETE) {
            show = "删除";
        }
        mBtTitleRight.setText(show);
    }

    private void norifyCheckedIdsChanged() {
        if(mCheckedIds.isEmpty()){
            setTitleRight(STATUS_DONE);
        }else{
            setTitleRight(STATUS_DELETE);
        }
    }


    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (mCurrentStatus) {
                case STATUS_EDIT:
                    setTitleRight(STATUS_DONE);
                    mAdapter.notifyDataSetChanged();
                    break;
                case STATUS_DONE:
                    setTitleRight(STATUS_EDIT);
                    mCheckedIds.clear();
                    mAdapter.notifyDataSetChanged();
                    break;
                case STATUS_DELETE:
                    if(!mCheckedIds.isEmpty()){
                        doDeleteMessages();
                    }
                    break;
            }
        }
    };

    private void doGetMessages() {
        TaskEngine.getInstance().doGetMessageList(new GBaseModel(), new NetCallback<List<BMessage>>(this) {
            @Override
            public void _onNext(List<BMessage> list) {
                L.d(list.size());
                mList = list;
                mAdapter.notifyDataSetChanged();
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

    private void doDeleteMessages() {
        StringBuilder sb = new StringBuilder();
        for(String id: mCheckedIds){
            sb.append(id);
            sb.append(",");
        }
        GDeleteMessages model = new GDeleteMessages();
        model.setID(sb.toString().substring(0,sb.length()-1));
        TaskEngine.getInstance().doDeleteMessages(model, new NetCallback(this) {
            @Override
            public void _onNext(Object o) {
                ToastUtil.showToast(_mActivity, "删除成功");
                mCheckedIds.clear();
                setTitleRight(STATUS_EDIT);
                doGetMessages();
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

    private class MyAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return mList.size();
        }

        @Override
        public Object getItem(int position) {
            return mList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            ViewHolder holder = null;
            if (null == convertView) {
                convertView = LayoutInflater.from(_mActivity).inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_message_item"), null);
                holder = new ViewHolder();
                holder.read = convertView.findViewById(getId("ug_message_item_read"));
                holder.title = (TextView) convertView.findViewById(getId("ug_message_item_title"));
                holder.desc = (TextView) convertView.findViewById(getId("ug_message_item_desc"));
                holder.cb = (CheckBox) convertView.findViewById(getId("ug_message_item_cb"));
                holder.go = (ImageView) convertView.findViewById(getId("ug_message_item_go"));
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }
            holder.title.setText(mList.get(position).Title);
            holder.desc.setText(mList.get(position).Content);
            if (mList.get(position).viewed) {
                holder.read.setBackgroundColor(_mActivity.getResources().getColor(ResourceUtils.getColorId(_mActivity, "green")));
            } else {
                holder.read.setBackgroundColor(_mActivity.getResources().getColor(ResourceUtils.getColorId(_mActivity, "pink")));
            }
            holder.read.setVisibility(View.GONE);

            if(mCurrentStatus == STATUS_DONE || mCurrentStatus == STATUS_DELETE){
                holder.cb.setVisibility(View.VISIBLE);
                holder.go.setVisibility(View.GONE);
            }else{
                holder.cb.setVisibility(View.GONE);
                holder.go.setVisibility(View.VISIBLE);
            }

            holder.cb.setChecked(mCheckedIds.contains(mList.get(position).ID));

            holder.cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(isChecked){
                        mCheckedIds.add(mList.get(position).ID);
                    }else{
                        mCheckedIds.remove(mList.get(position).ID);
                    }
                    norifyCheckedIdsChanged();
                }
            });

            return convertView;
        }

        private class ViewHolder {
            View read;
            TextView title;
            TextView desc;
            ImageView go;
            CheckBox cb;
        }
    }


}
