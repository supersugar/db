package com.uu898.gamesdk.core;

import com.uu898.gamesdk.network.NetConstant;
import com.uu898.gamesdk.utils.FloatViewHelper;

/**
 * Created by bo on 16/11/8.
 */

public class UGCoreHelper {

    public static String APPID = "";
    public static String APP_KEY = "";

    private static String URL = NetConstant.URL.URL_SYZ_TEST;

    public static void init(String appId, String key) {
        APPID = appId;
        APP_KEY = key;
        FloatViewHelper.init();
    }

    public static String getURL() {
        return URL;
    }

    public static void setURL(String URL) {
        UGCoreHelper.URL = URL;
    }
}
