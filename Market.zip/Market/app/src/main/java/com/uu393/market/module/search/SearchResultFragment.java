package com.uu393.market.module.search;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;

import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.model.PageModel;
import com.uu393.market.model.request.GGetGameList;
import com.uu393.market.model.response.BGame;
import com.uu393.market.module.base.BaseFragment;
import com.uu393.market.module.home.ApkListAdapter;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.CommonUtils;
import com.uu393.market.util.StringUtils;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

public class SearchResultFragment extends BaseFragment {

    private EditText mEditText;
    private ImageButton mSearchBt;

    private PullLoadMoreRecyclerView mRVResult;

    private ApkListAdapter mResultAdapter;

    private int mPageIndex = 1;
    private ArrayList<BGame> mGameList = new ArrayList<>();
    private String mSearchKey;

    public static SearchResultFragment newInstance(String searchKey, List<BGame> resultList) {
        SearchResultFragment fragment = new SearchResultFragment();
        Bundle args = new Bundle();
        args.putString("searchKey", searchKey);
        args.putSerializable("resultList", (Serializable) resultList);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.search_result_fragment, null);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mSearchKey = getArguments().getString("searchKey");
        mGameList = (ArrayList<BGame>) getArguments().getSerializable("resultList");

        mEditText = (EditText) view.findViewById(R.id.edit_text);
        mSearchBt = (ImageButton) view.findViewById(R.id.title_bar_right);
        mRVResult = (PullLoadMoreRecyclerView) view.findViewById(R.id.recycler_view_result);

        mResultAdapter = new ApkListAdapter(_mActivity);
        mRVResult.setLinearLayout();
        mRVResult.setAdapter(mResultAdapter);
        mResultAdapter.updateData(mGameList);
        mRVResult.setOnPullLoadMoreListener(new PullLoadMoreRecyclerView.PullLoadMoreListener() {
            @Override
            public void onRefresh() {
                doSearch(mSearchKey, false);
            }

            @Override
            public void onLoadMore() {
                doSearch(mSearchKey, true);
            }
        });

        mSearchBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String searchKey = mEditText.getText().toString();
                hideSoftInput();
                if (StringUtils.isEmpty(searchKey)) {
                } else {
                    mSearchKey = searchKey;
                    //联网搜索
                    doSearch(mSearchKey, false);
                    //存储历史记录
                    CommonUtils.updateSearchList(searchKey);
                }
            }
        });
    }




    private void doSearch(String searchKey, final boolean loadMore) {
        GGetGameList model = new GGetGameList();
        model.gameName = searchKey;
        model.gameType = "-1";
        if (loadMore == false) {
            mPageIndex = 1;
        }
        PageModel page = new PageModel(mPageIndex);
        TaskEngine.getInstance().doGetGameList(model, page, new JsonCallback<List<BGame>>() {
            @Override
            public void onSuccess(List<BGame> bGames, Call call, Response response) {
                mPageIndex++;
                if (loadMore == false) {//非增量加载
                    mGameList.clear();
                }
                mGameList.addAll(bGames);
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                if (e instanceof APIException) {
                    String apiCode = ((APIException) e).getCode();
                    if (apiCode.equals("1")) {
                        //                        changeView(NO_RESULT);
                    }
                }
            }

            @Override
            public void onAfter(List<BGame> bGames, Exception e) {
                super.onAfter(bGames, e);
                mRVResult.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mResultAdapter.updateData(mGameList);
                        mRVResult.setPullLoadMoreCompleted();
                    }
                }, 100);
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart("SearchResultFragment");
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("SearchResultFragment");
    }
}
