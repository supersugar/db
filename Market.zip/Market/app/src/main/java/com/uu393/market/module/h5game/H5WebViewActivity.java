package com.uu393.market.module.h5game;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.alipay.sdk.app.PayTask;
import com.uu393.market.R;
import com.uu393.market.app.App;

import com.uu393.market.model.request.GDoAddPlayedGame;
import com.uu393.market.model.request.GGetH5AppIdAndKey;
import com.uu393.market.model.request.GGetPayedInfo;
import com.uu393.market.model.response.BH5GameAppIdAndKey;
import com.uu393.market.model.response.BPayedInfo;
import com.uu393.market.module.alipay.AliPayResult;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ContactCustomerServicesUtils;
import com.uu393.market.util.DateUtils;
import com.uu393.market.util.DensityUtils;
import com.uu393.market.util.MD5;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.log.L;
import com.uu393.market.view.floatview.FloatView;

import java.net.URLEncoder;

import butterknife.Bind;
import butterknife.ButterKnife;
import okhttp3.Call;
import okhttp3.Response;
import pub.devrel.easypermissions.AppSettingsDialog;

import static android.webkit.WebSettings.LOAD_DEFAULT;


public class H5WebViewActivity extends BaseActivity {

    @Bind(R.id.wv_game)
    WebView mWvGame;
    private FloatView mFloatView;
    private String mGameId;
    private String uId;
    private String userId;
    private Dialog mUserDialog;
    private String mChannelExt;
    private String mUrl;
    private BPayedInfo mPayedInfo;
    private String signOrderNo;
    private String orderNo;
    private String mChannelId;
    private String mChannelKey;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_h5_game);
        ButterKnife.bind(this);
        requestDrawOverLays();//判断申请浮球权限
        Intent intent = getIntent();//获取url，拼装
        if (intent != null) {
            mUrl = intent.getStringExtra("url");
            mGameId = intent.getStringExtra("gameId");
            mChannelExt = intent.getStringExtra("APPID");
        } else {
            //异常
        }
        getH5GameAppIdAndAppKey(mChannelExt);
        getUserInfo();//获取UU用户信息
        getUserPayedInfo();//获取用户充值信息
        initFloatView();//初始化浮球

        //进入游戏后，添加一条游戏记录
        GDoAddPlayedGame addPlayedGame = new GDoAddPlayedGame();
        addPlayedGame.setAPPID(mChannelExt);
        addPlayedGame.setGameID(mGameId);
        addPlayedGame.setPlatform("1");
        doAddOnePlayedH5Game(addPlayedGame);
    }

    public void getH5GameAppIdAndAppKey(String APPID) {
        GGetH5AppIdAndKey model = new GGetH5AppIdAndKey();
        model.setAPPID(APPID);
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetH5AppIdAndKey(model, new JsonCallback<BH5GameAppIdAndKey>() {
            @Override
            public void onSuccess(final BH5GameAppIdAndKey bh5GameAppIdAndKey, Call call, Response response) {
                if (bh5GameAppIdAndKey != null) {

                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            mChannelId = bh5GameAppIdAndKey.getChannelAPPID();
                            mChannelKey = bh5GameAppIdAndKey.getMd5Key();
                            initWebView();//初始化WebView
                        }
                    });
                }
            }
        });
    }

    public void getUserInfo() {
        uId = (String) SPUtil.get(this, "uId", "");
        userId = (String) SPUtil.get(this, "userId", "");
    }

    private void getUserPayedInfo() {
        //-------------------------获取用户充值信息-----------------------------
        GGetPayedInfo model = new GGetPayedInfo();
        model.setAPPID(mChannelExt);
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetPayedInfo(model, new JsonCallback<BPayedInfo>() {
            @Override
            public void onSuccess(BPayedInfo bPayedInfo, Call call, Response response) {
                if (bPayedInfo != null)
                    mPayedInfo = bPayedInfo;
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                ToastUtil.showToast(App.mContext, "获取用户信息异常");
            }
        });
        //-------------------------获取用户充值信息-----------------------------
    }

    private void doAddOnePlayedH5Game(GDoAddPlayedGame model ){
        //---------------------添加一条玩过的记录---------------------------------
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doAddOnePlayedGame(model, new JsonCallback<Object>() {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                L.d("添加一条玩过的H5游戏成功");
            }
        });
        //---------------------添加一条玩过的记录---------------------------------
    }


    /**
     * @param uId    uu用户uId
     * @param userId uu用户userId
     * @return 游戏正式地址
     */
    private String jointGameUrl(String uId, String userId) {
        StringBuffer buffer = new StringBuffer();
        long time = DateUtils.dateToUnixTimestamp() / 1000;
        String preSign = new StringBuffer()
                .append("appId=")
                .append(mChannelId)
                .append("time=")
                .append("" + time)
                .append("userId=")
                .append(uId)
                .append(mChannelKey)//平台提供
                .toString();
        L.d("预签名字符串：："+preSign);
        String sign = MD5.getMD5(preSign.getBytes());
        L.d("MD5后字符串：："+sign);
        buffer.append(mUrl)
                .append("/")
                .append("?userId=").append(uId)
                .append("&userName=").append(userId)
                .append("&userSex=").append("0")//0未知；1 男；2女
                .append("&channelExt=").append(mChannelExt)
                .append("&userImg=").append(URLEncoder.encode(""))
                .append("&time=").append("" + time)
                .append("&sign=").append(sign);//签名
        L.d("生成的H5游戏链接：："+buffer.toString());
/**
 * 验证签名，该接口签名方式：md5(“appId=[appId]time=[time]userId=[userId][appKey]”);
 * [appId]代表appId的值， appId, appKey有Egret开放平台提供 （appId即为Egret开放平台上的渠道id），
 * sign 值应是数字和小写字母组成的字符串
 *
 * */
        return buffer.toString();
    }

    private void initWebView() {
        mWvGame.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        mWvGame.requestFocusFromTouch();//可以输入
        mWvGame.getSettings().setJavaScriptEnabled(true);//设置可以与h5交互
        String gameUrl = jointGameUrl(uId, userId);
        mWvGame.getSettings().setJavaScriptEnabled(true);
        mWvGame.getSettings().setDomStorageEnabled(true);
        mWvGame.getSettings().setAllowFileAccess(true);
        mWvGame.getSettings().setAppCacheEnabled(true);
        mWvGame.getSettings().setAppCachePath(getApplicationContext().getCacheDir().getAbsolutePath());
        mWvGame.getSettings().setAppCacheMaxSize(1024 * 1024 * 10);
        mWvGame.getSettings().setCacheMode(LOAD_DEFAULT);
        mWvGame.setWebChromeClient(new WebChromeClient());
        mWvGame.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }

            @SuppressLint("DefaultLocale")
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                L.d(url);
                // 如下方案可在非微信内部WebView的H5页面中调出微信支付
                if (url.startsWith("weixin://wap/pay?")) {//微信支付
                    try {
                        Intent intent = new Intent();
                        intent.setAction(Intent.ACTION_VIEW);
                        intent.setData(Uri.parse(url));
                        startActivity(intent);
                    } catch (ActivityNotFoundException e) {
                        e.printStackTrace();
                        ToastUtil.showToast(App.mContext, "请先安装微信");
                    }
                    return true;
                } else if (url.startsWith("http://ddd.cuowuwangzhi.com/?signOrderNo=")) {//支付宝支付
                    view.stopLoading();
                    int i = url.indexOf("=");
                    final String params = url.substring(i + 1);
                    int indexOrderNo = params.indexOf("&orderNo=");
                    signOrderNo = params.substring(0, indexOrderNo);
                    orderNo = params.substring(indexOrderNo + "&orderNo=".length());
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            PayTask payTask = new PayTask(H5WebViewActivity.this);
                            String result = payTask.pay(signOrderNo, true);
                            Message message = handler.obtainMessage();
                            message.what = 99;
                            message.obj = result;
                            handler.sendMessage(message);
                        }
                    }).start();
                    return true;
                }
                return super.shouldOverrideUrlLoading(view, url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
            }
        });
        mWvGame.loadUrl(gameUrl);
        L.d(gameUrl);
    }


    private void initFloatView() {
        mFloatView = new FloatView(this);
        mFloatView.show();
        View rootFloatView = mFloatView.getRootFloatView();
        rootFloatView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                L.d("H5游戏中个人中心");
                handler.sendEmptyMessage(0);
                getUserPayedInfo();//点浮球刷新用户充值信息
                final View inflate = LayoutInflater.from(H5WebViewActivity.this).inflate(R.layout.dialog_webview_user_center, null, false);
                ImageButton goBack = (ImageButton) inflate.findViewById(R.id.ib_web_view_user_center_go_back);

                View toPayed = inflate.findViewById(R.id.rl_web_view_user_center_to_payed);
                ImageView icon = (ImageView) inflate.findViewById(R.id.iv_web_view_user_center_icon);
                TextView id = (TextView) inflate.findViewById(R.id.tv_web_view_user_center_user_id);
                TextView charge = (TextView) inflate.findViewById(R.id.tv_web_view_user_center_charge);
                ImageButton go = (ImageButton) inflate.findViewById(R.id.ib_web_view_user_center_go);
                View giftBag = inflate.findViewById(R.id.rl_web_view_user_center_gift);
                View contact = inflate.findViewById(R.id.rl_web_view_user_center_contact);

                if (mPayedInfo == null) {
                    id.setText("ID：");
                    charge.setText("");
                } else {
                    go.setClickable(true);
                    giftBag.setClickable(true);
                    id.setText("ID：" + mPayedInfo.getUserID());
                    charge.setText(mPayedInfo.getRechargeMoney());
                }

                //todo 弹窗
                if (mUserDialog == null) {
                    mUserDialog = new Dialog(H5WebViewActivity.this, R.style.DialogStyle);
                    mUserDialog.setContentView(inflate);

                    Window window = mUserDialog.getWindow();
                    window.setGravity(Gravity.CENTER);
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                        window.setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
                    }
                    //获得窗体的属性
                    WindowManager.LayoutParams lp = window.getAttributes();
                    WindowManager m = getWindowManager();
                    Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
                    //获得窗体的属性
                    lp.width = d.getWidth() - DensityUtils.dp2px(App.mContext, 20);
                    lp.height = DensityUtils.dp2px(App.mContext, 266);
                    window.setAttributes(lp);

                }
                mUserDialog.show();

                goBack.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mUserDialog.dismiss();
                    }
                });

                toPayed.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        hideFloatView();
                        Intent intent = new Intent(H5WebViewActivity.this, PayedRecordActivity.class);
                        intent.putExtra("APPID", mChannelExt);
                        startActivity(intent);//支付记录中心
                    }
                });

                giftBag.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        hideFloatView();
                        Intent intent = new Intent(H5WebViewActivity.this, GiftBagActivity.class);
                        intent.putExtra("gameId", mGameId);
                        startActivity(intent);//礼包中心
                    }
                });

                contact.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        hideFloatView();
                        ContactCustomerServicesUtils.doXiaoNeng();
                    }
                });

            }
        });
    }


    @Override
    public void onBackPressedSupport() {

        if (!mWvGame.canGoBack()) {
            //提示是否退出游戏
            View inflate = LayoutInflater.from(H5WebViewActivity.this).inflate(R.layout.dialog_common, null, false);
            TextView dialogTitle2 = (TextView) inflate.findViewById(R.id.tv_dialog_title2);
            dialogTitle2.setText("是否要退出游戏？");
            Button dialogCancel = (Button) inflate.findViewById(R.id.btn_dialog_cancel);
            Button dialogConfirm = (Button) inflate.findViewById(R.id.btn_dialog_confirm);

            final Dialog dialog = new Dialog(H5WebViewActivity.this, R.style.DialogStyle);
            dialog.setContentView(inflate);
            Window window = dialog.getWindow();
            window.setGravity(Gravity.CENTER);
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                window.setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
            }
            //获得窗体的属性
            WindowManager.LayoutParams lp = window.getAttributes();
            WindowManager m = getWindowManager();
            Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
            //获得窗体的属性
            lp.height = DensityUtils.dp2px(App.mContext, 170);
            lp.width = d.getWidth() - DensityUtils.dp2px(App.mContext, 20); // 宽度设置为屏幕的0.65
            window.setAttributes(lp);
            dialog.show();//显示对话框
            dialogCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
            dialogConfirm.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    H5WebViewActivity.this.finish();
                }
            });
        } else {
            mWvGame.goBack();
        }
        L.d("back", "游戏中点击了返回键");

    }

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                //当弹窗显示时，需要隐藏悬浮球
                case 0:
                    if (mUserDialog != null && mFloatView != null) {
                        if (mUserDialog.isShowing())
                            hideFloatView();
                    }
                    break;
                //当弹窗未显示时，需要显示悬浮球
                case 1:
                    if (mUserDialog != null) {
                        if (!mUserDialog.isShowing())
                            showFloatView();
                    }
                    handler.sendEmptyMessage(1);
                    break;

                case 99:
                    AliPayResult aliPayResult = new AliPayResult((String) msg.obj);
                    String resultStatus = aliPayResult.getResultStatus();
                    // 判断resultStatus 为“9000”则代表支付成功，具体状态码代表含义可参考接口文档
                    if (TextUtils.equals(resultStatus, "9000")) {
                        ToastUtil.showToast(H5WebViewActivity.this, "支付完成,请稍等...");
                        mWvGame.stopLoading();
                        mWvGame.loadUrl("http://user.shouyouzhu.com/H5mPayResult.aspx?ID=" + orderNo);
                    } else {
                        // 判断resultStatus 为非"9000"则代表可能支付失败
                        // "8000"代表支付结果因为支付渠道原因或者系统原因还在等待支付结果确认，最终交易是否成功以服务端异步通知为准（小概率状态）
                        if (TextUtils.equals(resultStatus, "8000")) {
                            ToastUtil.showToast(H5WebViewActivity.this, "支付结果确认中...");

                        } else if (TextUtils.equals(resultStatus, "6001")) {
                            ToastUtil.showToast(App.mContext, "支付取消");
                            if (mWvGame.canGoBack())
                                mWvGame.goBack();
                        } else {
                            // 其他值就可以判断为支付失败，包括用户主动取消支付，或者系统返回的错误
                            ToastUtil.showToast(H5WebViewActivity.this, "支付失败");
                            if (mWvGame.canGoBack())
                                mWvGame.goBack();
                        }
                    }
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        mFloatView.show();
        handler.sendEmptyMessage(1);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mUserDialog != null) {
            if (mUserDialog.isShowing()) {
                mUserDialog.dismiss();
                hideFloatView();
                handler.removeMessages(1);
            } else {
                hideFloatView();
                handler.removeMessages(1);
            }
        } else {
            hideFloatView();
            handler.removeMessages(1);
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mFloatView != null) {
            mFloatView.destroy();
        }
        if (mWvGame != null) {
            mWvGame.destroy();
        }

    }

    private void hideFloatView() {
        if (mFloatView != null) {
            mFloatView.hide();
        }
    }

    private void showFloatView() {
        if (mFloatView != null) {
            mFloatView.show();
        }
    }

    //请求悬浮窗权限
    public void requestDrawOverLays() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            String string = checkPhoneType().toString();//手机型号
            if(TextUtils.isEmpty(string)) return;
            String lowerCase = string.toLowerCase().trim().replace(" ","");
            if (lowerCase.contains("huawei")) {
                showOverlayQuest(false);//不需请求也可显示浮球
            }else if(lowerCase.contains("r9splus")){
                showOverlayQuest(false);//不需请求也可显示浮球
            } else {
                showOverlayQuest(true);
            }
        }
    }

    private void showOverlayQuest(boolean show) {
        if (show) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.canDrawOverlays(H5WebViewActivity.this)) {
                    AppSettingsDialog appSettingsDialog = new AppSettingsDialog.Builder(this, "为了您能使用悬浮球功能，请开启悬浮窗权限")
                            .setTitle("提示")
                            .setPositiveButton("去设置")
                            .setNegativeButton("取消", null)
                            .setRequestCode(100).build();
                    appSettingsDialog.show();
                }
            }
        }
    }
    /**
     * 检查手机类型， 是否是三星 小米 或 普通root机 普通非root机
     */
    public String checkPhoneType() {

        String phoneInfo = "\n手机型号:" + android.os.Build.MODEL
                + "\n系统版本:" + android.os.Build.VERSION.RELEASE
                + "\n产品型号:" + android.os.Build.PRODUCT
                + "\n版本显示:" + android.os.Build.DISPLAY
                + "\n系统定制商:" + android.os.Build.BRAND
                + "\n设备参数:" + android.os.Build.DEVICE
                + "\n开发代号:" + android.os.Build.VERSION.CODENAME
                + "\nSDK版本号:" + android.os.Build.VERSION.SDK_INT
                + "\nCPU类型:" + android.os.Build.CPU_ABI
                + "\n硬件类型:" + android.os.Build.HARDWARE
                + "\n主机:" + android.os.Build.HOST
                + "\n生产ID:" + android.os.Build.ID
                + "\nROM制造商:" + android.os.Build.MANUFACTURER // 这行返回的是rom定制商的名称
                ;
        return phoneInfo;
    }

}
