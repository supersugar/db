package com.uu393.market.module.center;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.R;
import com.uu393.market.model.request.GGetShareOrderDetail;
import com.uu393.market.model.response.BShareOrderDetail;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ContactCustomerServicesUtils;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

public class ShareReportFormOrderDetailActivity extends BaseActivity {
    public static final String INTENT_KEY_ORDER_ID = "order_id";
    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    @Bind(R.id.tv_item_title)
    TextView mTvItemTitle;
    @Bind(R.id.tv_item_status)
    TextView mTvItemStatus;
    @Bind(R.id.tv_item_time)
    TextView mTvItemTime;
    @Bind(R.id.tv_item_money)
    TextView mTvItemMoney;
    @Bind(R.id.tv_order_number)
    TextView mTvOrderNumber;
    @Bind(R.id.tv_order_bank)
    TextView mTvOrderBank;
    @Bind(R.id.tv_order_money)
    TextView mTvOrderMoney;
    @Bind(R.id.tv_order_factorage)
    TextView mTvOrderFactorage;
    @Bind(R.id.tv_contact)
    TextView mTvContact;
    @Bind(R.id.ll_result)
    LinearLayout mLlResult;
    @Bind(R.id.tv_no_result_hint)
    TextView mTvNoResultHint;
    @Bind(R.id.bt_no_result)
    Button mBtNoResult;
    @Bind(R.id.no_result_view)
    LinearLayout mNoResultView;
    private String mOrderId;
    private BShareOrderDetail mShareOrderDetail;
    private GGetShareOrderDetail mGetShareOrderDetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_report_form_order_detail);
        ButterKnife.bind(this);
        initTitleBar();
        if (getIntent() != null) {
            mOrderId = getIntent().getStringExtra(INTENT_KEY_ORDER_ID);
        }
        mGetShareOrderDetail = new GGetShareOrderDetail();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mGetShareOrderDetail.setId(mOrderId);
        doGetShareOrderDetail(mGetShareOrderDetail);

    }
    private void initTitleBar(){
        mTitleBarTitle.setText("订单详情");
        mTitleBarRight.setVisibility(View.GONE);
    }

    private void initViews(BShareOrderDetail shareOrderDetail){
        mTvItemTitle.setText(shareOrderDetail.getAppName());//游戏名
        mTvItemTime.setText(shareOrderDetail.getCompleteTime());//时间
        mTvItemStatus.setText(shareOrderDetail.getStatus());//状态
        String inCome = shareOrderDetail.getInCome();
        if (!TextUtils.isEmpty(inCome)){
            if (inCome.contains("+")){
                mTvItemMoney.setTextColor(getResources().getColor(R.color.green));
            }else {
                mTvItemMoney.setTextColor(getResources().getColor(R.color.text_lv2));
            }
        }
        mTvItemMoney.setText(inCome);//收入
        mTvOrderNumber.setText(shareOrderDetail.getOrderNo());//订单编号
        mTvOrderBank.setText("商品名称："+shareOrderDetail.getTitle());//商品名称
        mTvOrderMoney.setText(shareOrderDetail.getOriginalMoney()+"元");//商品原价
        mTvOrderFactorage.setText(shareOrderDetail.getTotalMoney()+"元");//实际价格
    }

    private void showResult(boolean hasResult){
        if (hasResult){
            mLlResult.setVisibility(View.VISIBLE);
            mNoResultView.setVisibility(View.GONE);
        }else {
            mLlResult.setVisibility(View.GONE);
            mNoResultView.setVisibility(View.VISIBLE);
            mTvNoResultHint.setText("抱歉，无数据");
            mBtNoResult.setVisibility(View.VISIBLE);
            mBtNoResult.setText("点击刷新");
            mBtNoResult.setClickable(true);
        }
    }

    //获取分享赚分享记录订单详情APP056
    private void doGetShareOrderDetail(GGetShareOrderDetail model) {
        if (model == null) return;
        showLoadToast(ShareReportFormOrderDetailActivity.this);
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetShareOrderDetail(model, new JsonCallback<BShareOrderDetail>() {
            @Override
            public void onSuccess(BShareOrderDetail bShareOrderDetail, Call call, Response response) {
                hideLoadToast();
                if (bShareOrderDetail != null) {
                    mShareOrderDetail = bShareOrderDetail;
                    if (mShareOrderDetail!=null){
                        showResult(true);
                        initViews(mShareOrderDetail);
                    }else {
                        showResult(false);
                    }
                }else {
                    if (mShareOrderDetail!=null){
                        showResult(true);
                        initViews(mShareOrderDetail);
                    }else {
                        showResult(false);
                    }
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
                if (mShareOrderDetail!=null){
                    showResult(true);
                    initViews(mShareOrderDetail);
                }else {
                    showResult(false);
                }
            }
        });
    }

    @OnClick({R.id.title_bar_left, R.id.tv_contact,R.id.bt_no_result})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                super.onBackPressedSupport();
                break;
            case R.id.tv_contact:
                ContactCustomerServicesUtils.doXiaoNeng();//联系客服
                break;
            case R.id.bt_no_result://刷新
                mGetShareOrderDetail.setId(mOrderId);
                doGetShareOrderDetail(mGetShareOrderDetail);
                if (mShareOrderDetail!=null){
                    showResult(true);
                    initViews(mShareOrderDetail);
                }else {
                    showResult(false);
                }
                break;
        }
    }

}
