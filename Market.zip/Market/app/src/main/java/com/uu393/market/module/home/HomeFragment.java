package com.uu393.market.module.home;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.lzy.okgo.request.BaseRequest;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GGetBanner;
import com.uu393.market.model.response.BBanner;
import com.uu393.market.model.response.BGameKind;
import com.uu393.market.model.response.BGameTheme;
import com.uu393.market.module.base.BaseTabLazyFragment;
import com.uu393.market.module.base.BaseViewPagerFragment;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;
import com.uu393.market.view.lazyviewpager.LazyFragmentPagerAdapter;
import com.youth.banner.Banner;
import com.youth.banner.listener.OnBannerListener;
import com.youth.banner.loader.ImageLoader;

import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Response;

import static com.uu393.market.app.App.mContext;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class HomeFragment extends BaseTabLazyFragment{

    private Banner mBannerView;
    private ViewPager viewPager;
    private TabLayout tabLayout;
    private View mSearchLayout;

    private List<BBanner> mBanners = new ArrayList<>();

    private Map<Integer, BaseViewPagerFragment> fragmentsMap = new HashMap<>();

    private int mCurrentFragmentIndex = 0;



    private List<BGameKind> mGameKinds = new ArrayList<>();
    public static HomeFragment newInstance() {
        Bundle args = new Bundle();
        HomeFragment fragment = new HomeFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.home_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mBannerView = (Banner) view.findViewById(R.id.banner_view);
        viewPager = (ViewPager) view.findViewById(R.id.tabs_viewpager);
        tabLayout = (TabLayout) view.findViewById(R.id.tabs);
        mSearchLayout = view.findViewById(R.id.search_layout);




        mSearchLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EB.postEmpty(EB.TAG.GO_SEARCH);
            }
        });

    }


    @Override
    protected void initLazyView(@Nullable Bundle savedInstanceState) {
        //Fragmentation0.8版本已自带懒加载方法，如下
    }

    @Override
    public void onLazyInitView(@Nullable Bundle savedInstanceState) {
        super.onLazyInitView(savedInstanceState);
        L.d("懒加载" + this);
        doGetBaner();
        doGetGameKinds();
    }

    @Override
    public void onTabReselected() {
        L.d("onTabReselected " + this);
        doGetBaner();
        doGetGameKinds();
    }


    private void doGetGameKinds() {
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetGameKinds(new JsonCallback<List<BGameKind>>(this) {
            @Override
            public void onSuccess(List<BGameKind> gameKinds, Call call, Response response) {
//                L.d(gameKinds.size());
                if (null == mGameKinds || mGameKinds.isEmpty()) {
                    if(null == gameKinds || gameKinds.isEmpty()){
                        ToastUtil.showToast(_mActivity,"获取游戏类别失败");
                        return;
                    }
                    mGameKinds = gameKinds;
                    viewPager.setAdapter(new MyPagerAdapter(getChildFragmentManager(), gameKinds));
                    viewPager.setOffscreenPageLimit(0);
                    tabLayout.setupWithViewPager(viewPager);
                    //判断广告页进入主页方式是否为立即查看
                    if ( (boolean)SPUtil.get(App.mContext,"isSelectBT",false)){
                        int count = tabLayout.getTabCount();
                        for (int i=0;i<count;i++){
                            TabLayout.Tab tab = tabLayout.getTabAt(i);
                            String tabText = tab.getText().toString();
                            if ("BT游戏".equals(tabText)){
                                tab.select();
                                SPUtil.put(App.mContext,"isSelectBT",false);
                            }
                        }
                    }

                    viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                        @Override
                        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                        }

                        @Override
                        public void onPageSelected(int position) {
                            mCurrentFragmentIndex = position;
                            if (!fragmentsMap.isEmpty() && null != fragmentsMap.get(mCurrentFragmentIndex)) {
                                Log.d("-----------","----------position="+position);
                                fragmentsMap.get(mCurrentFragmentIndex).refresh();
                            }
                        }

                        @Override
                        public void onPageScrollStateChanged(int state) {

                        }
                    });
                }
            }
        });
    }

    private void doGetBaner() {
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetBanner(new GGetBanner(), new JsonCallback<List<BBanner>>() {
            @Override
            public void onBefore(BaseRequest request) {
                super.onBefore(request);

            }
            @Override
            public void onSuccess(final List<BBanner> result, Call call, Response response) {

                if (null != result && !result.isEmpty()) {
                    List<String> images = new ArrayList<>();
                    mBanners.clear();
                    mBanners.addAll(result);
                    for (int i = 0; i < mBanners.size(); i++) {
                        images.add( mBanners.get(i).imageUrl) ;
                    }
                    mBannerView.setDelayTime(5000);//设置轮播间隔时间,需要放到setImages前面
                    mBannerView.setImageLoader(new GlideImageLoader());
                    mBannerView.setImages(images);
                    mBannerView.isAutoPlay(true);
                    mBannerView.setOnBannerListener(new OnBannerListener() {
                        @Override
                        public void OnBannerClick(int position) {
                            BBanner temp = result.get(position);
                            //0:游戏详情页面  1:活动页面
                            if(temp.linkType == 0){
                                if(StringUtils.isEmpty(temp.gameID)){
                                    ToastUtil.showToast(_mActivity,"游戏id参数错误");
                                    return;
                                }
                                Intent intent = new Intent(mContext, AppDetailActivity.class);
                                intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_ID, temp.gameID);
                                _mActivity.startActivity(intent);
                            }else if(temp.linkType == 1){
                                if(StringUtils.isEmpty(temp.gameID)){
                                    ToastUtil.showToast(_mActivity,"活动链接参数错误");
                                    return;
                                }
                                Intent intent = new Intent(_mActivity, WebActivity.class);
                                intent.putExtra(WebActivity.INTENT_KEY_URL, temp.linkUrl);
                                startActivity(intent);
                            }
                        }
                    });
                    mBannerView.start();
                }
            }
        });
    }


    public class MyPagerAdapter extends LazyFragmentPagerAdapter {

        private List<BGameKind>  gameKinds;

        public MyPagerAdapter(FragmentManager fm, List<BGameKind> gameKinds) {
            super(fm);
            this.gameKinds = gameKinds;
        }

        @Override
        public int getCount() {
            return gameKinds.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return gameKinds.get(position).typeName;
        }

        @Override
        protected Fragment getItem(ViewGroup container, int position) {
            Log.d("-----------","----------生成新的="+position);
            BaseViewPagerFragment fragment = AppListFragment.newInstance(gameKinds.get(position).id);
            fragmentsMap.put(position, fragment);
            return fragment;
        }
    }

    private void refreshCurrentGameFragment() {
        if (!fragmentsMap.isEmpty() && null != fragmentsMap.get(mCurrentFragmentIndex)) {
            fragmentsMap.get(mCurrentFragmentIndex).refresh();
        }
    }


    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        L.d("onHiddenChanged" + hidden);
        if (hidden == false) {
            refreshCurrentGameFragment();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        L.d("onResume()");
        MobclickAgent.onPageStart("HomeFragment");
        EB.register(this);
        refreshCurrentGameFragment();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        L.d("onDestroy");
        MobclickAgent.onPageEnd("HomeFragment");
        EB.unregister(this);
    }

    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.APP_INSTALL:
                refreshCurrentGameFragment();
                break;
            default:
                break;
        }
    }
    public class GlideImageLoader extends ImageLoader {
        @Override
        public void displayImage(Context context, Object path, ImageView imageView) {
            /**
             注意：
             1.图片加载器由自己选择，这里不限制，只是提供几种使用方法
             2.返回的图片路径为Object类型，由于不能确定你到底使用的那种图片加载器，
             传输的到的是什么格式，那么这种就使用Object接收和返回，你只需要强转成你传输的类型就行，
             切记不要胡乱强转！
             */
            //为什么 会得到类似You cannot start a load for a destroyed activity这样的异常呢？
            //不要再非主线程里面使用Glide加载图片，如果真的使用了，请把context参数换成getApplicationContext
            int defaultAndError = ImageHelper.randomImage();
            Glide.with(App.mContext).load((String) path).error(defaultAndError).placeholder(defaultAndError).into(imageView);
        }

    }


















    private void doGetGameThemes(){
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetGameThemes(new JsonCallback<List<BGameTheme>>() {
            @Override
            public void onSuccess(List<BGameTheme> bGameThemes, Call call, Response response) {





            }



        });


    }
}
