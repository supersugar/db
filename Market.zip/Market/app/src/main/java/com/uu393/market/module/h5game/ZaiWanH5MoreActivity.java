package com.uu393.market.module.h5game;

import android.os.Bundle;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.module.base.BaseActivity;

import me.yokeyword.fragmentation.anim.DefaultHorizontalAnimator;
import me.yokeyword.fragmentation.anim.FragmentAnimator;

public class ZaiWanH5MoreActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zai_wan_h5_more);
        if (savedInstanceState == null) {
            loadRootFragment(R.id.activity_zai_wan_h5_more,ZaiWanH5MoreFragment.newInstance() );
        }
    }

    public FragmentAnimator onCreateFragmentAnimator() {
        return new DefaultHorizontalAnimator();
    }

    public void onResume() {
        super.onResume();
        MobclickAgent.onResume(this);       //统计时长
    }
    public void onPause() {
        super.onPause();
        MobclickAgent.onPause(this);
    }
}
