package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    :
 * =====================================================
 */

public class GGetServerListByGameId {
    /**
     * {
     "id": "1",（游戏唯一ID）
     }
     */

    public String gameID;//游戏id

    public GGetServerListByGameId(String gameID) {
        this.gameID = gameID;
    }
}
