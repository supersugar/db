package com.uu393.market.util.eventbus;

/**
 * Created by zhangbo on 2016/6/27.
 */
public class EventObject<T> extends BaseEvent{

    public T result;

    public EventObject(int t, T r) {
        tag = t;
        result = r;
    }
}
