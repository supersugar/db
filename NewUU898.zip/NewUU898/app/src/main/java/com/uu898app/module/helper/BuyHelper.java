package com.uu898app.module.helper;

import com.uu898app.model.request.GGoods;
import com.uu898app.model.response.BGame;
import com.uu898app.model.response.BGameArea;
import com.uu898app.model.response.BGameKind;
import com.uu898app.model.response.BGameServer;

/**
 * Created by zhangbo on 2016/7/6.
 */
public class BuyHelper {

    private BGame mGame;
    private BGameKind mGameKind;
    private BGameArea mGameArea;
    private BGameServer mGameService;

    private String mOrderIndex = GGoods.TIME_DESC;//默认按时间排序

    private final static BuyHelper INSTANCE = new BuyHelper();

    public static BuyHelper getInstance() {
        return INSTANCE;
    }

    public BGame getChooseGame() {
        return mGame;
    }

    public void setChooseGame(BGame mGame) {
        //每次切换游戏,选择的结果先清空
        resetChooseResult();
        this.mGame = mGame;
    }

    public BGameKind getChooseGameKind() {
        return mGameKind;
    }

    public void setChooseGameKind(BGameKind mGameKind) {
        this.mGameKind = mGameKind;
    }

    public BGameArea getChooseGameArea() {
        return mGameArea;
    }

    public void setChooseGameArea(BGameArea mGameArea) {
        this.mGameArea = mGameArea;
        //每次切换区,服就要清空
        this.mGameService = null;
    }

    public BGameServer getChooseGameService() {
        return mGameService;
    }

    public void setChooseGameServer(BGameServer mGameService) {
        this.mGameService = mGameService;
    }

    public String getOrderIndex() {
        return mOrderIndex;
    }

    /**
     * 设置排序方式
     * @param mOrderIndex
     */
    public void setOrderIndex(String mOrderIndex) {
        this.mOrderIndex = mOrderIndex;
    }

    public void resetChooseResult() {
        mGame = null;
        mGameKind = null;
        mGameArea = null;
        mGameService = null;
    }
}
