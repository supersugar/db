package com.uu393.market.module.center;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.R;
import com.uu393.market.model.request.GGetWalletWithdrawDetail;
import com.uu393.market.model.response.BWalletWithdrawDetail;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ContactCustomerServicesUtils;
import com.uu393.market.view.progressbutton.FlatButton;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

public class WalletDetailItemWithdrawDetailActivity extends BaseActivity {
    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    @Bind(R.id.tv_item_title)
    TextView mTvItemTitle;
    @Bind(R.id.tv_item_status)
    TextView mTvItemStatus;
    @Bind(R.id.tv_item_time)
    TextView mTvItemTime;
    @Bind(R.id.tv_item_money)
    TextView mTvItemMoney;
    @Bind(R.id.tv_order_number)
    TextView mTvOrderNumber;
    @Bind(R.id.tv_order_bank)
    TextView mTvOrderBank;
    @Bind(R.id.tv_order_1)
    TextView mTvOrder1;
    @Bind(R.id.tv_order_money)
    TextView mTvOrderMoney;
    @Bind(R.id.tv_order_2)
    TextView mTvOrder2;
    @Bind(R.id.tv_order_factorage)
    TextView mTvOrderFactorage;
    @Bind(R.id.tv_handle_time)
    TextView mTvHandleTime;
    @Bind(R.id.tv_contact)
    TextView mTvContact;

    private String mOrderNo;//订单编号
    private BWalletWithdrawDetail mWithdrawDetail;//提现记录详情bean对象
    private String mOrderStatusText;//订单状态文本
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallet_detail_withdraw_item_detail);
        ButterKnife.bind(this);
        initTitleBar();//初始化标题栏
        if (getIntent() != null) {
            mOrderNo = getIntent().getStringExtra("key_fund_order_no");
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        GGetWalletWithdrawDetail model = new GGetWalletWithdrawDetail();
        model.setTradeNo(mOrderNo);
        doGetWalletWithdrawDetail(model);
    }

    private void initTitleBar() {
        mTitleBarRight.setVisibility(View.GONE);
        mTitleBarTitle.setText("提现明细");
    }

    private void initViews(BWalletWithdrawDetail detail){
        if (detail ==null) return;
        mTvItemTitle.setText("提现");//标题 记录方式
        mTvItemTime.setText(detail.getAddTime());//时间
        String status = detail.getStatus();//（状态  0等待客服处理   1处理完成  2订单已取消  3延时提现）
        switch (status){
            case "0":
                mOrderStatusText = "等待客服处理";
                break;
            case "1":
                mOrderStatusText = "处理完成";
                break;
            case "2":
                mOrderStatusText = "订单已取消";
                break;
            case "3":
                mOrderStatusText = "延时提现";
                break;
        }
        mTvItemStatus.setText(mOrderStatusText);//订单状态
        String money = detail.getMoney();
        if (money.contains("+")){
            mTvItemMoney.setTextColor(getResources().getColor(R.color.green));
        }else if (money.contains("-")){
            mTvItemMoney.setTextColor(getResources().getColor(R.color.text_lv2));
        }
        mTvItemMoney.setText(money+"元");//金额
        mTvOrderNumber.setText("订单编号："+mOrderNo);//订单编号
        mTvOrderBank.setText("提现银行："+detail.getBankName());//银行名字
        mTvOrderMoney.setText(detail.getActMoney()+"元");//实际到账金额
        Float fMoney = Float.valueOf(money.trim());
        float fMoneyAbs = Math.abs(fMoney);//金额的绝对值
        Float fActMoney = Float.valueOf(detail.getActMoney().trim());
        mTvOrderFactorage.setText((fMoneyAbs-fActMoney)+"元");//扣手续费
        mTvHandleTime.setText("处理时间："+detail.getAddTime());//添加时间

    }

    @OnClick({R.id.title_bar_left, R.id.tv_contact})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                super.onBackPressedSupport();
                break;
            case R.id.tv_contact:
                ContactCustomerServicesUtils.doXiaoNeng();//联系客服
                break;
        }
    }

    //获取我的钱包中提现单项的详情APP050
    private void doGetWalletWithdrawDetail(GGetWalletWithdrawDetail model) {
        if (model == null) return;
        showLoadToast(WalletDetailItemWithdrawDetailActivity.this);
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetWalletWithdrawDetail(model, new JsonCallback<BWalletWithdrawDetail>() {
            @Override
            public void onSuccess(BWalletWithdrawDetail bWalletWithdrawDetail, Call call, Response response) {
                hideLoadToast();
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
            }

            @Override
            public void onAfter(BWalletWithdrawDetail bWalletWithdrawDetail, Exception e) {
                super.onAfter(bWalletWithdrawDetail, e);
                if (bWalletWithdrawDetail !=null){
                    mWithdrawDetail = bWalletWithdrawDetail;
                    initViews(mWithdrawDetail);
                }
            }
        });

    }
}
