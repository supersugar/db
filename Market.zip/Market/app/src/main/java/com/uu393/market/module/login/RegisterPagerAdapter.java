package com.uu393.market.module.login;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.ViewGroup;

import com.uu393.market.view.lazyviewpager.LazyFragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/16
 * Descrip    :
 * =====================================================
 */

public class RegisterPagerAdapter extends LazyFragmentPagerAdapter {
    private List<String> mTitles = new ArrayList<>();
    public RegisterPagerAdapter(FragmentManager fm) {
        super(fm);
        mTitles.add("手机号注册");
        mTitles.add("UU手游账号注册");
    }

    @Override
    protected Fragment getItem(ViewGroup container, int position) {
        if (position==0){
            return PhoneRegisterFragment.newInstance();
        }if (position == 1){
            return UURegisterFragment.newInstance();
        }
        return null;
    }

    @Override
    public int getCount() {
        return 2;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return mTitles.get(position);
    }
}
