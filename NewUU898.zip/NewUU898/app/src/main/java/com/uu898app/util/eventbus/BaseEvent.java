package com.uu898app.util.eventbus;

/**
 * Created by zhangbo on 2016/6/27.
 */
public class BaseEvent {
    public int tag;
}
