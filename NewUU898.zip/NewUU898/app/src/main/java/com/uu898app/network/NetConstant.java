package com.uu898app.network;


import com.uu898app.util.RsaHelper;

import java.security.PublicKey;

public class NetConstant {

    public static final class URL {

        /** 王琦环境 */
//        public static final String BASE_SERVICE = "http://192.168.5.233:8081";
//        public static final String SERVICE_COMMON = "Service/NewAppService.ashx";

        /** 周伟刚环境 */
//        public static final String BASE_SERVICE = "http://192.168.0.178:8085";
//        public static final String BASE_SERVICE = "http://192.168.5.186:8080";

        /** 线上环境 */
        public static final String BASE_SERVICE = "http://service.uu898.com/";
        public static final String SERVICE_COMMON = "Service/AppService.ashx";

        public static final String BASE_IMAGE_URL = "http://images.uu898.com/";

        public static final String BUY_GAME_URL = BASE_SERVICE + "/Service/AppCreateOrder.aspx?type=0&";// 游戏商品生成订单页面
        public static final String BUY_ACCOUNT_URL = BASE_SERVICE + "/Service/AppIDTrade_b.aspx?type=0&";// 账号商品生成订单页面

        public static final String BASE_USER = "http://user.uu898.com";//
        public static final String RECHARGE_COMMON_URL = BASE_USER + "/AppChargePay.aspx?type=0&";// 充值(话费/流量/QQ)
        public static final String RECHARGE_DK_URL = BASE_USER + "/AppCardPay.aspx?type=0&";  // 充值点卡

        public static final String GAME_PAYURL = BASE_USER + "/AppPay.aspx?type=0&";// 游戏商品付款页面/付款链接
        public static final String SELF_REGURL = BASE_USER + "/AppReg_2.aspx?type=0&";// 完善信息链接
    }

    public static final class Secret {
        public static final PublicKey RSA_PUBLIC_KEY = RsaHelper.decodePublicKeyFromXml("<RSAKeyValue><Modulus>vrF4CrJflpvSWyHhWZlKnWX/7LHhJ89YgQG583b6+zyCkpY6in38ud6Y/U30L6uf97bsS3kkuqv9vKpLXoXjBz4dWN3Hm+wqOqM7e/B2HglLRyUWxo7DM5LMAtfasE9ClIrQgJB+2R/yGV+gARX8L3mK3kpny6ZcYEI3M6ZR2U8=</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>");

    }


    /**********************
     * 公共协议
     ****************************************/

    public static final class ApiType {
        /**
         * 注册手机到系统
         */
        public static final String App0001 = "App0001";

        /**
         * 获取用户信息
         */
        public static final String App0002 = "App0002";

        /**
         * 游戏列表接口
         */
        public static final String App0003 = "App0003";

        /**
         * 游戏区列表
         */
        public static final String App0004 = "App0004";

        /**
         * 游戏服列表
         */
        public static final String App0005 = "App0005";

        /**
         * 游戏的物品类型接口
         */
        public static final String App0006 = "App0006";

        /**
         * 商品列表
         */
        public static final String App0008 = "App0008";

        /**
         * 商品详情
         */
        public static final String App0024 = "App0024";


        /**
         * 检查个人资料是否完善
         */
        public static final String App0030 = "App0030";

        /**
         * 支付宝生成订单号
         */
        public static final String App0033 = "App0033";

        /**
         * 支付宝生成订单号(New)
         */
        public static final String App0086 = "App0086";

        /**
         * 微信支付生成订单号
         */
        public static final String App0063 = "App0063";

        /**
         * 轮播图
         */
        public static final String App0070 = "App0070";

        /**
         * 获取充值金额
         */
        public static final String App0080 = "App0080";

        /***********账户**************/
        /**
         * 获取我的消息列表
         */
        public static final String App0047 = "App0047";

        /***********订单**************/
        /**
         * 我购买的商品(寄售、担保、账号)列表
         */
        public static final String App0014 = "App0014";

        /**
         * 我购买的点卡列表
         */
        public static final String App0015 = "App0015";

        /**
         * 我购买的手机话费订单列表
         */
        public static final String App0016 = "App0016";

        /**
         * 我购买的qq充值订单列表
         */
        public static final String App0017 = "App0017";


        /***********充值**************/
        /**
         * 生成充值订单(话费/流量/QQ)
         */
        public static final String App0009 = "App0009";

        /**
         * 获取点卡列表
         */
        public static final String App0011 = "App0011";

        /**
         * 生成点卡订单
         */
        public static final String App0012 = "App0012";

        /**
         * 根据手机号,获取流量类型列表
         */
        public static final String App0069 = "App0069";

        /***********其他**************/
        /**
         * 检测更新
         */
        public static final String App0029 = "App0029";
    }


}
