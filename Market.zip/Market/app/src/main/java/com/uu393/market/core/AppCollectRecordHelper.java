package com.uu393.market.core;

import android.content.Context;

import com.uu393.market.util.CacheUtil;

import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/22
 * Description    : 操作本地收藏记录工具类
 * =====================================================
 */

public class AppCollectRecordHelper {
    private static Context mContext;
    private static CacheUtil cacheUtil;

    private static Map<Object, Object> mAppCollects;
    private static AppCollectRecordHelper mInstance;

    public static AppCollectRecordHelper getInstance(Context context) {
        mContext = context;
        cacheUtil = CacheUtil.get(mContext, "app_collect_record");
        if (null == mInstance) {
            synchronized (AppCollectRecordHelper.class) {
                if (null == mInstance) {
                    mInstance = new AppCollectRecordHelper();
                }
            }
        }
        return mInstance;
    }

    private AppCollectRecordHelper() {
        mAppCollects = Collections.synchronizedMap(new HashMap<Object, Object>());
    }

    public void addOneAppCollectRecord(Object key, Object value) {
        addOneAppCollectRecord(mAppCollects, key, value);
    }

    public void removeOneAppCollectRecord(Object key) {
        if (hasKey(key)){
            mAppCollects = (Map<Object, Object>) cacheUtil.getAsObject("app_collect_record");
            mAppCollects.remove(key);
            cacheUtil.put("app_collect_record", (Serializable) mAppCollects);
        }
    }
    private boolean hasKey(Object key){
        getAllAppCollectRecord();
        Set<Object> objectSet = mAppCollects.keySet();
        for (Object object:objectSet){
            if (key.equals(object)){
                return true;
            }
        }
        return false;
    }


    public Map<Object,Object> getAllAppCollectRecord() {
        mAppCollects.clear();
        if ((Map<Object, Object>) cacheUtil.getAsObject("app_collect_record") != null)
            mAppCollects.putAll((Map<Object, Object>) cacheUtil.getAsObject("app_collect_record"));
        return mAppCollects;
    }

    private void addOneAppCollectRecord(Map<Object, Object> map, Object key, Object value) {
        map.put(key, value);
        cacheUtil.put("app_collect_record", (Serializable) map);
    }

}
