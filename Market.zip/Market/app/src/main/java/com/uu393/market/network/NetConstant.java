package com.uu393.market.network;


public class NetConstant {

    public static final String APP_KEY = "C7E9F8BA01F263439244141F366B60A7";


    public static final class URL {

        public static final String URL_OFFICAL = "http://api.shouyouzhu.com/api/APPMarket/APP/GetInfos";
        public static final String URL_TEST = "http://192.168.5.52:8090/api/APPMarket/APP/GetInfos";
    }

    /**********************
     * 协议
     * 获取所有的游戏类型              app001
     ****************************************/

    public static final class Api {

        public static final String GET_GAME_KINDS = "app001";
        public static final String GET_GAME_LIST = "app002";
        public static final String GET_GAME_DETAIL = "app003";
        public static final String GET_BANNER = "app004";
        public static final String GET_HOT_GAME = "app005";
        public static final String CHECK_UPDATE = "app006";
        //以下新增
        public static final String GET_IMAGE_CODE = "app007";
        public static final String DO_ACCOUNT_REGISTER = "app008";
        public static final String GET_PHONE_CODE = "app009";
        public static final String DO_LOGIN = "app010";
        public static final String DO_BIND_PHONE = "app011";
        public static final String DO_FIND_PASSWORD = "app012";
        public static final String DO_CHECK_PHONE_CODE = "app013";
        public static final String DO_MODIFY_PASSWORD = "app014";
        public static final String GET_H5_GAME_ZAIWAN= "app015";
        public static final String GET_H5_GAME_ZAIWAN_ALL= "app016";
        public static final String DO_THIRD_LOGIN= "app017";
        public static final String GET_H5_GAME_THREE= "app018";
        public static final String GET_H5_GAME_DETAIL= "app019";
        public static final String GET_H5_GAME_LIST= "app020";
        public static final String GET_PAYED_INFO= "app021";
        public static final String GET_ORDER_LIST= "app022";
        public static final String GET_ORDER_DETAIL= "app023";
        public static final String GET_GIFT_BAG_LIST= "app024";
        public static final String GET_GIFT_BAG_DETAIL= "app025";
        public static final String GET_GIFT_BAG_CODE= "app026";
        public static final String DO_ADD_PLAYED_GAME= "app027";
        public static final String DO_UPLOAD_COMMENT= "app028";
        public static final String GET_H5_APPID_KEY= "app029";
        //三次开发新增
        public static final String GET_GAME_THEMES = "app030";
        public static final String GET_SERVER_LIST_BY_GAME_ID = "app031";
        public static final String GET_SERVER_LIST_BY_TIME = "app032";
        public static final String GET_SERVER_LIST_BY_GAME_NAME = "app033";
        public static final String GET_HOT_ACTIVITY_LIST= "app034";
        public static final String GET_HOT_ACTIVITY_DETAIL= "app035";
        public static final String GET_MESSAGE_LIST= "app036";
        public static final String GET_MESSAGE_DETAIL= "app037";
        public static final String GET_MULTI_GAME_DETAIL= "app038";//获取多个游戏详情  下载管理中游戏列表、安装、玩过游戏记录列表
        public static final String GET_COUPON_TICKET_LIST= "app039";
        public static final String GET_USER_CENTER_INFO= "app040";
        public static final String DO_COMMIT_CHARGE_ORDER_INFO= "app041";
        public static final String GET_BANK_LIST= "app042";
        public static final String DO_BIND_BANK= "app043";
        public static final String GET_WITHDRAW_ACCOUNT_INFO= "app044";
        public static final String DO_COMMIT_WITHDRAW_ORDER_INFO= "app045";
        public static final String DO_CHANGE_BANK= "app046";
        public static final String DO_CHANGE_WITHDRAW_PASSWORD= "app047";
        public static final String GET_WALLET_RECORD= "app048";
        public static final String GET_WALLET_INCOME_DETAIL= "app049";
        public static final String GET_WALLET_WITHDRAW_DETAIL= "app050";
        public static final String DO_JOIN_SHARE_EARN= "app051";
        public static final String GET_SHARE_FORM_HOME_USER_INFO_TOTAL= "app052";
        public static final String GET_SHARE_FORM_HOME_USER_INFO_BY_DAY= "app053";
        public static final String GET_SHARE_FORM_MORE= "app054";
        public static final String GET_SHARE_ORDER_LIST= "app055";
        public static final String GET_SHARE_ORDER_DETAIL= "app056";
        public static final String GET_SHARE_GASME_DETAIL= "app057";
        public static final String GET_IS_BIND_PHONE= "app058";
        public static final String GET_Game_GiftBag_List= "app059";
        public static final String DO_REMOVE_BIND_PHONE= "app060";
        public static final String GET_GIFT_BAGNHTML_CODE= "app061";
        public static final String GET_GAME_DETAIL_NEW= "app062";//替换003
        public static final String GET_H5_GAME_DETAIL_NEW= "app063";//替换019
        public static final String GET_GIFT_BAG_DETAIL_NEW= "app064";//替换025
    }
}
