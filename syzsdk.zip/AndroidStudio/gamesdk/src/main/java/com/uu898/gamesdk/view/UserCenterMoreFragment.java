package com.uu898.gamesdk.view;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.uu898.gamesdk.R;
import com.uu898.gamesdk.UGActivity;
import com.uu898.gamesdk.core.ListenerCenter;
import com.uu898.gamesdk.core.ResourceUtils;
import com.uu898.gamesdk.log.L;
import com.uu898.gamesdk.model.response.BUserInfo;
import com.uu898.gamesdk.utils.AccountManager;
import com.uu898.gamesdk.utils.CommonUtils;
import com.uu898.gamesdk.utils.StringUtils;

import org.xutils.x;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class UserCenterMoreFragment extends BaseFragment {

    private TextView mTvBinding;
    private BaseFragment mParentFragment;

    public static UserCenterMoreFragment newInstance() {
        Bundle args = new Bundle();
        UserCenterMoreFragment fragment = new UserCenterMoreFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_center_more"), container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView tvAccount = (TextView) view.findViewById(getId("ug_tv_account"));
        tvAccount.setText("ID : " + AccountManager.getInstance().getCurrentUserID());
        TextView tvMoney = (TextView) view.findViewById(getId("ug_tv_money"));
        tvMoney.setText("￥ " + CommonUtils.fenToYuan(AccountManager.getInstance().getUserInfo().money));

        view.findViewById(getId("ug_bt_back")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_bt_recharge")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_bt_xh")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_bt_record")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_bt_hot")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_bt_coupon")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_bt_change_binding")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_bt_change_password")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_bt_exit")).setOnClickListener(onClickListener);

        mTvBinding = (TextView) view.findViewById(getId("ug_tv_change_binding"));
        setBindingBtText();
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        L.d("onHiddenChanged" + hidden);
        if (hidden == false) {
            setBindingBtText();
        }
    }

    /**
     * 设置绑定按钮文字显示
     * 如果未绑定,显示绑定手机,如果已绑定显示更换手机
     * 未绑定时,绑定后要刷新显示
     */
    private void setBindingBtText() {

        BUserInfo userInfo = AccountManager.getInstance().getUserInfo();
        if (StringUtils.isEmpty(userInfo.phoneNo)) {//未绑定
            mTvBinding.setText("绑定手机");
        } else {
            mTvBinding.setText("解绑手机");
        }
    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            mParentFragment = (BaseFragment) getParentFragment();
            if (v.getId() == getId("ug_bt_back")) {
                _mActivity.onBackPressed();
            } else if (v.getId() == getId("ug_bt_recharge")) {
                mParentFragment.start(UserDoRechargeFragment.newInstance());
            } else if (v.getId() == getId("ug_bt_xh")) {
                mParentFragment.start(UserSubAccountListFragment.newInstance());
            } else if (v.getId() == getId("ug_bt_record")) {
                mParentFragment.start(UserRecordFragment.newInstance());
            } else if (v.getId() == getId("ug_bt_hot")) {
                mParentFragment.start(UserHotFragment.newInstance());
            } else if (v.getId() == getId("ug_bt_coupon")) {
                mParentFragment.start(UserCouponFragment.newInstance());
            } else if (v.getId() == getId("ug_bt_change_binding")) {
                BUserInfo userInfo = AccountManager.getInstance().getUserInfo();
                if (StringUtils.isEmpty(userInfo.phoneNo)) {//未绑定
                    mParentFragment.start(RegisterBindingFragment.newInstance(RegisterBindingFragment.TYPE_FIRST_BINDING));
                } else {
                    mParentFragment.start(UserUnBindingFragment.newInstance());
                }
            } else if (v.getId() == getId("ug_bt_change_password")) {
                mParentFragment.start(UserChangePasswordFragment.newInstance());
            } else if (v.getId() == getId("ug_bt_exit")) {
                showExit();
            }

        }
    };

    /*private void showExit() {
        View popupView = _mActivity.getLayoutInflater().inflate(R.layout.ug_change_account, null);

        PopupWindow window = new PopupWindow(_mActivity);
        window.setContentView(popupView);
        window.setWidth(-2);
        window.setHeight(-2);
        setBackgroundAlpha(_mActivity, 0.4f);
//        window.setAnimationStyle(R.style.anim_popup_window);
        window.setBackgroundDrawable(_mActivity.getResources().getDrawable(R.drawable.ug_dialog_white_bg));
        window.setFocusable(true);
        window.setOutsideTouchable(true);

        window.showAtLocation(mTvBinding, Gravity.CENTER, 0, 0);

        window.setOnDismissListener(new PopupWindow.OnDismissListener() {
            // 在dismiss中恢复透明度
            public void onDismiss() {
                setBackgroundAlpha(_mActivity, 1f);
            }
        });
        window.update();

    }*/

    /*public void setBackgroundAlpha(Activity activity, float bgAlpha) {
        WindowManager.LayoutParams lp = activity.getWindow().getAttributes();
        lp.alpha = bgAlpha;
        if (bgAlpha == 1) {
            activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);//不移除该Flag的话,在有视频的页面上的视频会出现黑屏的bug
            activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);//不移除该Flag的话,在有视频的页面上的视频会出现黑屏的bug
        } else {
            activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);//此行代码主要是解决在华为手机上半透明效果无效的bug
        }
        activity.getWindow().setAttributes(lp);
    }*/

    private void showExit() {
        final Dialog dialog = new Dialog(_mActivity, R.style.Dialog);
        View view = _mActivity.getLayoutInflater().inflate(R.layout.ug_change_account, null);
        dialog.addContentView(view, new ViewGroup.LayoutParams(-2, -2));
        dialog.show();

        Button mBtGo = (Button) view.findViewById(getId("ug_bt_go"));
        Button mBtCancel = (Button) view.findViewById(getId("ug_bt_cancel"));
        mBtGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AccountManager.getInstance().setStatus(AccountManager.Status.LOGOUT, AccountManager.getInstance().getCurrentUserID());
                _mActivity.finish();
                if (null != ListenerCenter.getInstance().getChangeAccountListener()) {
                    ListenerCenter.getInstance().getChangeAccountListener().onChange();
                }
                Intent intent = new Intent(x.app(), UGActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra(UGActivity.INTENT_KEY_TO, UGActivity.INTENT_VALUE_TO_LOGIN);
                startActivity(intent);
            }
        });
        mBtCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }
}
