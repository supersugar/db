package com.uu393.market.module.center;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.R;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.util.ContactCustomerServicesUtils;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class WithdrawCashStateActivity extends BaseActivity {

    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    @Bind(R.id.tv_contact)
    TextView mTvContact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_withdraw_cash_state);
        ButterKnife.bind(this);
        initTitleBar();
    }

    private void initTitleBar() {
        mTitleBarTitle.setText("提现申请");
        mTitleBarRight.setVisibility(View.GONE);
    }

    @OnClick({R.id.title_bar_left, R.id.tv_contact})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                super.onBackPressed();
                break;
            case R.id.tv_contact:
                ContactCustomerServicesUtils.doXiaoNeng();
                break;
        }
    }
}
