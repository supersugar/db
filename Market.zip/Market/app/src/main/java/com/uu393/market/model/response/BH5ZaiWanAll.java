package com.uu393.market.model.response;

import java.io.Serializable;
import java.util.List;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/22
 * Descrip    :
 * =====================================================
 */

public class BH5ZaiWanAll implements Serializable {

    /**
     * playTime : 2017-02-21
     * gameList : [{"id":"123","icon":"123456","gameName":"大主宰","androidPackage":"Http:1213","APPID":"1213","typeName":"角色扮演"},"......"]
     */

    private String playTime;
    private List<GameListBean> gameList;

    public String getPlayTime() {
        return playTime;
    }

    public void setPlayTime(String playTime) {
        this.playTime = playTime;
    }

    public List<GameListBean> getGameList() {
        return gameList;
    }

    public void setGameList(List<GameListBean> gameList) {
        this.gameList = gameList;
    }

    public static class GameListBean {
        /**
         * id : 123
         * icon : 123456
         * gameName : 大主宰
         * androidPackage : Http:1213
         * APPID : 1213
         * typeName : 角色扮演
         */

        private String id;
        private String icon;
        private String gameName;
        private String androidPackage;
        private String APPID;
        private String typeName;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getIcon() {
            return icon;
        }

        public void setIcon(String icon) {
            this.icon = icon;
        }

        public String getGameName() {
            return gameName;
        }

        public void setGameName(String gameName) {
            this.gameName = gameName;
        }

        public String getAndroidPackage() {
            return androidPackage;
        }

        public void setAndroidPackage(String androidPackage) {
            this.androidPackage = androidPackage;
        }

        public String getAPPID() {
            return APPID;
        }

        public void setAPPID(String APPID) {
            this.APPID = APPID;
        }

        public String getTypeName() {
            return typeName;
        }

        public void setTypeName(String typeName) {
            this.typeName = typeName;
        }
    }
}
