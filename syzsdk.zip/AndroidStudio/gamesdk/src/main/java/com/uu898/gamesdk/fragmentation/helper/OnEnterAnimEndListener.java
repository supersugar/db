package com.uu898.gamesdk.fragmentation.helper;

/**
 * 动画结束 监听
 * Created by YoKeyword on 16/1/28.
 */
public interface OnEnterAnimEndListener {
    void onAnimationEnd();
}
