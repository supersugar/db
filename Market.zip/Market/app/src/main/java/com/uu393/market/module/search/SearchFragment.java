package com.uu393.market.module.search;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.beloo.widget.chipslayoutmanager.ChipsLayoutManager;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.model.PageModel;
import com.uu393.market.model.request.GGetSearchList;
import com.uu393.market.model.response.BGame;
import com.uu393.market.model.response.BGameSearch;
import com.uu393.market.module.base.BaseFragment;
import com.uu393.market.module.home.AppDetailActivity;
import com.uu393.market.module.home.SearchApkListAdapter;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.CommonUtils;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.eventbus.EventAnything;
import com.uu393.market.util.log.L;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;

import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

public class SearchFragment extends BaseFragment {

    private static final int NORMAL = 0;
    private static final int NO_RESULT = 1;
    private static final int RESULT = 2;

    private EditText mEditText;
    private ImageView mEditTextClear;
    private ImageButton mSearchBt;

    private View mNormalView;//默认页
    private View mNoResultView;//无结果页
    private View mResultView;//有结果页

    private RecyclerView mRVLabel;
    private RecyclerView mRVSuggest;
    private RecyclerView mRVHistory;
    private PullLoadMoreRecyclerView mRVResult;

    private LabelAdapter mLabelAdapter;
    private SuggestAdapter mSuggestAdapter;
    private HistoryAdapter mHistoryAdapter;
    private SearchApkListAdapter mResultAdapter;

    public static SearchFragment newInstance() {
        SearchFragment fragment = new SearchFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.search_fragment, null);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mNormalView = view.findViewById(R.id.search_normal_view);
        mNoResultView = view.findViewById(R.id.search_no_result_view);
        mResultView = view.findViewById(R.id.search_result_view);

        mEditText = (EditText) view.findViewById(R.id.edit_text);
        mEditTextClear = (ImageView) view.findViewById(R.id.edit_text_clear);
        mSearchBt = (ImageButton) view.findViewById(R.id.title_bar_right);
        mRVSuggest = (RecyclerView) view.findViewById(R.id.recycler_view_suggest);
        mRVLabel = (RecyclerView) view.findViewById(R.id.recycler_view_label);
        mRVHistory = (RecyclerView) view.findViewById(R.id.recycler_view_history);
        mRVResult = (PullLoadMoreRecyclerView) view.findViewById(R.id.recycler_view_result);

        mEditTextClear.setOnClickListener(onClickListener);

        initView();
    }

    private void initView() {
        LinearLayoutManager suggestLayoutManager = new LinearLayoutManager(_mActivity);
        suggestLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRVSuggest.setLayoutManager(suggestLayoutManager);
        mSuggestAdapter = new SuggestAdapter(_mActivity);
        mRVSuggest.setAdapter(mSuggestAdapter);

        ChipsLayoutManager chipsLayoutManager = ChipsLayoutManager.newBuilder(_mActivity)
                .setOrientation(ChipsLayoutManager.HORIZONTAL)
                .build();
        mLabelAdapter = new LabelAdapter(_mActivity);
        mRVLabel.setLayoutManager(chipsLayoutManager);
        mRVLabel.setAdapter(mLabelAdapter);

        doGetHotGameList();//获取热门搜索列表
        mRVHistory.setLayoutManager(new LinearLayoutManager(_mActivity) {
            @Override
            public boolean canScrollVertically() {
                return false;
            }
        });
        List<String> temp = CommonUtils.getSearchList();
        //无搜索历史的话不设置adapter
        if (null != temp && !temp.isEmpty()) {
            temp.add("清除搜索记录");//添加最后清除按钮
            mHistoryAdapter = new HistoryAdapter(temp);
            mRVHistory.setAdapter(mHistoryAdapter);
        }

        mResultAdapter = new SearchApkListAdapter(_mActivity);//搜索结果页的列表的适配器
        mRVResult.setLinearLayout();
        mRVResult.setAdapter(mResultAdapter);
        mRVResult.setOnPullLoadMoreListener(new PullLoadMoreRecyclerView.PullLoadMoreListener() {
            @Override
            public void onRefresh() {
                doSearch(mSearchKey, false);
            }

            @Override
            public void onLoadMore() {
                doSearch(mSearchKey, true);
            }
        });
        //执行搜索逻辑
        mSearchBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String searchKey = mEditText.getText().toString();
                hideSoftInput();
                if (StringUtils.isEmpty(searchKey)) {
                    changeView(NORMAL);
                } else {
                    mSearchKey = searchKey;
                    //联网搜索
                    doSearch(mSearchKey, false);
                    //存储历史记录
                    CommonUtils.updateSearchList(searchKey);
                    //历史记录列表刷新
                    //无搜索历史的话不设置adapter
                    List<String> temp = CommonUtils.getSearchList();
                    if (null != temp && !temp.isEmpty()) {
                        temp.add("清除搜索记录");//添加最后清除按钮
                        mHistoryAdapter = new HistoryAdapter(temp);
                        mRVHistory.setAdapter(mHistoryAdapter);
                    }
                }
            }
        });

        mEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (StringUtils.isEmpty(s.toString())) {
                    mEditTextClear.setVisibility(View.GONE);
                    changeView(NORMAL);
                    hideSoftInput();
                }else{
                    mEditTextClear.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mEditText.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    // 先隐藏键盘
                    hideSoftInput();
                    //进行搜索操作的方法，在该方法中可以加入mEditSearchUser的非空判断
                    mSearchBt.performClick();
                }
                return false;
            }
        });
    }

    /*@Override
    protected void initLazyView(@Nullable Bundle savedInstanceState) {
        L.d("懒加载" + this);
    }*/

    /*@Override
    public void onTabReselected() {
        L.d("onTabReselected " + this);
        doGetHotGameList();
    }*/

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(v.getId() == mEditTextClear.getId()){
                mEditText.setText("");
            }
        }
    };

    private void doGetHotGameList() {
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetHotGameList(new JsonCallback<List<BGame>>() {
            @Override
            public void onSuccess(List<BGame> bGames, Call call, Response response) {
                if (null == bGames || bGames.isEmpty()) {
                    L.d("热门游戏列表结果获取失败");
                } else {
                    mSuggestAdapter.refreshAdapter(bGames.size() >= 4 ? bGames.subList(0, 4) : bGames);
                    mLabelAdapter.refreshAdapter(bGames);
                }
            }
        });
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        L.d("onHiddenChanged" + hidden);
        if(hidden == false){
            if(null != mResultAdapter){
                mResultAdapter.notifyDataSetChanged();
            }
        }
    }

    //
    private void changeView(int state) {
        if (state == NORMAL) {
            mNormalView.setVisibility(View.VISIBLE);
            mNoResultView.setVisibility(View.GONE);
            mResultView.setVisibility(View.GONE);
        } else if (state == NO_RESULT) {
            mNormalView.setVisibility(View.VISIBLE);
            mNoResultView.setVisibility(View.VISIBLE);
            mResultView.setVisibility(View.GONE);
        } else if (state == RESULT) {
            mNormalView.setVisibility(View.GONE);
            mNoResultView.setVisibility(View.GONE);
            mResultView.setVisibility(View.VISIBLE);
        }
    }

    private int mPageIndex = 1;
    private ArrayList<BGameSearch> mGameList = new ArrayList<>();
    private String mSearchKey;

    private void doSearch(String searchKey, final boolean loadMore) {
        GGetSearchList model = new GGetSearchList();
        model.setGameName(searchKey);
        model.setGameType("-1");
        model.setPlatForm("-1");
        if (loadMore == false) {
            mPageIndex = 1;
        }
        PageModel page = new PageModel(mPageIndex);
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetSearchList(model, page, new JsonCallback<List<BGameSearch>>() {
            @Override
            public void onSuccess(List<BGameSearch> bGames, Call call, Response response) {
                //不管返回的数据是否
                if (null == bGames || bGames.isEmpty()) {
                    //无返回结果,需要根据当前页码判断是无结果,还是无更多
                    if(mPageIndex == 1){
                        changeView(NO_RESULT);
                        ToastUtil.showToast(_mActivity,"抱歉没有搜到该游戏");
                    }else{
                        ToastUtil.showToast(_mActivity,"没有更多了~");
                    }
                } else {
                    changeView(RESULT);
                    mPageIndex++;
                    if (loadMore == false) {//非增量加载
                        mGameList.clear();
                    }
                    mGameList.addAll(bGames);
                }
            }

            @Override
            public void onAfter(List<BGameSearch> bGames, Exception e) {
                super.onAfter(bGames, e);
                mRVResult.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mResultAdapter.updateData(mGameList);
                        mRVResult.setPullLoadMoreCompleted();
                    }
                }, 100);
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        L.d("onResume");
        MobclickAgent.onPageStart("SearchFragment");
        EB.register(this);
        doGetHotGameList();
        if (mSearchKey!=null&& !TextUtils.isEmpty(mSearchKey)){
            doSearch(mSearchKey,false);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        L.d("onDestroy");
        MobclickAgent.onPageEnd("SearchFragment");
        EB.unregister(this);
    }

    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            /*case EB.TAG.CLICK_SEARCH_SUGGEST_ITEM:
                EventString es = (EventString) event;
                Intent intent = new Intent(_mActivity, AppDetailActivity.class);
                intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_ID, es.result);
                _mActivity.startActivity(intent);
                break;*/
            case EB.TAG.CLICK_SEARCH_HISTORY_ITEM://
                EventAnything anything = (EventAnything) event;
                Object result[] = anything.result;
                int pos = (int) result[0];
                String searchKey = (String) result[1];
                mEditText.setText(searchKey);
                mEditText.setSelection(mEditText.getText().length());
                mSearchBt.performClick();
                break;
            case EB.TAG.APP_INSTALL:
                if(null != mResultAdapter){
                    mResultAdapter.notifyDataSetChanged();
                }
                break;
            default:
                break;
        }
    }
}
