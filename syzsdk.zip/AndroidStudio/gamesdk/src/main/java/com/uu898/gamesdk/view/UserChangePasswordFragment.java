package com.uu898.gamesdk.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.uu898.gamesdk.core.ResourceUtils;
import com.uu898.gamesdk.model.request.GChangePassword;
import com.uu898.gamesdk.network.NetCallback;
import com.uu898.gamesdk.network.TaskEngine;
import com.uu898.gamesdk.utils.CommonUtils;
import com.uu898.gamesdk.utils.StringUtils;
import com.uu898.gamesdk.utils.ToastUtil;
import com.uu898.gamesdk.utils.UGCache;
import com.uu898.gamesdk.utils.UGConstant;

import org.xutils.x;

/**
 * 修改密码
 * 只有登录之后才能修改密码
 * Created by zhangbo on 2016/6/23.
 */
public class UserChangePasswordFragment extends BaseFragment {

    private EditText mEdtPasswordOld;
    private EditText mEdtPassword;
    private EditText mEdtPasswordConfirm;

    public static UserChangePasswordFragment newInstance() {
        Bundle args = new Bundle();
        UserChangePasswordFragment fragment = new UserChangePasswordFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_change_password"), container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "修改密码");
        mEdtPasswordOld = (EditText) view.findViewById(getId("ug_edt_password_old"));
        mEdtPassword = (EditText) view.findViewById(getId("ug_edt_password"));
        mEdtPasswordConfirm = (EditText) view.findViewById(getId("ug_edt_password_confirm"));

        view.findViewById(getId("ug_bt_next")).setOnClickListener(onClickListener);
        view.findViewById(getId("ug_bt_kefu")).setOnClickListener(onClickListener);

    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v.getId() == getId("ug_bt_next")) {
                verifyForm();
            } else if (v.getId() == getId("ug_bt_kefu")) {//客服
                start(WebKefuFragment.newInstance());
            }
        }


    };

    /**
     * 校验帐号
     */
    private void verifyForm() {
        String pwOld = mEdtPasswordOld.getText().toString();
        String pw = mEdtPassword.getText().toString();
        String pwComfim = mEdtPasswordConfirm.getText().toString();

        if (StringUtils.isEmpty(pwOld)) {
            ToastUtil.showToast(_mActivity, "请输入原帐号");
            return;
        }
        if (StringUtils.isEmpty(pw)) {
            ToastUtil.showToast(_mActivity, "请输入新密码");
            return;
        }
        if (StringUtils.isEmpty(pwComfim)) {
            ToastUtil.showToast(_mActivity, "请确认新密码");
            return;
        }
        if (pwOld.equals(pw)) {
            ToastUtil.showToast(_mActivity, "新密码与原密码一样");
            return;
        }
        if (!pw.equals(pwComfim)) {
            ToastUtil.showToast(_mActivity, "两次输入密码不一致");
            return;
        }
        doChangePasswrod(pwOld, pw);
    }


    /**
     * 修改密码
     * 如果修改了密码,不管修改后的密码是否跟当前的一致,都需要在退出
     *
     * @param pwOld
     * @param pw
     */
    private void doChangePasswrod(String pwOld, String pw) {
        GChangePassword model = new GChangePassword();
        model.setOldPassWord(CommonUtils.encryptString(pwOld));
        model.setNewPassWord(CommonUtils.encryptString(pw));
        TaskEngine.getInstance().doChangePassword(model, new NetCallback(this) {
            @Override
            public void _onNext(Object o) {
                ToastUtil.showToast(_mActivity, "密码修改成功");
                UGCache.get(x.app()).put(UGConstant.Cache.LAST_CHANGE_PW, true);
                _mActivity.onBackPressed();
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

}
