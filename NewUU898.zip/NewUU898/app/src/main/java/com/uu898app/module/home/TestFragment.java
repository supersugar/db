package com.uu898app.module.home;

import android.Manifest;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.afollestad.materialdialogs.MaterialDialog;
import com.thin.downloadmanager.DefaultRetryPolicy;
import com.thin.downloadmanager.DownloadRequest;
import com.thin.downloadmanager.DownloadStatusListenerV1;
import com.thin.downloadmanager.RetryPolicy;
import com.thin.downloadmanager.ThinDownloadManager;
import com.uu898app.R;
import com.uu898app.model.response.BCheckUpdate;
import com.uu898app.module.base.BaseActivity;
import com.uu898app.module.base.BaseFragment;
import com.uu898app.module.helper.ToolbarHelper;
import com.uu898app.module.helper.UiHelper;
import com.uu898app.network.TaskEngine;
import com.uu898app.network.rxjava.RxSubscriber;
import com.uu898app.third.umeng.UUUmeng;
import com.uu898app.util.ToastUtil;
import com.uu898app.util.log.L;

import cn.finalteam.toolsfinal.StorageUtils;


public class TestFragment extends BaseFragment {

    private MaterialDialog dialog;

    public static TestFragment newInstance() {
        Bundle args = new Bundle();
        TestFragment fragment = new TestFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.test_layout, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Toolbar toolbar = (Toolbar) view.findViewById(R.id.toolbar);
        new ToolbarHelper.Builder(toolbar, this, _mActivity)
                .title("测试页面")
                .showBack(true)
                .build();
        view.findViewById(R.id.update).setOnClickListener(v1 -> update());
        view.findViewById(R.id.share).setOnClickListener(v1 -> UUUmeng.getInstance(_mActivity).startShare());
        view.findViewById(R.id.sina_oauth).setOnClickListener(v1 -> UUUmeng.getInstance(_mActivity).sinaOauth());
        view.findViewById(R.id.sina_oauth_clear).setOnClickListener(v1 -> UUUmeng.getInstance(_mActivity).sinaOauthClear());
        view.findViewById(R.id.sina_oauth_info).setOnClickListener(v1 -> UUUmeng.getInstance(_mActivity).sinaOauthInfo());
        view.findViewById(R.id.qq_oauth).setOnClickListener(v1 -> UUUmeng.getInstance(_mActivity).qqOauth());
        view.findViewById(R.id.qq_oauth_clear).setOnClickListener(v1 -> UUUmeng.getInstance(_mActivity).qqOauthClear());
        view.findViewById(R.id.qq_oauth_info).setOnClickListener(v1 -> UUUmeng.getInstance(_mActivity).qqOauthInfo());
        view.findViewById(R.id.permission).setOnClickListener(v1 -> permission());


        pxToSp();
    }

    private void pxToSp() {
        L.d("42px = " + UiHelper.px2sp(_mActivity, 42) + "sp");
        L.d("32px = " + UiHelper.px2sp(_mActivity, 32) + "sp");
        L.d("30px = " + UiHelper.px2sp(_mActivity, 30) + "sp");
        L.d("26px = " + UiHelper.px2sp(_mActivity, 26) + "sp");
        L.d("24px = " + UiHelper.px2sp(_mActivity, 24) + "sp");
        L.d("22px = " + UiHelper.px2sp(_mActivity, 22) + "sp");
        L.d("20px = " + UiHelper.px2sp(_mActivity, 20) + "sp");
    }

    private void update() {
        TaskEngine.getInstance().checkUpdate().subscribe(new RxSubscriber<BCheckUpdate>() {
            @Override
            public void _onNext(BCheckUpdate bCheckUpdate) {
                String url = bCheckUpdate.getUrl();
                DownloadRequest request = new DownloadRequest(Uri.parse(url));
                RetryPolicy retryPolicy = new DefaultRetryPolicy();
                request.setDestinationURI(Uri.parse(StorageUtils.getCacheDirectory(_mActivity).getAbsolutePath() + "/uu898.apk"))
                        .setRetryPolicy(retryPolicy)
                        .setStatusListener(new DownloadStatusListenerV1() {
                            @Override
                            public void onDownloadComplete(DownloadRequest downloadRequest) {

                            }

                            @Override
                            public void onDownloadFailed(DownloadRequest downloadRequest, int errorCode, String errorMessage) {

                            }

                            @Override
                            public void onProgress(DownloadRequest downloadRequest, long totalBytes, long downloadedBytes, int progress) {
                                L.d("总大小" + totalBytes/1024 + " 已下载" + downloadedBytes/1024 + " 当前进度" + progress);
                                dialog.setProgress(progress);
                            }
                        });
                ThinDownloadManager downloadManager = new ThinDownloadManager();
                downloadManager.add(request);
                dialog = new MaterialDialog.Builder(_mActivity)
                        .progress(false,100,true)
                        .showListener(new DialogInterface.OnShowListener() {
                            @Override
                            public void onShow(DialogInterface dialog) {

                            }
                        })
                        .show();

            }


            @Override
            public void _onError(String msg) {

            }
        });
    }

    private void permission(){
        ((BaseActivity)_mActivity).baseCheckPermission(new BaseActivity.CheckPermListener() {
            @Override
            public void superPermission() {
                ToastUtil.showToast(_mActivity,"已经授予拍照权限");
            }
        },"为了拍照啊,给个权限啊大哥", Manifest.permission.CAMERA);

    }

}
