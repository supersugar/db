package com.uu898app.model.request;

import com.uu898app.model.GBaseModel;

/**
 * Created by zhangbo on 2016/6/20.
 */
public class GOnlyId extends GBaseModel {

    private int id;

    public GOnlyId() {
    }

    public GOnlyId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
