package com.uu661.util.eventbus;

import org.greenrobot.eventbus.EventBus;

/**
 * Created by zhangbo on 2016/6/27.
 */
public class EB {

    private static EventBus mEventBus;

    private static EventBus getDefaultEventBus() {
        if (null == mEventBus) {
            mEventBus = EventBus.getDefault();
        }
        return mEventBus;
    }

    public static void register(Object subscriber) {
        if (!getDefaultEventBus().isRegistered(subscriber)) {
            getDefaultEventBus().register(subscriber);
        }

    }

    public static void unregister(Object subscriber) {
        getDefaultEventBus().unregister(subscriber);
    }

    public static void postEmpty(int tag) {
        getDefaultEventBus().post(new EventEmpty(tag));
    }

    public static void postString(int tag, String result) {
        getDefaultEventBus().post(new EventString(tag, result));
    }

    public static void postObject(int tag, Object result) {
        getDefaultEventBus().post(new EventObject(tag, result));
    }

    public static <T> void postAnything(int tag, Object... result) {
        getDefaultEventBus().post(new EventAnything(tag, result));
    }

    public static final class TAG {

        public static final int SHOW_MAIN_BOTTOM_VIEW = 111;//首页钻石列表,点击立即夺钻

        public static final int GET_DIAMOND_LIST_DONE = 2;//获取钻石列表完成

        public static final int GO_HOME = 11;
        public static final int GO_SEARCH_RESULT = 21;

        public static final int CHOOSE_COUPON = 30;//选择完优惠券


    }
}
