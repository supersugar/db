package com.uu898.gamesdk.model.request;

import com.uu898.gamesdk.model.GBaseModel;

/**
 * Created by zhangbo on 2016/6/15.
 */
public class GGetPayMoney extends GBaseModel {

    private int OriginalPrice;//单个商品原价(分)

    public int getOriginalPrice() {
        return OriginalPrice;
    }

    public void setOriginalPrice(int originalPrice) {
        OriginalPrice = originalPrice;
    }
}
