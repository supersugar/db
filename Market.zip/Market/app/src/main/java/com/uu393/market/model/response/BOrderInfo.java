package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/3
 * Descrip    : H5游戏中用户充值记录bean
 * =====================================================
 */

public class BOrderInfo implements Serializable {
    /**
     * orderNo : 2016092700001
     * title : 600元宝
     * addTime : 2016-09-27 15:15:15
     * totalMoney : 26.32
     * status : 0   //（状态：0:已取消,1:支付完成,2:订单完成,3:订单失败,4:支付超时，已取消）
     * discount : 0.45  // （显示折扣诚乘以10）
     */

    private String orderNo;
    private String title;
    private String addTime;
    private String totalMoney;
    private String status;
    private String discount;

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }

    public String getTotalMoney() {
        return totalMoney;
    }

    public void setTotalMoney(String totalMoney) {
        this.totalMoney = totalMoney;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }
}
