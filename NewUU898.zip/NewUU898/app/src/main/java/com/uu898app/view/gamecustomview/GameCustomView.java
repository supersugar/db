package com.uu898app.view.gamecustomview;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

/**
 * 购买商品前定制购买条件的自定义view
 *
 */
public class GameCustomView extends LinearLayout {

    private LinearLayout mParentView;
    private LayoutParams mButtonParams;
    private int mCurrentPosition = -1;
    private OnButtonSelectedListener mListener;

    private Context mContext;

    public GameCustomView(Context context) {
        super(context, null);
    }

    public GameCustomView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }


    private void init(Context context) {
        mContext = context;
        setOrientation(VERTICAL);

//        ImageView shadowView = new ImageView(context);
//        shadowView.setBackgroundResource(R.drawable.actionbar_shadow_up);
//        addView(shadowView, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        mParentView = new LinearLayout(context);
//        mParentView.setBackgroundColor(Color.WHITE);
        mParentView.setOrientation(LinearLayout.VERTICAL);
        addView(mParentView, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    public GameCustomView addButton(final GameCustomButton button) {
        button.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener == null){
                    return;
                }
                int pos = button.getButtonPos();
                if(!mListener.preOnClick(pos)){
                    return;
                }

                if (mCurrentPosition == pos) {
                    mListener.onButtonReselected(pos);
                } else {
                    if(button.hasValue()){
                        //点击了设置过值的按钮
                        mListener.clickHasValueButton(pos);
                    }
                    mListener.onButtonSelected(pos, mCurrentPosition);
                    button.setSelected(true);
                    if(mCurrentPosition >= 0){
                        mListener.onButtonUnselected(mCurrentPosition);
                        mParentView.getChildAt(mCurrentPosition).setSelected(false);
                    }
                    mCurrentPosition = pos;
                }
            }
        });
        button.setButtonPosition(mParentView.getChildCount());
        mButtonParams = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        button.setLayoutParams(mButtonParams);
        mParentView.addView(button);
        return this;
    }

    public void setOnButtonSelectedListener(OnButtonSelectedListener onTabSelectedListener) {
        mListener = onTabSelectedListener;
    }

    public void setCurrentItem(final int position) {
        mParentView.post(new Runnable() {
            @Override
            public void run() {
                mParentView.getChildAt(position).performClick();
            }
        });
    }

    public void resetItem(int position) {
        GameCustomButton button = (GameCustomButton) mParentView.getChildAt(position);
        button.reset();
    }

    public int getCurrentItemPosition() {
        return mCurrentPosition;
    }

    public void setChooseValue(int pos, String result) {
        GameCustomButton button = (GameCustomButton) mParentView.getChildAt(pos);
        button.setValue(result);
    }

    public interface OnButtonSelectedListener {
        boolean preOnClick(int position);

        void clickHasValueButton(int pos);

        void onButtonSelected(int position, int prePosition);

        void onButtonUnselected(int position);

        void onButtonReselected(int position);
    }

    @Override
    protected Parcelable onSaveInstanceState() {
        Parcelable superState = super.onSaveInstanceState();
        return new SavedState(superState, mCurrentPosition);
    }

    @Override
    protected void onRestoreInstanceState(Parcelable state) {
        SavedState ss = (SavedState) state;
        super.onRestoreInstanceState(ss.getSuperState());

        if (mCurrentPosition != ss.position) {
            mParentView.getChildAt(mCurrentPosition).setSelected(false);
            mParentView.getChildAt(ss.position).setSelected(true);
        }
        mCurrentPosition = ss.position;
    }

    static class SavedState extends BaseSavedState {
        private int position;

        public SavedState(Parcel source) {
            super(source);
            position = source.readInt();
        }

        public SavedState(Parcelable superState, int position) {
            super(superState);
            this.position = position;
        }

        @Override
        public void writeToParcel(Parcel out, int flags) {
            super.writeToParcel(out, flags);
            out.writeInt(position);
        }

        public static final Creator<SavedState> CREATOR = new Creator<SavedState>() {
            public SavedState createFromParcel(Parcel in) {
                return new SavedState(in);
            }

            public SavedState[] newArray(int size) {
                return new SavedState[size];
            }
        };
    }

}
