package com.uu393.market.module.h5game;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GDoAddPlayedGame;
import com.uu393.market.model.response.BGame;
import com.uu393.market.model.response.BH5Game;
import com.uu393.market.module.login.LoginActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.GlideRoundTransform;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

import static com.uu393.market.Constant.UMENG_EVENT_ID_PLAY_H5;
import static com.uu393.market.R.id.rl_h5game_suggest_parent3;
import static com.uu393.market.app.App.mContext;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/18
 * Descrip    :H5游戏中心推荐的RecyclerView的适配器
 * =====================================================
 */

public class SuggestRvAdapter extends RecyclerView.Adapter<SuggestRvAdapter.SuggestViewHolder> {
    private List<BH5Game> data = new ArrayList<>();
    private Activity activity;
    public SuggestRvAdapter(Activity activity){
        this.activity = activity;
    }

    public void refresh(List<BH5Game> games){
        this.data = games;
        this.notifyDataSetChanged();
    }

    @Override
    public SuggestViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_h5game_suggest, parent, false);
        return new SuggestViewHolder(inflate);
    }

    @Override
    public void onBindViewHolder(final SuggestViewHolder holder, final int position) {
        holder.bindView(data.get(position));
        holder.play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //开始游戏
                final Intent intent = new Intent();
                if ((boolean) SPUtil.get(App.mContext,"isLogin",false)){
                    HashMap<String, String> map = new HashMap<>();
                    map.put("H5GameName",data.get(position).getGameName());
                    MobclickAgent.onEvent(activity, UMENG_EVENT_ID_PLAY_H5,map);//友盟统计下载事件


                    intent.putExtra("gameId",data.get(position).getId());
                    intent.putExtra("APPID",data.get(position).getAPPID());
                    intent.putExtra("url",data.get(position).getAndroidPackage());
                    intent.setClass(activity,H5WebViewActivity.class);
                    activity.startActivity(intent);
                }else {
                    SPUtil.put(App.mContext, "GameId", data.get(position).getId());
                    SPUtil.put(App.mContext, "APPID", data.get(position).getAPPID());
                    SPUtil.put(App.mContext, "GameUrl", data.get(position).getAndroidPackage());

                    intent.setClass(mContext,LoginActivity.class);
                    activity.startActivity(intent);
                }
            }
        });
        holder.toGameDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {//进入游戏详情
                Intent intent1 = new Intent();
                intent1.putExtra("gameId",data.get(position).getId());
                intent1.setClass(activity,H5GameDetailActivity.class);
                activity.startActivity(intent1);
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class SuggestViewHolder extends RecyclerView.ViewHolder {
        private View toGameDetail;
        private ImageView appIcon,appImg;
        private TextView appName,appDiscount,appKind,appNumber,play,appDetail;

        public SuggestViewHolder(View itemView) {
            super(itemView);
            toGameDetail = itemView.findViewById(rl_h5game_suggest_parent3);
            appIcon = (ImageView) itemView.findViewById(R.id.iv_h5game_suggest_app_icon);
            appName = (TextView) itemView.findViewById(R.id.tv_h5game_suggest_app_name);
            appDiscount = (TextView) itemView.findViewById(R.id.tv_h5game_suggest_discount);
            appKind = (TextView) itemView.findViewById(R.id.tv_h5game_suggest_app_kind);
            appNumber = (TextView) itemView.findViewById(R.id.tv_h5game_suggest_app_number);
            play = (TextView) itemView.findViewById(R.id.tv_h5game_suggest_play);
            appDetail = (TextView) itemView.findViewById(R.id.tv_h5game_suggest_app_detail);
            appImg = (ImageView) itemView.findViewById(R.id.iv_h5game_suggest_img);

        }

        void bindView(BH5Game gameModel){
            int defaultAndError = ImageHelper.randomImage();
            Glide.with(App.mContext)
                    .load(gameModel.getIcon())
                    .error(defaultAndError)
                    .placeholder(defaultAndError)
                    .transform(new GlideRoundTransform(mContext, 5))
                    .into(appIcon);
            appName.setText(gameModel.getGameName());
            appDiscount.setText("");//todo 折扣暂无
            appKind.setText(gameModel.getTypeName());
            appNumber.setText("5.6万");//todo 人数暂无
            appDetail.setText(gameModel.getDescribe());
            Glide.with(App.mContext)
                    .load(gameModel.getHomeImg())
                    .error(defaultAndError)
                    .placeholder(defaultAndError)
                    .into(appImg);
        }
    }
}
