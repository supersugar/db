package com.uu898app.view.dropdownmenu.interfaces;

/**
 * author: baiiu
 * date: on 16/1/21 23:30
 * description:
 */
public interface OnFilterDoneListener {
    void onFilterDone(int position, String positionTitle, String urlValue);
}