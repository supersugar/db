package com.uu898.gamesdk;

import android.app.Application;

import com.uu898.gamesdk.support.listener.UGChangeAccountListener;
import com.uu898.gamesdk.support.listener.UGExitListener;
import com.uu898.gamesdk.support.listener.UGLoginListener;
import com.uu898.gamesdk.support.listener.UGPayListener;
import com.uu898.gamesdk.support.model.UGPayModel;

/**
 * Created by bo on 16/10/12.
 */

public interface IUGSDK {

    void init(Application application, String appid, String key, boolean debug);

    void login(UGLoginListener listener);

    void pay(UGPayModel model, UGPayListener listener);

    void exit(UGExitListener listener);

    void changeAccount(UGChangeAccountListener listener);
}
