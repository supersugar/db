package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/3
 * Descrip    :
 * =====================================================
 */

public class BGiftBagInfo implements Serializable {
    /**
     {
     "id":"1",（礼包id）
     "giftName":"情人节礼包",（礼包名称）
     "totalNumber":"5000",（礼包总数量）
     "surplusNumber":"3800",（礼包剩余数量）
     "expiredTime":"2017-03-02 10:00:00",（过期时间）
     "isReceive":"0",（是否领取  0未领取  1已领取）
     }

     */


    private String id;
    private String giftName;
    private String totalNumber;
    private String surplusNumber;
    private String expiredTime;
    private String isReceive;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGiftName() {
        return giftName;
    }

    public void setGiftName(String giftName) {
        this.giftName = giftName;
    }

    public String getTotalNumber() {
        return totalNumber;
    }

    public void setTotalNumber(String totalNumber) {
        this.totalNumber = totalNumber;
    }

    public String getSurplusNumber() {
        return surplusNumber;
    }

    public void setSurplusNumber(String surplusNumber) {
        this.surplusNumber = surplusNumber;
    }

    public String getExpiredTime() {
        return expiredTime;
    }

    public void setExpiredTime(String expiredTime) {
        this.expiredTime = expiredTime;
    }

    public String getIsReceive() {
        return isReceive;
    }

    public void setIsReceive(String isReceive) {
        this.isReceive = isReceive;
    }
}
