package com.uu898app.model.request;

import com.uu898app.model.GBaseModel;

/**
 * Created by zhangbo on 2016/7/4.
 */
public class GGoods extends GBaseModel {
    /**
     * kindid : -3
     * ssid :
     * serverid :
     * gameid : 41
     * keyword :
     * tradeid :
     * addt : 1467616421989
     * addm : a3bde40d820b1a6a35e821b8f09ab297
     * areaid :
     * page : 1
     * orderIndex : 0
     *  orderIndex
     *  {
     *    发布时间由近到远        "0"
     *    价格由低到高            "1"
     *    价格由高到低            "2"
     *    买家星级由高到低        "4"
     *  }
     */

    public static final String TIME_DESC = "0";
    public static final String PRICE_ASC = "1";
    public static final String PRICE_DESC = "2";
    public static final String CREDIT_DESC = "3";

    private String kindid;
    private String serverid;
    private String gameid;
    private String keyword;
    private String tradeid;
    private String addt;
    private String addm;
    private String orderIndex;
    private String areaid;
    private int page;

    public String getKindid() {
        return kindid;
    }

    public void setKindid(String kindid) {
        this.kindid = kindid;
    }

    public String getServerid() {
        return serverid;
    }

    public void setServerid(String serverid) {
        this.serverid = serverid;
    }

    public String getGameid() {
        return gameid;
    }

    public void setGameid(String gameid) {
        this.gameid = gameid;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getTradeid() {
        return tradeid;
    }

    public void setTradeid(String tradeid) {
        this.tradeid = tradeid;
    }

    public String getAddt() {
        return addt;
    }

    public void setAddt(String addt) {
        this.addt = addt;
    }

    public String getAddm() {
        return addm;
    }

    public void setAddm(String addm) {
        this.addm = addm;
    }

    public String getOrderIndex() {
        return orderIndex;
    }

    public void setOrderIndex(String orderIndex) {
        this.orderIndex = orderIndex;
    }

    public String getAreaid() {
        return areaid;
    }

    public void setAreaid(String areaid) {
        this.areaid = areaid;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }
}
