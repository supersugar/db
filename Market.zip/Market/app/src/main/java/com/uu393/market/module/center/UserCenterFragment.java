package com.uu393.market.module.center;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.response.BUserCenterInfo;
import com.uu393.market.model.response.BUserIsBindPhone;
import com.uu393.market.module.ADActivity;
import com.uu393.market.module.base.BaseTabLazyFragment;
import com.uu393.market.module.login.BindPhoneActivity;
import com.uu393.market.module.login.ModifyPasswordActivity;
import com.uu393.market.module.message.EventMessageActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ContactCustomerServicesUtils;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.log.L;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.Call;
import okhttp3.Response;

public class UserCenterFragment extends BaseTabLazyFragment {
    @Bind(R.id.iv_top_message_hint)
    CircleImageView mIvTopMessageHint;
    @Bind(R.id.message_layout)
    RelativeLayout mMessageLayout;
    @Bind(R.id.layout_wallet)
    RelativeLayout mLayoutWallet;
    @Bind(R.id.bt_center_charge)
    Button mBtCenterCharge;
    @Bind(R.id.bt_center_withdraw)
    Button mBtCenterWithdraw;
    @Bind(R.id.iv_top_avatar)
    CircleImageView mIvTopAvatar;
    @Bind(R.id.tv_user_name)
    TextView mTvUserName;
    @Bind(R.id.tv_center_ticket_number)
    TextView mTvCenterTicketNumber;
    @Bind(R.id.layout_ticket)
    RelativeLayout mLayoutTicket;
    @Bind(R.id.layout_collect)
    RelativeLayout mLayoutCollect;
    @Bind(R.id.layout_share)
    RelativeLayout mLayoutShare;
    @Bind(R.id.layout_discount)
    RelativeLayout mLayoutDiscount;
    @Bind(R.id.layout_modify)
    RelativeLayout mLayoutModify;
    @Bind(R.id.layout_bind)
    RelativeLayout mLayoutBind;
    @Bind(R.id.layout_setting)
    RelativeLayout mLayoutSetting;
    @Bind(R.id.layout_contact)
    LinearLayout mLayoutContact;
    @Bind(R.id.layout_join_group)
    LinearLayout mLayoutJoinGroup;
    @Bind(R.id.layout_share_form)
    RelativeLayout mLayoutShareForm;
    @Bind(R.id.tv_user_money)
    TextView mTvUserMoney;
    @Bind(R.id.tv_center_bind_or_unbind)
    TextView mTvBindOrUnBind;//文本显示绑定手机 | 解绑手机
    private boolean hasBindBank = false;
    private static final String INTENT_KEY_TO_WITHDRAW = "hasbindedbank";
    private BUserCenterInfo mUserCenterInfo;
    private BUserIsBindPhone mUserIsBindPhone;//用户是否绑定手机，是否分享用户
    private boolean mIsShareUser;

    public static UserCenterFragment newInstance() {
        UserCenterFragment fragment = new UserCenterFragment();
        Bundle bundle = new Bundle();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_user_center, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    private void initViews(BUserCenterInfo bUserCenterInfo) {
        if (bUserCenterInfo == null) {
            mTvUserName.setText("ID：未获取到用户信息");
            mTvCenterTicketNumber.setText("无");
            mTvUserMoney.setText("无数据");
            mLayoutShareForm.setVisibility(View.VISIBLE);//显示分享赚报表项
        } else {
            if (!TextUtils.isEmpty((String) SPUtil.get(App.mContext, "userId", ""))) {
                mTvUserName.setText("ID：" + (String) SPUtil.get(App.mContext, "userId", ""));
            } else {
                mTvUserName.setText("ID：");
            }

            //是否是分销用户
            if (!TextUtils.isEmpty(bUserCenterInfo.getIsShareSale())) {
                if ("true".equals(bUserCenterInfo.getIsShareSale().trim().toLowerCase())) {
                    mLayoutShareForm.setVisibility(View.VISIBLE);//显示分享赚报表项
                } else {
                    mLayoutShareForm.setVisibility(View.GONE);//隐藏分享赚报表项
                }
            } else {
                mLayoutShareForm.setVisibility(View.GONE);//隐藏分享赚报表项
            }
            //用户ID
            if (!TextUtils.isEmpty(bUserCenterInfo.getUserID())) {
                mTvUserName.setText("ID：" + bUserCenterInfo.getUserID());
            }
            //余额
            if (!TextUtils.isEmpty(bUserCenterInfo.getMoney())) {
                mTvUserMoney.setText(bUserCenterInfo.getMoney());
            } else {
                mTvUserMoney.setText("0.00");
            }
            //优惠券张数
            if (!TextUtils.isEmpty(bUserCenterInfo.getCoupon())) {
                mTvCenterTicketNumber.setText(bUserCenterInfo.getCoupon());
            } else {
                mTvCenterTicketNumber.setText("0");
            }
            //是否已经绑定银行卡
            if (!TextUtils.isEmpty(bUserCenterInfo.getIsTxBank())) {
                if ("true".equals(bUserCenterInfo.getIsTxBank().trim().toLowerCase())) {
                    hasBindBank = true;
                } else {
                    hasBindBank = false;
                }
            } else {
                hasBindBank = false;
            }
            String message = bUserCenterInfo.getMessage();
            if (Float.valueOf(message)!=null&&Float.valueOf(message)>0){//消息数大于0时显示消息红点提示
                mIvTopMessageHint.setVisibility(View.VISIBLE);
            }else {
                mIvTopMessageHint.setVisibility(View.GONE);
            }
        }
    }
    //调整绑定手机textview显示内容
    private void initTextView(boolean hasBindPhone){
        if (hasBindPhone){
            mTvBindOrUnBind.setText("解绑手机");
        }else {
            mTvBindOrUnBind.setText("绑定手机");
        }
    }

    @Override
    protected void initLazyView(@Nullable Bundle savedInstanceState) {
        //不需要
        L.d("原懒加载"+this);
    }

    @Override
    public void onLazyInitView(@Nullable Bundle savedInstanceState) {
        super.onLazyInitView(savedInstanceState);
        L.d("懒加载"+this);
    }

    @Override
    public void onTabReselected() {
        //复选刷新用户数据，，MainFragment中可见时调用、刷新数据
        doGetUserCenterInfo();
        doGetUserIsBindPhone();
    }

    @OnClick({R.id.message_layout, R.id.layout_wallet, R.id.bt_center_charge,
            R.id.bt_center_withdraw, R.id.iv_top_avatar, R.id.layout_ticket, R.id.layout_collect,
            R.id.layout_share, R.id.layout_discount, R.id.layout_modify, R.id.layout_bind,
            R.id.layout_setting, R.id.layout_contact, R.id.layout_join_group, R.id.layout_share_form})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.message_layout://我的消息
                //隐藏消息红点提示
//                mIvTopMessageHint.setVisibility(View.GONE);
                _mActivity.startActivity(new Intent(_mActivity, EventMessageActivity.class));
                break;
            case R.id.layout_wallet://我的钱包
                _mActivity.startActivity(new Intent(_mActivity, WalletActivity.class));
                break;
            case R.id.bt_center_charge://充值
                _mActivity.startActivity(new Intent(_mActivity, ChargeMoneyActivity.class));
                break;
            case R.id.bt_center_withdraw://提现
                Intent intentToWithdraw = new Intent(_mActivity, WithdrawCashActivity.class);
                intentToWithdraw.putExtra(INTENT_KEY_TO_WITHDRAW, hasBindBank);
                _mActivity.startActivity(intentToWithdraw);
                break;
            /*case R.id.iv_top_avatar://个人中心
                break;*/
            case R.id.layout_ticket://优惠券
                _mActivity.startActivity(new Intent(_mActivity, CouponTicketActivity.class));
                break;
            case R.id.layout_collect://收藏
                _mActivity.startActivity(new Intent(_mActivity, CollectGameActivity.class));
                break;
            case R.id.layout_share:
                _mActivity.startActivity(new Intent(_mActivity, JoinShareEarnActivity.class));
                break;
            case R.id.layout_share_form://分享赚
                _mActivity.startActivity(new Intent(_mActivity, ShareReportFormActivity.class));
                break;
            case R.id.layout_discount://折扣说明页
                _mActivity.startActivity(new Intent(_mActivity, ADActivity.class));
                break;
            case R.id.layout_modify://修改密码
                _mActivity.startActivity(new Intent(_mActivity, ModifyPasswordActivity.class));
                break;
            case R.id.layout_bind://绑定手机
                doGetUserIsBindPhone();
                // TODO: 2017/4/22 判断是否已绑定手机
                if (mUserIsBindPhone == null){
                    return;
                }else {
                    String isBindPhone = mUserIsBindPhone.getIsBindPhone();
                    if (TextUtils.isEmpty(isBindPhone)) {
                        _mActivity.startActivity(new Intent(_mActivity, BindPhoneActivity.class));//未绑定，去绑定
                    } else {
                        if (mIsShareUser){
                            ToastUtil.showToast(App.mContext,"分享赚用户不能解绑手机");
                        }else {
                            _mActivity.startActivity(new Intent(_mActivity, RemoveBindPhoneActivity.class));//已绑定，去解绑
                        }

                    }
                }
                break;
            case R.id.layout_setting://更多设置
                startActivity(new Intent(_mActivity, MoreActivity.class));
                break;
            case R.id.layout_contact://联系客服
                ContactCustomerServicesUtils.doXiaoNeng();
                break;
            case R.id.layout_join_group://加入QQ群
                ContactCustomerServicesUtils.joinQQGroup(_mActivity);
                break;
        }
    }

    //获取个人中心用户APP040
    private void doGetUserCenterInfo() {
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetUserCenterInfo(new JsonCallback<BUserCenterInfo>() {
            @Override
            public void onSuccess(BUserCenterInfo bUserCenterInfo, Call call, Response response) {
                if (bUserCenterInfo != null) {
                    mUserCenterInfo = bUserCenterInfo;
                    initViews(mUserCenterInfo);
                }else {
                    initViews(mUserCenterInfo);
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                initViews(mUserCenterInfo);
            }
        });
    }

    //获取用户是否绑定手机号APP058
    private void doGetUserIsBindPhone() {
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetUserIsBindPhone(new JsonCallback<BUserIsBindPhone>() {
            @Override
            public void onSuccess(BUserIsBindPhone bUserIsBindPhone, Call call, Response response) {
                if (bUserIsBindPhone != null) {
                    mUserIsBindPhone = bUserIsBindPhone;
                    if (!TextUtils.isEmpty(bUserIsBindPhone.getIsBindPhone())){
                        SPUtil.put(App.mContext,"chkMobile",bUserIsBindPhone.getIsBindPhone());
                        initTextView(true);
                    }else {
                        initTextView(false);
                    }
                    String isShareSale = bUserIsBindPhone.getIsShareSale();
                    if (!TextUtils.isEmpty(isShareSale)){
                        if ("true".equals(isShareSale.trim().replace(" ",""))){
                            mIsShareUser = true;
                        }else {
                            mIsShareUser = false;
                        }
                    }
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
            }

        });
    }

}
