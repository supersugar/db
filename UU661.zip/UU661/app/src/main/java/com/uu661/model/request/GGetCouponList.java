package com.uu661.model.request;

public class GGetCouponList {

    public static final int TYPE_ALL = -1;
    public static final int TYPE_CAN = 1;
    public static final int TYPE_NOT_CAN = 0;

    public String orderNo;//订单编号
    public int isValid;//是否可用 -1全部 1可用 0不可用

}
