package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    :
 * =====================================================
 */

public class BHotActivityDetail implements Serializable {
    /**
  {   "id":"1",
     "title":"买家下单活动测试买家下单活动",
     "beginTime":"2017-06-01 00:00:00","
     endTime":"2017-08-01 00:00:00","
     gameID":"1",
     "androidPackage":"http://syappmarketapk.oss-cn-hangzhou.aliyuncs.com/636186327803866628-684.apk","
     packageName":"com.iplay.assistant","
     platForm":"0","
     APPID":""}}


     */

    private String id;
    private String beginTime;
    private String endTime;
    private String info;
    private String gameID;
    private String androidPackage;
    private String packageName;
    private String platForm;
    private String title;
    private String APPID;

    public String getAPPID() {
        return APPID;
    }

    public void setAPPID(String APPID) {
        this.APPID = APPID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(String beginTime) {
        this.beginTime = beginTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getGameID() {
        return gameID;
    }

    public void setGameID(String gameID) {
        this.gameID = gameID;
    }

    public String getAndroidPackage() {
        return androidPackage;
    }

    public void setAndroidPackage(String androidPackage) {
        this.androidPackage = androidPackage;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getPlatForm() {
        return platForm;
    }

    public void setPlatForm(String platForm) {
        this.platForm = platForm;
    }






}
