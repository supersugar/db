package com.uu898app.module.common;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.uu898app.R;
import com.uu898app.adapter.GameLetterAdapter;
import com.uu898app.model.request.GGameList;
import com.uu898app.model.request.GOnlyId;
import com.uu898app.model.response.BGame;
import com.uu898app.model.response.BGameArea;
import com.uu898app.model.response.BGameKind;
import com.uu898app.model.response.BGameServer;
import com.uu898app.module.base.BaseFragment;
import com.uu898app.module.helper.AccountManager;
import com.uu898app.network.TaskEngine;
import com.uu898app.network.rxjava.RxSubscriber;
import com.uu898app.util.cache.UUCache;
import com.uu898app.util.cache.UUCacheConstant;
import com.uu898app.util.eventbus.EB;
import com.uu898app.util.eventbus.EventEmpty;
import com.uu898app.util.log.L;
import com.uu898app.util.wavesidebar.LetterComparator;
import com.uu898app.util.wavesidebar.PinnedHeaderDecoration;
import com.uu898app.util.wavesidebar.Util;
import com.uu898app.view.wavesidebar.WaveSideBarView;

import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import cc.solart.turbo.OnItemClickListener;

/**
 * 开始购买的界面，购买前当时是要先选择
 * Created by zhangbo on 2016/6/23.
 */
public class GameListFragment extends BaseFragment {


    private SwipeRefreshLayout mSwipeRefreshLayout;
    private RecyclerView mRecyclerView;
    private WaveSideBarView mSideBarView;

    private GameLetterAdapter mGameAdapter;
    private List<BGame> mGameList;

    private UUCache mCache;

    public static GameListFragment newInstance() {
        Bundle args = new Bundle();
        GameListFragment fragment = new GameListFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.common_game_list, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mCache = UUCache.get(_mActivity);

        mSideBarView = (WaveSideBarView) view.findViewById(R.id.side_view);
        mRecyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        mSwipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.refresh_layout);

        LinearLayoutManager manager = new LinearLayoutManager(_mActivity);
        mRecyclerView.setLayoutManager(manager);

        final PinnedHeaderDecoration decoration = new PinnedHeaderDecoration();
        decoration.registerTypePinnedHeader(1, new PinnedHeaderDecoration.PinnedHeaderCreator() {
            @Override
            public boolean create(RecyclerView parent, int adapterPosition) {
                return true;
            }
        });
        mRecyclerView.addItemDecoration(decoration);

        mSideBarView.setOnTouchLetterChangeListener(new WaveSideBarView.OnTouchLetterChangeListener() {
            @Override
            public void onLetterChange(String letter) {
                int pos = mGameAdapter.getLetterPosition(letter);
                if (pos != -1) {
                    mRecyclerView.scrollToPosition(pos);
                }
            }
        });

        mGameAdapter = new GameLetterAdapter(_mActivity);
        mRecyclerView.setAdapter(mGameAdapter);
        mGameAdapter.addOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(RecyclerView.ViewHolder vh, int position) {
                //点击的位置包含index
                L.d(mGameList.get(position).getName() + " id = " + mGameList.get(position).getID());
                if (!mGameList.isEmpty() && mGameList.get(position).getID() != 0) {
                    EB.postObject(EB.TAG.SELECT_GAME_DONE, mGameList.get(position));
                    _mActivity.finish();
                }
            }
        });
        doGetGameList();
    }

    private void doGetGameList() {
        Object cache = mCache.getAsObject(UUCacheConstant.KEY_GAMES_WITH_INDEX);
        if(null != cache){
            mGameList = (List<BGame>) cache;
            mGameAdapter.resetData(mGameList);
            L.d("从缓存取出游戏列表数据");
            return;
        }
        GGameList gameList = new GGameList();
        gameList.setIshot("0");
        gameList.setSSID(AccountManager.getInstance().getSSID());
        TaskEngine.getInstance().getGameList(gameList).subscribe(new RxSubscriber<List<BGame>>() {
            @Override
            public void _onNext(final List<BGame> bGames) {
                //服务器返回的数据,要加上首字母list
                bGames.addAll(0, Util.getAToZIndexList());
                Collections.sort(bGames, new LetterComparator());
                mGameList = bGames;
                mGameAdapter.resetData(mGameList);
                mCache.put(UUCacheConstant.KEY_GAMES_WITH_INDEX, (ArrayList)mGameList, UUCache.TIME_HOUR);
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }
}
