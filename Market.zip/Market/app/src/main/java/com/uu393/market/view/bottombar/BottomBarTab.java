package com.uu393.market.view.bottombar;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.support.annotation.DrawableRes;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.uu393.market.R;

/**
 * Created by YoKeyword on 16/6/3.
 */
public class BottomBarTab extends FrameLayout {
    private ImageView mIcon;
    private TextView mTvTitle;
    private Context mContext;
    private int mTabPosition = -1;

    private int mNormalIcon;
    private int mPressedIcon;


    public BottomBarTab(Context context, @DrawableRes int normalIcon, @DrawableRes int pressedIcon, CharSequence title) {
        this(context, null, normalIcon, pressedIcon, title);
    }

    public BottomBarTab(Context context, AttributeSet attrs, int normalIcon, int pressedIcon, CharSequence title) {
        this(context, attrs, 0, normalIcon, pressedIcon,  title);
    }

    public BottomBarTab(Context context, AttributeSet attrs, int defStyleAttr, int normalIcon, int pressedIcon, CharSequence title) {
        super(context, attrs, defStyleAttr);
        init(context, normalIcon, pressedIcon,  title);
    }

    private void init(Context context, int normalIcon, int pressedIcon, CharSequence title) {
        mContext = context;
        mNormalIcon = normalIcon;
        mPressedIcon = pressedIcon;
        /* 设置按钮背景图片
            ?android:attr/selectableItemBackground 有界限的波纹
            ?android:attr/selectableItemBackgroundBorderless 可以超出视图区域的波纹
         */
        TypedArray typedArray = context.obtainStyledAttributes(new int[]{R.attr.selectableItemBackgroundBorderless});
        Drawable drawable = typedArray.getDrawable(0);
        setBackgroundDrawable(drawable);
        typedArray.recycle();

        //垂直布局的layout,先new->设置方向/重心->设置lp
        LinearLayout lLContainer = new LinearLayout(context);
        lLContainer.setOrientation(LinearLayout.VERTICAL);
        lLContainer.setGravity(Gravity.CENTER);
        LayoutParams paramsContainer = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        paramsContainer.gravity = Gravity.CENTER;
        lLContainer.setLayoutParams(paramsContainer);

        mIcon = new ImageView(context);
        int size = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 22, getResources().getDisplayMetrics());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(size, size);
        mIcon.setImageResource(mNormalIcon);
        mIcon.setLayoutParams(params);
        //设置图片颜色,原图是一张白色的图,这个吊的是可以改变图片颜色,不管原来图片是什么颜色
//        mIcon.setColorFilter(ContextCompat.getColor(context, R.color.black_mid));
        lLContainer.addView(mIcon);

        mTvTitle = new TextView(context);
        mTvTitle.setText(title);
        LinearLayout.LayoutParams paramsTv = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams
                .WRAP_CONTENT);
        paramsTv.topMargin = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 2, getResources().getDisplayMetrics());
        mTvTitle.setTextSize(10);
        mTvTitle.setTextColor(ContextCompat.getColor(context, R.color.black_mid));
        mTvTitle.setLayoutParams(paramsTv);
        lLContainer.addView(mTvTitle);

        addView(lLContainer);
    }

    @Override
    public void setSelected(boolean selected) {
        super.setSelected(selected);
        if (selected) {
            //选中
//            mIcon.clearColorFilter();//去除滤镜效果
            mIcon.setImageResource(mPressedIcon);
            mTvTitle.setTextColor(ContextCompat.getColor(mContext, R.color.blue));
        } else {
            //未选中
            mIcon.setImageResource(mNormalIcon);
//            mIcon.setColorFilter(ContextCompat.getColor(mContext, R.color.black_mid));
            mTvTitle.setTextColor(ContextCompat.getColor(mContext, R.color.black_mid));
        }
    }

    public void setTabPosition(int position) {
        mTabPosition = position;
        if (position == 0) {
            setSelected(true);
        }
    }

    public int getTabPosition() {
        return mTabPosition;
    }
}
