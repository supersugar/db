package com.uu898.gamesdk.model.request;

import com.uu898.gamesdk.model.GBaseModel;

/**
 * Created by zhangbo on 2016/6/15.
 */
public class GGetOrderList extends GBaseModel {

    public static final String PAY_TYPE_ZFB = "13";
    public static final String PAY_TYPE_WX = "14";

    private String status;//商品编号

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
