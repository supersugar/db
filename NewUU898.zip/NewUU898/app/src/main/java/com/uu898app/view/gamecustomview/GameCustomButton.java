package com.uu898app.view.gamecustomview;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.uu898app.R;

import cn.finalteam.toolsfinal.DeviceUtils;

/**
 * Created by bo on 16/8/24.
 */
public class GameCustomButton extends RelativeLayout {


    private RelativeLayout mParentView;
    private LinearLayout mLayoutHasValue;
    private LinearLayout mLayoutBeSelected;
    private TextView mTvTitle;
    private Context mContext;
    private int mButtonPos = -1;

    private String mInitString = "";

    private boolean hasValue = false;

    public GameCustomButton(Context context, String title) {
        this(context, null, title);
    }

    public GameCustomButton(Context context, AttributeSet attrs, String title) {
        this(context, attrs, 0, title);
    }

    public GameCustomButton(Context context, AttributeSet attrs, int defStyleAttr, String title) {
        super(context, attrs, defStyleAttr);
        init(context, title);
    }

    private void init(Context context, String title) {
        mContext = context;
        mInitString = title;

        mParentView = (RelativeLayout) LayoutInflater.from(context).inflate(R.layout.game_custom_button, null);
        LayoutParams paramsContainer = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        paramsContainer.height = DeviceUtils.dip2px(context, 46);
        mParentView.setLayoutParams(paramsContainer);

        mLayoutHasValue = (LinearLayout) mParentView.findViewById(R.id.layout_has_value);
        mLayoutHasValue.setVisibility(View.GONE);
        mLayoutBeSelected = (LinearLayout) mParentView.findViewById(R.id.layout_be_selected);
        mLayoutBeSelected.setVisibility(View.GONE);

        mTvTitle = (TextView) mParentView.findViewById(R.id.tv_value);
        mTvTitle.setText(title);

        TypedArray typedArray = context.obtainStyledAttributes(new int[]{R.attr.selectableItemBackground});
        Drawable drawable = typedArray.getDrawable(0);
        setBackgroundDrawable(drawable);
        typedArray.recycle();

        addView(mParentView);

    }

    @Override
    public void setSelected(boolean selected) {
        super.setSelected(selected);
        //点击按钮的时候会触发这个方法
        if(hasValue){
            return;
        }
        if (selected) {
//            mParentView.setBackgroundColor(ContextCompat.getColor(mContext,R.color.white));
////            mParentView.setBackgroundResource(R.drawable.bg_game_selected);
            mLayoutBeSelected.setVisibility(View.VISIBLE);
            mTvTitle.setTextColor(ContextCompat.getColor(mContext, R.color.blue));
        } else {
            mLayoutBeSelected.setVisibility(View.GONE);
//            mParentView.setBackgroundColor(ContextCompat.getColor(mContext,android.R.color.transparent));
            mTvTitle.setTextColor(ContextCompat.getColor(mContext, R.color.black_light));
        }
    }

    public void setButtonPosition(int position){
        mButtonPos = position;
    }

    public int getButtonPos(){
        return mButtonPos;
    }

    public void setValue(String result){
        mTvTitle.setText(result);
        mTvTitle.setTextColor(ContextCompat.getColor(mContext, R.color.blue));
        hasValue = true;
        mLayoutHasValue.setVisibility(View.VISIBLE);
        mLayoutBeSelected.setVisibility(View.GONE);

    }

    /**
     * 重置
     */
    public void reset() {
        mTvTitle.setText(mInitString);
        mTvTitle.setTextColor(ContextCompat.getColor(mContext, R.color.black_light));
        hasValue = false;
        mLayoutHasValue.setVisibility(View.GONE);
        mLayoutBeSelected.setVisibility(View.GONE);
    }

    public boolean hasValue(){
        return hasValue;
    }
}
