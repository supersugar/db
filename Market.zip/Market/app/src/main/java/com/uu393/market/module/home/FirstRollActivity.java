package com.uu393.market.module.home;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.util.ImageHelper;

/**
 * Created by z on 2017/4/27.
 */

public class FirstRollActivity extends BaseActivity{

    private ImageButton mGoShouYe;
    private BrowserLayoutLink mWebView;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_roll);

        mWebView = (BrowserLayoutLink) findViewById(R.id.wv_hotactiondetails);
        mGoShouYe = (ImageButton) findViewById(R.id.go_shouye_bt);
        initWebView("http://192.168.5.52:8090/APPMarket/APPView/FirstCouponExplain");
        mGoShouYe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }

    public void initWebView(String url){

        mWebView.loadUrl(url);

    }
}
