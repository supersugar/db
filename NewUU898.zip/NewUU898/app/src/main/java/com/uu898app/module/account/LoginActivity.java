package com.uu898app.module.account;

import android.os.Bundle;

import com.uu898app.R;
import com.uu898app.module.base.BaseActivity;

/**
 * Created by YoKeyword on 16/4/19.
 */
public class LoginActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base);
        if (savedInstanceState == null) {
            loadRootFragment(R.id.fl_container, LoginFragment.newInstance());
        }
    }
}
