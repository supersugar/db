package com.uu898.gamesdk.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.uu898.gamesdk.fragmentation.SupportFragment;
import com.uu898.gamesdk.model.GBaseModel;
import com.uu898.gamesdk.model.request.GBinding;
import com.uu898.gamesdk.model.request.GGetSMSAuthCode;
import com.uu898.gamesdk.model.response.BUserInfo;
import com.uu898.gamesdk.network.NetCallback;
import com.uu898.gamesdk.network.TaskEngine;
import com.uu898.gamesdk.utils.AccountManager;
import com.uu898.gamesdk.utils.CountDownTimer;
import com.uu898.gamesdk.utils.StringUtils;
import com.uu898.gamesdk.utils.ToastUtil;

import java.util.List;

/**
 * 绑定手机,需要判断是首次绑定还是换绑手机
 * Created by zhangbo on 2016/6/23.
 */
public class RegisterBindingFragment extends BaseFragment {

    private final static String BINDING_TYPE = "type";//绑定操作类型
    public static final int TYPE_FIRST_BINDING = 0;//首次绑定
    public static final int TYPE_CHAGNE_BINDING = 1;//换绑

    private EditText mEdtPhone;
    private EditText mEdtAuthCode;
    private Button mBtGetSMSCode;
    private Button mBtNext;

    private int mCurrentType;

    public static RegisterBindingFragment newInstance(int type) {
        Bundle args = new Bundle();
        args.putInt(BINDING_TYPE, type);
        RegisterBindingFragment fragment = new RegisterBindingFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        if (args != null) {
            mCurrentType = args.getInt(BINDING_TYPE);
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        View view = inflater.inflate(getLayoutId("ug_register_binding"), container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, mCurrentType == TYPE_FIRST_BINDING ? "绑定手机" : "换绑手机");

        mEdtPhone = (EditText) view.findViewById(getId("ug_edt_phone"));
        mEdtAuthCode = (EditText) view.findViewById(getId("ug_edt_auth_code"));
        mBtGetSMSCode = (Button) view.findViewById(getId("ug_bt_get_sms_code"));
        mBtNext = (Button) view.findViewById(getId("ug_bt_next"));

        mBtGetSMSCode.setOnClickListener(onClickListener);
        mBtNext.setOnClickListener(onClickListener);
    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v.getId() == getId("ug_bt_get_sms_code")) {
                verifyPhone();
            } else if (v.getId() == getId("ug_bt_next")) {
                verifyForm();
            }
        }
    };

    private void verifyPhone() {
        String phone = mEdtPhone.getText().toString();

        if (StringUtils.isEmpty(phone)) {
            ToastUtil.showToast(_mActivity, "请输入手机号");
            return;
        }

        doGetSMSCode(phone);
    }

    private void verifyForm() {
        String phone = mEdtPhone.getText().toString();
        String authcode = mEdtAuthCode.getText().toString();


        if (StringUtils.isEmpty(phone)) {
            ToastUtil.showToast(_mActivity, "请输入手机号");
            return;
        }
        if (StringUtils.isEmpty(authcode)) {
            ToastUtil.showToast(_mActivity, "请输入验证码");
            return;
        }
        if(mCurrentType == TYPE_FIRST_BINDING){
            doFirstBindingPhone(phone, authcode);
        }else{
            doChangeBindingPhone(phone, authcode);
        }
    }

    /**
     * 获取手机验证码
     *
     * @param phone
     */
    private void doGetSMSCode(String phone) {
        GGetSMSAuthCode model = new GGetSMSAuthCode();
        int type = mCurrentType == TYPE_FIRST_BINDING ? GGetSMSAuthCode.type_1 : GGetSMSAuthCode.type_2;
        model.setType(type);
        model.setPhoneNo(phone);
        model.setSSID("");
        TaskEngine.getInstance().doGetSMSAuthCode(model, new NetCallback(this) {

            @Override
            public void _onNext(Object o) {
                ToastUtil.showToast(_mActivity, "短信验证码已发送至您的手机");
                new CountDownTimer(60000, 1000, mBtGetSMSCode, "获取验证码").start();
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

    private void doFirstBindingPhone(String phone, String authcode) {
        GBinding model = new GBinding();
        model.setPhoneNo(phone);
        model.setCheckCode(authcode);
        TaskEngine.getInstance().doBindingPhone(model, new NetCallback(this) {

            @Override
            public void _onNext(Object o) {
                ToastUtil.showToast(_mActivity, "绑定成功");
                doGetUserInfo();
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

    private void doChangeBindingPhone(String phone, String authcode) {
        GBinding model = new GBinding();
        model.setPhoneNo(phone);
        model.setCheckCode(authcode);
        TaskEngine.getInstance().doChangeBindingPhone(model, new NetCallback(this) {

            @Override
            public void _onNext(Object o) {
                ToastUtil.showToast(_mActivity, "换绑成功");
                doGetUserInfo();
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

    /**
     * 不管是绑定成功,还是换绑成功,都要重新获取一次用户信息
     */
    private void doGetUserInfo() {
        TaskEngine.getInstance().doGetUserInfo(new GBaseModel(), new NetCallback<BUserInfo>(this) {
            @Override
            public void _onNext(BUserInfo result) {
                AccountManager.getInstance().saveAccountInfo(result);
                List<Fragment> fragmentList = getFragmentManager().getFragments();
                if (null != fragmentList) {
                    Fragment fragment = fragmentList.get(0);
                    if (fragment instanceof SupportFragment) {
                        popTo(fragment.getClass(), false);
                    }
                }else{
                    _mActivity.finish();
                }
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

}
