package com.uu393.market.module.home;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.R;
import com.uu393.market.model.PageModel;
import com.uu393.market.model.response.BHotActivity;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import ezy.ui.layout.LoadingLayout;
import okhttp3.Call;
import okhttp3.Response;

public class HotActivity extends BaseActivity {

    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    @Bind(R.id.recycle_view_hot)
    PullLoadMoreRecyclerView mRecycleViewHot;
    @Bind(R.id.tv_no_result_hint)
    TextView mTvNoResultHint;
    @Bind(R.id.no_result_view)
    LinearLayout mNoResultView;
    HotAdapter adapter;
    int mPageIndex = 1;
    List<BHotActivity>  mGameList = new ArrayList<>();

    private LoadingLayout mLoadingLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hot);
        ButterKnife.bind(this);

        //初始化标题栏
        mTitleBarRight.setVisibility(View.GONE);
        mTitleBarTitle.setText("热门活动");
        mRecycleViewHot.setLinearLayout();

        adapter = new HotAdapter(HotActivity.this);

        mRecycleViewHot.setAdapter(adapter);

        mRecycleViewHot.setRefreshing(true);

        mLoadingLayout = LoadingLayout.wrap(HotActivity.this);
        mLoadingLayout.showLoading();

        doGetGameList(false);
        mLoadingLayout.setRetryListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doGetGameList(false);
            }
        });

        mRecycleViewHot.setOnPullLoadMoreListener(new PullLoadMoreRecyclerView.PullLoadMoreListener() {
            @Override
            public void onRefresh() {
                doGetGameList(false);
            }

            @Override
            public void onLoadMore() {
                doGetGameList(true);
            }
        });



        mTvNoResultHint.setText("抱歉，暂无活动");


    }
    public void showResult(boolean hasResult){
        if (hasResult){
            mNoResultView.setVisibility(View.GONE);
            mRecycleViewHot.setVisibility(View.VISIBLE);
        }else {
            mRecycleViewHot.setVisibility(View.GONE);
            mNoResultView.setVisibility(View.VISIBLE);
        }
    }

    private void doGetGameList(final boolean loadMore) {
        if(loadMore == false){
            mPageIndex = 1;
            mGameList.clear();
        }
        PageModel page = new PageModel(mPageIndex);
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetHotActivityList(null,page, new JsonCallback<List<BHotActivity>>() {
            @Override
            public void onSuccess(List<BHotActivity> bHotActivity, Call call, Response response) {
                mLoadingLayout.showContent();

                if (null == bHotActivity || bHotActivity.isEmpty()) {
                    //无返回结果,需要根据当前页码判断是无结果,还是无更多
                    if(mPageIndex == 1){
                        showResult(false);
                    }else{
                        ToastUtil.showToast(HotActivity.this,"没有更多了~");
                    }
                }else{
                    showResult(true);
                    mPageIndex++;
                    if (loadMore == false) {//非增量加载
                        mGameList.clear();
                    }
                    mGameList.addAll(bHotActivity);
                }
            }

            @Override
            public void onAfter(List<BHotActivity> bHotActivity, Exception e) {
                super.onAfter(bHotActivity, e);
                mRecycleViewHot.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        adapter.updateData(mGameList);
                        mRecycleViewHot.setPullLoadMoreCompleted();
                    }
                }, 100);
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
            }
        });
    }

    @OnClick(R.id.title_bar_left)
    public void onClick() {
        super.onBackPressed();
    }

}
