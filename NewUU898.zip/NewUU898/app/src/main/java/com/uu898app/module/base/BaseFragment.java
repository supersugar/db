package com.uu898app.module.base;

import android.app.Activity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

import com.uu898app.R;
import com.uu898app.view.loadtoast.LoadToast;

import me.yokeyword.fragmentation.SupportFragment;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class BaseFragment extends SupportFragment {

    private LoadToast mLoadToast;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mLoadToast = new LoadToast(_mActivity);
    }

    protected void initToolbarMenu(Toolbar toolbar) {
        toolbar.inflateMenu(R.menu.menu_hierarchy);
        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_hierarchy:
                        _mActivity.showFragmentStackHierarchyView();
                        break;
                }
                return true;
            }
        });
    }

    public void showLoadToast(){
        mLoadToast.show();
    }

    public void hideLoadToast(){
        mLoadToast.success();
    }

}
