package com.uu898.gamesdk.support.listener;

import com.uu898.gamesdk.support.result.UGPayResult;

public interface UGPayListener {
    void onPayDone(UGPayResult result);
}
