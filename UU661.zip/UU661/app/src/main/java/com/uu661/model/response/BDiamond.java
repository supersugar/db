package com.uu661.model.response;

import java.io.Serializable;

/**
 * Created by bo on 16/12/6.
 */

public class BDiamond implements Serializable {


    /**
     *
         "Id": 240,
         "periodId": 275739,
         "startTime": "2017-03-24 21:46:04.100",
         "fullTime": "",
         "openTime": "",
         "periodStatus": 1,
         "periodNo": 703240003,
         "totalCount": 2,
         "alreadySold": 1,
         "title": "5U钻【可兑换全站任意商】",
         "commodityCategory": 20,
         "commodityType": 5,
         "price": 5,
         "unitPrice": 3,
         "imageUrl": "http:\/\/u6.img898.com\/",
         "status": 1,
         "sortId": 0,
         "ifCanChange": false,
         "changeCount": 0,
         "addTime": "2017-03-24 09:52:12.387",
         "updateTime": "2017-03-24 09:52:12.390",
         "currentPeriodNo": 703240003,
         "clickNumber": 0,
         "leftCount": 1,
         "xsss": 1
     */

    private int Id;
    private int periodId;
    private String startTime;
    private Object fullTime;
    private Object openTime;
    private int periodStatus;
    private int periodNo;
    private int totalCount;
    private int alreadySold;
    private String title;
    private int commodityCategory;
    private int commodityType;
    private int price;
    private String imageUrl;
    private int status;
    private int sortId;
    private boolean ifCanChange;
    private int changeCount;
    private String addTime;
    private String updateTime;
    private int currentPeriodNo;
    private int clickNumber;
    private int leftCount;
    private int unitPrice;
    private int xsss;               //小试身手 0 false 1 true

    public int getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(int unitPrice) {
        this.unitPrice = unitPrice;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        this.Id = id;
    }

    public int getPeriodId() {
        return periodId;
    }

    public void setPeriodId(int periodId) {
        this.periodId = periodId;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public Object getFullTime() {
        return fullTime;
    }

    public void setFullTime(Object fullTime) {
        this.fullTime = fullTime;
    }

    public Object getOpenTime() {
        return openTime;
    }

    public void setOpenTime(Object openTime) {
        this.openTime = openTime;
    }

    public int getPeriodStatus() {
        return periodStatus;
    }

    public void setPeriodStatus(int periodStatus) {
        this.periodStatus = periodStatus;
    }

    public int getPeriodNo() {
        return periodNo;
    }

    public void setPeriodNo(int periodNo) {
        this.periodNo = periodNo;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getAlreadySold() {
        return alreadySold;
    }

    public void setAlreadySold(int alreadySold) {
        this.alreadySold = alreadySold;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getCommodityCategory() {
        return commodityCategory;
    }

    public void setCommodityCategory(int commodityCategory) {
        this.commodityCategory = commodityCategory;
    }

    public int getCommodityType() {
        return commodityType;
    }

    public void setCommodityType(int commodityType) {
        this.commodityType = commodityType;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getSortId() {
        return sortId;
    }

    public void setSortId(int sortId) {
        this.sortId = sortId;
    }

    public boolean isIfCanChange() {
        return ifCanChange;
    }

    public void setIfCanChange(boolean ifCanChange) {
        this.ifCanChange = ifCanChange;
    }

    public int getChangeCount() {
        return changeCount;
    }

    public void setChangeCount(int ChangeCount) {
        this.changeCount = ChangeCount;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public int getCurrentPeriodNo() {
        return currentPeriodNo;
    }

    public void setCurrentPeriodNo(int currentPeriodNo) {
        this.currentPeriodNo = currentPeriodNo;
    }

    public int getClickNumber() {
        return clickNumber;
    }

    public void setClickNumber(int clickNumber) {
        this.clickNumber = clickNumber;
    }

    public int getLeftCount() {
        return leftCount;
    }

    public void setLeftCount(int LeftCount) {
        this.leftCount = LeftCount;
    }

    public int getXsss() {
        return xsss;
    }

    public void setXsss(int xsss) {
        this.xsss = xsss;
    }
}
