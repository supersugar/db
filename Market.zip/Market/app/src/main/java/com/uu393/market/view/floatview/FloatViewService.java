package com.uu393.market.view.floatview;

import android.app.ActivityManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import static com.uu393.market.app.App.mContext;

/**
 * Desction:Float view service
 * Author:pengjianbo
 * Date:15/10/26 下午5:15
 */
public class FloatViewService extends Service {

    public FloatView getFloatView() {
        return mFloatView;
    }

    private FloatView mFloatView;
    private Timer timer;
    /**
     * 用于在线程中创建或移除悬浮窗。
     */
    private Handler handler = new Handler();

    private boolean isFloatViewShow = false;
    private boolean isFloatViewUsed = false;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return new FloatViewServiceBinder();
    }


    @Override
    public void onCreate() {
        super.onCreate();
        mFloatView = new FloatView(this);

        // 开启定时器，每隔0.5秒刷新一次
        if (timer == null) {
            timer = new Timer();
            timer.scheduleAtFixedRate(new RefreshTask(), 0, 500);
        }
    }

    public void showFloat() {
        isFloatViewUsed = true;
        if (mFloatView != null) {
            mFloatView.show();
            isFloatViewShow = true;
        }
    }

    public void hideFloat() {
        if (mFloatView != null) {
            mFloatView.hide();
            isFloatViewShow = false;
        }
    }

    public void destroyFloat() {
        if (mFloatView != null) {
            mFloatView.destroy();
            isFloatViewShow = false;
        }
        mFloatView = null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // Service被终止的同时也停止定时器继续运行
//        timer.cancel();
//        timer = null;
        destroyFloat();
    }

    public class FloatViewServiceBinder extends Binder {
        public FloatViewService getService() {
            return FloatViewService.this;
        }
    }

    class RefreshTask extends TimerTask {
        @Override
        public void run() {
            if (isFloatViewUsed = false || null == mFloatView) {
                return;
            }
            //如果FloatView不为null,并且位于后台,隐藏掉
            if (isFloatViewShow && isBackground()) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        mFloatView.hide();
                    }
                });

            } else if (isFloatViewShow && !isBackground()) {//如果FloatView不为null,并且位于前台,隐藏掉

                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        mFloatView.show();
                    }
                });
            }
        }
    }

    public boolean isBackground() {


        ActivityManager activityManager = (ActivityManager) mContext.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> appProcesses = activityManager.getRunningAppProcesses();
        for (ActivityManager.RunningAppProcessInfo appProcess : appProcesses) {
            if (appProcess.processName.equals(mContext.getPackageName())) {
                if (appProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_BACKGROUND) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        return false;
    }

}
