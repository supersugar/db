package com.uu393.market.module.center;

import android.Manifest;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.AppCollectRecordHelper;
import com.uu393.market.core.DevConfig;
import com.uu393.market.model.PageModel;
import com.uu393.market.model.request.GGetGameList;
import com.uu393.market.model.request.GGetMultiGameDetail;
import com.uu393.market.model.response.BGame;
import com.uu393.market.model.response.BUserIsBindPhone;
import com.uu393.market.module.MainActivity;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;

import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;
import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.EasyPermissions;

/**
 * Created by Z on 2017/4/11.
 */

public class CollectGameActivity extends BaseActivity implements EasyPermissions.PermissionCallbacks{


    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    TextView mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    @Bind(R.id.rv_bt_game)
    PullLoadMoreRecyclerView mRecyclerViewCollectApps;
    @Bind(R.id.btn_collect_bottom)
    Button mBtnCollectBottom;
    @Bind(R.id.download_bt_layout)
    RelativeLayout mDownloadBtLayout;
    @Bind(R.id.ll_result)
    LinearLayout mLlResult;
    @Bind(R.id.tv_no_result_hint)
    TextView mTvNoResultHint;
    @Bind(R.id.bt_no_result)
    Button mBtNoResult;
    @Bind(R.id.ll_no_result)
    LinearLayout mLlNoResult;
    private List<BGame> mGameList;
    private ApkListAdapterNew mAdapter;
    private Set<String> mCancelCollectSelectedApps = new HashSet<>();//存放取消收藏的游戏ID
    private List<String> mCollectionRecords = new ArrayList<>();//存放从本地获取到的所有收藏记录
    private boolean mIsShareUser;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collectgame);
        ButterKnife.bind(this);
        mTitleBarTitle.setText("我的收藏");
        mTitleBarRight.setVisibility(View.GONE);
        mGameList = new ArrayList<>();
        mRecyclerViewCollectApps.setLinearLayout();
        mRecyclerViewCollectApps.setPullRefreshEnable(false);
        mRecyclerViewCollectApps.setPushRefreshEnable(false);

        mAdapter = new ApkListAdapterNew(this);
        mRecyclerViewCollectApps.setAdapter(mAdapter);
    }

    private void doGetLocalCollectRecord() {
        mCollectionRecords.clear();
        Map<Object, Object> allAppCollectRecord = AppCollectRecordHelper.getInstance(App.mContext).getAllAppCollectRecord();
        if (allAppCollectRecord.isEmpty() || allAppCollectRecord == null) {
            showResult(false);//本地无记录时
            return;
        }
        Set<Map.Entry<Object, Object>> entrySet = allAppCollectRecord.entrySet();
        Iterator<Map.Entry<Object, Object>> iterator = entrySet.iterator();
        Pattern pattern = Pattern.compile("^[1-9]\\d*$");
        while (iterator.hasNext()) {
            Object value = iterator.next().getValue();
            if (value != null) {
                if (value instanceof String) {
                    if (pattern.matcher((String) value).matches()){//匹配游戏id为正整数
                        mCollectionRecords.add((String) value);
                    }
                }
            }
        }

    }


    @Override
    protected void onResume() {
        super.onResume();
        EB.register(this);
        doGetUserIsBindPhone();

        doGetLocalCollectRecord();
        doGetGameList(mCollectionRecords);
    }

    private void showResult(boolean hasResult) {
        if (hasResult) {
            mTitleBarRight.setVisibility(View.VISIBLE);
            mLlResult.setVisibility(View.VISIBLE);
            mLlNoResult.setVisibility(View.GONE);
        } else {
            mTitleBarRight.setVisibility(View.GONE);
            mLlNoResult.setVisibility(View.VISIBLE);
            mLlResult.setVisibility(View.GONE);
        }
    }


    private void doGetGameList(List<String> ids) {
        if (ids == null || ids.isEmpty()) {
            showResult(false);
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    hideLoadToast();
                }
            },2000);
            return;
        }
        GGetMultiGameDetail model = new GGetMultiGameDetail();
        model.setId("" + ids.toString().replace("[", "").replace("]", "").trim());//多个ID
        showLoadToast(CollectGameActivity.this);
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetMultiGameDetail(model, new JsonCallback<List<BGame>>() {
            @Override
            public void onSuccess(List<BGame> bGames, Call call, Response response) {
                hideLoadToast();
                if (null == bGames || bGames.isEmpty()) {
                    showResult(false);
                } else {
                    mGameList.clear();
                    mGameList.addAll(bGames);
                    showResult(true);
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
                showResult(false);
            }

            @Override
            public void onAfter(List<BGame> bGames, Exception e) {
                super.onAfter(bGames, e);
                hideLoadToast();
                mRecyclerViewCollectApps.setPullLoadMoreCompleted();
                mAdapter.updateData(mGameList);
            }
        });
    }

    private void editItems() {
        if ("编辑".equals(mTitleBarRight.getText().toString())) {
            mTitleBarRight.setText("完成");
            mCancelCollectSelectedApps.clear();
            mAdapter.updateData(mGameList);
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (mAdapter!=null){
                        mAdapter.slideOpen();
                    }
                    mDownloadBtLayout.setVisibility(View.VISIBLE);
                }
            }, 300);


        } else if ("完成".equals(mTitleBarRight.getText().toString())) {
            mTitleBarRight.setText("编辑");
            mAdapter.updateData(mGameList);
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mDownloadBtLayout.setVisibility(View.GONE);
                    if (mAdapter!=null){
                        mAdapter.slideClose();
                    }
                }
            }, 300);
        }
    }

    @OnClick({R.id.title_bar_left, R.id.title_bar_right, R.id.btn_collect_bottom, R.id.bt_no_result})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                onBackPressedSupport();
                break;
            case R.id.title_bar_right:
                editItems();
                break;
            case R.id.btn_collect_bottom://todo 取消收藏选中的游戏-->删除本地记录
                //======删除网络获取到的列表中的单项
                if (mGameList != null && !mGameList.isEmpty()) {
                    ArrayList<BGame> arrayList = new ArrayList<>();//暂存要删除的App收藏记录:存的是BGame
                    Set<Integer> integers = new HashSet<>();//暂存从adapter的单项状态map中拿到选中的单项id

                    Map<Integer, Boolean> map = mAdapter.getMap();
                    Set<Map.Entry<Integer, Boolean>> entrySet = map.entrySet();
                    for (Map.Entry<Integer, Boolean> entry : entrySet) {
                        if (entry.getValue()) {
                            integers.add(entry.getKey());
                        }
                    }
                    Iterator<Integer> iterator1 = integers.iterator();
                    for (; iterator1.hasNext(); ) {
                        Integer next = iterator1.next();
                        if (next < mGameList.size() && next >= 0) {
                            arrayList.add(mGameList.get(next));
                        }
                    }
                    //从列表中删除记录
                    for (BGame game : arrayList) {
                        Iterator<BGame> iterator = mGameList.iterator();
                        while (iterator.hasNext()) {
                            if (iterator.next().getId().equals(game.getId())) {
                                iterator.remove();
                                continue;
                            }
                        }
                    }
                    //=============从本地删除记录=========
                    for (BGame game : arrayList) {
                        String packageName = game.getPackageName();
                        AppCollectRecordHelper.getInstance(App.mContext).removeOneAppCollectRecord(packageName);
                    }
                    //^^^^^^^^^^^^^从本地删除记录^^^^^^^^^
                    mAdapter.updateData(mGameList);
                    if (mGameList.isEmpty() || mGameList == null) {
                        mHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (mAdapter!=null){
                                    mAdapter.slideClose();
                                }
                            }
                        }, 300);

                        showResult(false);
                    } else {
                        showResult(true);
                    }
                }

                break;
            case R.id.bt_no_result:
                mTitleBarRight.setText("编辑");
                mAdapter.updateData(mGameList);
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mDownloadBtLayout.setVisibility(View.GONE);
                        if (mAdapter!=null){
                            mAdapter.slideClose();
                        }
                    }
                }, 300);
                showLoadToast(CollectGameActivity.this);
                //刷新数据,,网络错误刷新
                doGetLocalCollectRecord();
                doGetGameList(mCollectionRecords);
                break;
        }
    }

    private Handler mHandler = new Handler();

    //获取用户是否绑定手机号,是否是分享赚用户APP058
    private void doGetUserIsBindPhone() {
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetUserIsBindPhone(new JsonCallback<BUserIsBindPhone>() {
            @Override
            public void onSuccess(BUserIsBindPhone bUserIsBindPhone, Call call, Response response) {
                if (bUserIsBindPhone != null) {

                    String isShareSale = bUserIsBindPhone.getIsShareSale();
                    if (!TextUtils.isEmpty(isShareSale)){
                        if ("true".equals(isShareSale.toLowerCase().trim().replace(" ",""))){
                            mIsShareUser = true;
                            if (mAdapter != null) {
                                mAdapter.setIsShareUser(mIsShareUser);
                            }
                        }else {
                            mIsShareUser = false;
                            if (mAdapter != null) {
                                mAdapter.setIsShareUser(mIsShareUser);
                            }
                        }
                    }
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                if (mAdapter != null) {
                    mAdapter.setIsShareUser(mIsShareUser);
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mAdapter!=null){
                    mAdapter.slideClose();
                }
            }
        }, 300);
        super.onDestroy();
        EB.unregister(this);

        if (mAdapter!=null){
            mAdapter.removeReference();
        }
        mAdapter=null;
    }
    @AfterPermissionGranted(100)
    private void requestPermissions() {
        String[] mPermissionList = new String[]{
                //                Manifest.permission.ACCESS_FINE_LOCATION,       //位置信息
                //                Manifest.permission.CALL_PHONE,                 //电话相关
                //                Manifest.permission.READ_LOGS,
                //                Manifest.permission.READ_PHONE_STATE,           //电话相关
                //                Manifest.permission.GET_ACCOUNTS,//联系人,通讯录
                //                Manifest.permission.SET_DEBUG_APP,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,};
        if (!EasyPermissions.hasPermissions(CollectGameActivity.this, mPermissionList)) {
            EasyPermissions.requestPermissions(CollectGameActivity.this,
                    "应用下载时需要保存到本地，为了保证核心功能的稳定性，请您同意授权权限", 100, mPermissionList);
        }

    }

    @Override
    public void onPermissionsGranted(int requestCode, List<String> perms) {
        //同意授权

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    @Override
    public void onPermissionsDenied(int requestCode, List<String> perms) {
        //取消授权时
    }
    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.REQUEST_SD_CARD_COLLECT_ACTIVITY://点击下载时申请sd卡权限
                requestPermissions();
                break;
        }
    }

    @Override
    public void onBackPressedSupport() {
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mAdapter!=null){
                    mAdapter.slideClose();
                }
            }
        }, 300);
        super.onBackPressedSupport();
    }
}

