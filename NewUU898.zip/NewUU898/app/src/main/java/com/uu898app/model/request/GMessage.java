package com.uu898app.model.request;

import com.uu898app.model.GBaseModel;

/**
 * Created by zhangbo on 2016/7/11.
 */
public class GMessage extends GBaseModel {
    private int pageIndex;

    public GMessage(int pageIndex) {
        this.pageIndex = pageIndex;
    }

    public GMessage(String SSID, int pageIndex) {
        super(SSID);
        this.pageIndex = pageIndex;
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }
}
