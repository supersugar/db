package com.uu661.model.response;

import java.io.Serializable;


public class BBuyRecord implements Serializable {


    /**
     * rowId : 1
     * commodityId : 230
     * periodNo : 701180043
     * killOrderNo : 1000847882
     * nickName : 其实我是女的
     * uu898UserId : 10****06
     * avatar : null
     * userId : 1003306
     * addTime : 2017-01-18 10:20:56.683
     * buyNum : 1
     * IP : 183.208.195.176
     * city : 江苏省苏州市
     * name : 1003306
     */

    private String rowId;
    private int commodityId;
    private int periodNo;
    private String killOrderNo;
    private String nickName;
    private String uu898UserId;
    private Object avatar;
    private String userId;
    private String addTime;
    private String buyNum;
    private String IP;
    private String city;
    private String name;

    public String getRowId() {
        return rowId;
    }

    public void setRowId(String rowId) {
        this.rowId = rowId;
    }

    public int getCommodityId() {
        return commodityId;
    }

    public void setCommodityId(int commodityId) {
        this.commodityId = commodityId;
    }

    public int getPeriodNo() {
        return periodNo;
    }

    public void setPeriodNo(int periodNo) {
        this.periodNo = periodNo;
    }

    public String getKillOrderNo() {
        return killOrderNo;
    }

    public void setKillOrderNo(String killOrderNo) {
        this.killOrderNo = killOrderNo;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getUu898UserId() {
        return uu898UserId;
    }

    public void setUu898UserId(String uu898UserId) {
        this.uu898UserId = uu898UserId;
    }

    public Object getAvatar() {
        return avatar;
    }

    public void setAvatar(Object avatar) {
        this.avatar = avatar;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }

    public String getBuyNum() {
        return buyNum;
    }

    public void setBuyNum(String buyNum) {
        this.buyNum = buyNum;
    }

    public String getIP() {
        return IP;
    }

    public void setIP(String IP) {
        this.IP = IP;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
