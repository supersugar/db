package com.uu393.market.module.h5game;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GGetGameDetail;
import com.uu393.market.model.response.BGiftBagInfo;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

public class GiftBagActivity extends BaseActivity {

    @Bind(R.id.ptf_gift_bag)
    PullLoadMoreRecyclerView mPtfRecyclerView;
    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    private GiftBagAdapter mGiftBagAdapter;
    private String mGameId;
    private List<BGiftBagInfo> mGifgBags = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gift_bag);
        mGameId = getIntent().getStringExtra("gameId");
        ButterKnife.bind(this);
        initTitleBar();
        initRecyclerView();
    }

    private void initTitleBar() {
        mTitleBarRight.setVisibility(View.GONE);
        mTitleBarTitle.setText("游戏礼包");
    }

    @Override
    protected void onResume() {
        super.onResume();
        getGiftBagList();
    }

    private void initRecyclerView() {
        mPtfRecyclerView.setLinearLayout();
        mGiftBagAdapter = new GiftBagAdapter();
        mPtfRecyclerView.setPullRefreshEnable(true);
        mPtfRecyclerView.setPushRefreshEnable(false);
        mPtfRecyclerView.setAdapter(mGiftBagAdapter);
        mPtfRecyclerView.setOnPullLoadMoreListener(new PullLoadMoreRecyclerView.PullLoadMoreListener() {
            @Override
            public void onRefresh() {
                getGiftBagList();
                mPtfRecyclerView.setPullLoadMoreCompleted();
            }

            @Override
            public void onLoadMore() {

            }
        });
    }

    private void getGiftBagList() {
        GGetGameDetail model = new GGetGameDetail(mGameId);//传入游戏id

        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetGiftBagList(model, new JsonCallback<List<BGiftBagInfo>>() {
            @Override
            public void onSuccess(List<BGiftBagInfo> bGiftBagInfos, Call call, Response response) {
                if (bGiftBagInfos == null || bGiftBagInfos.isEmpty()) {
                    ToastUtil.showToast(App.mContext, "暂无礼包信息");
                } else {
                    mGifgBags.clear();
                    mGifgBags.addAll(bGiftBagInfos);
                    mGiftBagAdapter.refresh(mGifgBags);
                }
            }
        });
    }

    @OnClick(R.id.title_bar_left)
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                super.onBackPressedSupport();
                break;
            default:
                break;
        }
    }

    // 礼包列表适配器
    public class GiftBagAdapter extends RecyclerView.Adapter<GiftBagAdapter.GiftBagItemHolder> {
        private List<BGiftBagInfo> bags = new ArrayList<>();

        @Override
        public GiftBagItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_gift_bag, parent, false);

            return new GiftBagItemHolder(inflate);
        }

        @Override
        public void onBindViewHolder(GiftBagItemHolder holder, final int position) {
            holder.bindItem(bags.get(position));
            holder.parent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //todo 传去参数 礼包详情

                    Intent intent = new Intent(GiftBagActivity.this, GiftBagDetailActivity.class);
                    intent.putExtra("giftId", bags.get(position).getId());
                    startActivity(intent);
                }
            });
        }

        @Override
        public int getItemCount() {
            return bags.size();
        }

        public void refresh(List<BGiftBagInfo> bags) {
            this.bags = bags;
            this.notifyDataSetChanged();
        }


        public class GiftBagItemHolder extends RecyclerView.ViewHolder {
            private TextView name, count, totalCount, date, status;
            private ImageButton go;
            private View parent;

            public GiftBagItemHolder(View itemView) {
                super(itemView);
                parent = itemView.findViewById(R.id.rl_gift_bag_item_parent);
                name = (TextView) itemView.findViewById(R.id.tv_gift_bag_name);
                totalCount = (TextView) itemView.findViewById(R.id.tv_gift_bag_total_count);
                count = (TextView) itemView.findViewById(R.id.tv_gift_bag_count);
                date = (TextView) itemView.findViewById(R.id.tv_gift_bag_date);
                status = (TextView) itemView.findViewById(R.id.tv_gift_bag_status);
                go = (ImageButton) itemView.findViewById(R.id.ib_gift_bag_item_go);

            }

            private void bindItem(BGiftBagInfo bag) {
                name.setText(bag.getGiftName());
                totalCount.setText("剩余数量：" + bag.getTotalNumber() + " / ");
                count.setText(bag.getSurplusNumber());
                date.setText(bag.getExpiredTime());

                if ("0".equals(bag.getIsReceive())) {
                    status.setVisibility(View.INVISIBLE);
                    //status.setText("未领取");
                } else if ("1".equals(bag.getIsReceive())) {
                    status.setText("已领取");
                }

            }
        }
    }
}
