package com.uu393.market.module.login;

import android.app.Dialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GDoLogin;
import com.uu393.market.model.response.BUserInfo;
import com.uu393.market.module.ADActivity;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.message.EventMessageActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.DensityUtils;
import com.uu393.market.util.RsaHelper;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.log.L;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

public class UserCenterActivity extends BaseActivity {

    @Bind(R.id.ib_user_center_go_back)
    ImageButton mIbUserCenterGoBack;
    @Bind(R.id.tv_user_center_name)
    TextView mTvUserCenterName;
    @Bind(R.id.tv_user_center_phone_number)
    TextView mTvUserCenterPhoneNumber;
    @Bind(R.id.ll_center_message)
    LinearLayout mLlCenterMessage;
    @Bind(R.id.ll_center_modify_pass)
    LinearLayout mLlCenterModifyPass;
    @Bind(R.id.ll_center_discount)
    LinearLayout mLlCenterDiscount;
    @Bind(R.id.ll_center_bind_phone)
    LinearLayout mLlCenterBindPhone;
    @Bind(R.id.ib_logout)
    ImageButton mIbLogout;
    @Bind(R.id.tv_user_center_third_name)
    TextView mTvUserCenterThirdName;
    @Bind(R.id.iv_center_modify_pass)
    ImageView mIvCenterModifyPass;
    @Bind(R.id.iv_user_center_bind_phone_icon)
    ImageView mIvUserCenterBindPhoneIcon;
    @Bind(R.id.tv_user_center_bind_phone)
    TextView mTvUserCenterBindPhone;
    private String userId;
    private String token;
    private String uId;
    private String chkMobile;
    private String thirdUserId;
    private String loginType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_center);
        ButterKnife.bind(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!(boolean) SPUtil.get(App.mContext, "isLogin", false)) {
            UserCenterActivity.this.finish();
        }
        loginType = (String) SPUtil.get(App.mContext, "loginType", "");
        thirdUserId = (String) SPUtil.get(App.mContext, "thirdUserId", "");
        userId = (String) SPUtil.get(App.mContext, "userId", "");
        token = (String) SPUtil.get(App.mContext, "token", "");
        uId = (String) SPUtil.get(App.mContext, "uId", "");
        chkMobile = (String) SPUtil.get(App.mContext, "chkMobile", "");
        doAutoLogin();
        initView();
    }

    private void doAutoLogin() {
        if (!(boolean) SPUtil.get(App.mContext, "isLogin", false)) {
            startActivity(new Intent(this,LoginActivity.class));
            UserCenterActivity.this.finish();
            return;
        }
        if ("0".equals(SPUtil.get(App.mContext, "loginType", ""))) {
            GDoLogin model = new GDoLogin();
            model.setUserId("");
            model.setPassword(RsaHelper.encryptDataFromStr("", RsaHelper.RSA_PUBLIC_KEY));
            model.setDecipheringType("0");
            TaskEngine.setTokenUseridPhoneState(2);
            TaskEngine.getInstance().doLogin(model, new JsonCallback<BUserInfo>() {
                @Override
                public void onSuccess(BUserInfo bUserInfo, Call call, Response response) {
                    loginType = "0";
                    thirdUserId = "";
                    userId = bUserInfo.getUserId();
                    token = bUserInfo.getToken();
                    uId = bUserInfo.getUId();
                    chkMobile = bUserInfo.getChkMobile();
                    SPUtil.put(App.mContext, "isLogin", true);
                    SPUtil.put(App.mContext, "loginType", "0");
                    SPUtil.put(App.mContext, "thirdUserId", "");
                    SPUtil.put(App.mContext, "token", bUserInfo.getToken());
                    SPUtil.put(App.mContext, "userId", bUserInfo.getUserId());
                    SPUtil.put(App.mContext, "uId", bUserInfo.getUId());
                    SPUtil.put(App.mContext, "chkMobile", bUserInfo.getChkMobile());
                }

                @Override
                public void onError(Call call, Response response, Exception e) {
                    super.onError(call, response, e);
                    SPUtil.put(App.mContext, "isLogin", false);
                    SPUtil.put(App.mContext, "loginType", "");
                    SPUtil.put(App.mContext, "thirdUserId", "");
                    SPUtil.put(App.mContext, "token", "");
                    SPUtil.put(App.mContext, "userId", "");
                    SPUtil.put(App.mContext, "uId", "");
                    SPUtil.put(App.mContext, "chkMobile", "");
                    startActivity(new Intent(UserCenterActivity.this, LoginActivity.class));
                    UserCenterActivity.this.finish();
                }
            });
        }


    }



    private void initView() {
        if (loginType.equals("0")) {
            mTvUserCenterThirdName.setVisibility(View.GONE);
            mLlCenterModifyPass.setClickable(true);
            mIvCenterModifyPass.setImageResource(R.drawable.ic_center_modify_pass);
        } else {
            mIvCenterModifyPass.setImageResource(R.drawable.ic_center_modify_pass_dark);
            mLlCenterModifyPass.setClickable(false);
            mTvUserCenterThirdName.setVisibility(View.VISIBLE);
            if (!TextUtils.isEmpty(thirdUserId)){
                mTvUserCenterThirdName.setVisibility(View.VISIBLE);
                mTvUserCenterThirdName.setText((String) SPUtil.get(App.mContext, "thirdUserId", ""));
            }else {
                mTvUserCenterThirdName.setVisibility(View.GONE);
            }
        }

        mTvUserCenterName.setText("ID：" + userId);
        if (!StringUtils.isEmpty(chkMobile)) {
            mTvUserCenterPhoneNumber.setText(chkMobile);
            mLlCenterBindPhone.setClickable(false);
            mTvUserCenterBindPhone.setText("已绑定手机");
            mIvUserCenterBindPhoneIcon.setImageResource(R.drawable.ic_center_bind_phone_grey);//灰色图片
        } else {
            mTvUserCenterPhoneNumber.setText(" 未绑定手机号");
            mLlCenterBindPhone.setClickable(true);
            mTvUserCenterBindPhone.setText("绑定手机");
            mIvUserCenterBindPhoneIcon.setImageResource(R.drawable.ic_center_bind_phone);
        }

    }


    @OnClick({R.id.ib_user_center_go_back, R.id.ll_center_message, R.id.ll_center_modify_pass,
            R.id.ll_center_discount, R.id.ll_center_bind_phone, R.id.ib_logout})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ib_user_center_go_back:
                super.onBackPressedSupport();
                break;
            case R.id.ib_logout:
                doLogout();
                break;
            case R.id.ll_center_message://暂无消息
                startActivity(new Intent(UserCenterActivity.this, EventMessageActivity.class));
                break;
            case R.id.ll_center_modify_pass:
                doModifyPassword();
                break;
            case R.id.ll_center_discount://进入app折扣页
                startActivity(new Intent(UserCenterActivity.this, ADActivity.class));
                break;
            case R.id.ll_center_bind_phone:
                doBindPhone();
                break;
        }
    }

    private void doLogout() {
        View inflate = LayoutInflater.from(App.mContext).inflate(R.layout.dialog_common, null, false);
        TextView dialogTitle2 = (TextView) inflate.findViewById(R.id.tv_dialog_title2);
        dialogTitle2.setText("是否要切换账号？");
        Button dialogCancel = (Button) inflate.findViewById(R.id.btn_dialog_cancel);
        Button dialogConfirm = (Button) inflate.findViewById(R.id.btn_dialog_confirm);

        final Dialog dialog = new Dialog(UserCenterActivity.this,R.style.DialogStyle);
        dialog.setContentView(inflate);
        Window window = dialog.getWindow();
        window.setGravity(Gravity.BOTTOM);

        WindowManager m = getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        //获得窗体的属性
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.y = DensityUtils.dp2px(App.mContext, 10);
        lp.height = DensityUtils.dp2px(App.mContext, 170);
        lp.width = d.getWidth() - DensityUtils.dp2px(App.mContext, 20);
        window.setAttributes(lp);
        dialog.show();//显示对话框
        dialogCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialogConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MobclickAgent.onProfileSignOff();
                SPUtil.put(App.mContext, "isLogin", false);
                SPUtil.put(App.mContext, "thirdUserId", "");
                SPUtil.put(App.mContext, "loginType", "");
                SPUtil.put(App.mContext, "token", "");
                SPUtil.put(App.mContext, "userId", "");
                SPUtil.put(App.mContext, "uId", "");
                SPUtil.put(App.mContext, "chkMobile", "");
                startActivity(new Intent(UserCenterActivity.this, LoginActivity.class));
                UserCenterActivity.this.finish();
            }
        });
    }

    private void doModifyPassword() {
        startActivity(new Intent(UserCenterActivity.this, ModifyPasswordActivity.class));
    }

    private void doBindPhone() {
        startActivity(new Intent(UserCenterActivity.this, BindPhoneActivity.class));
    }

    @Override
    public void onBackPressedSupport() {
        super.onBackPressedSupport();
        this.finish();
    }
}
