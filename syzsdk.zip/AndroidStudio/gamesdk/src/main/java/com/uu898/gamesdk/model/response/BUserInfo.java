package com.uu898.gamesdk.model.response;

/**
 * Created by bo on 16/9/14.
 */
public class BUserInfo {

    public String id;
    public String userId;
    public int money = 0;//用户可用余额 单位:分
    public String phoneNo;//如果绑定了手机号返回手机号，否则传空字符串

}
