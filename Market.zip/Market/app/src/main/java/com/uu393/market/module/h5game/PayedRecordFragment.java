package com.uu393.market.module.h5game;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.PageModel;
import com.uu393.market.model.request.GGetOrderList;
import com.uu393.market.model.response.BOrderInfo;
import com.uu393.market.module.base.BaseViewPagerFragment;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import okhttp3.Call;
import okhttp3.Response;


public class PayedRecordFragment extends BaseViewPagerFragment {


    @Bind(R.id.ptf_payed_record)
    PullLoadMoreRecyclerView mPtfPayedRecord;
    private String kind;
    private String APPID;
    private List<BOrderInfo> mOrders = new ArrayList<>();
    private PayedRecordAdapter recordAdapter;
    private int page=1;
    public static PayedRecordFragment newInstance(String kind,String APPID) {
        PayedRecordFragment fragment = new PayedRecordFragment();
        Bundle bundle = new Bundle();
        bundle.putString("kind", kind);
        bundle.putString("APPID",APPID);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_payed_record, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Bundle bundle = getArguments();
        kind = bundle.getString("kind");
        APPID = bundle.getString("APPID");

        mPtfPayedRecord.setLinearLayout();
        recordAdapter = new PayedRecordAdapter();
        mPtfPayedRecord.setPullRefreshEnable(false);
        mPtfPayedRecord.setPushRefreshEnable(true);
        mPtfPayedRecord.setAdapter(recordAdapter);
        mPtfPayedRecord.setOnPullLoadMoreListener(new PullLoadMoreRecyclerView.PullLoadMoreListener() {
            @Override
            public void onRefresh() {
                getOrderList(false);
            }

            @Override
            public void onLoadMore() {
                page++;
                getOrderList(true);
            }
        });
        getOrderList(false);
    }

    @Override
    public void onResume() {
        super.onResume();
        getOrderList(false);
    }

    private void getOrderList(final boolean isLoadMore){
        GGetOrderList model = new GGetOrderList();
        model.setAPPID(APPID);
        if ("所有订单".equals(kind)){
            model.setStatus("");
        }else if ("充值成功".equals(kind)){
            model.setStatus("2");
        }
        PageModel pageModel = new PageModel(page);
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetOrderList(model,pageModel, new JsonCallback<List<BOrderInfo>>() {
            @Override
            public void onSuccess(List<BOrderInfo> bOrderInfos, Call call, Response response) {
                mPtfPayedRecord.setPullLoadMoreCompleted();
                if (bOrderInfos==null||bOrderInfos.isEmpty()){
                    ToastUtil.showToast(App.mContext,"暂无订单信息");
                }else {
                    if (isLoadMore){

                    }else {
                        mOrders.clear();
                    }
                    mOrders.addAll(bOrderInfos);
                    recordAdapter.refresh(mOrders);


                }
            }
        });
    }
    @Override
    public void refresh() {

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    // 礼包列表适配器
    public class PayedRecordAdapter extends RecyclerView.Adapter<PayedRecordAdapter.PayedRecordItemHolder> {
        private List<BOrderInfo> orders=new ArrayList<>();


        @Override
        public PayedRecordItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_payed_record, parent, false);

            return new PayedRecordItemHolder(inflate);
        }

        @Override
        public void onBindViewHolder(PayedRecordItemHolder holder, final int position) {
            holder.bindItem(orders.get(position));
            holder.parent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getActivity(), PayedDetailActivity.class);
                    intent.putExtra("APPID",APPID);
                    intent.putExtra("orderNo",orders.get(position).getOrderNo());
                    getActivity().startActivity(intent);
                }
            });
        }

        @Override
        public int getItemCount() {
            return orders.size();
        }

        public void refresh(List<BOrderInfo> orders){
            this.orders = orders;
            this.notifyDataSetChanged();
        }


        public class PayedRecordItemHolder extends RecyclerView.ViewHolder {
            private View parent;
            private TextView name, time, price, status;
            private ImageButton go;

            public PayedRecordItemHolder(View itemView) {
                super(itemView);
                parent = itemView.findViewById(R.id.rl_item_payed_record);
                name = (TextView) itemView.findViewById(R.id.tv_payed_name);
                time = (TextView) itemView.findViewById(R.id.tv_payed_time);
                price = (TextView) itemView.findViewById(R.id.tv_payed_price);
                status = (TextView) itemView.findViewById(R.id.tv_payed_status);
                go = (ImageButton) itemView.findViewById(R.id.ib_payed_go);

            }

            private void bindItem(BOrderInfo orderInfo) {
                    name.setText(orderInfo.getTitle());//订单名字
                    time.setText(orderInfo.getAddTime());//时间
                    price.setText(orderInfo.getTotalMoney()+"元");//价格
                    //todo 判断礼包状态
                    status.setVisibility(View.VISIBLE);
                    String statusInfo = "";
                    switch (orderInfo.getStatus()){
                        case "0":
                            statusInfo="已取消";
                            break;
                        case "1":
                            statusInfo="支付完成";
                            break;
                        case "2":
                            statusInfo="订单完成";
                            break;
                        case "3":
                            statusInfo="订单失败";
                            break;
                        case "4":
                            statusInfo="支付超时，已取消";
                            break;
                        default:
                            break;
                    }
                    status.setText(statusInfo);//订单状态
            }
        }
    }
}
