package com.uu898app.util.customanimator;

import android.animation.ValueAnimator;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;

import java.util.ArrayList;
import java.util.List;

public class CustomAnimator extends ValueAnimator implements ValueAnimator.AnimatorUpdateListener {
    private final Rect mTmpRect;

    private boolean mIsRevert;

    private ViewGroup mMainContainer;
    private View mFocusedView;
    private View mFocusedViewContainer;
    private List<View> mFadedOutToBottomViews, mSlideToTop;
    private View mStickyTo;
    private ViewGroup mEditModeViewGroup;

    private int mEditModeHalfHeight;
    private final int ANIMATION_DURATION = 300;
    private boolean mIsExpanding = false;


    public CustomAnimator() {
        super();
        mTmpRect = new Rect();
        mIsRevert = false;
        mFadedOutToBottomViews = new ArrayList<View>();
        mSlideToTop = new ArrayList<View>();

        setInterpolator(new DecelerateInterpolator());
        setDuration(ANIMATION_DURATION);
        addUpdateListener(this);
    }

    /**
     * mMainContainer 			整个布局的最上层容器。
     * one 			  			被点击的控件，也就是上面说道的选择控件
     * mFirstGroup    			focusedView所在的父容器
     * fadedOutToBottomViews	动画过程中将消失到底部去的view列表
     * stickyTo
     * editModeView				被隐藏的选择界面
     * slideToTop				动画过程中将滑动到顶部的view列表
     */
    public void setAnimatorViews(ViewGroup mainContainer, View focusedView, View focusedViewContainer, List<View> fadedOutToBottomViews, View stickyTo, ViewGroup editModeView, List<View> slideToTop) {
        if (mainContainer == null) throw new NullPointerException();
        if (focusedView == null) throw new NullPointerException();
        if (focusedViewContainer == null) throw new NullPointerException();
        if (editModeView == null) throw new NullPointerException();

        mMainContainer = mainContainer;
        mFocusedView = focusedView;
        mFocusedViewContainer = focusedViewContainer;
        mFadedOutToBottomViews.clear();
        if (fadedOutToBottomViews != null) {
            mFadedOutToBottomViews.addAll(fadedOutToBottomViews);
        }
        mStickyTo = stickyTo;
        mEditModeViewGroup = editModeView;
        mSlideToTop.clear();
        if (slideToTop != null) {
            mSlideToTop.addAll(slideToTop);
        }

        removeAllListeners();

        addListener(new LayerEnablingAnimatorListener(focusedView));
        for (View v : mFadedOutToBottomViews) {
            addListener(new LayerEnablingAnimatorListener(v));
        }
        for (View v : mSlideToTop) {
            addListener(new LayerEnablingAnimatorListener(v));
        }
        addListener(new LayerEnablingAnimatorListener(editModeView));
    }

    public void setEditModeHalfHeight(int editModeHalfHeight) {
        mEditModeHalfHeight = editModeHalfHeight;
    }

    private Positions getPositionsStart() {
        // focusOn 选中view的父容器
        float focusY = mFocusedViewContainer.getY();

        // slideToTop
        float[] slideToTopY = new float[mSlideToTop.size()];
        for (int i = 0; i < mSlideToTop.size(); i++) {
            slideToTopY[i] = mSlideToTop.get(i).getY();
        }

        // fadeToBottom
        float[] nextContainersY = new float[mFadedOutToBottomViews.size()];
        for (int i = 0; i < mFadedOutToBottomViews.size(); i++) {
            nextContainersY[i] = mFadedOutToBottomViews.get(i).getY();
        }
        float nextContainersAlpha = 1;

        // stickyTo
        float stickToY = mStickyTo == null ? 0 : mStickyTo.getY();

        // fadeInToTop
        float editY = mEditModeViewGroup.getY();
        float editAlpha = 0f;

        return new Positions(focusY, nextContainersY, nextContainersAlpha, stickToY, editY, editAlpha, slideToTopY);
    }

    private Positions getPositionsEnd() {
        // focusOn
        mFocusedView.getDrawingRect(mTmpRect);
        mMainContainer.offsetDescendantRectToMyCoords(mFocusedView, mTmpRect);
        float focusY = mFocusedViewContainer.getY() - mTmpRect.top;

        // slideToTop
        float[] slideToTopY = new float[mSlideToTop.size()];
        for (int i = 0; i < mSlideToTop.size(); i++) {
            slideToTopY[i] = mSlideToTop.get(i).getY() - mTmpRect.top;
        }

        // fadeToBottom
        float[] nextContainersY = new float[mFadedOutToBottomViews.size()];
        for (int i = 0; i < mFadedOutToBottomViews.size(); i++) {
            nextContainersY[i] = mFadedOutToBottomViews.get(i).getY() + mEditModeHalfHeight;
        }
        float nextContainersAlpha = 0;

        // stickyTo
        float stickToY = 0;
        if (mStickyTo != null) {
            mStickyTo.getDrawingRect(mTmpRect);
            mMainContainer.offsetDescendantRectToMyCoords(mStickyTo, mTmpRect);
            stickToY = mStickyTo.getY() + (mStickyTo.getHeight() - mTmpRect.top);
        }

        // fadeInToTop
        float editY = 0;
        float editAlpha = 1f;

        return new Positions(focusY, nextContainersY, nextContainersAlpha, stickToY, editY, editAlpha, slideToTopY);
    }

    //开始动画
    public void prepareAnimation() {
        mIsRevert = false;
        setObjectValues(getPositionsStart(), getPositionsEnd());
        setEvaluator(new PositionTypeEvaluator());
    }

    private Positions getRevertPositionsStart() {
        // focusOn
        float focusY = mFocusedViewContainer.getY();

        // slideToTop
        float[] slideToTopY = new float[mSlideToTop.size()];
        for (int i = 0; i < mSlideToTop.size(); i++) {
            slideToTopY[i] = mSlideToTop.get(i).getY();
        }

        // fadeToBottom
        float[] nextContainersY = new float[mFadedOutToBottomViews.size()];
        for (int i = 0; i < mFadedOutToBottomViews.size(); i++) {
            nextContainersY[i] = mFadedOutToBottomViews.get(i).getY();
        }
        float nextContainersAlpha = 0;

        // stickyTo
        float stickToY = mStickyTo == null ? 0 : mStickyTo.getY();

        // fadeInToTop
        float editY = mEditModeViewGroup.getY();
        float editAlpha = 1f;

        return new Positions(focusY, nextContainersY, nextContainersAlpha, stickToY, editY, editAlpha, slideToTopY);
    }

    private Positions getRevertPositionsEnd() {
        // focusOn
        mFocusedView.getDrawingRect(mTmpRect);
        mMainContainer.offsetDescendantRectToMyCoords(mFocusedView, mTmpRect);
        float focusY = mFocusedViewContainer.getY() + mTmpRect.top;

        // slideToTop
        float[] slideToTopY = new float[mSlideToTop.size()];
        for (int i = 0; i < mSlideToTop.size(); i++) {
            slideToTopY[i] = mSlideToTop.get(i).getY() + mTmpRect.top;
        }

        // fadeToBottom
        float[] nextContainersY = new float[mFadedOutToBottomViews.size()];
        for (int i = 0; i < mFadedOutToBottomViews.size(); i++) {
            nextContainersY[i] = mFadedOutToBottomViews.get(i).getY() - mEditModeHalfHeight;
        }
        float nextContainersAlpha = 1;

        // stickyTo
        float stickToY = 0;
        if (mStickyTo != null) {
            mStickyTo.getDrawingRect(mTmpRect);
            mMainContainer.offsetDescendantRectToMyCoords(mStickyTo, mTmpRect);
            stickToY = mStickyTo.getY() - (mStickyTo.getHeight() - mTmpRect.top);
        }

        // fadeInToTop
        float editY = mEditModeHalfHeight;
        float editAlpha = 0f;

        return new Positions(focusY, nextContainersY, nextContainersAlpha, stickToY, editY, editAlpha, slideToTopY);
    }

    //反转动画，结束
    public void prepareRevert() {
        mIsRevert = true;

        setObjectValues(getRevertPositionsStart(), getRevertPositionsEnd());
        setEvaluator(new PositionTypeEvaluator());
    }

    public boolean isExpanding() {
        return mIsExpanding;
    }

    @Override
    public void onAnimationUpdate(ValueAnimator animation) {
        Positions currentPos = (Positions) animation.getAnimatedValue();
        if (!mIsRevert) {
            for (int i = 0; i < mSlideToTop.size(); i++) {
                mSlideToTop.get(i).setY(currentPos.getSlideToTop()[i]);
            }

            mFocusedViewContainer.setY(currentPos.getFocusY());

            for (int i = 0; i < mFadedOutToBottomViews.size(); i++) {
                mFadedOutToBottomViews.get(i).setY(currentPos.getNextContainersY()[i]);
                mFadedOutToBottomViews.get(i).setAlpha(currentPos.getNextContainersAlpha());
            }

            if (mStickyTo != null)
                mStickyTo.setY(currentPos.getStickToY());

            mEditModeViewGroup.setY(currentPos.getEditY());
            mEditModeViewGroup.setAlpha(currentPos.getEditAlpha());
            mEditModeViewGroup.setVisibility(View.VISIBLE);
            mIsExpanding = true;
        } else {
            mEditModeViewGroup.setY(currentPos.getEditY());
            mEditModeViewGroup.setAlpha(currentPos.getEditAlpha());

            if (mStickyTo != null)
                mStickyTo.setY(currentPos.getStickToY());

            for (int i = 0; i < mFadedOutToBottomViews.size(); i++) {
                mFadedOutToBottomViews.get(i).setY(currentPos.getNextContainersY()[i]);
                mFadedOutToBottomViews.get(i).setAlpha(currentPos.getNextContainersAlpha());
            }

            mFocusedViewContainer.setY(currentPos.getFocusY());

            for (int i = 0; i < mSlideToTop.size(); i++) {
                mSlideToTop.get(i).setY(currentPos.getSlideToTop()[i]);
            }
            mIsExpanding = false;

        }
    }
}
