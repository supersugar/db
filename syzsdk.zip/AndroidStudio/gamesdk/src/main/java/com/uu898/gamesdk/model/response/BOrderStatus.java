package com.uu898.gamesdk.model.response;

import java.io.Serializable;

/**
 * Created by bo on 16/9/14.
 */
public class BOrderStatus implements Serializable{

    public static final String STATUS_PAY_ING = "0";
    public static final String STATUS_SUCCESS = "1";
    public static final String STATUS_FAIL = "2";

    public String ZFstatus;
    public String money;//单价(元)


}
