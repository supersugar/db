package com.uu393.market.module.manager;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.format.Formatter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.bumptech.glide.Glide;
import com.lzy.okserver.download.DownloadInfo;
import com.lzy.okserver.download.DownloadManager;
import com.lzy.okserver.download.DownloadService;
import com.lzy.okserver.listener.DownloadListener;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.DownloadHelper;
import com.uu393.market.model.request.GGetGameDetail;
import com.uu393.market.model.request.GGetMultiGameDetail;
import com.uu393.market.model.response.BGame;
import com.uu393.market.module.base.BaseViewPagerFragment;
import com.uu393.market.module.home.AppDetailActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.GlideRoundTransform;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;
import com.uu393.market.view.progressbutton.SubmitProcessButton;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

import static com.uu393.market.app.App.mContext;

/**
 * 下载管理,两个列表
 * 上面列表展示:下载中/暂停/错误/等待状态的app
 * 下面列表展示:下载完成的app
 */
public class DownloadFragment extends BaseViewPagerFragment {

    private DownloadManager mDownloadManager;

    private RecyclerView mRecyclerViewOne;
    private RecyclerView mRecyclerViewTwo;
    private NotDoneAdapter mNotDoneAdapter;
    private DoneAdapter mDoneAdapter;

    private List<DownloadInfo> mAllDownloadInfo = new ArrayList<>();
    private List<DownloadInfo> mNotDoneDownloadInfo = new ArrayList<>();
    private List<DownloadInfo> mDoneDownloadInfo = new ArrayList<>();

    private List<String> mNotDoneDownloadInfoString = new ArrayList<>();
    private List<String> mDoneDownloadInfoString = new ArrayList<>();

    private String mDoneInfoString;
    private String mNotDoneInfoString;

    private HashMap<String,List<BGame>> all_ids_mp = new HashMap<>();

    private TextView mBtClearDoneDownload;

    private List<BGame> mGameList = new ArrayList<>();
    private List<BGame> mGameDoneList = new ArrayList<>();

    public static DownloadFragment newInstance() {
        DownloadFragment fragment = new DownloadFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart("DownloadFragment");
        refresh();
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("DownloadFragment");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.manage_download_fragment, null);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mDownloadManager = DownloadService.getDownloadManager();
        mNotDoneAdapter = new NotDoneAdapter();
        mDoneAdapter = new DoneAdapter(_mActivity, mDownloadManager);
        mBtClearDoneDownload = (TextView) view.findViewById(R.id.bt_clear_done_download);
        mBtClearDoneDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showClearDownloadedDialog();
            }
        });

        loadData();
        //-------------------------------没有下载完成的---正在下载的、暂停下载的------
        mRecyclerViewOne = (RecyclerView) view.findViewById(R.id.recycler_view_one);
        mRecyclerViewTwo = (RecyclerView) view.findViewById(R.id.recycler_view_two);


        mRecyclerViewOne.setLayoutManager(new LinearLayoutManager(_mActivity) {
            @Override
            public boolean canScrollVertically() {
                return false;
            }
        });

        //---------------------------------------------------------------------

        //---------------------------下载完成的----------------------------------
        mRecyclerViewTwo.setLayoutManager(new LinearLayoutManager(_mActivity) {
            @Override
            public boolean canScrollVertically() {
                return false;
            }
        });

        //---------------------------------------------------------------------
    }

    //// TODO: 2017/2/20 加载所有任务
    private void loadData() {

        /*int currentVersionCode = ManifestUtils.getVersionCode(_mActivity);
        if (currentVersionCode==6&&!((boolean)SPUtil.get(App.mContext,"hasDelete",false))){
            mDownloadManager.removeAllTask();
            SPUtil.put(App.mContext,"hasDelete",true);
        }*/
        mAllDownloadInfo = mDownloadManager.getAllTask();
        mDoneDownloadInfo.clear();
        mDoneDownloadInfoString.clear();
        mNotDoneDownloadInfo.clear();
        if (null != mAllDownloadInfo && !mAllDownloadInfo.isEmpty()) {
            for (DownloadInfo info : mAllDownloadInfo) {
                if (info.getState() == DownloadManager.FINISH) {
                    mDoneDownloadInfo.add(info);//完成的
                    mDoneDownloadInfoString.add(info.getTaskKey());
                } else {
                    mNotDoneDownloadInfo.add(info);//未完成的
                    mNotDoneDownloadInfoString.add(info.getTaskKey());
                }
            }


            doGetDoneGameList(mDoneInfoString,mDoneDownloadInfoString);
            doNotGetGameList(mNotDoneInfoString,mNotDoneDownloadInfoString);


        }
        mBtClearDoneDownload.setVisibility(mDoneDownloadInfo.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void doNotGetGameList(final String info, List<String> ids) {
        if (ids == null || ids.isEmpty()) {
            return;
        }
        GGetMultiGameDetail model = new GGetMultiGameDetail();
        model.setId("" + ids.toString().replace("[", "").replace("]", "").trim());//多个ID
        showLoadToast();
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetMultiGameDetail(model, new JsonCallback<List<BGame>>() {
            @Override
            public void onSuccess(List<BGame> bGames, Call call, Response response) {
                hideLoadToast();
                if (null == bGames || bGames.isEmpty()) {
                } else {

                    mGameList.clear();
                    mGameList.addAll(bGames);
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
            }

            @Override
            public void onAfter(List<BGame> bGames, Exception e) {
                super.onAfter(bGames, e);

                mRecyclerViewOne.setAdapter(mNotDoneAdapter);
                hideLoadToast();
            }
        });
    }

    private void doGetDoneGameList(final String info, List<String> ids) {

        if (ids == null || ids.isEmpty()) {
            return;
        }
        GGetMultiGameDetail model = new GGetMultiGameDetail();
        model.setId("" + ids.toString().replace("[", "").replace("]", "").trim());//多个ID
        showLoadToast();
        TaskEngine.setTokenUseridPhoneState(2);

        mGameDoneList.clear();
        TaskEngine.getInstance().doGetMultiGameDetail(model, new JsonCallback<List<BGame>>() {
            @Override
            public void onSuccess(List<BGame> bGames, Call call, Response response) {
                hideLoadToast();
                if (null == bGames || bGames.isEmpty()) {
                } else {
                    mGameDoneList.addAll(bGames);
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
            }

            @Override
            public void onAfter(List<BGame> bGames, Exception e) {
                super.onAfter(bGames, e);
                mDoneAdapter.setData(mGameDoneList,mDoneDownloadInfo);

                mRecyclerViewTwo.setAdapter(mDoneAdapter);
                hideLoadToast();
            }
        });
    }

    public void refresh() {
        if (null == mDownloadManager || null == mNotDoneAdapter) {
            return;
        }
        loadData();
        mNotDoneAdapter.notifyDataSetChanged();
        mDoneAdapter.notifyDataSetChanged();
    }

    // TODO: 2017/2/20 清空记录弹出框
    public void showClearDownloadedDialog() {
        MaterialDialog.Builder builder = new MaterialDialog.Builder(_mActivity).title("清空下载记录").content("您确认要删除所有下载记录吗？").positiveText
                ("是").negativeText("否").onPositive(new MaterialDialog.SingleButtonCallback() {
            @Override
            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                if (null != mDoneDownloadInfo && !mDoneDownloadInfo.isEmpty()) {
                    for (DownloadInfo temp : mDoneDownloadInfo) {

                        mDownloadManager.removeTask(temp.getTaskKey(), false);
                    }
                    refresh();
                }
            }
        });

        MaterialDialog dialog = builder.build();
        dialog.show();
    }






    // TODO: 2017/2/20下载未完成的适配器
    public class NotDoneAdapter extends RecyclerView.Adapter<NotDoneAdapter.ApkHolder> {

        @Override
        public ApkHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_manage_download_ing, parent, false);
            return new ApkHolder(view);
        }

        @Override
        public void onBindViewHolder(ApkHolder holder, int position) {
            L.d("onBindViewHolder" + position);

            if (mNotDoneDownloadInfo != null && !mNotDoneDownloadInfo.isEmpty()){
            DownloadInfo downloadInfo = mNotDoneDownloadInfo.get(position);
            //holder更新持有对应的downloadinfo对象
            holder.bind(downloadInfo,mGameList.get(position));
            DownloadListener downloadListener = new MyDownloadListener();
            downloadListener.setUserTag(holder);
            downloadInfo.setListener(downloadListener);
            holder.refresh();
            }
        }

        @Override
        public int getItemCount() {
            return mNotDoneDownloadInfo.size();
        }

        public class ApkHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

            private View itemView;
            private DownloadInfo downloadInfo;
            private BGame gameModel;
            private ImageView icon;
            private TextView name;
            private TextView discount;
            private TextView speed;
            private TextView progressTv;
            private ImageView deleteBt;
            private SubmitProcessButton downloadBt;
            private ProgressBar progressBar;

            public ApkHolder(View view) {
                super(view);
                itemView = view.findViewById(R.id.rl_download_ing_parent);
                icon = (ImageView) view.findViewById(R.id.app_icon);
                name = (TextView) view.findViewById(R.id.tv_one);
                discount = (TextView) view.findViewById(R.id.tv_discount);
                speed = (TextView) view.findViewById(R.id.tv_two);
                progressTv = (TextView) view.findViewById(R.id.tv_three);
                deleteBt = (ImageView) view.findViewById(R.id.delete_bt);
                downloadBt = (SubmitProcessButton) view.findViewById(R.id.download_bt);
                progressBar = (ProgressBar) view.findViewById(R.id.progress_bar);

                int defaultAndError = ImageHelper.randomImage();
                icon.setImageResource(defaultAndError);
            }

            public void bind(DownloadInfo downloadInfo,BGame bGame) {
                this.downloadInfo = downloadInfo;

                        gameModel = bGame;
                        int defaultAndError = ImageHelper.randomImage();
                        Glide.with(App.mContext)
                                .load(gameModel.getIcon())
                                .error(defaultAndError)
                                .placeholder(defaultAndError)
                                .transform(new GlideRoundTransform(App.mContext, 10))
                                .into(icon);
                        name.setText(gameModel.getGameName());
                        if (gameModel == null || gameModel.getDiscount() == null || gameModel.getDiscount().equals("10")) {
                            discount.setVisibility(View.GONE);
                        } else {
                            discount.setVisibility(View.VISIBLE);
                            discount.setText(gameModel.getDiscount() + "折");
                        }
                        downloadBt.setOnClickListener(ApkHolder.this);
                        deleteBt.setOnClickListener(ApkHolder.this);
                        itemView.setOnClickListener(ApkHolder.this);


            }

            @Override
            public void onClick(View v) {
                if (v.getId() == R.id.download_bt) {
                    EB.postEmpty(EB.TAG.REQUEST_SD_CARD_DOWNLOAD_CENTER);
                    String text = downloadBt.getText().toString();
                    if (text.equals("暂停")) {
                        mDownloadManager.pauseTask(gameModel.getId());
                    }
                    if (text.equals("重试") || text.equals("继续")) {
                        if (DownloadHelper.checkCanDownload(mContext)) {
                            mDownloadManager.addTask(gameModel.getId(), downloadInfo.getRequest(), downloadInfo.getListener());
                        }
                    }
                    if (text.equals("等待")) {
                        ToastUtil.showToast(mContext, "已经加入下载队列");
                    }

                } else if (v.getId() == R.id.delete_bt) {
                    MaterialDialog.Builder builder = new MaterialDialog.Builder(_mActivity)
                            .content("您确认要删除该下载任务吗？")
                            .positiveText("是")
                            .negativeText("否")
                            .onPositive(new MaterialDialog.SingleButtonCallback() {
                                @Override
                                public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                    mDownloadManager.removeTask(gameModel.getId(), true);
                                    mNotDoneDownloadInfo.remove(getAdapterPosition());
                                    mGameList.remove(getAdapterPosition());
                                    notifyDataSetChanged();
                                }
                            });

                    MaterialDialog dialog = builder.build();
                    dialog.show();
                } else {
                    Intent intent = new Intent(_mActivity, AppDetailActivity.class);
                    intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_ID, gameModel.getId());
                    intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_PACKAGENAME, gameModel.getPackageName());
                    _mActivity.startActivity(intent);
                }
            }

            private void refresh() {
                String totalLength = Formatter.formatFileSize(_mActivity, downloadInfo.getTotalLength());
                String downloadLength = Formatter.formatFileSize(_mActivity, downloadInfo.getDownloadLength());
                String networkSpeed = Formatter.formatFileSize(_mActivity, downloadInfo.getNetworkSpeed());
                speed.setText(networkSpeed + "/s");
                progressTv.setText(downloadLength + "/" + totalLength);
                progressBar.setMax((int) downloadInfo.getTotalLength());
                progressBar.setProgress((int) downloadInfo.getDownloadLength());

                switch (downloadInfo.getState()) {
                    case DownloadManager.NONE:
                        downloadBt.setProgress("继续");
                        break;
                    case DownloadManager.DOWNLOADING:
                        downloadBt.setProgress("暂停");
                        break;
                    case DownloadManager.PAUSE://当前为暂停状态
                        downloadBt.setProgress("继续");
                        break;
                    case DownloadManager.WAITING://当前为等待状态
                        downloadBt.setProgress("等待");
                        break;
                    case DownloadManager.ERROR://当前为错误状态
                        downloadBt.setProgress("重试");
                        break;

                }
            }
        }

        private class MyDownloadListener extends DownloadListener {

            public MyDownloadListener() {
            }

            @Override
            public void onProgress(DownloadInfo downloadInfo) {
                //需要找到正确的位置刷新
                if (getUserTag() == null) {
                    return;
                }
                ApkHolder holder = (ApkHolder) getUserTag();
                holder.refresh();  //这里不能使用传递进来的 DownloadInfo，否者会出现条目错乱的问题
            }

            @Override
            public void onFinish(DownloadInfo downloadInfo) {
                //BGame game = (BGame) downloadInfo.getData();
                //ToastUtil.showToast(mContext, game.getGameName() + "已经下载完成");
                if (downloadInfo == null)
                    return;
                String taskKey = downloadInfo.getTaskKey();
                if (taskKey == null)
                    return;
                GGetGameDetail model = new GGetGameDetail(taskKey);
                TaskEngine.setTokenUseridPhoneState(1);
                TaskEngine.getInstance().doGetGameDetail(model, new JsonCallback<BGame>() {
                    @Override
                    public void onSuccess(BGame bGame, Call call, Response response) {
                        if (bGame != null && bGame.getGameName() != null)
                            ToastUtil.showToast(mContext, bGame.getGameName() + "已经下载完成");

                    }
                });
                DownloadHelper.addOneDownloadRecord(mContext, downloadInfo);//todo 向缓存的下载记录中加入一条游戏信息记录
                refresh();
            }

            @Override
            public void onError(DownloadInfo downloadInfo, String errorMsg, Exception e) {
                if (StringUtils.isEmpty(errorMsg)) {
                    errorMsg = "下载出错，请重试";
                }
                ToastUtil.showToast(mContext, errorMsg);
            }
        }

    }


}
