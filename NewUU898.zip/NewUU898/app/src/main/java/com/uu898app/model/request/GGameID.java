package com.uu898app.model.request;

import com.uu898app.model.GBaseModel;

/**
 * Created by zhangbo on 2016/6/20.
 */
public class GGameID extends GBaseModel {

    private int gameID;

    public GGameID() {
    }

    public GGameID(int id) {
        this.gameID = id;
    }

    public int getGameID() {
        return gameID;
    }

    public void setGameID(int gameID) {
        this.gameID = gameID;
    }
}
