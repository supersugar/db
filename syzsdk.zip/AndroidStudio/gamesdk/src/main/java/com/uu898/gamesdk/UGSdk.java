package com.uu898.gamesdk;

import com.uu898.gamesdk.core.UGSdkCore;

public class UGSdk {

    private static IUGSDK mIUGSDK = null;

    public UGSdk() {
    }

    public static IUGSDK getInstance() {
        if(mIUGSDK == null) {
            mIUGSDK = UGSdkCore.getInstance();
        }
        return mIUGSDK;
    }

}
