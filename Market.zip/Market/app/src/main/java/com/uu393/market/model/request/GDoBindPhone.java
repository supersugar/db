package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/18
 * Descrip    :
 * =====================================================
 */

public class GDoBindPhone {

    /**
     * phoneNo : 13256898745
     * checkCode : 258968
     */

    private String phoneNo;
    private String checkCode;

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getCheckCode() {
        return checkCode;
    }

    public void setCheckCode(String checkCode) {
        this.checkCode = checkCode;
    }
}
