package com.uu898.gamesdk.network;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import com.uu898.gamesdk.log.L;
import com.uu898.gamesdk.utils.StringUtils;
import com.uu898.gamesdk.utils.ToastUtil;
import com.uu898.gamesdk.view.BaseFragment;

import org.json.JSONException;
import org.json.JSONObject;
import org.xutils.common.Callback;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.URLDecoder;

/**
 * Created by bo on 16/9/19.
 */

public abstract class NetCallback<T> implements Callback.PrepareCallback<String, T> {

    private Class mTargetClass;
    private Type mTargetType;
    private BaseFragment mFragment;


    public NetCallback() {
    }

    public NetCallback(BaseFragment mFragment) {
        this.mFragment = mFragment;
    }

    /**
     * 设置Json转换类class
     *
     * @param targetClass
     */
    public void setTargetClass(Class targetClass) {
        this.mTargetClass = targetClass;
    }

    public void setTargetType(Type mTargetType) {
        this.mTargetType = mTargetType;
    }

    public abstract void _onNext(T t);

    public abstract void _onError(String msg);

    public void _onStart() {
        showLoading();
    }

    /**
     * 服务器返回结果->decode->
     *
     * @param s
     * @return
     */
    @Override
    public T prepare(String s) {
        if (StringUtils.isEmpty(s)) {
            L.e("未返回数据");
            _onError("未返回数据");
            return null;
        }
        try {
            s = URLDecoder.decode(s, "UTF-8");
            L.json(s);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            L.e(e.getMessage());
        }
        JSONObject jsonObject = null;
        String message = "";
        String status = "";
        try {
            jsonObject = new JSONObject(s);
            status = jsonObject.getString("Status");
            message = jsonObject.getString("Message");
            if (!status.equals("0")) {
                onError(new APIException(status, message), false);
                return null;
            }
            s = jsonObject.getString("Data");
        } catch (JSONException e) {
            e.printStackTrace();
            L.e(e.getMessage());
        }

        Gson gson = new Gson();
        if (null == mTargetClass && null == mTargetType) {//无需转化为model,且Status = 0
            return (T) message;
        }
        try {
            if (null != mTargetType) {
                return gson.fromJson(s, mTargetType);
            } else {
                return (T) gson.fromJson(s, mTargetClass);
            }
        } catch (JsonParseException e) {
            e.printStackTrace();
            L.e(e.getMessage());
        }
        return null;
    }

    @Override
    public void onSuccess(T result) {
        if (null != result) {
            _onNext(result);
        }
    }

    @Override
    public void onError(Throwable throwable, boolean b) {
        throwable.printStackTrace();
        L.e(throwable.getMessage());
        String error_msg = "";
        String apiCode = "";
        if (throwable instanceof APIException) {
            error_msg = throwable.getMessage();
            apiCode = ((APIException) throwable).getCode();
        } else if (throwable instanceof JSONException) {
            error_msg = "Json数据解析错误";
        } else if (throwable instanceof UnsupportedEncodingException) {
            error_msg = "UnsupportedEncodingException";
        } else if (throwable instanceof SocketTimeoutException) {
            error_msg = "请求数据超时,请稍后重试";
        } else if (throwable.getMessage().equals("Gateway Time-out")) {
            error_msg = "504网关超时,请稍后重试";
        } else if (throwable instanceof ConnectException) {
            error_msg = "网络中断,请检查您的网络状态";
        } else {
            error_msg = "未知错误 " + throwable.getMessage();
        }

        if (!StringUtils.isEmpty(apiCode)) {
            _onError(apiCode);
        } else {
            _onError(error_msg);
        }
        if (null != mFragment) {
            final String finalError_msg = error_msg;
            mFragment.getSupportActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ToastUtil.showToast(mFragment.getSupportActivity(), finalError_msg);
                }
            });
        }
    }

    @Override
    public void onCancelled(CancelledException e) {
        hideLoading();
    }

    @Override
    public void onFinished() {
        L.d("onFinished()");
        hideLoading();
    }

    private void showLoading() {
        if (mFragment != null) {
            mFragment.showLoadToast();
        }
    }

    private void hideLoading() {
        if (mFragment != null) {
            mFragment.hideLoadToast();
        }
    }


    public static class APIException extends Exception {
        public String code;
        public String message;

        public APIException(String code, String message) {
            this.code = code;
            this.message = message;
        }

        @Override
        public String getMessage() {
            return message;
        }

        public String getCode() {
            return code;
        }
    }
}
