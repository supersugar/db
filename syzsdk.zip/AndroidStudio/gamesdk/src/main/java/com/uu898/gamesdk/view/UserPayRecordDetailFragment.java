package com.uu898.gamesdk.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.uu898.gamesdk.core.ResourceUtils;
import com.uu898.gamesdk.model.request.GGetOrderDetail;
import com.uu898.gamesdk.model.response.BOrder;
import com.uu898.gamesdk.network.NetCallback;
import com.uu898.gamesdk.network.TaskEngine;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class UserPayRecordDetailFragment extends BaseFragment {

    private BOrder mOrderModel;

    private TextView mTvTitle;
    private TextView mTvTime;
    private TextView mTvPrice;//总价
    private TextView mTvStatus;
    private TextView mTvNo;
    private TextView mTvDesc;
    private TextView mTvPriceOne;//单价


    public static UserPayRecordDetailFragment newInstance(BOrder model) {
        Bundle args = new Bundle();
        args.putSerializable("model", model);
        UserPayRecordDetailFragment fragment = new UserPayRecordDetailFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        if (args != null) {
            mOrderModel = (BOrder) args.getSerializable("model");
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        View view = inflater.inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_pay_record_detail"), container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "充值记录");

        mTvTitle = (TextView) view.findViewById(getId("ug_order_item_title"));
        mTvTime = (TextView) view.findViewById(getId("ug_order_item_time"));
        mTvPrice = (TextView) view.findViewById(getId("ug_order_item_price"));
        mTvStatus = (TextView) view.findViewById(getId("ug_order_item_status"));
        mTvNo = (TextView) view.findViewById(getId("ug_order_item_no"));
        mTvDesc = (TextView) view.findViewById(getId("ug_order_item_desc"));
        mTvPriceOne = (TextView) view.findViewById(getId("ug_order_item_price_one"));

        doGetOrderDetail();
    }

    private void setContent() {
        mTvTitle.setText(mOrderModel.Title);
        mTvTime.setText(mOrderModel.AddTime);
        mTvPrice.setText(mOrderModel.TotalMoney + "元");
        mTvStatus.setText(mOrderModel.getStatusForShow());

        mTvNo.setText("订单编号 : " + mOrderModel.OrderNo);
        mTvDesc.setText("订单信息 : " + mOrderModel.Describe);
        mTvPriceOne.setText("单价 : " + mOrderModel.Price + " 元 ");
    }

    private void doGetOrderDetail() {
        GGetOrderDetail model = new GGetOrderDetail();
        model.setOrderNo(mOrderModel.OrderNo);
        TaskEngine.getInstance().doGetOrderDetail(model, new NetCallback<BOrder>(this) {
            @Override
            public void _onNext(BOrder result) {
                mOrderModel = result;
                setContent();
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }


}
