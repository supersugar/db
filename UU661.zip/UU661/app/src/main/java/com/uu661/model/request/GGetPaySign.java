package com.uu661.model.request;

public class GGetPaySign {

    public long timespan;//发起请求的时间戳
    public String jsonForSignature;//md5（json）
    public String payCode;//支付验证码，validType为0可以为空

}
