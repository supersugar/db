package com.uu661.model.response;

import java.io.Serializable;

/**
 * Created by bo on 16/9/14.
 */
public class BPaySetting implements Serializable {

    //1为app支付，0为网页支付
    public int userPayStatus;//游图片地址
}
