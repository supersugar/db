package com.uu393.market.module.mygame;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.ViewGroup;

import com.uu393.market.view.lazyviewpager.LazyFragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class MyGameViewPagerAdapter extends LazyFragmentPagerAdapter {
    private List<String> gameKinds = new ArrayList<>();

    public MyGamePlayedListFragment getPlayedFragment() {
        return playedFragment;
    }

    private MyGamePlayedListFragment playedFragment;
    public MyGameInstalledListFragment getInstalledFragment() {
        return installedFragment;
    }

    private MyGameInstalledListFragment installedFragment;

    public MyGameViewPagerAdapter(FragmentManager fm) {
        super(fm);
        gameKinds.add("已装");
        gameKinds.add("玩过");
        //gameKinds.add("回购");//todo 回购
    }

    @Override
    protected Fragment getItem(ViewGroup container, int position) {
        if (position == 0) {
            installedFragment = MyGameInstalledListFragment.newInstance();
            return installedFragment;
        }
        if (position == 1) {
            playedFragment = MyGamePlayedListFragment.newInstance();
            return playedFragment;
        }
        return null;
    }

    @Override
    public int getCount() {
        return gameKinds.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return gameKinds.get(position);
    }

}