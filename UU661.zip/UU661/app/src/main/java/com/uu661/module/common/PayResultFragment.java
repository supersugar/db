package com.uu661.module.common;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.widget.NestedScrollView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afollestad.materialdialogs.MaterialDialog;
import com.bumptech.glide.Glide;
import com.github.florent37.viewanimator.AnimationListener;
import com.github.florent37.viewanimator.ViewAnimator;
import com.lcodecore.tkrefreshlayout.RefreshListenerAdapter;
import com.lcodecore.tkrefreshlayout.TwinklingRefreshLayout;
import com.lzy.okgo.request.BaseRequest;
import com.ms.square.android.expandabletextview.ExpandableTextView;
import com.uu661.R;
import com.uu661.core.DialogCenter;
import com.uu661.model.request.GGetOrderDetail;
import com.uu661.model.response.BDiamond;
import com.uu661.model.response.BOrderDetail;
import com.uu661.module.MainActivity;
import com.uu661.module.base.BaseFragment;
import com.uu661.module.home.DiamondDetailFragment;
import com.uu661.module.my.MyOrderFragment;
import com.uu661.network.JsonCallback;
import com.uu661.network.TaskEngine;
import com.uu661.util.NoDoubleClickUtils;
import com.uu661.util.StringUtils;
import com.uu661.util.ToastUtil;
import com.uu661.util.log.L;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.iwgang.countdownview.CountdownView;
import okhttp3.Call;
import okhttp3.Response;


public class PayResultFragment extends BaseFragment {

    //多状态view
    @BindView(R.id.lv1_loading) LinearLayout mLv1Loading;
    @BindView(R.id.lv1_error) LinearLayout mLv1Error;
    @BindView(R.id.retry_button) TextView mRetryButton;

    @BindView(R.id.pay_result_nested_scroll_view) NestedScrollView mPayResultNestedScrollView;      //滚动NestedScrollView
    @BindView(R.id.pay_result_refresh_layout) TwinklingRefreshLayout mPayResultRefreshLayout;       //下拉刷新view
    @BindView(R.id.ptf_tip_tv) TextView mPtfTipTv;                                                  //下来刷新提示view

    //未买满,显示进度条
    @BindView(R.id.pay_result_view_can_buy) LinearLayout mPayResultViewCanBuy;                      //未买满view
    @BindView(R.id.pay_result_tv_name_wkj) TextView mPayResultNameWkj;                              //xx钻
    @BindView(R.id.status_tv_period_no) TextView mStatusTvPeriodNo;                                 //期号xxxx(未买满时期号)
    @BindView(R.id.status_progress_bar) ProgressBar mStatusProgressBar;                             //未买满时进度条
    @BindView(R.id.status_tv_total) TextView mStatusTvTotal;                                        //满2人次揭晓(未买满时总人数)
    @BindView(R.id.status_tv_left) TextView mStatusTvLeft;                                          //已参与1人未(未买满时已买人数)

    //已买满未开奖,显示倒计时
    @BindView(R.id.pay_result_view_count_down) LinearLayout mPayResultViewCountDown;                //倒计时view
    @BindView(R.id.pay_result_tv_name_djs) TextView mPayResultNameDjs;                              //xx钻
    @BindView(R.id.status_tv_count_down_djs) LinearLayout mStatusTvCountDownDjs;                    //倒计时...
    @BindView(R.id.status_tv_count_down_period_no) TextView mStatusTvCountDownPeriodNo;             //倒计时期号
    @BindView(R.id.status_count_down_view) CountdownView mStatusCountDownView;                      //倒计时时间
    @BindView(R.id.status_tv_count_down_jsz) TextView mStatusTvCountDownJsz;                        //倒计时计算中
    @BindView(R.id.status_bt_count_detail) Button mStatusBtCountDetail;                             //倒计时计算详情按钮

    //已开奖,中奖或未中奖
    @BindView(R.id.pay_result_view_opened) LinearLayout mPayResultViewOpened;                       //已开奖
    @BindView(R.id.pay_result_view_lucky) RelativeLayout mPayResultViewLucky;                       //幸运view
    @BindView(R.id.status_tv_lucky) TextView mStatusTvLucky;                                        //幸运title(中奖了)
    @BindView(R.id.status_tv_not_lucky) TextView mStatusTvNotLucky;                                 //非幸运title(没有中奖)
    @BindView(R.id.pay_result_diamond_img) ImageView mPayResultDiamondImg;                          //幸运钻石图标
    @BindView(R.id.pay_result_tv_diamond_num) TextView mPayResultTvDiamondNum;                      //钻石数量
    @BindView(R.id.pay_result_tv_who_lucky) TextView mPayResultTvWhoLucky;                          //中奖人
    @BindView(R.id.status_view_lucky_tv_lucky_no) TextView mStatusViewLuckyTvLuckyNo;               //幸运号码
    @BindView(R.id.status_bt_lucky_count_detail) Button mStatusBtLuckyCountDetail;                  //幸运view计算详情

    //失败界面
    @BindView(R.id.pay_result_view_failed) LinearLayout mPayResultViewFailed;                       //失败

    //未知界面
    @BindView(R.id.pay_result_bt_unknown_see) Button mPayResultBtUnknownSee;
    @BindView(R.id.pay_result_bt_unknown_call) TextView mPayResultBtUnknownCall;
    @BindView(R.id.pay_result_view_unknown) LinearLayout mPayResultViewUnknown;


    //两个按钮
    @BindView(R.id.pay_result_bt_layout) LinearLayout mPayResultBtLayout;                                 //按钮父view
    @BindView(R.id.pay_result_bt_blue) Button mPayResultBtBlue;                                     //查看参与记录
    @BindView(R.id.pay_result_bt_red) Button mPayResultBtRed;                                       //继续夺钻

    //下部view
    @BindView(R.id.pay_result_record_view) RelativeLayout mPayResultRecordView;
    @BindView(R.id.pay_result_my_tv_one) TextView mPayResultMyTvOne;                                //我成功参与....
    @BindView(R.id.pay_result_my_tv_two) TextView mPayResultMyTvTwo;                                //12U钻....
    @BindView(R.id.pay_result_my_tv_two_right) TextView mPayResultMyTvTwoRight;                     //1人次
    @BindView(R.id.pay_result_my_tv_three) TextView mPayResultMyTvThree;                            //商品期号...
    @BindView(R.id.pay_result_my_tv_four) TextView mPayResultMyTvFour;                              //我的夺钻码
    @BindView(R.id.pay_result_my_lucky_label) ImageView mPayResultMyLuckyLabel;                     //幸运图标,中奖显示,否则不显示
    @BindView(R.id.pay_result_my_expandable_tv) ExpandableTextView mPayResultMyExpandableTv;        //折叠

    @BindView(R.id.pay_result_i_am_lucky) RelativeLayout mPayResultIAmLucky;
    @BindView(R.id.pay_result_i_am_lucky_diamond) ImageView mPayResultIAmLuckyDiamond;
    @BindView(R.id.pay_result_i_am_lucky_close) ImageView mPayResultIAmLuckyClose;
    @BindView(R.id.pay_result_i_am_lucky_bg) ImageView mPayResultIAmLuckyBg;

    private BDiamond mDiamond;
    private String mOrderNo;

    private BOrderDetail mOrderDetail;

    private boolean isIAmLuckyViewShow = false;//中奖提示view是否显示中
    private boolean hasLuckyViewShowed = false;//中奖提示view是否已经弹出过

    private boolean isOnCreate = false;//

    public static PayResultFragment newInstance(BDiamond diamond, String orderNo) {
        PayResultFragment fragment = new PayResultFragment();
        Bundle args = new Bundle();
        args.putSerializable("diamond", diamond);
        args.putString("orderNo", orderNo);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mDiamond = (BDiamond) getArguments().getSerializable("diamond");
        mOrderNo = getArguments().getString("orderNo");
        View view = inflater.inflate(R.layout.pay_result_fragment, null);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        L.d("onViewCreated");
        initTitleBar(view, "支付结果", true);
        initRefreshLayout();
        showStatusView(0);
        isOnCreate = true;
        delayRequest(3000);
    }

    @Override
    public void onSupportVisible() {
        super.onSupportVisible();
        L.d("onSupportVisible");
        if(isOnCreate){
            return;
        }
        doGetOrderDetail(true);
    }

    /**
     * 展示状态view
     * 0  loading
     * 1  success
     * 2  error
     */
    private void showStatusView(int status) {
        if (null == mLv1Loading || null == mPayResultRefreshLayout || null == mLv1Error) {
            return;
        }
        switch (status) {
            case 0:
                mLv1Loading.setVisibility(View.VISIBLE);
                mPayResultRefreshLayout.setVisibility(View.GONE);
                mLv1Error.setVisibility(View.GONE);
                break;
            case 1:
                mLv1Loading.setVisibility(View.GONE);
                mPayResultRefreshLayout.setVisibility(View.VISIBLE);
                mLv1Error.setVisibility(View.GONE);
                break;
            case 2:
                mLv1Loading.setVisibility(View.GONE);
                mPayResultRefreshLayout.setVisibility(View.GONE);
                mLv1Error.setVisibility(View.VISIBLE);
                break;
        }
    }

    private void initRefreshLayout() {
        //以下代码是使用黑色转圈Loading
        //        ProgressLayout headerView = new ProgressLayout(_mActivity);
        //        mRefreshLayout.setHeaderView(headerView);
        mPayResultRefreshLayout.setEnableLoadmore(false);
        mPayResultRefreshLayout.setEnableOverScroll(false);//是否允许越界回弹

        mPayResultRefreshLayout.setOnRefreshListener(new RefreshListenerAdapter() {
            @Override
            public void onRefresh(final TwinklingRefreshLayout refreshLayout) {
                doGetOrderDetail(false);
            }
        });
    }

    private void doGetOrderDetail(boolean showLoading) {
        TaskEngine.getInstance().doGetOrderDetail(new GGetOrderDetail(mOrderNo), new JsonCallback<BOrderDetail>(showLoading ? this : null) {

            @Override
            public void onBefore(BaseRequest request) {
                super.onBefore(request);
                if(isOnCreate){
                    isOnCreate = false;
                }
            }

            @Override
            public void onSuccess(BOrderDetail result, Call call, Response response) {
                if (!isVisible()) {
                    return;
                }
                showStatusView(1);
                mOrderDetail = result;
                setContent();
                if (null != result.getCoupon() && !result.getCoupon().isEmpty()) {
                    DialogCenter.showOverBuyCouponPopDialog(_mActivity, result.getCoupon().get(0));
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                showStatusView(2);
            }

            @Override
            public void onAfter(BOrderDetail bOrderDetail, Exception e) {
                super.onAfter(bOrderDetail, e);
                if (!isVisible()) {
                    return;
                }
                mPayResultNestedScrollView.scrollTo(0, 0);
                //延迟200毫秒结束刷新效果,不然视觉看起来会卡顿
                mPayResultRefreshLayout.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (null != mPayResultRefreshLayout) {
                            mPayResultRefreshLayout.finishRefreshing();
                        }
                    }
                }, 200);
            }
        });
    }


    /**
     * periodStatus=1，orderStatus=1正在进行
     * periodStatus=2，orderStatus=1倒计时
     * periodStatus=3，orderStatus=1已开奖
     * periodStatus=3，orderStatus=1， isWin=1已开奖，已中奖
     * periodStatus=3，orderStatus=1， isWin=0已开奖，未中奖
     * orderStatus=4本期商品秒杀次数不足，支付的金额已退还至您的UU898账户，您可以再次尝试购买
     * <p>
     * orderStatus == 4 购买失败,不产生订单号,无夺钻码
     * orderStatus == 1 购买成功
     * orderStatus == 其他的 未知界面
     * periodStatus == 1  未买满
     * periodStatus == 2  倒计时 delay有值
     * periodStatus == 3  已开奖
     * isWin == 1 中奖
     * isWin == 0 未中奖
     */
    private void setContent() {
        if (mOrderDetail.getOrderStatus() == 4) {
            mPayResultViewFailed.setVisibility(View.VISIBLE);//失败页面可见
            mPayResultViewCanBuy.setVisibility(View.GONE);
            mPayResultViewCountDown.setVisibility(View.GONE);
            mPayResultViewOpened.setVisibility(View.GONE);
            mPayResultViewUnknown.setVisibility(View.GONE);//结果未知界面不可见
            mPayResultRecordView.setVisibility(View.GONE);//下面的购买记录不可见
            mPayResultRefreshLayout.setEnableRefresh(false);
            mPtfTipTv.setVisibility(View.GONE);
            //隐藏查看参与记录按钮,继续夺钻按钮居中
            mPayResultBtBlue.setVisibility(View.GONE);
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) mPayResultBtRed.getLayoutParams();
            lp.setMargins(0, 0, 0, 0);
            mPayResultBtRed.setLayoutParams(lp);
        } else if (mOrderDetail.getOrderStatus() == 1) {
            mPayResultViewFailed.setVisibility(View.GONE);//失败页面不可见
            mPayResultViewUnknown.setVisibility(View.GONE);//结果未知界面不可见
            mPayResultRecordView.setVisibility(View.VISIBLE);//购买记录view可见
            switch (mOrderDetail.getPeriodStatus()) {
                case 1://未买满
                    mPayResultViewCanBuy.setVisibility(View.VISIBLE);
                    mPayResultViewCountDown.setVisibility(View.GONE);
                    mPayResultViewOpened.setVisibility(View.GONE);
                    mPtfTipTv.setVisibility(View.VISIBLE);
                    mPayResultRefreshLayout.setEnableRefresh(true);
                    setCanBuyView();
                    break;
                case 2://已买满未开奖,显示倒计时
                    mPayResultViewCanBuy.setVisibility(View.GONE);
                    mPayResultViewCountDown.setVisibility(View.VISIBLE);
                    mPayResultViewOpened.setVisibility(View.GONE);
                    mPtfTipTv.setVisibility(View.VISIBLE);
                    mPayResultRefreshLayout.setEnableRefresh(true);
                    setCountDown();
                    break;
                case 3://已开奖
                    mPayResultViewCanBuy.setVisibility(View.GONE);
                    mPayResultViewCountDown.setVisibility(View.GONE);
                    mPayResultViewOpened.setVisibility(View.VISIBLE);
                    mPayResultRefreshLayout.setEnableRefresh(false);
                    mPtfTipTv.setVisibility(View.GONE);
                    setLuckyView();
                    break;
                default:
                    break;
            }
            setMyInfo();
        } else {
            mPayResultViewUnknown.setVisibility(View.VISIBLE);//结果未知界面可见
            mPayResultViewFailed.setVisibility(View.GONE);//失败页面可见
            mPayResultViewCanBuy.setVisibility(View.GONE);
            mPayResultViewCountDown.setVisibility(View.GONE);
            mPayResultViewOpened.setVisibility(View.GONE);
            mPayResultRecordView.setVisibility(View.GONE);//下面的购买记录不可见
            mPayResultBtBlue.setVisibility(View.GONE);
            mPayResultBtRed.setVisibility(View.GONE);
            mPayResultRefreshLayout.setEnableRefresh(false);
            mPtfTipTv.setVisibility(View.GONE);
        }
    }


    /**
     * 显示期号/进度条/总需人次/剩余人次
     */
    private void setCanBuyView() {
        mPayResultNameWkj.setText(mDiamond.getTitle());
        mStatusTvPeriodNo.setText("期号" + mOrderDetail.getPeriodNo());
        mStatusTvTotal.setText(Html.fromHtml("总需人次" + "<font color='#ff3b51'>" + mOrderDetail.getTotalCount() +
                "</font>"));
        mStatusTvLeft.setText(Html.fromHtml("剩余人次" + "<font color='#ff3b51'>" + mOrderDetail.getLeftCount() + "</font>"));
        mStatusProgressBar.setMax(mOrderDetail.getTotalCount());
        mStatusProgressBar.setProgress(mOrderDetail.getTotalCount() - mOrderDetail.getLeftCount());
    }


    /**
     * 显示倒计时
     */
    private void setCountDown() {
        mPayResultNameDjs.setText(mDiamond.getTitle());
        //根据倒计时的时间判断显示已揭晓还是未揭晓,未揭晓显示倒计时
        mStatusTvCountDownPeriodNo.setText("期号 : " + mOrderDetail.getPeriodNo());
        if (mOrderDetail.getDelay() > 0) {
            mStatusTvCountDownJsz.setVisibility(View.GONE);
            mStatusTvCountDownDjs.setVisibility(View.VISIBLE);
            long time = mOrderDetail.getDelay() * 1000;
            mStatusCountDownView.start(time);
            delayRequest(time);
        } else {
            mStatusTvCountDownJsz.setVisibility(View.VISIBLE);
            mStatusTvCountDownDjs.setVisibility(View.GONE);
            //正在结算结果中，请稍后...   需要3秒一刷新,直到揭晓结果
            delayRequest(3000);
        }
    }

    private void delayRequest(long time) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (null == mStatusTvCountDownJsz || null == mStatusTvCountDownDjs || null == mPayResultRefreshLayout) {
                    L.d("PayResultFragment结束掉了,不再请求订单详情");
                    return;//可能页面已经结束掉了
                }
                if (isVisible()) {
                    mStatusTvCountDownJsz.setVisibility(View.VISIBLE);
                    mStatusTvCountDownDjs.setVisibility(View.GONE);
                    mPayResultRefreshLayout.startRefresh();
                }
            }
        }, time);
    }

    /**
     * 设置幸运view
     *
     * @BindView(R.id.pay_result_view_lucky) RelativeLayout mPayResultViewLucky;                       //幸运view
     * @BindView(R.id.status_tv_lucky) TextView mStatusTvLucky;                                        //幸运title(中奖了)
     * @BindView(R.id.status_tv_not_lucky) TextView mStatusTvNotLucky;                                 //非幸运title(没有中奖)
     * @BindView(R.id.pay_result_diamond_img) ImageView mPayResultDiamondImg;                          //幸运钻石图标
     * @BindView(R.id.pay_result_tv_diamond_num) TextView mPayResultTvDiamondNum;                      //钻石数量
     * @BindView(R.id.pay_result_tv_who_lucky) TextView mPayResultTvWhoLucky;                          //中奖人
     * @BindView(R.id.status_view_lucky_tv_lucky_no) TextView mStatusViewLuckyTvLuckyNo;               //幸运号码
     * @BindView(R.id.status_bt_lucky_count_detail) Button mStatusBtLuckyCountDetail;                  //幸运view计算详情
     */
    private void setLuckyView() {
        if (mOrderDetail.getIsWin() == 1) {//中奖
            mStatusTvLucky.setVisibility(View.VISIBLE);
            mStatusTvNotLucky.setVisibility(View.GONE);
            mPayResultTvWhoLucky.setText(Html.fromHtml("<font color='#ff3b51'>" + mOrderDetail.getWinnerName() + "</font>获得了本期商品"));
            showIAmLuckyView();
        } else if (mOrderDetail.getIsWin() == 0) {//未中奖
            mStatusTvLucky.setVisibility(View.GONE);
            mStatusTvNotLucky.setVisibility(View.VISIBLE);
            //132****1123共购买了40人次\n获得了本期商品
            mPayResultTvWhoLucky.setText(Html.fromHtml("<font color='#ff3b51'>" + mOrderDetail.getWinnerName() + "</font>共购买了<font " +
                    "color='#ff3b51'>" +
                    mOrderDetail.getWinnerCodeCount() + "</font>人次<br/>获得了本期商品<br/><font color='#0fabff'>查看他的夺钻码</font>"));
            mPayResultTvWhoLucky.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    MaterialDialog dialog = new MaterialDialog.Builder(_mActivity).customView(R.layout.dialog_diamond_code_list, true)
                            .build();

                    ImageView close = (ImageView) dialog.getCustomView().findViewById(R.id.img_close);
                    ExpandableTextView expTv = (ExpandableTextView) dialog.getCustomView().findViewById(R.id.expand_tv);
                    TextView onlyOneTv = (TextView) dialog.getCustomView().findViewById(R.id.only_one_tv);

                    if (mOrderDetail.getWinnerCodeCount() == 1) {
                        expTv.setVisibility(View.GONE);
                        onlyOneTv.setVisibility(View.VISIBLE);
                        onlyOneTv.setText(mOrderDetail.getWinnerCodeList());
                    } else {
                        expTv.setVisibility(View.VISIBLE);
                        onlyOneTv.setVisibility(View.GONE);
                        String temp = mOrderDetail.getWinnerCodeList().replace(",", "   ");
                        expTv.setText(temp);
                    }

                    dialog.show();

                }
            });
        }
        Glide.with(_mActivity).load(mOrderDetail.getImageUrl()).into(mPayResultDiamondImg);
        mStatusViewLuckyTvLuckyNo.setText(String.valueOf(mOrderDetail.getWinCode()));
        //隐藏查看参与记录按钮,继续夺钻按钮拉长
        mPayResultBtBlue.setVisibility(View.GONE);
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) mPayResultBtRed.getLayoutParams();
        lp.setMargins(0, 0, 0, 0);
        mPayResultBtRed.setLayoutParams(lp);

    }

    /**
     * isWin == 1 中奖
     * isWin == 0 未中奖
     */
    private void setMyInfo() {
        //如果夺钻码长度为0,说明订单是错误的
        if (StringUtils.isEmpty(mOrderDetail.getMyCodeList())) {
            ToastUtil.showToast(_mActivity, "未获取到夺钻码");
            return;
        }
        mPayResultMyTvOne.setText("我成功参与1件商品，共 " + mOrderDetail.getMyCodeCount() + " 人次");
        mPayResultMyTvTwo.setText(mDiamond.getTitle());
        mPayResultMyTvTwoRight.setText(mOrderDetail.getMyCodeCount() + " 人次");
        mPayResultMyTvThree.setText("商品期号 : " + mOrderDetail.getPeriodNo());
        String temp = mOrderDetail.getMyCodeList().replace(",", "   ");
        mPayResultMyExpandableTv.setText(temp);

        if (mOrderDetail.getIsWin() == 1) {
            mPayResultMyLuckyLabel.setVisibility(View.VISIBLE);
            //            mPayResultMyTvOne.setBackgroundColor(getResources().getColor(R.color.red));
        } else {
            mPayResultMyLuckyLabel.setVisibility(View.GONE);
            //            mPayResultMyTvOne.setBackgroundColor(getResources().getColor(R.color.blue));
        }
    }

    @OnClick({R.id.pay_result_bt_blue, R.id.pay_result_bt_red, R.id.retry_button, R.id.status_bt_lucky_count_detail, R.id
            .status_bt_count_detail, R.id.pay_result_i_am_lucky_close, R.id.pay_result_i_am_lucky_bg, R.id.pay_result_bt_unknown_call, R
            .id.pay_result_bt_unknown_see})
    public void onClick(View view) {
        if (NoDoubleClickUtils.isDoubleClick()) {
            return;
        }
        switch (view.getId()) {
            case R.id.pay_result_bt_blue://进入当期详情页
                start(DiamondDetailFragment.newInstance(mOrderDetail.getCommodityId(), mOrderDetail.getPeriodNo()));
                break;
            case R.id.pay_result_bt_red://回到首页继续购买
                Intent intent = new Intent(_mActivity, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra(MainActivity.INTENT_KEY_CHECK_UPDATE, false);
                startActivity(intent);
                break;
            case R.id.retry_button://失败重试按钮
                doGetOrderDetail(true);
                break;
            case R.id.status_bt_lucky_count_detail://计算详情页面
            case R.id.status_bt_count_detail://计算详情页面
                start(CalculateFragment.newInstance(mOrderDetail.getCommodityId(), mOrderDetail.getPeriodNo()));
                break;
            case R.id.pay_result_i_am_lucky_close:
                hideIAmLuckyView(false);
                break;
            case R.id.pay_result_i_am_lucky_bg:
                hideIAmLuckyView(true);
                break;
            case R.id.pay_result_bt_unknown_see://支付结果未知,进入订单记录页面
                start(MyOrderFragment.newInstance());
                break;
            case R.id.pay_result_bt_unknown_call://支付结果未知,拨打电话
                Intent callIntent = new Intent(Intent.ACTION_DIAL);
                callIntent.setData(Uri.parse("tel:0371-56522898"));
                startActivity(callIntent);
                break;
        }
    }

    /**
     * 显示中奖提示蒙层view
     */
    private void showIAmLuckyView() {
        if (hasLuckyViewShowed == true) {
            return;
        }
        ViewAnimator.animate(mPayResultIAmLucky).alpha(0, 1).scale(0.2f, 1f).duration(200).onStart(new AnimationListener.Start() {
            @Override
            public void onStart() {
                mPayResultIAmLucky.setVisibility(View.VISIBLE);
                hasLuckyViewShowed = true;
                Glide.with(_mActivity).load(mOrderDetail.getImageUrl()).into(mPayResultIAmLuckyDiamond);
            }
        }).onStop(new AnimationListener.Stop() {
            @Override
            public void onStop() {
                isIAmLuckyViewShow = true;
            }
        }).start();
    }

    /**
     * 隐藏中奖提示蒙层view
     */
    private void hideIAmLuckyView(final boolean seeDetail) {
        ViewAnimator.animate(mPayResultIAmLucky).alpha(1, 0).scale(1f, 0.2f).duration(200).onStart(new AnimationListener.Start() {
            @Override
            public void onStart() {

            }
        }).onStop(new AnimationListener.Stop() {
            @Override
            public void onStop() {
                isIAmLuckyViewShow = false;
                mPayResultIAmLucky.setVisibility(View.GONE);
                if (seeDetail) {
                    start(DiamondDetailFragment.newInstance(mOrderDetail.getCommodityId(), mOrderDetail.getPeriodNo()));
                }
            }
        }).start();
    }

    @Override
    public boolean onBackPressedSupport() {

        if (isIAmLuckyViewShow) {
            hideIAmLuckyView(false);
            return true;
        }
        return super.onBackPressedSupport();
    }

}
