package com.uu898.gamesdk.model.response;

/**
 * Created by bo on 16/9/14.
 */
public class BLogin {

    public String SSID;
    public String userid;
    public String uid;
}
