package com.uu393.market.module.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GDoModifyPassword;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ContactCustomerServicesUtils;
import com.uu393.market.util.RsaHelper;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

public class ModifyPasswordActivity extends BaseActivity {


    @Bind(R.id.et_modify_pass_set_old_pass)
    EditText mEtModifyPassSetOldPass;
    @Bind(R.id.et_modify_pass_set_new_pass)
    EditText mEtModifyPassSetNewPass;
    @Bind(R.id.et_modify_pass_verify_new_pass)
    EditText mEtModifyPassVerifyNewPass;
    @Bind(R.id.btn_modify_pass_go)
    Button mBtnModifyPassGo;
    @Bind(R.id.tv_modify_pass_contact)
    TextView mTvModifyPassContact;
    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    private String mOldPass;
    private String mNewPass;
    private String mNewPassVerify;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_password);
        ButterKnife.bind(this);
        initTitleBar();
    }

    private void initTitleBar() {
        mTitleBarTitle.setText("修改密码");
        mTitleBarRight.setVisibility(View.GONE);
    }

    @OnClick({R.id.title_bar_left, R.id.btn_modify_pass_go, R.id.tv_modify_pass_contact})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                super.onBackPressedSupport();
                break;
            case R.id.btn_modify_pass_go:
                doModifyPass();
                break;
            case R.id.tv_modify_pass_contact:
                ContactCustomerServicesUtils.doXiaoNeng();
                break;
        }
    }

    private void doModifyPass() {
        mOldPass = mEtModifyPassSetOldPass.getText().toString().trim();
        mNewPass = mEtModifyPassSetNewPass.getText().toString().trim();
        mNewPassVerify = mEtModifyPassVerifyNewPass.getText().toString().trim();

        if (StringUtils.isEmpty(mOldPass)) {
            ToastUtil.showToast(App.mContext, "请输入旧密码");
            return;
        }
        if (StringUtils.isEmpty(mNewPass)) {
            ToastUtil.showToast(App.mContext, "请输入新密码");
            return;
        }
        if (!mNewPass.equals(mNewPassVerify)) {
            ToastUtil.showToast(App.mContext, "两次密码不一致");
            return;
        }
        GDoModifyPassword model = new GDoModifyPassword();
        model.setOldPassWord(RsaHelper.encryptDataFromStr(mOldPass, RsaHelper.RSA_PUBLIC_KEY));
        model.setNewPassWord(RsaHelper.encryptDataFromStr(mNewPassVerify, RsaHelper.RSA_PUBLIC_KEY));
        model.setDecipheringType("0");
        TaskEngine.setTokenUseridPhoneState(2);//修改密码token不能为 ""
        TaskEngine.getInstance().doModifyPassword(model, new JsonCallback<Object>() {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                SPUtil.put(App.mContext, "isLogin", false);
                SPUtil.put(App.mContext, "thirdUserId", "");
                SPUtil.put(App.mContext, "loginType", "");
                SPUtil.put(App.mContext, "token", "");
                SPUtil.put(App.mContext, "userId", "");
                SPUtil.put(App.mContext, "uId", "");
                SPUtil.put(App.mContext, "chkMobile", "");
                ToastUtil.showToast(App.mContext, "修改成功，请重新登录");
                startActivity(new Intent(ModifyPasswordActivity.this, LoginActivity.class));
                ModifyPasswordActivity.this.finish();
            }
        });
    }
}
