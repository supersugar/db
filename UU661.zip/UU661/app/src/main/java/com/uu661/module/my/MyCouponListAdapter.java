package com.uu661.module.my;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.uu661.R;
import com.uu661.model.response.BCoupon;
import com.uu661.util.CommonUtils;
import com.uu661.util.NoDoubleClickUtils;
import com.uu661.util.StringUtils;
import com.uu661.util.eventbus.EB;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by bo on 16/11/4.
 */

public class MyCouponListAdapter extends RecyclerView.Adapter<MyCouponListAdapter.MyHolder> {

    public static final int TYPE_SEE = 0;       //我的->我的红包 只是查看
    public static final int TYPE_CHOOSE = 1;    //收银台->选择红包 可以选择

    private Context mContext;
    private List<BCoupon> data = new ArrayList<>();
    private int type;
    private BCoupon mSelectedCoupon;

    public MyCouponListAdapter(Context context, int type) {
        this.mContext = context;
        this.type = type;
    }

    public void updateData(List<BCoupon> data) {
        updateData(data, null);
    }

    public void updateData(List<BCoupon> data, BCoupon selectedCoupon) {
        this.data = data;
        this.mSelectedCoupon = selectedCoupon;
        notifyDataSetChanged();
    }

    @Override
    public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_my_coupon, parent, false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(MyHolder holder, int position) {
        BCoupon model = data.get(position);
        holder.bindItem(model);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }


    public class MyHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        @BindView(R.id.item_parent) LinearLayout mItemParent;
        @BindView(R.id.item_img) ImageView mItemImg;
        @BindView(R.id.tv_coupon_price) TextView mTvCouponPrice;
        @BindView(R.id.item_tv1) TextView mItemTv1;
        @BindView(R.id.item_tv2) TextView mItemTv2;
        @BindView(R.id.item_tv3) TextView mItemTv3;
        @BindView(R.id.img_label) ImageView mImgLabel;
        @BindView(R.id.img_check) ImageView mImgCheck;

        private BCoupon mModel;

        public MyHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);//用butterKnife绑定
        }


        void bindItem(BCoupon model) {
            this.mModel = model;
            mItemTv1.setText(mModel.title);
            mItemTv2.setText("有效期 : " + mModel.validTime);
            mItemTv3.setText(mModel.remark);
            //（1可用，2过期，3已使用）
            switch (mModel.status) {
                case 1:
                    mImgLabel.setImageResource(R.drawable.ic_red_label_can);
                    mItemImg.setImageResource(R.drawable.ic_red_enable);
                    showPrice(true);
                    break;
                case 2:
                    mImgLabel.setImageResource(R.drawable.ic_red_label_dated);
                    mItemImg.setImageResource(R.drawable.ic_red_disable);
                    showPrice(false);
                    break;
                case 3:
                    mImgLabel.setImageResource(R.drawable.ic_red_label_used);
                    mItemImg.setImageResource(R.drawable.ic_red_disable);
                    showPrice(false);
                    break;
            }
            if (type == TYPE_SEE) {
                mImgCheck.setVisibility(View.GONE);
            } else {
                if (null != mSelectedCoupon && !StringUtils.isEmpty(mSelectedCoupon.id) && mSelectedCoupon.id.equals(mModel.id)) {
                    mImgCheck.setVisibility(View.VISIBLE);
                    mItemParent.setBackgroundResource(R.drawable.ic_shape_bt_blue_white);
                } else {
                    mImgCheck.setVisibility(View.GONE);
                    mItemParent.setBackgroundResource(R.drawable.ic_shape_bt_white);
                }
                mItemParent.setOnClickListener(this);
            }
        }

        private void showPrice(boolean canUse){
            String money = CommonUtils.fenToYuan(mModel.money);
            String voucherMoney = CommonUtils.fenToYuan(mModel.voucherMoney);
            if(money.endsWith(".00")){
                money = money.substring(0, money.lastIndexOf("."));
            }
            if(voucherMoney.endsWith(".00")){
                voucherMoney = voucherMoney.substring(0, voucherMoney.lastIndexOf("."));
            }
            mTvCouponPrice.setText(canUse ? money + "元": voucherMoney + "元");
        }

        @Override
        public void onClick(View v) {
            if (NoDoubleClickUtils.isDoubleClick()) {
                return;
            }
            EB.postObject(EB.TAG.CHOOSE_COUPON, mModel);
        }
    }

}
