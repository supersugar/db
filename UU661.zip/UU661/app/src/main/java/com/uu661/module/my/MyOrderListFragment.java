package com.uu661.module.my;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.lcodecore.tkrefreshlayout.RefreshListenerAdapter;
import com.lcodecore.tkrefreshlayout.TwinklingRefreshLayout;
import com.uu661.R;
import com.uu661.model.PageModel;
import com.uu661.model.request.GGetOrderList;
import com.uu661.model.response.BMyOrder;
import com.uu661.module.base.BaseViewPagerFragment;
import com.uu661.network.JsonCallback;
import com.uu661.network.TaskEngine;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import ezy.ui.layout.LoadingLayout;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 钻石列表界面
 */
public class MyOrderListFragment extends BaseViewPagerFragment {

    @BindView(R.id.order_recycler_view) RecyclerView mOrderRecyclerView;
    @BindView(R.id.order_refresh_layout) TwinklingRefreshLayout mOrderRefreshLayout;

    private int mType;//

    private MyOrderListAdapter mAdapter;
    private int mPageIndex = 1;
    private LoadingLayout mLoadingLayout;

    public static MyOrderListFragment newInstance(int type) {
        MyOrderListFragment fragment = new MyOrderListFragment();
        Bundle args = new Bundle();
        args.putInt("type", type);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mType = getArguments().getInt("type");
        View view = inflater.inflate(R.layout.my_order_list, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //        initLoadingLayout(view);
        initRecycleView();
        initRefreshLayout();
        doGetOrderList(false);
    }

    private void initLoadingLayout(View view) {
        mLoadingLayout = LoadingLayout.wrap(view);
        mLoadingLayout.showLoading();
        mLoadingLayout.setRetryListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doGetOrderList(false);
            }
        });
    }

    private void initRecycleView() {
        LinearLayoutManager manager = new LinearLayoutManager(_mActivity);
        mOrderRecyclerView.setLayoutManager(manager);
        mAdapter = new MyOrderListAdapter(_mActivity);
        mOrderRecyclerView.setAdapter(mAdapter);
    }

    private void initRefreshLayout() {
        //以下代码是使用黑色转圈Loading
        //        ProgressLayout headerView = new ProgressLayout(_mActivity);
        //        mRefreshLayout.setHeaderView(headerView);
        mOrderRefreshLayout.setEnableLoadmore(true);
        mOrderRefreshLayout.setEnableOverScroll(true);//是否允许越界回弹
        mOrderRefreshLayout.setAutoLoadMore(true);
        mOrderRefreshLayout.setOverScrollRefreshShow(false);

        mOrderRefreshLayout.setOnRefreshListener(new RefreshListenerAdapter() {
            @Override
            public void onRefresh(final TwinklingRefreshLayout refreshLayout) {
                doGetOrderList(false);
            }

            @Override
            public void onLoadMore(TwinklingRefreshLayout refreshLayout) {
                doGetOrderList(true);
            }
        });
    }

    private int mCurrentRecordIndex = 1;
    private int mRecordTotalPage = -1;
    private List<BMyOrder> mRecords = new ArrayList<>();

    private void resetRecordData() {
        mCurrentRecordIndex = 1;
        mRecordTotalPage = -1;
        mRecords.clear();
        mAdapter.updateData(mRecords);
        mOrderRefreshLayout.setAutoLoadMore(true);
        mOrderRefreshLayout.setEnableLoadmore(true);
    }

    private void doGetOrderList(final boolean loadMore) {
        if (loadMore == false) {//非加载更多
            resetRecordData();
        }
        PageModel model = new PageModel();
        model.pageIndex = mCurrentRecordIndex;
        model.pageSize = 10;
        TaskEngine.getInstance().doGetOrderList(new GGetOrderList(mType), model, new JsonCallback<List<BMyOrder>>(this) {
            @Override
            public void onSuccess(List<BMyOrder> result, Call call, Response response) {
                if(!isVisible()){
                    return;
                }
                if (null != result && !result.isEmpty()) {
                    mCurrentRecordIndex++;//成功且有数据,当前页码+1
                    mRecords.addAll(result);
                    mAdapter.updateData(mRecords);
                }
            }

            @Override
            public void onGetPage(PageModel page) {
                super.onGetPage(page);
                mRecordTotalPage = page.pageCount;
            }

            @Override
            public void onAfter(List<BMyOrder> bMyOrders, Exception e) {
                super.onAfter(bMyOrders, e);
                if(!isVisible()){
                    return;
                }
                if (loadMore) {
                    if (null != mOrderRefreshLayout) {
                        mOrderRefreshLayout.finishLoadmore();
                        if (mRecordTotalPage > 0 && mRecordTotalPage == mCurrentRecordIndex - 1) {
                            mOrderRefreshLayout.setAutoLoadMore(false);
                            mOrderRefreshLayout.setEnableLoadmore(false);
                        }
                    }
                } else {
                    //首次获取
                    if (mRecordTotalPage == 1) {
                        mOrderRefreshLayout.setAutoLoadMore(false);
                        mOrderRefreshLayout.setEnableLoadmore(false);
                    }
                    mOrderRefreshLayout.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (null != mOrderRefreshLayout) {
                                mOrderRefreshLayout.finishRefreshing();
                            }
                        }
                    }, 200);
                }
            }
        });
    }


    @Override
    public void refresh(boolean showLoading) {
        doGetOrderList(false);
    }


}
