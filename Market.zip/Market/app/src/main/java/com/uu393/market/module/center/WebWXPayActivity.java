package com.uu393.market.module.center;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.util.ToastUtil;

public class WebWXPayActivity extends BaseActivity {
    private WebView mWebView;
    private String signOrderNo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_wxpay);
        mWebView = (WebView) findViewById(R.id.wb_web_wx_pay);
        if (getIntent()!=null){
            signOrderNo = getIntent().getStringExtra("wx_pay_order");
        }
        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.setWebChromeClient(new WebChromeClient());
        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                showLoadToast(WebWXPayActivity.this);
            }

            @SuppressLint("DefaultLocale")
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                hideLoadToast();
                // 如下方案可在非微信内部WebView的H5页面中调出微信支付
                if (url.startsWith("weixin://wap/pay?")) {
                    try {
                        Intent intent = new Intent();
                        intent.setAction(Intent.ACTION_VIEW);
                        intent.setData(Uri.parse(url));
                        startActivity(intent);
                    } catch (ActivityNotFoundException e) {
                        e.printStackTrace();
                        ToastUtil.showToast(App.mContext, "请先安装微信");
                    }
                    return true;
                }else if(url.equals("http://ddd.cuowuwangzhi.com/")){//支付成功
                    Intent intent = new Intent();
                    intent.setClass(WebWXPayActivity.this,ChargeMoneyStateActivity.class);
                    WebWXPayActivity.this.startActivity(intent);
                    return true;
                }
                return super.shouldOverrideUrlLoading(view, url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                hideLoadToast();
                super.onPageFinished(view, url);
            }
        });
        mWebView.loadUrl(signOrderNo);
    }

    @Override
    public void onBackPressedSupport() {
        super.onBackPressedSupport();
    }
}
