package com.uu898app.adapter;

import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.uu898app.R;
import com.uu898app.model.response.BGame;
import com.uu898app.network.NetConstant;

import java.util.List;

/**
 *
 */
public class GameAdapter extends BaseMultiItemQuickAdapter<BGame> {

    public GameAdapter( List<BGame> data) {
        super(data);
        //R.layout.home_grid_item_big,
        addItemType(BGame.MULTI_TYPE_BIG, R.layout.home_grid_item_big);
        addItemType(BGame.MULTI_TYPE_SMALL, R.layout.home_grid_item_small);
    }

    @Override
    protected void convert(BaseViewHolder helper, BGame item) {
        switch (helper.getItemViewType()) {
            case BGame.MULTI_TYPE_BIG:
                helper.setText(R.id.tv_title, item.getName());
                Glide.with(mContext).load(NetConstant.URL.BASE_IMAGE_URL + item.getGameImage()).crossFade().into((ImageView) helper.getView(R.id.img));
                break;
            case BGame.MULTI_TYPE_SMALL:
                helper.setText(R.id.tv_title, item.getName());
                Glide.with(mContext).load(NetConstant.URL.BASE_IMAGE_URL + item.getGameImage()).crossFade().into((ImageView) helper.getView(R.id.img));
                break;
        }
    }


}
