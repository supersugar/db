package com.uu393.market.module.search;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.request.GetRequest;
import com.lzy.okserver.download.DownloadManager;
import com.lzy.okserver.download.DownloadService;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.DownloadHelper;
import com.uu393.market.model.request.GDoAddPlayedGame;
import com.uu393.market.model.response.BGame;
import com.uu393.market.module.h5game.H5GameDetailActivity;
import com.uu393.market.module.h5game.H5WebViewActivity;
import com.uu393.market.module.home.AppDetailActivity;
import com.uu393.market.module.login.LoginActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.GlideRoundTransform;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;
import com.uu393.market.view.progressbutton.SubmitProcessButton;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

import static com.uu393.market.Constant.UMENG_EVENT_ID_PLAY_H5;
import static com.uu393.market.app.App.mContext;

public class SuggestAdapter extends RecyclerView.Adapter<SuggestAdapter.ViewHolder> {
    private Activity activity;
    private List<BGame> data = new ArrayList<>();

    public SuggestAdapter(Activity activity) {
        this.activity = activity;
    }

    public void refreshAdapter(List<BGame> chipsEntities) {
        this.data = chipsEntities;
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_search_suggest, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        holder.bindItem(data.get(position));

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private BGame game;
        private View parentView;
        private ImageView icon;
        private TextView name;
        private SubmitProcessButton downloadBt;
        private DownloadManager mDownloadManager;

        ViewHolder(View itemView) {
            super(itemView);
            parentView = itemView.findViewById(R.id.parent_view);
            icon = (ImageView) itemView.findViewById(R.id.app_icon);
            name = (TextView) itemView.findViewById(R.id.name);
            downloadBt = (SubmitProcessButton) itemView.findViewById(R.id.download_bt);
            //取控件textView当前的布局参数
            RecyclerView.LayoutParams linearParams = (RecyclerView.LayoutParams) parentView.getLayoutParams();
            WindowManager wm = (WindowManager) App.mContext.getSystemService(Context.WINDOW_SERVICE);
            int width = wm.getDefaultDisplay().getWidth();

            final float scale = App.mContext.getResources().getDisplayMetrics().density;
            int twoSide = (int) (20 * scale + 0.5f);
            linearParams.width = (width - twoSide) / 4;// 控件的宽强制设成30

            parentView.setLayoutParams(linearParams); //使设置好的布局参数应用到控件
            this.mDownloadManager = DownloadService.getDownloadManager();
        }

        void bindItem(BGame gameModel) {
            if (gameModel != null) {
                this.game = gameModel;
                int defaultAndError = ImageHelper.randomImage();
                Glide.with(App.mContext).load(gameModel.getIcon())
                        .error(defaultAndError)
                        .placeholder(defaultAndError)
                        .transform(new GlideRoundTransform(App.mContext, 10))
                        .into(icon);
                name.setText(gameModel.getGameName());
                if (gameModel.getPlatForm() != null && !TextUtils.isEmpty(gameModel.getPlatForm())) {
                    if (gameModel.getPlatForm().equals("0")) {
                        downloadBt.setProgress("下载");
                        downloadBt.setTextColor(mContext.getResources().getColor(R.color.text_lv1));
                        downloadBt.setBackground(mContext.getResources().getDrawable(R.drawable.third_pb_normal));
                    } else if (gameModel.getPlatForm().equals("1")) {
                        downloadBt.setProgress("直接玩");
                        downloadBt.setTextColor(mContext.getResources().getColor(R.color.white));
                        downloadBt.setBackground(mContext.getResources().getDrawable(R.drawable.third_pb_progress_orange));
                    }
                }
                parentView.setOnClickListener(this);
                downloadBt.setOnClickListener(this);
            }

        }

        @Override
        public void onClick(View v) {
            if (game != null) {
                if (v.getId() == R.id.download_bt) {
                    if (game.getPlatForm() != null && !TextUtils.isEmpty(game.getPlatForm())) {
                        if (game.getPlatForm().equals("0")) {
                            Intent intent = new Intent();
                            intent.setClass(activity, AppDetailActivity.class);
                            intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_ID, game.getId());
                            activity.startActivity(intent);
                        } else if (game.getPlatForm().equals("1")) {
                            Intent intent = new Intent();
                            intent.putExtra("gameId", game.getId());
                            intent.setClass(activity, H5GameDetailActivity.class);
                            activity.startActivity(intent);
                        }
                    }
                } else {
                    if (game.getPlatForm() != null && !TextUtils.isEmpty(game.getPlatForm())) {
                        if (game.getPlatForm().equals("0")) {
                            Intent intent = new Intent();
                            intent.setClass(activity, AppDetailActivity.class);
                            intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_ID, game.getId());
                            activity.startActivity(intent);
                        } else if (game.getPlatForm().equals("1")) {
                            Intent intent = new Intent();
                            intent.putExtra("gameId", game.getId());
                            intent.setClass(activity, H5GameDetailActivity.class);
                            activity.startActivity(intent);
                        }
                    }
                }
            }
        }
    }

}
