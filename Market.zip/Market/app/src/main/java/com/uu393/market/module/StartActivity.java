package com.uu393.market.module;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GDoUploadComment;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.log.L;

import java.io.IOException;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import me.yokeyword.fragmentation.anim.DefaultHorizontalAnimator;
import me.yokeyword.fragmentation.anim.FragmentAnimator;
import okhttp3.Call;
import okhttp3.Response;
/**
 * 启动页
 * */
public class StartActivity extends BaseActivity {
    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what==99){
                //判断是否第一次登录
                if (App.getIsFirstAppLaunch()){//第一次跳转到折扣页
                    Intent intent = new Intent(StartActivity.this, ADSActivity.class);
                    startActivity(intent);
                }else {//不是第一次跳转到广告页
                    Intent intent = new Intent(StartActivity.this, AdvertisementActivity.class);
                    startActivity(intent);
                }
                StartActivity.this.finish();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        mHandler.sendEmptyMessageDelayed(99,2000);
        uploadComment();//上传comment信息
    }

    private void uploadComment() {
        if (App.getIsFirstAppLaunch()) {//第一次打开App

            final String comment = com.uu393.market.util.ApkUtils.readApk(this);

            if (comment!=null&&!StringUtils.isEmpty(comment)){
                GDoUploadComment model = new GDoUploadComment();
                model.setComment(comment);
                TaskEngine.setTokenUseridPhoneState(1);
                TaskEngine.getInstance().doUploadComment(model, new JsonCallback<Object>() {
                    @Override
                    public void onSuccess(Object o, Call call, Response response) {
                        L.d("上传comment成功：：comment=="+comment);
                    }

                    @Override
                    public void onError(Call call, Response response, Exception e) {
                        //super.onError(call, response, e);
                        L.d("上传comment失败   "+e.getMessage());
                    }
                });
            }

        }
    }


    @Override
    public void onBackPressedSupport() {
        // 对于 4个类别的主Fragment内的回退back逻辑,已经在其onBackPressedSupport里各自处理了
        super.onBackPressedSupport();
    }

    @Override
    public FragmentAnimator onCreateFragmentAnimator() {
        // 设置横向(和安卓4.x动画相同)
        return new DefaultHorizontalAnimator();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        App.setIsFirstAppLaunch(false);
    }



    public static String getChannel(Context context) {

        String channel="";
        final String start_flag = "META-INF/channel_";
        ApplicationInfo appinfo = context.getApplicationInfo();
        String sourceDir = appinfo.sourceDir;
        ZipFile zipfile = null;
        try {
            zipfile = new ZipFile(sourceDir);
            Enumeration<?> entries = zipfile.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = ((ZipEntry) entries.nextElement());
                String entryName = entry.getName();
                if (entryName.contains(start_flag)) {
                    channel = entryName.replace(start_flag, "");
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (zipfile != null) {
                try {
                    zipfile.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return channel;
    }
}
