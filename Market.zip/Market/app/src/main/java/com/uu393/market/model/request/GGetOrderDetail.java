package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/3
 * Descrip    : 获取订单详情
 * =====================================================
 */

public class GGetOrderDetail {
    /**
     * APPID : 123456
     * orderNo : 201609270001
     */

    private String APPID;
    private String orderNo;

    public String getAPPID() {
        return APPID;
    }

    public void setAPPID(String APPID) {
        this.APPID = APPID;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
}
