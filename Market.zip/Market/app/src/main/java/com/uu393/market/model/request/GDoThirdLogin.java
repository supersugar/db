package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/24
 * Descrip    :
 * =====================================================
 */

public class GDoThirdLogin {
    /**
     * openId : fdsfdsfdsfdsf （第三方用户唯一标示）,微信是unionID
     * token : retewdsfd（第三方登录token）
     * type : 0 （0QQ，1微博，2支付宝，3uu898，4微信）
     */

    private String openId;
    private String token;
    private String type;

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
