package com.uu661.model.request;

public class GGetVerifyCode {

    public static final int SMS = 0;
    public static final int PHONE = 1;

    public String userId;//
    public int isVoice;//短信 = 0  语音 = 1
    public String clientIP;//

}
