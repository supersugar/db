package com.uu898app.module.account;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.uu898app.R;
import com.uu898app.adapter.MyBuyRecordAdapter;
import com.uu898app.model.request.GPage;
import com.uu898app.model.response.BGame;
import com.uu898app.model.response.BOrderCommon;
import com.uu898app.module.base.BaseFragment;
import com.uu898app.module.helper.BuyHelper;
import com.uu898app.network.TaskEngine;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import rx.functions.Action1;

/**
 * 我的购买记录
 * Created by zhangbo on 2016/6/23.
 */
public class MyBuyRecordListFragment extends BaseFragment {


    @BindView(R.id.recycler_view)
    RecyclerView recyclerView;
    @BindView(R.id.refresh_layout)
    SwipeRefreshLayout refreshLayout;

    private MyBuyRecordAdapter mAdapter;

    public static MyBuyRecordListFragment newInstance() {
        Bundle args = new Bundle();
        MyBuyRecordListFragment fragment = new MyBuyRecordListFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.my_buy_record_list_layout, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        LinearLayoutManager manager = new LinearLayoutManager(_mActivity);
        recyclerView.setLayoutManager(manager);
        mAdapter = new MyBuyRecordAdapter(null);
        mAdapter.openLoadAnimation();
        recyclerView.setAdapter(mAdapter);
        recyclerView.addOnItemTouchListener(new OnItemClickListener( ){

            @Override
            public void SimpleOnItemClick(BaseQuickAdapter adapter, View view, int position) {
                start(LoginFragment.newInstance());
            }
        });
        getBuyCommonList();
    }

    private void getBuyCommonList(){
        TaskEngine.getInstance().getBuyCommonList(new GPage(1)).subscribe(new Action1<List<BOrderCommon>>() {
            @Override
            public void call(List<BOrderCommon> result) {
                mAdapter.setNewData(result);
            }
        });
    }

}
