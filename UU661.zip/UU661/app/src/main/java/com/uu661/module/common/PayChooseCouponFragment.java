package com.uu661.module.common;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.uu661.R;
import com.uu661.model.request.GGetCouponList;
import com.uu661.model.response.BCoupon;
import com.uu661.module.base.BaseFragment;
import com.uu661.module.my.MyCouponListAdapter;
import com.uu661.network.JsonCallback;
import com.uu661.network.TaskEngine;
import com.uu661.util.StringUtils;
import com.uu661.util.ToastUtil;
import com.uu661.util.eventbus.BaseEvent;
import com.uu661.util.eventbus.EB;
import com.uu661.util.eventbus.EventObject;
import com.uu661.util.log.L;

import org.greenrobot.eventbus.Subscribe;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 钻石列表界面
 */
public class PayChooseCouponFragment extends BaseFragment {

    @BindView(R.id.bt_ok) Button mBtOk;
    @BindView(R.id.tv_can_use_num) TextView mTvCanUseNum;
    @BindView(R.id.choose_red_recycler_view) RecyclerView mRecyclerView;
    @BindView(R.id.bt_not_use_red) Button mBtNotUseRed;

    private String mOrderNo;//
    private BCoupon mCurrentCoupon;//

    private MyCouponListAdapter mAdapter;

    public static PayChooseCouponFragment newInstance(String orderNo, BCoupon currentCoupon) {
        PayChooseCouponFragment fragment = new PayChooseCouponFragment();
        Bundle args = new Bundle();
        args.putString("orderNo", orderNo);
        args.putSerializable("currentCoupon", currentCoupon);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mOrderNo = getArguments().getString("orderNo");
        mCurrentCoupon = (BCoupon) getArguments().getSerializable("currentCoupon");
        View view = inflater.inflate(R.layout.pay_choose_red_fragment, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "选择红包", true);
        initRecycleView();
        doGetCouponList();
    }


    private void initRecycleView() {
        LinearLayoutManager manager = new LinearLayoutManager(_mActivity);
        mRecyclerView.setLayoutManager(manager);
        mAdapter = new MyCouponListAdapter(_mActivity, MyCouponListAdapter.TYPE_CHOOSE);
        mRecyclerView.setAdapter(mAdapter);
    }


    private void doGetCouponList() {
        GGetCouponList model = new GGetCouponList();
        model.isValid = 1;
        model.orderNo = mOrderNo;
        TaskEngine.getInstance().doGetCouponList(model, new JsonCallback<List<BCoupon>>(this) {
            @Override
            public void onSuccess(List<BCoupon> result, Call call, Response response) {
                if (null != result && !result.isEmpty()) {
                    L.d(result.size());
                    mAdapter.updateData(result, mCurrentCoupon);
                }
            }
        });
    }


    @OnClick({R.id.bt_ok, R.id.bt_not_use_red})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.bt_ok:
                if(null == mCurrentCoupon || StringUtils.isEmpty(mCurrentCoupon.id)){
                    ToastUtil.showToast(_mActivity, "请选择使用一个红包");
                }else{
                    setResult();
                }
                break;
            case R.id.bt_not_use_red:
                mCurrentCoupon = new BCoupon();
                setResult();
                break;
        }
    }

    // 设置传给上个Fragment的数据
    private void setResult(){
        Bundle bundle = new Bundle();
        bundle.putSerializable(PayFragment.BUNDLE_KEY_CHOOSE_COUPON, mCurrentCoupon);
        setFragmentResult(RESULT_OK, bundle);
        pop();
    }

    @Override
    public void onResume() {
        super.onResume();
        EB.register(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EB.unregister(this);
    }

    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.CHOOSE_COUPON://首页点击搜索框,切换底部tab到搜索页
                EventObject eventObject = (EventObject) event;
                final BCoupon model = (BCoupon) eventObject.result;
                mCurrentCoupon = model;
                mBtOk.performClick();
                break;
            default:
                break;
        }
    }
}
