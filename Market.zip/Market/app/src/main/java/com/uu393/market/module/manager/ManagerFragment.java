package com.uu393.market.module.manager;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.module.base.BaseFragment;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;

import org.greenrobot.eventbus.Subscribe;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class ManagerFragment extends BaseFragment {

    private ViewPager mViewPager;
    private TabLayout mTabLayout;

    private DownloadFragment mDownloadFragment;


    public static ManagerFragment newInstance() {
        Bundle args = new Bundle();
        ManagerFragment fragment = new ManagerFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.manage_fragment, container, false);
    }

    @Override

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "管理", false);
        mViewPager = (ViewPager) view.findViewById(R.id.viewpager);
        mTabLayout = (TabLayout) view.findViewById(R.id.tab_layout);

        mDownloadFragment = DownloadFragment.newInstance();

        mViewPager.setAdapter(new MyPagerAdapter(getChildFragmentManager()));
        mTabLayout.setupWithViewPager(mViewPager);
    }

    public class MyPagerAdapter extends FragmentPagerAdapter {

        String titles[] = new String[]{"下载管理", "安装包", "更新"};

        public MyPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            //            return TempTextFragment.newInstance(titles[position]);
            BaseFragment fragment = null;
            switch (position) {
                case 0:
                    return mDownloadFragment;
                case 1:
                    fragment = SDApkFragment.newInstance();
                    break;
                case 2:
                    fragment = TempTextFragment.newInstance(titles[position]);
                    break;
                default:
                    break;
            }
            return fragment;
        }


        @Override
        public int getCount() {
            return 3;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return titles[position];
        }
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        L.d("onHiddenChanged" + hidden);
        if (hidden == false) {//可见时
            mDownloadFragment.refresh();
        }
    }
    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.APP_INSTALL:
                mDownloadFragment.refresh();
                break;
            default:
                break;
        }
    }
    @Override
    public void onResume() {
        super.onResume();
        L.d("onResume");
        MobclickAgent.onPageStart("ManagerScreen");
        EB.register(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("ManagerScreen");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        L.d("onDestroy");
        EB.unregister(this);
    }


}
