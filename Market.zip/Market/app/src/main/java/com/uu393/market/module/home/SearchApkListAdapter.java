package com.uu393.market.module.home;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.request.GetRequest;
import com.lzy.okserver.download.DownloadInfo;
import com.lzy.okserver.download.DownloadManager;
import com.lzy.okserver.download.DownloadService;
import com.lzy.okserver.listener.DownloadListener;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.DownloadHelper;
import com.uu393.market.model.request.GDoAddPlayedGame;
import com.uu393.market.model.response.BGame;
import com.uu393.market.model.response.BGameSearch;
import com.uu393.market.model.response.BH5Game;
import com.uu393.market.module.h5game.H5GameDetailActivity;
import com.uu393.market.module.h5game.H5WebViewActivity;
import com.uu393.market.module.login.LoginActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ApkUtils;
import com.uu393.market.util.GlideRoundTransform;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;
import com.uu393.market.view.progressbutton.SubmitProcessButton;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

import static com.uu393.market.Constant.UMENG_EVENT_ID_DOWNLOAD;

/**
 * Created by bo on 16/11/4.
 */

public class SearchApkListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Activity mContext;
    private DownloadManager mDownloadManager;
    private List<BGameSearch> data = new ArrayList<>();

    public SearchApkListAdapter(Activity context) {
        this.mContext = context;
        this.mDownloadManager = DownloadService.getDownloadManager();
    }

    public void updateData(List<BGameSearch> data) {
        this.data = data;
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        if (data.get(position).getPlatForm().equals("0")) {
            return 0;
        } else if (data.get(position).getPlatForm().equals("1")) {
            return 1;
        }
        return super.getItemViewType(position);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View viewApp = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_home_app, parent, false);
        View viewH5 = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_h5game_recyclerview, parent, false);
        if (viewType == 0) {
            return new ApkHolder(viewApp);
        } else {
            return new H5ApkHolder(viewH5);
        }

    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof ApkHolder) {
            ((ApkHolder) holder).bind(data.get(position));
        } else if (holder instanceof H5ApkHolder) {
            ((H5ApkHolder) holder).bindItem(data.get(position));
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ApkHolder extends RecyclerView.ViewHolder implements View.OnClickListener {


        private DownloadInfo downloadInfo;
        private BGameSearch gameModel;
        private ImageView icon;
        private TextView name;
        private TextView discount;
        private TextView typeAndSize;
        private TextView describe;
        private TextView isbt;
        private SubmitProcessButton downloadBt;

        public ApkHolder(View view) {
            super(view);
            icon = (ImageView) view.findViewById(R.id.app_icon);
            name = (TextView) view.findViewById(R.id.tv_one);
            discount = (TextView) view.findViewById(R.id.tv_discount);
            typeAndSize = (TextView) view.findViewById(R.id.tv_two);
            describe = (TextView) view.findViewById(R.id.tv_three);
            isbt = (TextView) view.findViewById(R.id.tv_bt);
            downloadBt = (SubmitProcessButton) view.findViewById(R.id.download_bt);
        }

        public void bind(BGameSearch gameModel) {
            this.gameModel = gameModel;
            //更新持有的downloadInfo对象
            downloadInfo = mDownloadManager.getDownloadInfo(gameModel.getId());
            if (null != downloadInfo) {
                DownloadListener downloadListener = new MyDownloadListener();
                downloadListener.setUserTag(this);
                downloadInfo.setListener(downloadListener);
            } else {
                return;
            }
            //固定不变的在这里设置
            int defaultAndError = ImageHelper.randomImage();
            Glide.with(App.mContext).load(gameModel.getIcon()).error(defaultAndError).placeholder(defaultAndError).transform(new
                    GlideRoundTransform(App.mContext, 10)).into(icon);
            name.setText(gameModel.getGameName());
            if (gameModel.getDiscount().equals("10")) {
                discount.setVisibility(View.GONE);
            } else {
                discount.setVisibility(View.VISIBLE);
                discount.setText(gameModel.getDiscount() + "折");
            }
            if (!gameModel.getTypeName().equals("BT游戏")) {
                isbt.setVisibility(View.GONE);
            } else {
                isbt.setVisibility(View.VISIBLE);
            }
            typeAndSize.setText(gameModel.getTypeName() + " / " + gameModel.getSize());
            describe.setText(gameModel.getDescribe());
            downloadBt.setOnClickListener(this);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            //需要转换为BGame对象，不然下载中心会崩溃
            BGame game = new BGame();
            if (gameModel == null) return;
            game.setId(gameModel.getId());
            game.setGameName(gameModel.getGameName());
            game.setTypeName(gameModel.getTypeName());
            game.setAndroidPackage(gameModel.getAndroidPackage());
            game.setPackageName(gameModel.getPackageName());
            game.setIcon(gameModel.getIcon());
            game.setDiscount(gameModel.getDiscount());
            game.setDescribe(gameModel.getDescribe());
            game.setSize(gameModel.getSize());

            if (v.getId() == R.id.download_bt) {
                EB.postEmpty(EB.TAG.REQUEST_SD_CARD_SEARCH);
                String text = downloadBt.getText().toString();
                if (text.equals("打开")) {
                    EB.postObject(EB.TAG.CLICK_PLAY, game);
                    ApkUtils.launchApp(mContext, game.getPackageName());
                }
                if (text.equals("安装")) {
                    //先判断安装文件是否存在
                    if (downloadInfo == null) {
                        return;
                    }
                    File temp = new File(downloadInfo.getTargetPath());
                    if (temp.exists()) {
                        ApkUtils.install(mContext, temp);
                        EB.postObject(EB.TAG.CLICK_INSATLL, game);
                    } else {
                        mDownloadManager.removeTask(game.getId(), true);
                        ToastUtil.showToast(mContext, "安装包可能被删除了，请重新下载");
                        notifyDataSetChanged();
                    }
                }
                if (text.equals("下载")) {
                    EB.postEmpty(EB.TAG.REQUEST_SD_CARD);
                    MobclickAgent.onEvent(mContext, UMENG_EVENT_ID_DOWNLOAD);//友盟统计下载事件
                    //一旦触发下载动作(下载/更新/重试/继续),都要综合判断当前手机情况及设置是否允许下载
                    if (DownloadHelper.checkCanDownload(mContext)) {
                        String url = game.getAndroidPackage();
                        if (StringUtils.isEmpty(url)) {
                            ToastUtil.showToast(mContext, "下载链接错误 " + url);
                            return;
                        }
                        GetRequest request = OkGo.get(game.getAndroidPackage());
                        mDownloadManager.addTask(game.getId(), game, request, null);
                        notifyDataSetChanged();
                    }
                }
                if (text.equals("重试")) {
                    if (DownloadHelper.checkCanDownload(mContext)) {
                        mDownloadManager.addTask(game.getId(), downloadInfo.getRequest(), downloadInfo.getListener());
                    }
                }
                if (text.equals("等待")) {
                    ToastUtil.showToast(mContext, "已经加入下载队列");
                }
            } else {
                Intent intent = new Intent(mContext, AppDetailActivity.class);
                intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_ID, game.getId());
                mContext.startActivity(intent);
            }
        }

        private void refresh() {
            //先根据包名判断游戏是否安装
            if (ApkUtils.hasInstalled(mContext, gameModel.getPackageName())) {
                //已安装的,有可能正在升级
                if (null != downloadInfo && downloadInfo.getState() == DownloadManager.DOWNLOADING) {
                    int progress = Math.round(downloadInfo.getProgress() * 10000) * 1 / 100;
                    downloadBt.setProgress(progress, progress + "%");
                    return;
                }
                //已经安装的,需要判断是否需要升级
                if (ApkUtils.whetherUpdate(mContext, gameModel.getPackageName(), gameModel.getVersionCode())) {
                    downloadBt.setProgress("更新");
                } else {
                    downloadBt.setProgress("打开");
                }
                return;
            }

            if (null == downloadInfo) {
                downloadBt.setProgress("下载");
                return;
            }
            switch (downloadInfo.getState()) {
                case DownloadManager.NONE:
                    downloadBt.setProgress("下载");
                    break;
                case DownloadManager.DOWNLOADING:
                    double progress = Math.round(downloadInfo.getProgress() * 10000) * 1 / 100.00;
                    downloadBt.setProgress(progress, progress + "%");
                    break;
                case DownloadManager.PAUSE://当前为暂停状态
                    downloadBt.setProgress(Math.round(downloadInfo.getProgress() * 10000) * 1 / 100.00, "暂停中");
                    break;
                case DownloadManager.WAITING://当前为等待状态
                    downloadBt.setProgress("等待");
                    break;
                case DownloadManager.ERROR://当前为错误状态
                    downloadBt.setProgress("重试");
                    break;
                case DownloadManager.FINISH://当前为完成状态
                    if (ApkUtils.hasInstalled(mContext, new File(downloadInfo.getTargetPath()))) {
                        downloadBt.setProgress("打开");
                    } else {
                        downloadBt.setProgress("安装");
                    }
                    break;
            }
        }
    }

    public class H5ApkHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private BGameSearch game;
        private ImageView icon;
        private TextView name;
        private TextView discount;
        private TextView typeAndSize;
        private TextView describe;
        private TextView play;
        private View parent;

        public H5ApkHolder(View itemView) {
            super(itemView);
            parent = itemView.findViewById(R.id.rl_parent);
            icon = (ImageView) itemView.findViewById(R.id.h5_app_icon);
            name = (TextView) itemView.findViewById(R.id.h5_tv_one);
            discount = (TextView) itemView.findViewById(R.id.h5_tv_discount);
            typeAndSize = (TextView) itemView.findViewById(R.id.h5_tv_two);
            describe = (TextView) itemView.findViewById(R.id.h5_tv_three);
            play = (TextView) itemView.findViewById(R.id.tv_play);
        }

        public void bindItem(BGameSearch gameModel) {
            this.game = gameModel;
            int defaultAndError = ImageHelper.randomImage();
            Glide.with(App.mContext)
                    .load(game.getIcon())
                    .error(defaultAndError)
                    .placeholder(defaultAndError)
                    .transform(new GlideRoundTransform(mContext, 10))
                    .into(icon);

            name.setText(game.getGameName());
            typeAndSize.setText(game.getTypeName());
            describe.setText(game.getDescribe());
            play.setOnClickListener(this);
            parent.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int id = v.getId();
            Intent intent = new Intent();
            if (id == R.id.tv_play) {
                if ((boolean) SPUtil.get(App.mContext, "isLogin", false)) {
                    intent.putExtra("gameId", game.getId());
                    intent.putExtra("APPID", game.getAPPID());
                    intent.putExtra("url", game.getAndroidPackage());
                    intent.setClass(mContext, H5WebViewActivity.class);
                    mContext.startActivity(intent);
                } else {
                    intent.setClass(mContext, LoginActivity.class);
                    mContext.startActivity(intent);
                }
            } else {// TODO: 2017/2/14 详情页
                intent.putExtra("gameId", game.getId());
                intent.setClass(mContext, H5GameDetailActivity.class);
                mContext.startActivity(intent);
            }
        }
    }

    private class MyDownloadListener extends DownloadListener {

        public MyDownloadListener() {
        }

        @Override
        public void onProgress(DownloadInfo downloadInfo) {
            //需要找到正确的位置刷新
            if (getUserTag() == null) {
                return;
            }
            ApkHolder holder = (ApkHolder) getUserTag();
            holder.refresh();  //这里不能使用传递进来的 DownloadInfo，否者会出现条目错乱的问题

        }

        @Override
        public void onFinish(DownloadInfo downloadInfo) {
            if (downloadInfo != null) {
                BGame game = (BGame) downloadInfo.getData();
                ToastUtil.showToast(mContext, game.getGameName() + "已经下载完成");
                DownloadHelper.addOneDownloadRecord(mContext, downloadInfo);//todo 向缓存的下载记录中加入一条游戏信息记录
            }

        }

        @Override
        public void onError(DownloadInfo downloadInfo, String errorMsg, Exception e) {
            if (StringUtils.isEmpty(errorMsg)) {
                errorMsg = "下载出错，请重试";
            }
            ToastUtil.showToast(mContext, errorMsg);
        }
    }
}
