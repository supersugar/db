package com.uu393.market.util;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.uu393.market.app.App;

import java.util.ArrayList;
import java.util.List;

/**
 * Desction:
 * Author:pengjianbo
 * Date:15/10/22 下午3:39
 */
public class CommonUtils {

    private CacheUtil cacheUtil = CacheUtil.get(App.mContext);

    /**
     * 获取所有搜索结果
     *
     * @return
     */
    public static List<String> getSearchList() {
        List<String> list = new ArrayList<String>();
        String userNameList = CacheUtil.get(App.mContext).getAsString("search_list");
        if (StringUtils.isEmpty(userNameList)) {
        } else {
            String[] userList = userNameList.split(",");
            if (userList == null || userList.length == 0) {
            } else {
                for (String username : userList) {
                    list.add(username);
                }
            }
        }
        return list;
    }

    /**
     * 清空搜索结果
     */
    public static void clearSearchList() {
        CacheUtil.get(App.mContext).put("search_list", "");
    }

    /**
     * 更新搜索结果
     */
    public static void updateSearchList(String searchKey) {
        int maxSize = 11;
        String currentList = CacheUtil.get(App.mContext).getAsString("search_list");
        List<String> tempList = new ArrayList<String>();
        if (StringUtils.isEmpty(currentList)) {
            tempList.add(searchKey);
        } else {
            String[] userList = currentList.split(",");
            if (userList == null || userList.length == 0) {
                tempList.add(searchKey);
            } else {
                tempList.add(0, searchKey);
                int temp = 1;
                for (String username : userList) {
                    if (!TextUtils.equals(username, searchKey) && temp < maxSize) {
                        tempList.add(username);
                        temp++;
                    }
                }
            }
        }

        StringBuilder result = new StringBuilder();
        for (String name : tempList) {
            result.append(name);
            result.append(",");
        }

        result.delete(result.length() - 1, result.length());
        CacheUtil.get(App.mContext).put("search_list", result.toString());
    }

    /**
     * 获取设备唯一id
     *
     * @return
     */
    public static String getDeviceId() {
        String deviceId = "";
        try {
            WifiManager wm = (WifiManager) App.mContext.getSystemService(App.mContext.WIFI_SERVICE);
            deviceId = Settings.Secure.getString(App.mContext.getContentResolver(), Settings.Secure.ANDROID_ID);
            if (deviceId == null) {
                deviceId = wm.getConnectionInfo().getMacAddress();
                if (deviceId != null)
                    deviceId = deviceId.replaceAll(":", "");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return deviceId;
    }


    /**
     * 获取IMEI
     */
    public static String getIMEI(Context context) {
        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        String imei = tm.getDeviceId();
        if (StringUtils.isEmpty(imei)) {
            imei = "";
        }

        return imei;
    }

    public static String getNetType(Context context) {
        String netType = null;
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (connectivityManager == null) {
                netType = "";
            }

            NetworkInfo info = connectivityManager.getActiveNetworkInfo();
            if (info == null) {
                netType = "";
            }

            String type = info.getTypeName();

            if (type.equalsIgnoreCase("WIFI")) {
                // WIFI
                netType = "wifi";
            } else if (type.equalsIgnoreCase("MOBILE")) {
                // GPRS
                String proxyHost = android.net.Proxy.getDefaultHost();
                if (proxyHost != null && !proxyHost.equals("")) {
                    // WAP
                    netType = "wap";
                } else {
                    netType = "net";
                }
            }
        } catch (Exception ex) {
        }
        if (netType == null || netType.length() == 0) {
            netType = "unknown";
        }
        return netType;
    }


    /**
     * 获取版本名称
     *
     * @param context 上下文
     * @return 版本名称
     */
    public static String getVersionName(Context context) {
        //获取包管理器
        PackageManager pm = context.getPackageManager();
        //获取包信息
        try {
            PackageInfo packageInfo = pm.getPackageInfo(context.getPackageName(), 0);
            //返回版本号
            return packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取版本号
     *
     * @param context 上下文
     * @return 版本号
     */
    public static int getVersionCode(Context context) {
        //获取包管理器
        PackageManager pm = context.getPackageManager();
        //获取包信息
        try {
            PackageInfo packageInfo = pm.getPackageInfo(context.getPackageName(), 0);
            //返回版本号
            return packageInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * 获取App的名称
     *
     * @param context 上下文
     * @return 名称
     */
    public static String getAppName(Context context) {
        PackageManager pm = context.getPackageManager();
        //获取包信息
        try {
            PackageInfo packageInfo = pm.getPackageInfo(context.getPackageName(), 0);
            //获取应用 信息
            ApplicationInfo applicationInfo = packageInfo.applicationInfo;
            //获取albelRes
            int labelRes = applicationInfo.labelRes;
            //返回App的名称
            return context.getResources().getString(labelRes);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }
    /**
     * 判断微信是否安装
     * @param context
     * @return
     */
    public static boolean isWeixinInstall(Context context) {
        final PackageManager packageManager = context.getPackageManager();// 获取packagemanager
        List<PackageInfo> pinfo = packageManager.getInstalledPackages(0);// 获取所有已安装程序的包信息
        if (pinfo != null) {
            for (int i = 0; i < pinfo.size(); i++) {
                String pn = pinfo.get(i).packageName;
                if (pn.equals("com.tencent.mm")) {
                    return true;
                }
            }
        }

        return false;
    }
}
