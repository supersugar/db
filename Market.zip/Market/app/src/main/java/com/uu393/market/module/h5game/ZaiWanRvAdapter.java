package com.uu393.market.module.h5game;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.DevConfig;
import com.uu393.market.model.request.GDoAddPlayedGame;
import com.uu393.market.model.response.BGame;
import com.uu393.market.model.response.BH5ZaiWan;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.GlideRoundTransform;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.log.L;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

import static com.uu393.market.Constant.UMENG_EVENT_ID_DOWNLOAD;
import static com.uu393.market.Constant.UMENG_EVENT_ID_PLAY_H5;
import static com.uu393.market.R.id.ll_h5game_zaiwan_parent_view;
import static com.uu393.market.app.App.mContext;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/18
 * Descrip    : H5游戏中心在玩的RecyclerView的适配器
 * =====================================================
 */

public class ZaiWanRvAdapter extends RecyclerView.Adapter<ZaiWanRvAdapter.ZaiWanViewHolder> {
    private Activity activity;
    private List<BH5ZaiWan> data = new ArrayList<>();

    public ZaiWanRvAdapter(Activity activity) {
        this.activity = activity;
    }

    public void refresh(List<BH5ZaiWan> chipsEntities) {
        this.data = chipsEntities;
        notifyDataSetChanged();
    }

    @Override
    public ZaiWanViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_h5game_zaiwan, parent, false);
        return new ZaiWanViewHolder(inflate);
    }

    @Override
    public void onBindViewHolder(ZaiWanViewHolder holder, final int position) {
        try {
            if (data.get(position) != null) {
                holder.bindItem(data.get(position));
                //点击直接玩
                holder.play.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        HashMap<String, String> map = new HashMap<>();
                        map.put("H5GameName", data.get(position).getGameName());
                        MobclickAgent.onEvent(activity, UMENG_EVENT_ID_PLAY_H5, map);//友盟统计下载事件


                        Intent intent = new Intent();
                        intent.putExtra("gameId", data.get(position).getId());
                        intent.putExtra("APPID", data.get(position).getAPPID());
                        intent.putExtra("url", data.get(position).getAndroidPackage());
                        intent.setClass(activity, H5WebViewActivity.class);
                        activity.startActivity(intent);
                    }
                });
                holder.appIcon.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent();
                        intent.putExtra("gameId", data.get(position).getId());
                        intent.setClass(activity, H5GameDetailActivity.class);
                        activity.startActivity(intent);
                    }
                });
            }

        } catch (Exception e) {
            if (e instanceof IndexOutOfBoundsException){
                e.printStackTrace();
            }
        }


    }

    @Override
    public int getItemCount() {
        return data.size() >= 4 ? 4 : data.size();
    }


    class ZaiWanViewHolder extends RecyclerView.ViewHolder {
        private View parentView;
        private ImageView appIcon;
        private TextView appName;
        private Button play;

        public ZaiWanViewHolder(View itemView) {
            super(itemView);
            parentView = itemView.findViewById(ll_h5game_zaiwan_parent_view);
            appIcon = (ImageView) itemView.findViewById(R.id.iv_h5game_zaiwan_app_icon);
            appName = (TextView) itemView.findViewById(R.id.tv_h5game_zaiwan_app_name);
            play = (Button) itemView.findViewById(R.id.btn_h5game_zaiwan_play);

            //取控件textView当前的布局参数
            RecyclerView.LayoutParams linearParams = (RecyclerView.LayoutParams) parentView.getLayoutParams();
            WindowManager wm = (WindowManager) App.mContext.getSystemService(Context.WINDOW_SERVICE);
            int width = wm.getDefaultDisplay().getWidth();//屏幕宽度

            final float scale = App.mContext.getResources().getDisplayMetrics().density;
            int twoSide = (int) (20 * scale + 0.5f);
            linearParams.width = (width - twoSide) / 4;// 控件的宽强制设成4分之一
            parentView.setLayoutParams(linearParams); //使设置好的布局参数应用到控件

        }

        void bindItem(BH5ZaiWan gameModel) {
            int defaultAndError = ImageHelper.randomImage();
            Glide.with(App.mContext).load(gameModel.getIcon())
                    .error(defaultAndError)
                    .placeholder(defaultAndError)
                    .transform(new GlideRoundTransform(App.mContext, 10))
                    .into(appIcon);
            appName.setText(gameModel.getGameName());
        }
    }
}
