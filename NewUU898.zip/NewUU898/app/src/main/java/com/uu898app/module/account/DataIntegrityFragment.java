package com.uu898app.module.account;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.uu898app.R;
import com.uu898app.module.base.BaseFragment;
import com.uu898app.module.helper.AccountManager;
import com.uu898app.module.helper.ToolbarHelper;
import com.uu898app.network.NetConstant;
import com.uu898app.util.CommonUtil;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * 用户资料完善
 * Created by zhangbo on 2016/6/23.
 */
public class DataIntegrityFragment extends BaseFragment {


    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.webview)
    WebView webview;


    public static DataIntegrityFragment newInstance() {
        Bundle args = new Bundle();
        DataIntegrityFragment fragment = new DataIntegrityFragment();
        fragment.setArguments(args);
        return fragment;
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.buy_order, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        new ToolbarHelper.Builder(toolbar, this,_mActivity)
                .title("资料完善")
                .showBack(true)
                .build();

        webview.getSettings().setJavaScriptEnabled(true);
//        webview.addJavascriptInterface(new WebAppInterface(getActivity(), webview), "Android");
        webview.setWebChromeClient(new WebChromeClient());
        webview.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                showLoadToast();
            }

            @SuppressLint("DefaultLocale")
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                hideLoadToast();
                view.loadUrl(url);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                hideLoadToast();
                super.onPageFinished(view, url);
            }
        });
        String url = NetConstant.URL.SELF_REGURL + "SSID=" + CommonUtil.encryptString(AccountManager.getInstance().getSSID());
        webview.loadUrl(url);
    }


}
