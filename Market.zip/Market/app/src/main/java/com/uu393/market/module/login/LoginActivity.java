package com.uu393.market.module.login;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.text.TextUtilsCompat;
import android.text.TextUtils;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.lzy.okgo.OkGo;
import com.sina.weibo.sdk.auth.AuthInfo;
import com.sina.weibo.sdk.auth.Oauth2AccessToken;
import com.sina.weibo.sdk.auth.WeiboAuthListener;
import com.sina.weibo.sdk.auth.sso.SsoHandler;
import com.sina.weibo.sdk.exception.WeiboException;
import com.tencent.connect.UserInfo;
import com.tencent.connect.common.Constants;
import com.tencent.mm.opensdk.modelmsg.SendAuth;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import com.tencent.tauth.IUiListener;
import com.tencent.tauth.Tencent;
import com.tencent.tauth.UiError;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.Constant;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GDoAddPlayedGame;
import com.uu393.market.model.request.GDoLogin;
import com.uu393.market.model.request.GDoThirdLogin;
import com.uu393.market.model.response.BUserInfo;
import com.uu393.market.model.response.BWbUserInfo;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.h5game.H5WebViewActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.DensityUtils;
import com.uu393.market.util.RsaHelper;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;
import com.uu393.market.view.loadtoast.LoadToast;

import org.greenrobot.eventbus.Subscribe;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.HashMap;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

import static com.uu393.market.Constant.WB_GET_USER_INFO;

/**
 * 登录页
 */
public class LoginActivity extends BaseActivity {

    @Bind(R.id.iv_login_go_back)
    ImageView mIvLoginGoBack;//返回按钮
    @Bind(R.id.iv_login_logo)
    ImageView mIvLoginLogo;//头像
    @Bind(R.id.et_login_account_input)
    EditText mEtLoginAccountInput;//用户名输入框
    @Bind(R.id.et_login_password_input)
    EditText mEtLoginPasswordInput;//密码输入框
    @Bind(R.id.ll_login_frame)
    LinearLayout mLlLoginFrame;
    @Bind(R.id.tv_login_forgot_password)
    TextView mTvLoginForgotPassword;//忘记密码
    @Bind(R.id.tv_login_register)
    TextView mTvLoginRegister;//免费注册
    @Bind(R.id.ll_login_frame_one)
    LinearLayout mLlLoginFrameOne;
    @Bind(R.id.ll_login_uu)
    LinearLayout mLlLoginUu;
    @Bind(R.id.ll_login_wx)
    LinearLayout mLlLoginWx;
    @Bind(R.id.ll_login_qq)
    LinearLayout mLlLoginQq;
    @Bind(R.id.ll_login_wb)
    LinearLayout mLlLoginWb;
    @Bind(R.id.ll_login_frame_two)
    LinearLayout mLlLoginFrameTwo;
    @Bind(R.id.iv_background)
    ImageView mIvBackground;
    @Bind(R.id.btn_login_do)
    Button mBtnLoginDo;
    private Activity mActivity;
    private Tencent mTencent;

    private BaseUiListener baseUiListener;
    private IWXAPI iwxapi;
    private String mUserId;
    private String mPassword;
    private SsoHandler mSsoHandler;
    private String mGameId;
    private String APPID;
    private String mGameUrl;
    private Dialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);
        mActivity = LoginActivity.this;
        mTencent = Tencent.createInstance(Constant.QQ_APP_ID, App.mContext);//QQ登录
        iwxapi = WXAPIFactory.createWXAPI(App.mContext, Constant.WX_APP_ID, true);//微信登录

        mDialog = new Dialog(this, R.style.DialogStyle);
        mDialog.setContentView(R.layout.loading_dialog);
        mDialog.setCancelable(true);
        mDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        TextView message = (TextView) mDialog.findViewById(R.id.tv_dialog_message);
        message.setText("登陆中 ···");

    }

    public void showLoadToast() {
        if (mDialog != null && !mDialog.isShowing())
            mDialog.show();
    }

    public void hideLoadToast() {
        if (mDialog != null && mDialog.isShowing())
            mDialog.dismiss();
    }

    //处理点击事件
    @OnClick({R.id.iv_login_go_back, R.id.tv_login_forgot_password, R.id.tv_login_register, R.id.ll_login_uu, R.id.ll_login_wx, R.id.ll_login_qq, R.id.ll_login_wb, R.id.btn_login_do})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_login_go_back://返回按钮
                onBackPressedSupport();
                break;
            case R.id.tv_login_forgot_password://忘记密码
                LoginActivity.this.startActivity(new Intent(mActivity, FindPassWrodActivity.class));
                break;
            case R.id.tv_login_register://去注册
                startActivity(new Intent(mActivity, RegisterActivity.class));
                break;
            case R.id.ll_login_uu://UU账号登录
                doUU898Login();
                break;
            case R.id.ll_login_wx://WX登录
                showLoadToast();
                doWxLogin();
                break;
            case R.id.ll_login_qq://QQ登录
                //doQQLogin();
                ToastUtil.showToast(LoginActivity.this, "功能尚未上线敬请期待");
                break;
            case R.id.ll_login_wb://微博登录
                showLoadToast();
                doWbLogin();
                break;
            case R.id.btn_login_do://登录
                doLogin();
                break;
        }
    }

    private void doUU898Login() {
        LoginActivity.this.startActivity(new Intent(LoginActivity.this, UU898LoginActivity.class));
    }

    private void doLogin()  {
        mUserId = mEtLoginAccountInput.getText().toString().trim();
        mPassword = mEtLoginPasswordInput.getText().toString().trim();
        if (TextUtils.isEmpty(mUserId)) {
            ToastUtil.showToast(App.mContext, "请输入正确的账号");
            return;
        }
        if (TextUtils.isEmpty(mPassword)) {
            ToastUtil.showToast(App.mContext, "密码不能为空");
            return;
        }
        showLoadToast();
        final GDoLogin model = new GDoLogin();
        model.setUserId(mUserId);
        model.setPassword(RsaHelper.encryptDataFromStr(mPassword, RsaHelper.RSA_PUBLIC_KEY));
        model.setDecipheringType("0");
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doLogin(model, new JsonCallback<BUserInfo>() {
            @Override
            public void onSuccess(BUserInfo bUserInfo, Call call, Response response) {
                hideLoadToast();
                MobclickAgent.onProfileSignIn("uushouyou", bUserInfo.getUserId());//友盟统计用户登录
                SPUtil.put(App.mContext, "isLogin", true);
                SPUtil.put(App.mContext, "loginType", "0");
                SPUtil.put(App.mContext, "thirdUserId", "");
                SPUtil.put(App.mContext, "token", bUserInfo.getToken());
                SPUtil.put(App.mContext, "userId", bUserInfo.getUserId());
                SPUtil.put(App.mContext, "uId", bUserInfo.getUId());
                SPUtil.put(App.mContext, "chkMobile", bUserInfo.getChkMobile());
                ToastUtil.showToast(App.mContext, "登录成功");

                mGameId = (String) SPUtil.get(App.mContext, "GameId", "");
                APPID = (String) SPUtil.get(App.mContext, "APPID", "");
                mGameUrl = (String) SPUtil.get(App.mContext, "GameUrl", "");
                if (!TextUtils.isEmpty(mGameId)) {
                    //---------------------添加一条玩过的记录---------------------------------
                    GDoAddPlayedGame model = new GDoAddPlayedGame();
                    model.setGameID(mGameId);
                    model.setPlatform("1");
                    model.setAPPID(APPID);
                    TaskEngine.setTokenUseridPhoneState(2);
                    TaskEngine.getInstance().doAddOnePlayedGame(model, new JsonCallback<Object>() {
                        @Override
                        public void onSuccess(Object o, Call call, Response response) {
                            L.d("添加一条玩过的H5游戏成功");
                        }
                    });
                    //---------------------添加一条玩过的记录---------------------------------


                    Intent intent = new Intent();
                    intent.putExtra("gameId", mGameId);
                    intent.putExtra("APPID", APPID);
                    intent.putExtra("url", mGameUrl);
                    intent.setClass(LoginActivity.this, H5WebViewActivity.class);
                    startActivity(intent);
                    SPUtil.put(App.mContext, "GameId", "");
                    SPUtil.put(App.mContext, "APPID", "");
                    SPUtil.put(App.mContext, "GameUrl", "");
                } else {
                    LoginActivity.this.startActivity(new Intent(LoginActivity.this, UserCenterActivity.class));
                }

                LoginActivity.this.finish();//退出界面
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
            }
        });
    }

    private void doWxLogin() {
        if (!iwxapi.isWXAppInstalled()) {
            Toast.makeText(mActivity, "请先安装微信客户端", Toast.LENGTH_SHORT).show();
            hideLoadToast();
            return;
        }
        //ToastUtil.showToast(App.mContext,"请稍后");
        SendAuth.Req req = new SendAuth.Req();
        req.scope = Constant.WX_SCOPE;//需要的权限范围
        req.state = "uu_wx_sdk";
        iwxapi.sendReq(req);
        L.d("微信登录");
    }


    private void doQQLogin() {
        L.d("tag", "QQ登录");
        baseUiListener = new BaseUiListener();
        mTencent.login(mActivity, Constant.QQ_SCOPE, baseUiListener);
    }

    //QQ登录回调
    public class BaseUiListener implements IUiListener {
        @Override
        public void onComplete(Object o) {
            L.d("tag", "QQ登录成功");
            if (o != null) {
                try {
                    final JSONObject data = (JSONObject) o;

                    final String openID = data.getString("openid");
                    final String accessToken = data.getString("access_token");
                    String expires_in = data.getString("expires_in");

                    mTencent.setOpenId(openID);
                    mTencent.setAccessToken(accessToken, expires_in);
                    UserInfo userInfo = new UserInfo(mActivity, mTencent.getQQToken());
                    userInfo.getUserInfo(new IUiListener() {
                        @Override
                        public void onComplete(Object o) {
                            if (o != null) {
                                JSONObject data = (JSONObject) o;
                                try {
                                    final String nickname = data.getString("nickname");

                                    GDoThirdLogin model = new GDoThirdLogin();
                                    model.setOpenId(openID);
                                    model.setToken(accessToken);
                                    model.setType("0");
                                    TaskEngine.setTokenUseridPhoneState(1);
                                    TaskEngine.getInstance().doThirdLogin(model, new JsonCallback<BUserInfo>() {
                                        @Override
                                        public void onSuccess(BUserInfo userInfo, Call call, Response response) {
                                            MobclickAgent.onProfileSignIn("qq", userInfo.getUserId());//友盟统计用户登录
                                            SPUtil.put(App.mContext, "isLogin", true);
                                            SPUtil.put(App.mContext, "thirdUserId", nickname);
                                            SPUtil.put(App.mContext, "loginType", "1");
                                            SPUtil.put(App.mContext, "token", userInfo.getToken());
                                            SPUtil.put(App.mContext, "userId", userInfo.getUserId());
                                            SPUtil.put(App.mContext, "uId", userInfo.getUId());
                                            SPUtil.put(App.mContext, "chkMobile", userInfo.getChkMobile());
                                            ToastUtil.showToast(App.mContext, "登录成功");
                                            startActivity(new Intent(LoginActivity.this, UserCenterActivity.class));
                                            LoginActivity.this.finish();//退出界面
                                        }
                                    });
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }catch (Exception e){
                                    e.printStackTrace();
                                }
                            }
                        }

                        @Override
                        public void onError(UiError uiError) {
                        }

                        @Override
                        public void onCancel() {

                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }

        @Override
        public void onError(UiError uiError) {
        }

        @Override
        public void onCancel() {
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Constants.ACTIVITY_OK) {
            if (requestCode == Constants.REQUEST_LOGIN) {
                if (baseUiListener != null)
                    Tencent.onActivityResultData(requestCode, resultCode, data, baseUiListener);
            }
        }

        if (mSsoHandler != null) {//处理微博回调
            mSsoHandler.authorizeCallBack(requestCode, resultCode, data);
        }

    }


    private void doWbLogin() {
        L.d("tag", "微博登录");
        AuthInfo authInfo = new AuthInfo(App.mContext, Constant.WB_APP_KEY, Constant.WB_REDIRECT_URL, Constant.WB_SCOPE);
        mSsoHandler = new SsoHandler(LoginActivity.this, authInfo);
        mSsoHandler.authorize(new AuthListener());//SSO授权 如果手机安装了微博客户端则使用客户端授权,没有则进行网页授权
    }

    private class AuthListener implements WeiboAuthListener {

        @Override
        public void onComplete(Bundle bundle) {
            Oauth2AccessToken mAccessToken = Oauth2AccessToken.parseAccessToken(bundle);
            if (mAccessToken.isSessionValid()) {
                final String uid = mAccessToken.getUid();
                final String token = mAccessToken.getToken();
                HashMap<String, String> map = new HashMap<>();
                map.put("uid", uid);
                map.put("access_token", token);
                OkGo.get(WB_GET_USER_INFO).params(map).execute(new JsonCallback<BWbUserInfo>() {
                    @Override
                    public void onSuccess(BWbUserInfo o, Call call, Response response) {
                        if (o != null) {
                            final String name = o.getName();
                            GDoThirdLogin model = new GDoThirdLogin();
                            model.setOpenId(uid);
                            model.setToken(token);
                            model.setType("0");
                            TaskEngine.setTokenUseridPhoneState(1);
                            TaskEngine.getInstance().doThirdLogin(model, new JsonCallback<BUserInfo>() {
                                @Override
                                public void onSuccess(BUserInfo userInfo, Call call, Response response) {
                                    MobclickAgent.onProfileSignIn("weibo", userInfo.getUserId());//友盟统计用户登录
                                    SPUtil.put(App.mContext, "isLogin", true);
                                    SPUtil.put(App.mContext, "thirdUserId", name);
                                    SPUtil.put(App.mContext, "loginType", "3");
                                    SPUtil.put(App.mContext, "token", userInfo.getToken());
                                    SPUtil.put(App.mContext, "userId", userInfo.getUserId());
                                    SPUtil.put(App.mContext, "uId", userInfo.getUId());
                                    SPUtil.put(App.mContext, "chkMobile", userInfo.getChkMobile());

                                    mGameId = (String) SPUtil.get(App.mContext, "GameId", "");
                                    APPID = (String) SPUtil.get(App.mContext, "APPID", "");
                                    mGameUrl = (String) SPUtil.get(App.mContext, "GameUrl", "");
                                    if (!TextUtils.isEmpty(mGameId)) {
                                        Intent intent = new Intent();
                                        intent.putExtra("gameId", mGameId);
                                        intent.putExtra("APPID", APPID);
                                        intent.putExtra("url", mGameUrl);
                                        intent.setClass(LoginActivity.this, H5WebViewActivity.class);
                                        startActivity(intent);
                                        SPUtil.put(App.mContext, "GameId", "");
                                        SPUtil.put(App.mContext, "APPID", "");
                                        SPUtil.put(App.mContext, "GameUrl", "");
                                    } else {
                                        ToastUtil.showToast(App.mContext, "登录成功");
                                        startActivity(new Intent(LoginActivity.this, UserCenterActivity.class));
                                    }
                                    LoginActivity.this.finish();//退出界面
                                }
                            });
                        }
                    }

                    @Override
                    public void onError(Call call, Response response, Exception e) {
                        super.onError(call, response, e);
                        L.d(e.getMessage() + e.getCause());
                        hideLoadToast();
                    }
                });

            } else {
                // 当您注册的应用程序签名不正确时，就会收到错误Code，请确保签名正确
                //Toast.makeText(mActivity, "错误码" + bundle.getString("code", "") + "请确保您的应用签名正确", Toast.LENGTH_SHORT).show();
                hideLoadToast();
            }

        }

        @Override
        public void onWeiboException(WeiboException e) {
            //Toast.makeText(mActivity, "微博登录失败", Toast.LENGTH_SHORT).show();
            hideLoadToast();
        }

        @Override
        public void onCancel() {
            //Toast.makeText(mActivity, "取消微博登录", Toast.LENGTH_SHORT).show();
            hideLoadToast();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        EB.register(this);
        L.d("onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EB.unregister(this);
    }

    //处理event事件
    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.LOGIN_SUCCESS:
                this.finish();
                break;
            case EB.TAG.HIDE_LOGINING:
                hideLoadToast();
                break;
            default:
                break;
        }
    }

    @Override
    public void onBackPressedSupport() {
        SPUtil.put(App.mContext, "GameId", "");
        SPUtil.put(App.mContext, "APPID", "");
        SPUtil.put(App.mContext, "GameUrl", "");
        super.onBackPressedSupport();
    }
}
