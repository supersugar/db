package com.uu393.market.module.h5game;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.RelativeLayout;

import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.response.BH5Game;
import com.uu393.market.model.response.BH5ZaiWan;
import com.uu393.market.module.base.BaseTabLazyFragment;
import com.uu393.market.module.base.BaseViewPagerFragment;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;
import com.uu393.market.view.lazyviewpager.LazyFragmentPagerAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/14
 * Descrip    : H5游戏中心界面
 * =====================================================
 */

public class H5GameFragment extends BaseTabLazyFragment {
    @Bind(R.id.iv_h5game_do_search)
    ImageButton mIvH5gameDoSearch;
    @Bind(R.id.ib_h5game_zaiwan_more)
    ImageButton mIbH5gameZaiwanMore;
    RecyclerView mRvH5gameZaiwan;
    @Bind(R.id.h5_tabs)
    TabLayout mTabLayout;
    @Bind(R.id.h5_tabs_viewpager)
    ViewPager mViewPager;
    RecyclerView mRvH5gameSuggest;
    RelativeLayout mRlH5gameZaiwan;
    @Bind(R.id.h5_appbar)
    AppBarLayout mH5Appbar;

    private List<BH5ZaiWan> mZaiWanGames;
    private List<BH5Game> mSuggestGames;
    private ZaiWanRvAdapter zaiWanRvAdapter;
    private SuggestRvAdapter suggestRvAdapter;
    private MyAdapter myViewPagerAdapter;
    private int mCurrentFragmentIndex;
    private Map<Integer, BaseViewPagerFragment> fragmentsMap = new HashMap<>();

    public static H5GameFragment newInstance() {
        Bundle args = new Bundle();
        H5GameFragment fragment = new H5GameFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_h5game, container, false);
        mRlH5gameZaiwan = (RelativeLayout) view.findViewById(R.id.rl_h5game_zaiwan);
        mRvH5gameSuggest = (RecyclerView) view.findViewById(R.id.rv_h5game_suggest);
        mRvH5gameZaiwan = (RecyclerView) view.findViewById(R.id.rv_h5game_zaiwan);

        ButterKnife.bind(this, view);
        mZaiWanGames = new ArrayList<>();
        initZaiWanRecycler();
        getGameList();
        return view;
    }

    @Override
    protected void initLazyView(@Nullable Bundle savedInstanceState) {

    }

    @Override
    public void onLazyInitView(@Nullable Bundle savedInstanceState) {
        super.onLazyInitView(savedInstanceState);
        L.d("懒加载"+this);

        getZaiWanGameList();
        getSuggestGameList();
    }

    private void initZaiWanRecycler() {
        FullyLinearLayoutManager zaiwanLayoutManager = new FullyLinearLayoutManager(_mActivity, LinearLayoutManager.HORIZONTAL, false);
        mRvH5gameZaiwan.setLayoutManager(zaiwanLayoutManager);
        zaiWanRvAdapter = new ZaiWanRvAdapter(_mActivity);
        mRvH5gameZaiwan.setHasFixedSize(true);
        mRvH5gameZaiwan.setNestedScrollingEnabled(false);
        mRvH5gameZaiwan.setAdapter(zaiWanRvAdapter);
    }

    @Override
    public void onTabReselected() {
        getZaiWanGameList();
        getSuggestGameList();
        refreshCurrentGameFragment();
    }


    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart("H5GameFragment"); //统计页面(仅有Activity的应用中SDK自动调用，不需要单独写。"SplashScreen"为页面名称，可自定义)
        getZaiWanGameList();
        getSuggestGameList();
        refreshCurrentGameFragment();
    }

    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("H5GameFragment"); // （仅有Activity的应用中SDK自动调用，不需要单独写）保证 onPageEnd 在onPause 之前调用,因为 onPause 中会保存信息。
    }

    private void showZaiwan(boolean show) {
        if (show) {
            mRlH5gameZaiwan.setVisibility(View.VISIBLE);
        } else {
            mRlH5gameZaiwan.setVisibility(View.GONE);
        }
    }

    //获取在玩列表 分为登录前和登录后
    public void getZaiWanGameList() {
        //---------------在玩游戏列表-------------------
        mZaiWanGames.clear();
        //todo 判断登陆状态
        if ((boolean) SPUtil.get(App.mContext, "isLogin", false)) {
            TaskEngine.setTokenUseridPhoneState(2);
            TaskEngine.getInstance().doGetH5ZaiWan(new JsonCallback<List<BH5ZaiWan>>() {
                @Override
                public void onSuccess(List<BH5ZaiWan> bh5ZaiWan, Call call, Response response) {

                }

                @Override
                public void onAfter(List<BH5ZaiWan> bh5ZaiWan, Exception e) {
                    super.onAfter(bh5ZaiWan, e);
                    mZaiWanGames.clear();
                    if (bh5ZaiWan != null && !bh5ZaiWan.isEmpty()) {
                        mZaiWanGames.addAll(bh5ZaiWan);
                        zaiWanRvAdapter.refresh(mZaiWanGames);
                        showZaiwan(true);
                    } else {
                        zaiWanRvAdapter.refresh(mZaiWanGames);
                        showZaiwan(false);
                    }
                }
            });
        } else {
            mZaiWanGames.clear();
            zaiWanRvAdapter.refresh(mZaiWanGames);
            showZaiwan(false);
        }
        //---------------在玩游戏列表-------------------

    }

    //获取推荐的游戏列表
    private void getSuggestGameList() {
        FullyLinearLayoutManager suggestLayoutManager = new FullyLinearLayoutManager(_mActivity, LinearLayoutManager.VERTICAL, false);
        mRvH5gameSuggest.setLayoutManager(suggestLayoutManager);
        suggestRvAdapter = new SuggestRvAdapter(_mActivity);
        mRvH5gameSuggest.setHasFixedSize(true);
        mRvH5gameSuggest.setNestedScrollingEnabled(false);
        mRvH5gameSuggest.setAdapter(suggestRvAdapter);
        //----------------推荐游戏列表------------------
        mSuggestGames = new ArrayList<>();
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetH5Tree(new JsonCallback<List<BH5Game>>() {
            @Override
            public void onSuccess(List<BH5Game> bh5Games, Call call, Response response) {
                if (bh5Games != null) {
                    mSuggestGames.clear();
                    mSuggestGames.addAll(bh5Games);
                    suggestRvAdapter.refresh(mSuggestGames);
                }
            }
        });
        //----------------------------------
    }

    //获取游戏列表
    private void getGameList() {
        myViewPagerAdapter = new MyAdapter(getChildFragmentManager());
        mViewPager.setAdapter(myViewPagerAdapter);
        mViewPager.setOffscreenPageLimit(1);
        mTabLayout.setupWithViewPager(mViewPager);
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                mCurrentFragmentIndex = position;
                if (!fragmentsMap.isEmpty() && null != fragmentsMap.get(mCurrentFragmentIndex)) {
                    fragmentsMap.get(mCurrentFragmentIndex).refresh();
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private void refreshCurrentGameFragment() {
        if (!fragmentsMap.isEmpty() && null != fragmentsMap.get(mCurrentFragmentIndex)) {
            fragmentsMap.get(mCurrentFragmentIndex).refresh();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        L.d("onHiddenChanged" + hidden);
        if (hidden == false) {
            refreshCurrentGameFragment();
        }
    }

    @OnClick({R.id.ib_h5game_zaiwan_more, R.id.iv_h5game_do_search})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_h5game_do_search:

                EB.postEmpty(EB.TAG.GO_SEARCH);
                break;
            case R.id.ib_h5game_zaiwan_more:
                startActivity(new Intent(_mActivity, ZaiWanH5MoreActivity.class));
                break;
        }
    }



    //todo 底部ViewPage的适配器
    private class MyAdapter extends LazyFragmentPagerAdapter {
        private List<String> gameKinds = new ArrayList<>();

        public MyAdapter(FragmentManager fm) {
            super(fm);
            gameKinds.add("全部游戏");
            gameKinds.add("热门游戏");
        }

        @Override
        protected Fragment getItem(ViewGroup container, int position) {
            H5ListFragment fragment = H5ListFragment.newInstance(gameKinds.get(position));
            fragmentsMap.put(position, fragment);
            return fragment;
        }

        @Override
        public int getCount() {
            return gameKinds.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return gameKinds.get(position);
        }

    }
}
