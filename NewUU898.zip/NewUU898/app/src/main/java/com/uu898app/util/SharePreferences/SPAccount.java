package com.uu898app.util.SharePreferences;

import com.baoyz.treasure.Clear;
import com.baoyz.treasure.Preferences;
import com.uu898app.model.response.BUserInfo;

/**
 * Created by zhangbo on 2016/7/1.
 */
@Preferences
public interface SPAccount {

    void setU(String username);
    void setP(String password);
    void setIsAutoLogin(boolean flag);
    void setTime(long time);
    void setUserInfo(BUserInfo userInfo);

    void setSsid(String ssid);
    void setUserid(String userId);




    String getU();
    String getP();
    boolean getIsAutoLogin();
    long getTime();
    BUserInfo getUserInfo();

    String getSsid();
    String getUserId();

    @Clear
    void clear();
}
