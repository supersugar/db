package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * Created by bo on 16/9/14.
 */
public class BBanner implements Serializable {

    public String imageUrl;//游图片地址
    public String linkUrl;//链接地址
    public int linkType;//(0:游戏详情页面  1:活动页面)
    public String gameID;//游戏ID
}
