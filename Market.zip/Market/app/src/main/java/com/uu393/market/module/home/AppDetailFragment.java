package com.uu393.market.module.home;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.request.GetRequest;
import com.lzy.okserver.download.DownloadInfo;
import com.lzy.okserver.download.DownloadManager;
import com.lzy.okserver.download.DownloadService;
import com.lzy.okserver.listener.DownloadListener;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.DownloadHelper;
import com.uu393.market.model.request.GGetGameDetail;
import com.uu393.market.model.response.BGame;
import com.uu393.market.module.base.BaseFragment;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ApkUtils;
import com.uu393.market.util.Base64Helper;
import com.uu393.market.util.DateUtils;
import com.uu393.market.util.DensityUtils;
import com.uu393.market.util.GlideRoundTransform;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;
import com.uu393.market.view.progressbutton.SubmitProcessButton;

import org.greenrobot.eventbus.Subscribe;

import java.io.File;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;

import ezy.ui.layout.LoadingLayout;
import okhttp3.Call;
import okhttp3.Response;

import static com.uu393.market.Constant.UMENG_EVENT_ID_DOWNLOAD;
import static com.uu393.market.app.App.mContext;

/**
 * Created by bo on 16/11/10.
 */

public class AppDetailFragment extends BaseFragment implements View.OnClickListener {

    private ImageButton mBtBack;
    private ImageButton mBtShare;
    private ImageView mIcon;
    private TextView mName;
    private TextView mDiscount;
    private TextView mTypeAndSize;
    private RecyclerView mRecyclerView;
    private TextView mGameInfo;
    private TextView mTvSize;
    private TextView mTvVersion;
    private TextView mTvMinSdkVersion;
    private TextView mTvType;
    private TextView mTvLauguage;
    private TextView mTvTime;
    private TextView mTvBt;
    private TextView mTvFirst;

    private SubmitProcessButton mBtDownload;

    private MyListener listener;
    private DownloadInfo downloadInfo;
    private String mGameId;
    private BGame mGame;
    private DownloadManager mDownloadManager;
    private LoadingLayout mLoadingLayout;

    public static AppDetailFragment newInstance(String gameId) {
        AppDetailFragment fragment = new AppDetailFragment();
        Bundle args = new Bundle();
        args.putString("gameId", gameId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        mGameId = args.getString("gameId");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.detail_fragment, container, false);
        mBtBack = (ImageButton) view.findViewById(R.id.title_bar_left);
        mBtShare = (ImageButton) view.findViewById(R.id.title_bar_right);
        mIcon = (ImageView) view.findViewById(R.id.app_icon);
        mName = (TextView) view.findViewById(R.id.name);
        mDiscount = (TextView) view.findViewById(R.id.tv_discount);
        mTypeAndSize = (TextView) view.findViewById(R.id.tv_type_size);
        mRecyclerView = (RecyclerView) view.findViewById(R.id.hor_center_recycle_rview);
        mGameInfo = (TextView) view.findViewById(R.id.tv_game_info);
        mTvSize = (TextView) view.findViewById(R.id.tv_size);
        mTvVersion = (TextView) view.findViewById(R.id.tv_version);
        mTvMinSdkVersion = (TextView) view.findViewById(R.id.tv_min_sdk_version);
        mTvType = (TextView) view.findViewById(R.id.tv_type);
        mTvLauguage = (TextView) view.findViewById(R.id.tv_language);
        mTvTime = (TextView) view.findViewById(R.id.tv_time);
        mTvBt = (TextView) view.findViewById(R.id.tv_detail_bt);
        mTvFirst = (TextView) view.findViewById(R.id.tv_detail_first);

        mBtDownload = (SubmitProcessButton) view.findViewById(R.id.download_bt);
        mBtDownload.setOnClickListener(this);
        mDownloadManager = DownloadService.getDownloadManager();
        listener = new MyListener();

        mBtBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _mActivity.onBackPressed();
            }
        });
        mBtShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });

        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mLoadingLayout = LoadingLayout.wrap(view);
        mLoadingLayout.showLoading();
        mLoadingLayout.setRetryListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doGetGameDetail();
            }
        });
        doGetGameDetail();
    }

    private void doGetGameDetail() {
        GGetGameDetail model = new GGetGameDetail(mGameId);
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetGameDetailNew(model, new JsonCallback<BGame>() {
            @Override
            public void onSuccess(BGame bGame, Call call, Response response) {
                mLoadingLayout.showContent();
                mGame = bGame;
                if (mGame==null)
                    return;
                int defaultAndError = ImageHelper.randomImage();
                Glide.with(App.mContext).load(mGame.getIcon())
                        .error(defaultAndError)
                        .placeholder(defaultAndError)
                        .transform(new GlideRoundTransform(App.mContext, 10))
                        .into(mIcon);

                mName.setText(mGame.getGameName());
                if (mGame.getDiscount() != null && mGame.getDiscount().equals("10")) {
                    mDiscount.setVisibility(View.GONE);
                } else {
                    mDiscount.setVisibility(View.VISIBLE);
                    mDiscount.setText(mGame.getDiscount() + "折");
                }
                mTypeAndSize.setText(mGame.getTypeName() + " / " + mGame.getSize());
                if (mGame.getTypeName().equals("BT游戏")) {
                    mTvBt.setVisibility(View.VISIBLE);
                } else {
                    mTvBt.setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(mGame.getIsFirst())){
                    if ("1".equals(mGame.getIsFirst())){//是首发游戏

                        String firstTime = mGame.getFirstTime();
                        if (TextUtils.isEmpty(firstTime)){
                            mTvFirst.setVisibility(View.GONE);
                        }else {

                            Date date = DateUtils.parse(firstTime);//"firstTime": "2017-3-31 00:00:00”,(首发时间)
                            SimpleDateFormat format = new SimpleDateFormat("MM-dd");
                            if (date!=null){

                                SimpleDateFormat formatDay = new SimpleDateFormat("d日");
                                String day = formatDay.format(date);
                                Date nextDay = DateUtils.getNextDay(new Date());
                                Calendar calendar = Calendar.getInstance();
                                calendar.setTime(date);
                                calendar.add(Calendar.DAY_OF_MONTH, 7);
                                Date dateAfterSeven  = calendar.getTime();

                                int compareTo = dateAfterSeven.compareTo(new Date());
                                if (format.format(date).equals(format.format(new Date()))){//当天
                                    mTvFirst.setVisibility(View.VISIBLE);
                                    mTvFirst.setText("今日首发");
                                }else if (format.format(date).equals(format.format(nextDay))){
                                    mTvFirst.setVisibility(View.VISIBLE);
                                    mTvFirst.setText("明日首发");
                                }else if (compareTo<0){
                                    mTvFirst.setVisibility(View.GONE);
                                }else {
                                    mTvFirst.setVisibility(View.VISIBLE);
                                    mTvFirst.setText(day+"首发");
                                }
                            }else {
                                mTvFirst.setVisibility(View.GONE);
                            }
                        }
                    }else {
                        mTvFirst.setVisibility(View.GONE);
                        //first.setText("31日首发");
                    }
                }

                mGameInfo.setText(Base64Helper.decodeToHtml(mGame.getGameInfo()));
                mTvSize.setText("大小: " + mGame.getSize());
                mTvVersion.setText("版本: " + mGame.getVersionName());
                mTvMinSdkVersion.setText("系统: " + mGame.getSupportSdkVersion());
                mTvType.setText("类别: " + mGame.getTypeName());
                mTvLauguage.setText("语言: " + mGame.getLanguage());
                mTvTime.setText("时间: " + mGame.getReleaseTime());
                downloadInfo = mDownloadManager.getDownloadInfo(mGame.getId());
                if (null != downloadInfo) {
                    downloadInfo.setListener(listener);
                }
                refreshUi(downloadInfo);

                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(_mActivity);
                linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
                mRecyclerView.setLayoutManager(linearLayoutManager);
                //这句代码是让图片居中显示
//                new LinearSnapHelper().attachToRecyclerView(mRecyclerView);
//                ada
//                mRecyclerView.setAdapter(adapter);
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                mLoadingLayout.showError();
            }


        });
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.download_bt) {
            EB.postEmpty(EB.TAG.REQUEST_SD_CARD_APP_DETAIL);
            String text = mBtDownload.getText().toString();
            downloadInfo = mDownloadManager.getDownloadInfo(mGame.getId());
            if (text.equals("打开")) {
                EB.postObject(EB.TAG.CLICK_PLAY, mGame);
                ApkUtils.launchApp(mContext, mGame.getPackageName());
            }
            if (text.equals("安装") && downloadInfo != null) {
                //先判断安装文件是否存在

                File temp = new File(downloadInfo.getTargetPath());
                if (temp.exists()) {
                    ApkUtils.install(mContext, temp);
                    EB.postObject(EB.TAG.CLICK_INSATLL, mGame);//todo 2 点击安装了 将游戏对象发送出去
                } else {
                    mDownloadManager.removeTask(mGame.getId(), true);
                    ToastUtil.showToast(mContext, "安装包可能被删除了，请重新下载");
                }
            }
            if (text.equals("下载") || text.equals("更新")) {

                HashMap<String, String> map = new HashMap<>();
                map.put("gameName", mGame.getGameName());
                MobclickAgent.onEvent(getActivity(), UMENG_EVENT_ID_DOWNLOAD, map);//友盟统计下载事件
                //一旦触发下载动作(下载/更新/重试/继续),都要综合判断当前手机情况及设置是否允许下载
                if (DownloadHelper.checkCanDownload(mContext)) {
                    String url = mGame.getAndroidPackage();
                    if (StringUtils.isEmpty(url)) {
                        ToastUtil.showToast(mContext, "下载链接错误 " + url);
                        return;
                    }
                    GetRequest request = OkGo.get(mGame.getAndroidPackage());
                    mDownloadManager.addTask(mGame.getId(), mGame, request, listener);
                }
            }

            if (text.contains("%")) {
                mDownloadManager.pauseTask(mGame.getId());
            }

            if (text.equals("重试") || text.equals("继续")) {
                if (DownloadHelper.checkCanDownload(mContext)) {
                    mDownloadManager.addTask(mGame.getId(), downloadInfo.getRequest(), downloadInfo.getListener());
                }
            }
            if (text.equals("等待")) {
                ToastUtil.showToast(mContext, "已经加入下载队列");
            }
        }
    }

    private class MyListener extends DownloadListener {

        @Override
        public void onProgress(DownloadInfo downloadInfo) {
            //进度有更新的时候会把整个downloadInfo回调过来
            refreshUi(downloadInfo);
        }

        @Override
        public void onFinish(DownloadInfo downloadInfo) {
            //BGame game = (BGame) downloadInfo.getData();
            //ToastUtil.showToast(mContext, game.getGameName() + "已经下载完成");
            if (downloadInfo == null)
                return;
            String taskKey = downloadInfo.getTaskKey();
            if (taskKey == null)
                return;
            GGetGameDetail model = new GGetGameDetail(taskKey);
            TaskEngine.setTokenUseridPhoneState(1);
            TaskEngine.getInstance().doGetGameDetail(model, new JsonCallback<BGame>() {
                @Override
                public void onSuccess(BGame bGame, Call call, Response response) {
                    if (bGame != null && bGame.getGameName() != null)
                        ToastUtil.showToast(mContext, bGame.getGameName() + "已经下载完成");
                }
            });
            DownloadHelper.addOneDownloadRecord(mContext, downloadInfo);//todo 向缓存的下载记录中加入一条游戏信息记录
        }

        @Override
        public void onError(DownloadInfo downloadInfo, String errorMsg, Exception e) {
            if (StringUtils.isEmpty(errorMsg)) {
                errorMsg = "下载出错，请重试";
            }
            ToastUtil.showToast(mContext, errorMsg);
        }
    }

    private void refreshUi(DownloadInfo downloadInfo) {

        //先根据包名判断游戏是否安装
        if (ApkUtils.hasInstalled(mContext, mGame.getPackageName())) {
            if (null != downloadInfo && downloadInfo.getState() == DownloadManager.DOWNLOADING) {
                double progress = Math.round(downloadInfo.getProgress() * 10000.00) * 1 / 100.00;
                mBtDownload.setProgress(progress, progress + "%");
                return;
            }
            //已经安装的,需要判断是否需要升级
            if (ApkUtils.whetherUpdate(mContext, mGame.getPackageName(), mGame.getVersionCode())) {
                mBtDownload.setProgress("更新");
            } else {
                mBtDownload.setProgress("打开");
            }
            return;
        }
        if (null == downloadInfo) {
            mBtDownload.setProgress("下载");
            return;
        }

        switch (downloadInfo.getState()) {
            case DownloadManager.NONE:
                mBtDownload.setProgress("下载");
                break;
            case DownloadManager.DOWNLOADING:
                double progress = Math.round(downloadInfo.getProgress() * 10000.00) * 1 / 100.00;
                mBtDownload.setProgress(progress, progress + "%");
                break;
            case DownloadManager.PAUSE://当前为暂停状态
                mBtDownload.setProgress(Math.round(downloadInfo.getProgress() * 10000) * 1 / 100, "继续");
                break;
            case DownloadManager.WAITING://当前为等待状态
                mBtDownload.setProgress("等待");
                break;
            case DownloadManager.ERROR://当前为错误状态
                mBtDownload.setProgress("重试");
                break;
            case DownloadManager.FINISH://当前为完成状态
                if (ApkUtils.hasInstalled(mContext, new File(downloadInfo.getTargetPath()))) {
                    mBtDownload.setProgress("打开");
                } else {
                    mBtDownload.setProgress("安装");
                }
                break;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        L.d("onResume()");
        MobclickAgent.onPageStart("AppDetailFragment");
        EB.register(this);
        if (null != mGame&&downloadInfo!=null) {
            refreshUi(downloadInfo);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("AppDetailFragment");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        L.d("onDestroy()");
        EB.unregister(this);
    }

    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.APP_INSTALL:
                if (null != mGame) {
                    refreshUi(downloadInfo);
                }
                break;
            default:
                break;
        }
    }
}
