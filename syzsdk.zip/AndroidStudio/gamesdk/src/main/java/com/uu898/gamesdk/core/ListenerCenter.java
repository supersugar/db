package com.uu898.gamesdk.core;

import com.uu898.gamesdk.support.listener.UGChangeAccountListener;
import com.uu898.gamesdk.support.listener.UGExitListener;
import com.uu898.gamesdk.support.listener.UGLoginListener;
import com.uu898.gamesdk.support.listener.UGPayListener;

/**
 * Created by bo on 16/9/26.
 */

public class ListenerCenter {

    private static ListenerCenter instance = new ListenerCenter();

    private UGLoginListener mLoginListener;
    private UGPayListener mPayListener;
    private UGExitListener mExitListener;
    private UGChangeAccountListener mChangeAccountListener;

    private ListenerCenter() {

    }

    public static ListenerCenter getInstance() {
        return instance;
    }

    public UGPayListener getPayListener() {
        return mPayListener;
    }

    public void setPayListener(UGPayListener mPayListener) {
        this.mPayListener = mPayListener;
    }

    public UGLoginListener getLoginListener() {
        return mLoginListener;
    }

    public void setLoginListener(UGLoginListener mLoginListener) {
        this.mLoginListener = mLoginListener;
    }

    public UGExitListener getExitListener() {
        return mExitListener;
    }

    public void setExitListener(UGExitListener mExitListener) {
        this.mExitListener = mExitListener;
    }

    public UGChangeAccountListener getChangeAccountListener() {
        return mChangeAccountListener;
    }

    public void setChangeAccountListener(UGChangeAccountListener mChangeAccountListener) {
        this.mChangeAccountListener = mChangeAccountListener;
    }
}
