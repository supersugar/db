package com.uu898.gamesdk.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.uu898.gamesdk.core.ResourceUtils;
import com.uu898.gamesdk.log.L;
import com.uu898.gamesdk.model.request.GGetOrderList;
import com.uu898.gamesdk.model.response.BOrder;
import com.uu898.gamesdk.network.NetCallback;
import com.uu898.gamesdk.network.TaskEngine;

import java.util.ArrayList;
import java.util.List;

/**
 * 优惠券
 */
public class UserCouponFragment extends BaseFragment {

    private ListView mListView;
    private MyAdapter mAdapter;
    private List<BOrder> mList = new ArrayList<BOrder>();

    private String mStatus;

    public static UserCouponFragment newInstance() {
        Bundle args = new Bundle();
        UserCouponFragment fragment = new UserCouponFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        View view = inflater.inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_coupon"), container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initTitleBar(view, "优惠券");

        mListView = (ListView) view.findViewById(getId("ug_list_view"));
        mAdapter = new MyAdapter();
        mListView.setAdapter(mAdapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ((BaseFragment) getParentFragment()).start(UserPayRecordDetailFragment.newInstance(mList.get(position)));
            }
        });

        doGetOrders();
    }



    private void doGetOrders() {
        GGetOrderList model = new GGetOrderList();
        model.setStatus("");

        TaskEngine.getInstance().doGetOrderList(model, new NetCallback<ArrayList<BOrder>>() {
            @Override
            public void _onNext(ArrayList<BOrder> list) {
                L.d(list.size());
                mList = list;
                mAdapter.notifyDataSetChanged();
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }


    private class MyAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return mList.size();
        }

        @Override
        public Object getItem(int position) {
            return mList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            ViewHolder holder = null;
            if (null == convertView) {
                convertView = LayoutInflater.from(_mActivity).inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_coupon_disable"), null);
                holder = new ViewHolder();
//                holder.title = (TextView) convertView.findViewById(getId("ug_order_item_title"));
//                holder.time = (TextView) convertView.findViewById(getId("ug_order_item_time"));
//                holder.price = (TextView) convertView.findViewById(getId("ug_order_item_price"));
//                holder.status = (TextView) convertView.findViewById(getId("ug_order_item_status"));
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }
//            holder.title.setText(mList.get(position).Title);
//            holder.time.setText(mList.get(position).AddTime);
//            holder.price.setText(mList.get(position).TotalMoney + "元");
//            holder.status.setText(mList.get(position).getStatusForShow());

            return convertView;
        }

        private class ViewHolder {
            TextView title;
            TextView time;
            TextView price;
            TextView status;
        }
    }


}
