package com.uu898app.module.helper;


import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;

import com.uu898app.R;
import com.uu898app.third.xiaoneng.XiaoNeng;

import me.yokeyword.fragmentation.SupportActivity;
import me.yokeyword.fragmentation.SupportFragment;

/**
 * Toolbar帮助类
 * Created by zhangbo on 2016/8/11.
 */
public class ToolbarHelper {

    protected final Builder mBuilder;

    protected ToolbarHelper(Builder builder) {
        mBuilder = builder;
    }

    public ToolbarHelper init() {
        if (this.mBuilder == null) {
            throw new IllegalStateException("未配置builder");
        }
        Toolbar toolbar = mBuilder.toolbar;
        final SupportFragment fragment = mBuilder.fragment;
        final SupportActivity activity = mBuilder.activity;
        toolbar.setTitle(mBuilder.title);
        toolbar.setSubtitle(mBuilder.subTitle);
//        toolbar.setBackgroundResource(R.drawable.shape);
        if (mBuilder.showBack) {
            toolbar.setNavigationIcon(R.drawable.ic_arrow_back_white_24dp);
            toolbar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    fragment.pop();
                    activity.onBackPressed();
                }

            });
        }

        toolbar.inflateMenu(R.menu.menu_main);
        toolbar.getMenu().findItem(R.id.xiao_neng).setVisible(mBuilder.showXiaoNeng ? true : false);
        toolbar.getMenu().findItem(R.id.action_hierarchy).setVisible(mBuilder.showHierarchy ? true : false);
        toolbar.getMenu().findItem(R.id.action_hierarchy).setIcon(UiHelper.getColorFilterDwawable(R.drawable.ic_format_list_numbered_white_24dp));

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.xiao_neng://小能客服
                        XiaoNeng.getInstance().startSimpleChat(0);
                        break;
                    case R.id.action_hierarchy://试图层级
                        activity.showFragmentStackHierarchyView();
                        break;
                    default:
                        break;
                }
                return true;
            }
        });

        return this;
    }

    public static class Builder {
        private Toolbar toolbar;
        private SupportFragment fragment;
        private SupportActivity activity;

        private String title = "";
        private String subTitle = "";

        private boolean showBack = false;
        private boolean showXiaoNeng = false;
        private boolean showHierarchy = false;

        public Builder(Toolbar toolbar, SupportFragment fragment, SupportActivity activity) {
            this.toolbar = toolbar;
            this.fragment = fragment;
            this.activity = activity;
        }

        public Builder title(String title) {
            this.title = title;
            return this;
        }

        public Builder subTitle(String subTitle) {
            this.subTitle = subTitle;
            return this;
        }

        public Builder showBack(boolean showBack) {
            this.showBack = showBack;
            return this;
        }

        public Builder showXiaoNeng(boolean showXiaoNeng) {
            this.showXiaoNeng = showXiaoNeng;
            return this;
        }

        public Builder showHierarchy(boolean showHierarchy) {
            this.showHierarchy = showHierarchy;
            return this;
        }

        public ToolbarHelper build() {
            initEmptyFieldsWithDefaultValues();
            return new ToolbarHelper(this).init();
        }

        private void initEmptyFieldsWithDefaultValues() {

        }
    }

}
