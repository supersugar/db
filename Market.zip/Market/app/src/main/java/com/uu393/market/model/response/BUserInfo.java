package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/16
 * Descrip    :
 * =====================================================
 */

public class BUserInfo implements Serializable{


    /**
     * token : 98A6F5470454F0DB5619AC50808ACAA8
     * userId : zzgxl
     * uId : 12698745
     * chkMobile : 12698745
     */

    private String token;
    private String userId;
    private String uId;
    private String chkMobile;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUId() {
        return uId;
    }

    public void setUId(String uId) {
        this.uId = uId;
    }

    public String getChkMobile() {
        return chkMobile;
    }

    public void setChkMobile(String chkMobile) {
        this.chkMobile = chkMobile;
    }
}
