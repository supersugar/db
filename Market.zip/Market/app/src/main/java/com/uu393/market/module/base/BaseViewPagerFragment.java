package com.uu393.market.module.base;

import com.uu393.market.view.lazyviewpager.LazyFragmentPagerAdapter;

/**
 * Created by bo on 16/11/25.
 */

public abstract class BaseViewPagerFragment extends BaseFragment implements LazyFragmentPagerAdapter.Laziable{

    public abstract void refresh();
}
