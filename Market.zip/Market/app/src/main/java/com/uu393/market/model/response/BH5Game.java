package com.uu393.market.model.response;

import java.io.Serializable;
import java.util.List;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/2
 * Descrip    :
 * =====================================================
 */

public class BH5Game implements Serializable {

    /**
     * id : 123456
     * icon : kjkjjk.jpg
     * gameName : 御剑情缘
     * typeName : 策略
     * describe : 最好玩的游戏
     * discount : 1
     * androidPackage : Http:1213
     * homeImg : 1
     * gameInfo : 游戏好玩
     * gameImages : ["1.jpg"]
     * language : 中文
     * releaseTime : 2016-10-22
     * APPID : 1213
     */

    private String id;
    private String icon;
    private String gameName;
    private String typeName;
    private String describe;
    private String discount;
    private String androidPackage;

    public String getHomeImg() {
        return homeImg;
    }

    public void setHomeImg(String homeImg) {
        this.homeImg = homeImg;
    }

    private String homeImg;
    private String gameInfo;
    private String language;
    private String releaseTime;
    private String APPID;
    private List<String> imageUrl;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {
        this.describe = describe;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    public String getAndroidPackage() {
        return androidPackage;
    }

    public void setAndroidPackage(String androidPackage) {
        this.androidPackage = androidPackage;
    }

    public String getGameInfo() {
        return gameInfo;
    }

    public void setGameInfo(String gameInfo) {
        this.gameInfo = gameInfo;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getReleaseTime() {
        return releaseTime;
    }

    public void setReleaseTime(String releaseTime) {
        this.releaseTime = releaseTime;
    }

    public String getAPPID() {
        return APPID;
    }

    public void setAPPID(String APPID) {
        this.APPID = APPID;
    }

    public List<String> getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(List<String> imageUrl) {
        this.imageUrl = imageUrl;
    }
}
