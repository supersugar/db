package com.uu898app.model.request;

import com.uu898app.model.GBaseModel;

/**
 * 生成支付宝订单号
 * Created by zhangbo on 2016/7/13.
 */
public class GGenAliPayNo extends GBaseModel{

    /**
     * money : 101
     */

    private String Money;

    public String getMoney() {
        return Money;
    }

    public void setMoney(String money) {
        this.Money = money;
    }
}
