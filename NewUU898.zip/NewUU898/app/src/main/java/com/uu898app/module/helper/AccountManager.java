package com.uu898app.module.helper;

import com.baoyz.treasure.Treasure;
import com.uu898app.app.App;
import com.uu898app.model.request.GLogin;
import com.uu898app.model.response.BUserInfo;
import com.uu898app.util.CommonUtil;
import com.uu898app.util.SharePreferences.SPAccount;
import com.uu898app.util.StringUtils;

/**
 * Created by zhangbo on 2016/7/1.
 */
public class AccountManager {

    public enum Status {
        LOGIN, LOGOUT
    }

    private final static AccountManager INSTANCE = new AccountManager();

    private Status mStatus;

    private String ssid;
    private String userId;

    private BUserInfo userInfo;

    private SPAccount spAccount;

    public AccountManager() {
        spAccount = Treasure.get(App.mContext, SPAccount.class);
    }

    public static AccountManager getInstance() {
        return INSTANCE;
    }

    public Status getStatus() {
        return mStatus;
    }


    public String getSSID() {
        return ssid;
    }

    public boolean isAutoLogin(){
        return spAccount.getIsAutoLogin();
    }

    public GLogin getSaveGLogin(){
        if(StringUtils.isNull(spAccount.getU()) || StringUtils.isNull(spAccount.getP()) ){
            return null;
        }else{
            GLogin model = new GLogin();
            model.setUserName(spAccount.getU());
            model.setPassword(CommonUtil.encryptString(spAccount.getP()));
            model.setUuid(CommonUtil.getDeviceId());
            model.setDecipheringType("0");
            return model;
        }
    }


    public String getUserId() {
        return userId;
    }

    public BUserInfo getUserInfo() {
        return null == userInfo ? spAccount.getUserInfo() : userInfo;
    }

    public void saveLoginInfo(String ssid, String userId) {
        this.ssid = ssid;
        this.userId = userId;
        spAccount.setSsid(ssid);
        spAccount.setUserid(userId);
    }

    public void saveLoginInfoMore(String username, String password, boolean autoLogin, long time) {
        spAccount.setU(username);
        spAccount.setP(password);
        spAccount.setIsAutoLogin(autoLogin);
        spAccount.setTime(time);
    }

    public void setStatus(Status status){
        this.mStatus  = status;
    }

    public void saveUserInfo(BUserInfo bUserInfo) {
        userInfo = bUserInfo;
        spAccount.setUserInfo(bUserInfo);
    }

    public void clearCurrentUserInfo() {
        this.userId = "";
        this.ssid = "";
        this.userInfo = null;
        mStatus = Status.LOGOUT;
        spAccount.clear();
    }
}
