package com.uu393.market.module.center;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.Window;
import android.widget.Toast;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.InstalledHelper;
import com.uu393.market.core.PlayedHelper;
import com.uu393.market.model.response.BGame;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.base.BaseFragment;
import com.uu393.market.module.center.timepicker.listener.OnFinishPListener;
import com.uu393.market.module.center.timepicker.view.TimePickerView;
import com.uu393.market.module.more.AboutFragment;
import com.uu393.market.module.search.SearchActivity;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.eventbus.EventObject;
import com.uu393.market.util.log.L;

import org.greenrobot.eventbus.Subscribe;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import static com.uu393.market.module.center.ShareImgPopWindow.getTime;

/**
 * Created by Administrator on 2017/4/12.
 */

public class TimePickerPopActivity extends Activity implements OnFinishPListener {
    private TimePickerView pvTime;
    public static final String INTENT_KEY_SELECT_DATE = "default_select_date";
    public static final String INTENT_KEY_SELECT_START_OR_END = "select_date_start_or_end";
    private Date mDefaultSelectDate;
    public static final int SEND_START_DATE = 1;//发送开始日期
    public static final int SEND_END_DATE = 2;//发送结束日期
    private int mSendStartOrEnd=0;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pop);
        if (getIntent()!=null){
            Serializable serializableExtra = getIntent().getSerializableExtra(INTENT_KEY_SELECT_DATE);
            if (serializableExtra!=null&&serializableExtra instanceof Date){
                mDefaultSelectDate = (Date) serializableExtra;
            }
            mSendStartOrEnd= getIntent().getIntExtra(INTENT_KEY_SELECT_START_OR_END,0);
        }
        // 时间选择器
        pvTime = new TimePickerView(TimePickerPopActivity.this, TimePickerView.Type.YEAR_MONTH_DAY);
        // 控制时间范围
		 Calendar calendar = Calendar.getInstance();
		 pvTime.setRange(calendar.get(Calendar.YEAR) - 20,
		 calendar.get(Calendar.YEAR));
        if (mDefaultSelectDate!=null){
            pvTime.setTime(mDefaultSelectDate);
        }else {
            pvTime.setTime(new Date());
        }
        pvTime.setCyclic(false);
        pvTime.setCancelable(true);
        // 时间选择后回调
        pvTime.setOnTimeSelectListener(new TimePickerView.OnTimeSelectListener() {

            @Override
            public void onTimeSelect(Date date) {
                if (mSendStartOrEnd==SEND_START_DATE){
                    EB.postAnything(EB.TAG.SEND_SELECT_DATE_IN_SHARE_POP,date,Integer.valueOf(SEND_START_DATE));
                }else if (mSendStartOrEnd==SEND_END_DATE){
                    EB.postAnything(EB.TAG.SEND_SELECT_DATE_IN_SHARE_POP,date,Integer.valueOf(SEND_END_DATE));
                }

            }
        });

        pvTime.setOnTimeUnSelectListener(new TimePickerView.OnTimeUnSelectListener() {
            @Override
            public void onTimeUnSelect() {
                TimePickerPopActivity.this.finish();
            }
        });
        if (mSendStartOrEnd==SEND_START_DATE){
            pvTime.setTitle("请选择开始时间");
        }else if (mSendStartOrEnd==SEND_END_DATE){
            pvTime.setTitle("请选择结束时间");
        }
        pvTime.show();

    }

    @Override
    protected void onResume() {
        super.onResume();
        EB.register(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EB.unregister(this);
    }

    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.TimePicker_kill:
                L.d("---","-------------毁掉");
                TimePickerPopActivity.this.finish();
                break;
        }
    }

    @Override
    public void OnFinish(Object o) {
        finish();
    }
}
