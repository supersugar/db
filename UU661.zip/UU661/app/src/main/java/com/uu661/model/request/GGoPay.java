package com.uu661.model.request;

public class GGoPay {


    /**
     *  "timespan": "1", (发起请求的时间戳)
     "jsonForSignature": "0",(md5（json）)
     "signature": "", (获取的签名)
     "payCode": "", (支付验证码，validType为0可以为空)
     "validType ": "", (验证方式0:不需要验证 1:支付密码。2:手机短信（包括语音。文字）。3：微信。 6：手机密令)
     "killOrderNo": "1000857670"(订单号)

     */
    public long timespan;//发起请求的时间戳
    public String jsonForSignature;//md5（json）
    public String signature;//获取的签名
    public String payCode;//支付验证码，validType为0可以为空
    public int validType;//验证方式 0:不需要验证 1:支付密码。2:手机短信（包括语音。文字）。3：微信。 6：手机密令)
    public String killOrderNo;//订单号
    public String voucherId;//红包id

}
