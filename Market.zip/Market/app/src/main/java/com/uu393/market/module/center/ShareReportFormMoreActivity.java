package com.uu393.market.module.center;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GGetShareFormMore;
import com.uu393.market.model.response.BShareFormMore;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.center.timepicker.view.TimePickerView;
import com.uu393.market.module.center.timepicker.view.WheelTime;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ContactCustomerServicesUtils;
import com.uu393.market.util.DateUtils;
import com.uu393.market.util.ScreenUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.eventbus.EventObject;
import com.uu393.market.view.lazyviewpager.LazyFragmentPagerAdapter;

import org.greenrobot.eventbus.Subscribe;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

// 2017/4/20 UI界面改变，暂未出效果
public class ShareReportFormMoreActivity extends BaseActivity {

    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;

    @Bind(R.id.tv_report_form_time_1)
    TextView mTvReportFormTime1;
    @Bind(R.id.tv_report_form_day_1)
    TextView mTvReportFormDay1;
    @Bind(R.id.tv_report_form_time_2)
    TextView mTvReportFormTime2;
    @Bind(R.id.tv_report_form_day_2)
    TextView mTvReportFormDay2;

    @Bind(R.id.tv_report_form_income)
    TextView mTvReportFormIncome;

    @Bind(R.id.tab_layout_share_report_more)
    TabLayout mTabLayoutShareReportMore;
    @Bind(R.id.view_pager_share_report_more)
    ViewPager mViewPagerShareReportMore;

    @Bind(R.id.tv_contact)
    TextView mTvContact;

    @Bind(R.id.ll_select_date)
    LinearLayout mLlSelectDate;

    @Bind(R.id.ll_share_form_more_no_result)
    LinearLayout mLlShareFormMoreNoResult;
    private ShareReportFormMoreViewPagerAdapter mPagerAdapter;
    private BShareFormMore mShareFormMore;
    private Date mStartDate;//全局起始日期
    private Date mEndDate;//全局结束日期
    private GGetShareFormMore mGetShareFormMore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_report_form_more);
        ButterKnife.bind(this);

        initTitleBar();
        //进入界面，默认请求最近一周记录
        //-----------------------------------
        mGetShareFormMore = new GGetShareFormMore();
        mGetShareFormMore.setEndTime(DateUtils.getNowTime(DateUtils.DATE_SMALL_STR));

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.DAY_OF_MONTH, -7);
        String lastSevenDay = cn.finalteam.toolsfinal.DateUtils.format(calendar.getTime(), "yyyy-MM-dd");
        mGetShareFormMore.setBeginTime(lastSevenDay);

        //-----------------------------------
        initTimePickViewLayout(calendar.getTime(),new Date());
        initTabAndViewPager();
    }

    @Override
    protected void onResume() {
        super.onResume();
        EB.register(this);
        doGetShareFormMore(mGetShareFormMore);
    }

    private void initTitleBar() {
        mTitleBarRight.setVisibility(View.GONE);
        mTitleBarTitle.setText("更多数据");
    }

    private void initView(BShareFormMore shareFormMore) {
        if (shareFormMore!=null){
            mTvReportFormIncome.setText(shareFormMore.getInCome());
        }else {
            mTvReportFormIncome.setText("无数据");
        }
    }

    //时间范围UI更改
    private void initTimePickViewLayout(Date startDate,Date endDate){
        String startDateYear = cn.finalteam.toolsfinal.DateUtils.format(startDate, "yyyy年");
        String startDateMonthAndDay = cn.finalteam.toolsfinal.DateUtils.format(startDate, "MM月dd日");
        String endDateYear = cn.finalteam.toolsfinal.DateUtils.format(endDate, "yyyy年");
        String endDateMonthAndDay = cn.finalteam.toolsfinal.DateUtils.format(endDate, "MM月dd日");
        mTvReportFormTime1.setText(""+startDateYear);
        mTvReportFormDay1.setText(""+startDateMonthAndDay);

        mTvReportFormTime2.setText(""+endDateYear);
        mTvReportFormDay2.setText(""+endDateMonthAndDay);
    }

    private void initTabAndViewPager() {
        if (mPagerAdapter == null) {
            mPagerAdapter = new ShareReportFormMoreViewPagerAdapter(getSupportFragmentManager());
        }
        mViewPagerShareReportMore.setAdapter(mPagerAdapter);
        mTabLayoutShareReportMore.setupWithViewPager(mViewPagerShareReportMore);
    }



    @Override
    protected void onDestroy() {
        super.onDestroy();
        EB.unregister(this);
    }

    @Subscribe
    public void onEvent(BaseEvent event){
        switch (event.tag){
            case EB.TAG.REFRESH_IN_SHARE_MORE_ACTIVITY://获取fragment中刷新数据后回传的数据
                if (event instanceof EventObject){
                    Object result = ((EventObject) event).result;
                    if (result!=null &&result instanceof BShareFormMore){
                        mShareFormMore = (BShareFormMore) result;
                        initView(mShareFormMore);
                    }
                }
                break;
        }

    }

    @OnClick({R.id.title_bar_left, R.id.tv_contact,R.id.ll_select_date})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                super.onBackPressedSupport();
                break;
            case R.id.tv_contact:
                ContactCustomerServicesUtils.doXiaoNeng();
                break;
            case R.id.ll_select_date://选择时间
                // TODO: 2017/4/21 弹出时间选择框
                ToastUtil.showToast(App.mContext,"选择时间");
                showTimePickPop();
                break;
        }
    }


    public class ShareReportFormMoreViewPagerAdapter extends LazyFragmentPagerAdapter {
        private String[] tabTitles = {"安卓", "H5游戏"};//

        public ShareReportFormMoreViewPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        protected Fragment getItem(ViewGroup container, int position) {
            //初次初始化Fragment传过去结果Bean
            ShareReportFormMoreGameKindRecordFragment fragment = ShareReportFormMoreGameKindRecordFragment.newInstance(tabTitles[position],mShareFormMore);
            return fragment;
        }

        @Override
        public int getCount() {
            return tabTitles.length;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return tabTitles[position];
        }
    }

    /*获取分享赚更多数据：APP054
     */
    private void doGetShareFormMore(GGetShareFormMore model) {
        if (model == null) return;
        showLoadToast(ShareReportFormMoreActivity.this);
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetShareFormMore(model, new JsonCallback<BShareFormMore>() {
            @Override
            public void onSuccess(BShareFormMore bShareFormMore, Call call, Response response) {
                hideLoadToast();
                if (bShareFormMore != null) {
                    mShareFormMore = bShareFormMore;
                    initView(mShareFormMore);
                } else {
                    initView(mShareFormMore);
                    ToastUtil.showToast(App.mContext, "未获取到分享信息");
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
                initView(mShareFormMore);
            }
        });

    }


    //===========================时间选择框逻辑=====================================
    private boolean mIsSelectStart = true;//是否是选择起始时间
    private String mSelectStartTime = "";
    private String mSelectEndTime= "";
    private void showTimePickPop(){
        View view = LayoutInflater.from(ShareReportFormMoreActivity.this).inflate(R.layout.popwindow_time_select_share_more, null, false);
        final PopupWindow popupWindow = new PopupWindow(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popupWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popupWindow.setAnimationStyle(android.R.style.Animation_InputMethod);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setFocusable(true);
        WindowManager.LayoutParams lp = ShareReportFormMoreActivity.this.getWindow().getAttributes();
        lp.alpha = 0.5f;
        ShareReportFormMoreActivity.this.getWindow().setAttributes(lp);
        popupWindow.showAtLocation(ShareReportFormMoreActivity.this.getWindow().getDecorView(), Gravity.CENTER | Gravity.BOTTOM, 0, 0);
        popupWindow.update();
        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                mIsSelectStart = true;
                WindowManager.LayoutParams lp = ShareReportFormMoreActivity.this.getWindow().getAttributes();
                lp.alpha = 1.0f;
                ShareReportFormMoreActivity.this.getWindow().setAttributes(lp);
            }
        });

        final TextView tvTimeSelectTitle = (TextView) view.findViewById(R.id.tv_pick_time_share_more_title);//标题
        final TextView tvTimeSelectHint = (TextView) view.findViewById(R.id.tv_pick_time_share_more_hint);//标题下方提示
        Button btnLastOneMonth = (Button) view.findViewById(R.id.btn_pick_time_share_more_one_month);//最近一月记录
        Button btnLastOneWeek = (Button) view.findViewById(R.id.btn_pick_time_share_more_one_week);//最近一周记录
        View timePickerView = view.findViewById(R.id.ll_time_picker);//时间选择器视图
        Button btnCancel = (Button) view.findViewById(R.id.btn_cancel);//取消按钮
        Button btnSubmit= (Button) view.findViewById(R.id.btn_submit);//确定按钮

        final WheelTime wheelTime = new WheelTime(timePickerView, TimePickerView.Type.YEAR_MONTH_DAY);
        // 默认选中当前时间
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int hours = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        wheelTime.setPicker(year, month, day, hours, minute);
        wheelTime.setCyclic(false);
        wheelTime.setStartYear(calendar.get(Calendar.YEAR)-20);
        wheelTime.setEndYear(calendar.get(Calendar.YEAR));

        btnLastOneMonth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
                //查询最近一月
                mGetShareFormMore = new GGetShareFormMore();
                mGetShareFormMore.setEndTime(DateUtils.getNowTime(DateUtils.DATE_SMALL_STR));

                Calendar calendar = Calendar.getInstance();
                calendar.setTime(new Date());
                calendar.add(Calendar.MONTH, -1);
                String lastSevenDay = cn.finalteam.toolsfinal.DateUtils.format(calendar.getTime(), "yyyy-MM-dd");
                mGetShareFormMore.setBeginTime(lastSevenDay);
                EB.postObject(EB.TAG.REFRESH_IN_SHARE_MORE_FRAGMENT,mGetShareFormMore);//传GGetShareFormMore
            }
        });
        btnLastOneWeek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
                //查询今日
                mGetShareFormMore = new GGetShareFormMore();
                mGetShareFormMore.setEndTime(DateUtils.getNowTime(DateUtils.DATE_SMALL_STR));
                mGetShareFormMore.setBeginTime(DateUtils.getNowTime(DateUtils.DATE_SMALL_STR));
                EB.postObject(EB.TAG.REFRESH_IN_SHARE_MORE_FRAGMENT,mGetShareFormMore);//传GGetShareFormMore
            }
        });
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
            }
        });
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mIsSelectStart){//先选择开始时间
                    mIsSelectStart = false;
                    tvTimeSelectTitle.setText("请选择结束时间");
                    try {
                        Date date = WheelTime.dateFormat.parse(wheelTime.getTime());
                        mSelectStartTime = cn.finalteam.toolsfinal.DateUtils.format(date,"yyyy-MM-dd");//选择的开始时间yyyy-MM-dd HH:mm
                        tvTimeSelectHint.setVisibility(View.VISIBLE);
                        tvTimeSelectHint.setText("(已选择开始时间："+mSelectStartTime+")");
                    } catch (ParseException e) {
                        return;
                    }

                }else {//选择结束时间
                    if (TextUtils.isEmpty(mSelectStartTime)){
                        mIsSelectStart = true;
                        tvTimeSelectTitle.setText("请选择开始时间");
                        tvTimeSelectHint.setVisibility(View.VISIBLE);
                        tvTimeSelectHint.setText("");
                        ToastUtil.showToast(App.mContext,"请先选择开始时间");
                        return;
                    }
                    try {
                        Date date = WheelTime.dateFormat.parse(wheelTime.getTime());
                        mSelectEndTime = cn.finalteam.toolsfinal.DateUtils.format(date,"yyyy-MM-dd");;//选择的结束时间
                        Date parseStart = DateUtils.parse(mSelectStartTime, "yyyy-MM-dd");
                        Date parseEnd = DateUtils.parse(mSelectEndTime, "yyyy-MM-dd");
                        if (parseStart!=null&&parseEnd!=null){
                            if (parseStart.compareTo(parseEnd)>0){
                                ToastUtil.showToast(App.mContext,"起始日期不能大于结束日期");
                                return;
                            }
                        }else {
                            return;
                        }
                        mGetShareFormMore = new GGetShareFormMore();
                        mGetShareFormMore.setEndTime(mSelectEndTime);
                        mGetShareFormMore.setBeginTime(mSelectStartTime);
                        popupWindow.dismiss();
                        EB.postObject(EB.TAG.REFRESH_IN_SHARE_MORE_FRAGMENT,mGetShareFormMore);//传GGetShareFormMore
                    } catch (ParseException e) {
                        return;
                    }

                }

            }
        });
    }
    //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^时间选择框逻辑^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

}
