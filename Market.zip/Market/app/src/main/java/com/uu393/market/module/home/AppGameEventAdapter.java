package com.uu393.market.module.home;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.model.response.BHotSomeDetail;

import java.util.ArrayList;
import java.util.List;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/28
 * Descrip    :
 * =====================================================
 */

public class AppGameEventAdapter extends RecyclerView.Adapter<AppGameEventAdapter.EventHolder> {

    private Activity mContext;
    List<BHotSomeDetail> mBHotSomeDetail = new ArrayList<>();

    public AppGameEventAdapter(Activity mContext){
        this.mContext = mContext;

    }

    public void setData(List<BHotSomeDetail> list){
        this.mBHotSomeDetail = list;
        notifyDataSetChanged();
    }

    @Override
    public EventHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_app_game_detail_event, parent, false);
        return new EventHolder(inflate);
    }

    @Override
    public void onBindViewHolder(EventHolder holder, int position) {
        holder.bindItem(position);
    }

    @Override
    public int getItemCount() {
            return mBHotSomeDetail.size();
    }

    class EventHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView eventInfo;
        private ImageView eventKind;
        private LinearLayout mGGameDetail;
        BHotSomeDetail mSomrOne;
        private LinearLayout mGoHuogameDetail;
        public EventHolder(View itemView) {
            super(itemView);
            eventInfo = (TextView) itemView.findViewById(R.id.tv_item_event_info);
            eventKind = (ImageView) itemView.findViewById(R.id.iv_item_event_go);
            mGGameDetail = (LinearLayout) itemView.findViewById(R.id.go_game_detail);
            mGoHuogameDetail = (LinearLayout) itemView.findViewById(R.id.go_huogame_detail);
            mGoHuogameDetail.setOnClickListener(this);

        }
        public void bindItem(int position){
             mSomrOne = mBHotSomeDetail.get(position);
            if (mSomrOne != null){
                eventInfo.setText(mSomrOne.getTitle()+" "+mSomrOne.getAddTime());
            }
        }

        @Override
        public void onClick(View v) {
            Intent intent = new Intent(mContext,HotActionDetailsActivity.class);
            intent.putExtra("id",mSomrOne.getId());

            mContext.startActivity(intent);
        }
    }

    public void refresh(){
        this.notifyDataSetChanged();
    }
}
