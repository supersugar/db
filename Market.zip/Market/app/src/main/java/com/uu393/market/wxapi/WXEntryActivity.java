package com.uu393.market.wxapi;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.lzy.okgo.OkGo;
import com.tencent.mm.opensdk.modelbase.BaseReq;
import com.tencent.mm.opensdk.modelbase.BaseResp;
import com.tencent.mm.opensdk.modelmsg.SendAuth;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.IWXAPIEventHandler;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.Constant;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GDoThirdLogin;
import com.uu393.market.model.response.BUserInfo;
import com.uu393.market.model.response.BWxAccessToken;
import com.uu393.market.model.response.BWxUserInfo;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.h5game.H5WebViewActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;

import java.util.HashMap;

import okhttp3.Call;
import okhttp3.Response;

public class WXEntryActivity extends BaseActivity implements IWXAPIEventHandler {
    private IWXAPI api;
    private String mGameId;
    private String APPID;
    private String mGameUrl;

    private static final int RETURN_MSG_TYPE_LOGIN = 1;//登录的响应
    private static final int RETURN_MSG_TYPE_SHARE = 2;//分享的响应
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        api = WXAPIFactory.createWXAPI(this, Constant.WX_APP_ID);
        api.handleIntent(getIntent(), this);
    }

    @Override
    public void onReq(BaseReq baseReq) {

    }

    @Override
    public void onResp(BaseResp resp) {
        int type = resp.getType();
        if(type==RETURN_MSG_TYPE_LOGIN){
            switch (resp.errCode) {
                case BaseResp.ErrCode.ERR_OK:
                    L.i("微信登录", "发送成功");
                    // TODO:  继续请求，获取微信账户信息
                    if (resp instanceof SendAuth.Resp) {
                        SendAuth.Resp newResp = (SendAuth.Resp) resp;
                        //获取微信传回的code
                        String code = newResp.code;
                        HashMap<String, String> map = new HashMap<>();
                        map.put("appid", Constant.WX_APP_ID);
                        map.put("secret", Constant.WX_APP_SECRET);
                        map.put("code", code);
                        map.put("grant_type", "authorization_code");//这个参数是固定的值

                        OkGo.get(Constant.WX_GET_TOKEN)
                                .params(map)
                                .execute(new JsonCallback<BWxAccessToken>() {
                                    @Override
                                    public void onSuccess(BWxAccessToken bWxAccessToken, Call call, Response response) {
                                        if (bWxAccessToken != null) {
                                            final String accessToken = bWxAccessToken.getAccess_token();
                                            String refresh_token = bWxAccessToken.getRefresh_token();
                                            final String openID = bWxAccessToken.getOpenid();//拿到openid，然后去获取微信用户信息

                                            HashMap<String, String> getInfoMap = new HashMap<>();
                                            getInfoMap.put("access_token", accessToken);
                                            getInfoMap.put("openid", openID);
                                            OkGo.get(Constant.WX_GET_USER_INFO)
                                                    .params(getInfoMap)
                                                    .execute(new JsonCallback<BWxUserInfo>() {
                                                        @Override
                                                        public void onSuccess(BWxUserInfo o, Call call, Response response) {
                                                            if (o != null) {
                                                                /**
                                                                 * {
                                                                 "openid":"OPENID",
                                                                 "nickname":"NICKNAME",
                                                                 "sex":1,
                                                                 "province":"PROVINCE",
                                                                 "city":"CITY",
                                                                 "country":"COUNTRY",
                                                                 "headimgurl": "http://wx.qlogo.cn/mmopen/g3MonUZtNHkdmzicIlibx6iaFqAc56vxLSUfpb6n5WKSYVY0ChQKkiaJSgQ1dZuTOgvLLrhJbERQQ4eMsv84eavHiaiceqxibJxCfHe/0",
                                                                 "privilege":[
                                                                 "PRIVILEGE1",
                                                                 "PRIVILEGE2"
                                                                 ],
                                                                 "unionid": " o6_bmasdasdsad6_2sgVt7hMZOPfL"

                                                                 }
                                                                 * */
                                                                String unionid = o.getUnionid();
                                                                final String nickname = o.getNickname();
                                                                GDoThirdLogin model = new GDoThirdLogin();
                                                                model.setOpenId(unionid);
                                                                model.setToken(accessToken);
                                                                model.setType("4");//微信
                                                                TaskEngine.setTokenUseridPhoneState(1);
                                                                TaskEngine.getInstance().doThirdLogin(model, new JsonCallback<BUserInfo>() {

                                                                    @Override
                                                                    public void onSuccess(BUserInfo userInfo, Call call, Response response) {
                                                                        MobclickAgent.onProfileSignIn("weixin",userInfo.getUserId());//友盟统计用户登录
                                                                        SPUtil.put(App.mContext, "isLogin", true);
                                                                        SPUtil.put(App.mContext, "thirdUserId", nickname);
                                                                        SPUtil.put(App.mContext, "loginType", "2");
                                                                        SPUtil.put(App.mContext, "token", userInfo.getToken());
                                                                        SPUtil.put(App.mContext, "userId", userInfo.getUserId());
                                                                        SPUtil.put(App.mContext, "uId", userInfo.getUId());
                                                                        SPUtil.put(App.mContext, "chkMobile", userInfo.getChkMobile());
                                                                        ToastUtil.showToast(App.mContext, "登录成功");
                                                                        EB.postEmpty(EB.TAG.LOGIN_SUCCESS);
                                                                        mGameId = (String) SPUtil.get(App.mContext,"GameId","");
                                                                        APPID = (String) SPUtil.get(App.mContext,"APPID","");
                                                                        mGameUrl = (String) SPUtil.get(App.mContext,"GameUrl","");
                                                                        if (!TextUtils.isEmpty(mGameId)){
                                                                            Intent intent = new Intent();
                                                                            intent.putExtra("gameId",mGameId);
                                                                            intent.putExtra("APPID",APPID);
                                                                            intent.putExtra("url",mGameUrl);
                                                                            intent.setClass(WXEntryActivity.this,H5WebViewActivity.class);
                                                                            startActivity(intent);
                                                                            SPUtil.put(App.mContext, "GameId", "");
                                                                            SPUtil.put(App.mContext, "APPID", "");
                                                                            SPUtil.put(App.mContext, "GameUrl", "");
                                                                        }/*else {
                                                                            startActivity(new Intent(WXEntryActivity.this, UserCenterActivity.class));
                                                                        }*/

                                                                    }
                                                                });

                                                            }
                                                        }
                                                    });


                                        }
                                    }
                                });
                    }
                    break;
                case BaseResp.ErrCode.ERR_USER_CANCEL:
                case BaseResp.ErrCode.ERR_AUTH_DENIED:
                case BaseResp.ErrCode.ERR_COMM:
                case BaseResp.ErrCode.ERR_UNSUPPORT:
                case BaseResp.ErrCode.ERR_BAN:
                case BaseResp.ErrCode.ERR_SENT_FAILED:
                    EB.postEmpty(EB.TAG.HIDE_LOGINING);
                    break;
            }
        }else if (type==RETURN_MSG_TYPE_SHARE){
            switch (resp.errCode){
                case BaseResp.ErrCode.ERR_OK:
                    ToastUtil.showToast(App.mContext,"分享成功");
                    break;
                case BaseResp.ErrCode.ERR_USER_CANCEL:
                case BaseResp.ErrCode.ERR_AUTH_DENIED:
                case BaseResp.ErrCode.ERR_COMM:
                case BaseResp.ErrCode.ERR_UNSUPPORT:
                case BaseResp.ErrCode.ERR_BAN:
                case BaseResp.ErrCode.ERR_SENT_FAILED:
                    //ToastUtil.showToast(App.mContext,"分享取消");
                    break;
            }
        }

        this.finish();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        api.handleIntent(intent, this);
    }

    @Override
    public void onBackPressedSupport() {
        super.onBackPressedSupport();
        EB.postEmpty(EB.TAG.HIDE_LOGINING);
    }
}
