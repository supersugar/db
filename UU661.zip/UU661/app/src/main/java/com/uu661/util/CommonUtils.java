package com.uu661.util;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.uu661.R;
import com.uu661.app.App;
import com.uu661.model.response.BUpdate;
import com.uu661.network.JsonCallback;
import com.uu661.network.NetConstant;
import com.uu661.network.TaskEngine;

import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URLEncoder;
import java.security.PublicKey;
import java.util.Enumeration;

import cn.finalteam.toolsfinal.ManifestUtils;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Desction:
 * Author:pengjianbo
 * Date:15/10/22 下午3:39
 */
public class CommonUtils {

    private CacheUtil cacheUtil = CacheUtil.get(App.mContext);

    /**
     * 获取设备唯一id
     *
     * @return
     */
    public static String getDeviceId() {
        String deviceId = "";
        try {
            WifiManager wm = (WifiManager) App.mContext.getSystemService(App.mContext.WIFI_SERVICE);
            deviceId = Settings.Secure.getString(App.mContext.getContentResolver(), Settings.Secure.ANDROID_ID);
            if (deviceId == null) {
                deviceId = wm.getConnectionInfo().getMacAddress();
                if (deviceId != null)
                    deviceId = deviceId.replaceAll(":", "");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return deviceId;
    }

    /**
     * 加密字符串
     * String -> byte[] (utf-8格式) -> Rsa加密 -> Base64.encode -> UrlEncoder.encode
     * @param original
     * @return
     */
    public static String encryptString(String original){
        if(StringUtils.isEmpty(original)){
            return "";
        }
        String result = "";
        byte[] dataByteArray = new byte[0];//
        try {
            dataByteArray = original.getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        PublicKey key = NetConstant.Secret.RSA_PUBLIC_KEY;
        byte[] encryptedDataByteArray = RsaHelper.encryptData(dataByteArray, key);
        result = URLEncoder.encode(Base64Helper.encode(encryptedDataByteArray));
        return result;
    }


    /**
     * 获取IMEI
     */
    public static String getIMEI(Context context) {
        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        String imei = tm.getDeviceId();
        if (StringUtils.isEmpty(imei)) {
            imei = "";
        }

        return imei;
    }

    public static String getNetType(Context context) {
        String netType = null;
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (connectivityManager == null) {
                netType = "";
            }

            NetworkInfo info = connectivityManager.getActiveNetworkInfo();
            if (info == null) {
                netType = "";
            }

            String type = info.getTypeName();

            if (type.equalsIgnoreCase("WIFI")) {
                // WIFI
                netType = "wifi";
            } else if (type.equalsIgnoreCase("MOBILE")) {
                // GPRS
                String proxyHost = android.net.Proxy.getDefaultHost();
                if (proxyHost != null && !proxyHost.equals("")) {
                    // WAP
                    netType = "wap";
                } else {
                    netType = "net";
                }
            }
        } catch (Exception ex) {
        }
        if (netType == null || netType.length() == 0) {
            netType = "unknown";
        }
        return netType;
    }


    /**
     * 获取版本名称
     *
     * @param context 上下文
     * @return 版本名称
     */
    public static String getVersionName(Context context) {
        //获取包管理器
        PackageManager pm = context.getPackageManager();
        //获取包信息
        try {
            PackageInfo packageInfo = pm.getPackageInfo(context.getPackageName(), 0);
            //返回版本号
            return packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取版本号
     *
     * @param context 上下文
     * @return 版本号
     */
    public static int getVersionCode(Context context) {
        //获取包管理器
        PackageManager pm = context.getPackageManager();
        //获取包信息
        try {
            PackageInfo packageInfo = pm.getPackageInfo(context.getPackageName(), 0);
            //返回版本号
            return packageInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * 获取App的名称
     *
     * @param context 上下文
     * @return 名称
     */
    public static String getAppName(Context context) {
        PackageManager pm = context.getPackageManager();
        //获取包信息
        try {
            PackageInfo packageInfo = pm.getPackageInfo(context.getPackageName(), 0);
            //获取应用 信息
            ApplicationInfo applicationInfo = packageInfo.applicationInfo;
            //获取albelRes
            int labelRes = applicationInfo.labelRes;
            //返回App的名称
            return context.getResources().getString(labelRes);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 功能描述：金额字符串转换：单位分转成单元
     *
     * @return 转换后的金额字符串
     */
    public static String fenToYuan(Object o) {
        if (o == null)
            return "0.00";
        String s = o.toString();
        if(TextUtils.equals(s , "0.0")){
            return "0.00";
        }
        int len = -1;
        StringBuilder sb = new StringBuilder();
        if (s != null && s.trim().length() > 0 && !s.equalsIgnoreCase("null")) {
            s = removeZero(s);
            if (s != null && s.trim().length() > 0 && !s.equalsIgnoreCase("null")) {
                len = s.length();
                int tmp = s.indexOf("-");
                if (tmp >= 0) {
                    if (len == 2) {
                        sb.append("-0.0").append(s.substring(1));
                    } else if (len == 3) {
                        sb.append("-0.").append(s.substring(1));
                    } else {
                        sb.append(s.substring(0, len - 2)).append(".").append(s.substring(len - 2));
                    }
                } else {
                    if (len == 1) {
                        sb.append("0.0").append(s);
                    } else if (len == 2) {
                        sb.append("0.").append(s);
                    } else {
                        sb.append(s.substring(0, len - 2)).append(".").append(s.substring(len - 2));
                    }
                }
            } else {
                sb.append("0.00");
            }
        } else {
            sb.append("0.00");
        }
        return sb.toString();
    }

    /**
     * 功能描述：金额字符串转换：单位元转成单分
     *
     * @return 转换后的金额字符串
     */
    public static String yuanToFen(Object o) {
        if (o == null)
            return "0";
        String s = o.toString();
        int posIndex = -1;
        String str = "";
        StringBuilder sb = new StringBuilder();
        if (s != null && s.trim().length() > 0 && !s.equalsIgnoreCase("null")) {
            posIndex = s.indexOf(".");
            if (posIndex > 0) {
                int len = s.length();
                if (len == posIndex + 1) {
                    str = s.substring(0, posIndex);
                    if (str == "0") {
                        str = "";
                    }
                    sb.append(str).append("00");
                } else if (len == posIndex + 2) {
                    str = s.substring(0, posIndex);
                    if (str == "0") {
                        str = "";
                    }
                    sb.append(str).append(s.substring(posIndex + 1, posIndex + 2)).append("0");
                } else if (len == posIndex + 3) {
                    str = s.substring(0, posIndex);
                    if (str == "0") {
                        str = "";
                    }
                    sb.append(str).append(s.substring(posIndex + 1, posIndex + 3));
                } else {
                    str = s.substring(0, posIndex);
                    if (str == "0") {
                        str = "";
                    }
                    sb.append(str).append(s.substring(posIndex + 1, posIndex + 3));
                }
            } else {
                sb.append(s).append("00");
            }
        } else {
            sb.append("0");
        }
        str = removeZero(sb.toString());
        if (str != null && str.trim().length() > 0 && !str.trim().equalsIgnoreCase("null")) {
            return str;
        } else {
            return "0";
        }
    }

    /**
     * 功能描述：去除字符串首部为"0"字符
     *
     * @param str 传入需要转换的字符串
     * @return 转换后的字符串
     */
    public static String removeZero(String str) {
        char ch;
        String result = "";
        if (str != null && str.trim().length() > 0 && !str.trim().equalsIgnoreCase("null")) {
            try {
                for (int i = 0; i < str.length(); i++) {
                    ch = str.charAt(i);
                    if (ch != '0') {
                        result = str.substring(i);
                        break;
                    }
                }
            } catch (Exception e) {
                result = "";
            }
        } else {
            result = "";
        }
        return result;

    }

    public static String getIP(Context application) {
        //获取wifi服务
        WifiManager wifiManager = (WifiManager) application.getSystemService(Context.WIFI_SERVICE);
        //判断wifi是否开启
        if (!wifiManager.isWifiEnabled()) {
            try {
                for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements(); ) {
                    NetworkInterface intf = en.nextElement();
                    for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements(); ) {
                        InetAddress inetAddress = enumIpAddr.nextElement();
                        if (!inetAddress.isLoopbackAddress()) {
                            return inetAddress.getHostAddress().toString();
                        }
                    }
                }
            } catch (SocketException e) {
                e.printStackTrace();
            }
        } else {
            WifiInfo wifiInfo = wifiManager.getConnectionInfo();
            int ipAddress = wifiInfo.getIpAddress();
            String ip = intToIp(ipAddress);
            return ip;
        }
        return null;
    }

    private static String intToIp(int i) {

        return (i & 0xFF) + "." +
                ((i >> 8) & 0xFF) + "." +
                ((i >> 16) & 0xFF) + "." +
                (i >> 24 & 0xFF);
    }

    /**
     * 检查更新
     *
     * @param context
     */
    public static void checkUpdate(final Context context, final boolean showMessage) {
        TaskEngine.getInstance().doGetUpdate(new JsonCallback<BUpdate>() {
            @Override
            public void onSuccess(final BUpdate result, Call call, Response response) {
                if (null == result) {
                    if(showMessage){
                        ToastUtil.showToast(context, "检查失败");
                    }
                    return;
                }
                int currentVersionCode = ManifestUtils.getVersionCode(context);
                if (currentVersionCode >= result.versionCode) {
                    if(showMessage){
                        ToastUtil.showToast(context, "已经是最新版本");
                    }
                    return;
                }
                if (currentVersionCode < result.versionCode) {
                    MaterialDialog.Builder builder = new MaterialDialog.Builder(context).title("更新提示").content(result.updateInfo)
                            .positiveText("马上更新").negativeText(result.isForceUpdate == 0 ? "稍候再说" : "").negativeColor(context
                                    .getResources().getColor(R.color.text_lv2)).cancelable(result.isForceUpdate == 0 ? true : false)
                            //是否强制更新，0否  1是
                            .onPositive(new MaterialDialog.SingleButtonCallback() {
                                @Override
                                public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                    Uri uri = Uri.parse(result.packageUrl);
                                    Intent intent = new Intent(Intent.ACTION_VIEW);
                                    intent.setData(uri);
                                    context.startActivity(intent);
                                }
                            });

                    MaterialDialog dialog = builder.build();
                    dialog.show();
                }
            }
        });
    }

}
