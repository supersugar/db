package com.uu661.model;

/**
 * Created by zhangbo on 2016/5/14.
 */
public class BaseModel<T> {


    /**
     * {
         "mode": "app",
         "Type": " app001",
         "token":"98A6F5470454F0DB5619AC50808ACAA8",
         "uuid": "a3432ggfd343bc",
         "signature": "b7d9900502d692893da4ad",
         "Data": {}
        }
     */

    private String platform;//平台
    private String type;//接口类型
    private String appId;//应用编号,固定值 2
    private String deviceId;//手机设备id
    private String token;//用户token
    private String signature;//
    private String message;
    private String status;
    private String version;
    private PageModel page;
    private T data;

    public BaseModel() {
    }

    public boolean isSuccess() {
        return status.equals("0");
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public PageModel getPage() {
        return page;
    }

    public void setPage(PageModel page) {
        this.page = page;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
}
