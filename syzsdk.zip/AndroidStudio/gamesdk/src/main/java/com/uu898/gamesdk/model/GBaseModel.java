package com.uu898.gamesdk.model;


import com.uu898.gamesdk.core.UGCoreHelper;
import com.uu898.gamesdk.utils.AccountManager;
import com.uu898.gamesdk.utils.CommonUtils;
import com.uu898.gamesdk.utils.MD5;

/**
 * Created by zhangbo on 2016/6/20.
 */
public class GBaseModel {
    private String SSID;
    private String appid = UGCoreHelper.APPID;
    private String signature;
    private String uuid = CommonUtils.getDeviceId();

    public GBaseModel() {
        SSID = AccountManager.getInstance().getSSID();
        signature = MD5.getMD5((UGCoreHelper.APPID + UGCoreHelper.APP_KEY + SSID).getBytes());
    }


    public String getSSID() {
        return SSID;
    }

    public void setSSID(String SSID) {
        this.SSID = SSID;
        signature = MD5.getMD5((UGCoreHelper.APPID + UGCoreHelper.APP_KEY + SSID).getBytes());
    }

    public String getAppid() {
        return appid;
    }

    public void setAppid(String appid) {
        this.appid = appid;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }
}
