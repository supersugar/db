package com.uu898app.module.root;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uu898app.R;
import com.uu898app.module.base.BaseLazyFragment;
import com.uu898app.module.home.HomeFragment;
import com.uu898app.util.log.L;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class RootHomeFragment extends BaseLazyFragment {

    public static RootHomeFragment newInstance() {
        Bundle args = new Bundle();
        RootHomeFragment fragment = new RootHomeFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.root_fragment, container, false);
    }

    @Override
    protected void initLazyView(@Nullable Bundle savedInstanceState) {
        L.d("RootHomeFragment.initLazyView");
        if (null == savedInstanceState) {
            loadRootFragment(R.id.fl_container, HomeFragment.newInstance());
        }
    }
}
