package com.uu661.util.eventbus;

/**
 * Created by zhangbo on 2016/6/27.
 */
public class EventEmpty extends BaseEvent{
    public EventEmpty(int t) {
        tag = t;
    }
}
