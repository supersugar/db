package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/28
 * Descrip    :
 * =====================================================
 */

public class GDoCheckUpdate {

    public String getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(String versionCode) {
        this.versionCode = versionCode;
    }

    private String versionCode;// "1”,(版本编号);
}
