package com.uu661.module.common;

import android.os.Bundle;

import com.uu661.R;
import com.uu661.model.response.BDiamond;
import com.uu661.model.response.BUUOrder;
import com.uu661.module.base.BaseSwipeBackActivity;

/**
 * Created by YoKeyword on 16/4/19.
 */
public class PayActivity extends BaseSwipeBackActivity {

    public static final String INTENT_KEY_UU_ORDER = "intent_key_uu_order";//UU订单
    public static final String INTENT_KEY_DIAMOND = "intent_key_diamond";//钻石信息
    public static final String INTENT_KEY_BUY_NUM = "intent_key_buy_num";//购买数量

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_main);
        BUUOrder order = (BUUOrder) getIntent().getSerializableExtra(INTENT_KEY_UU_ORDER);
        BDiamond diamond = (BDiamond) getIntent().getSerializableExtra(INTENT_KEY_DIAMOND);
        int num = getIntent().getIntExtra(INTENT_KEY_BUY_NUM, 0);
        if (savedInstanceState == null) {
            loadRootFragment(R.id.fl_container, PayFragment.newInstance(order, diamond, num));
        }
    }
}
