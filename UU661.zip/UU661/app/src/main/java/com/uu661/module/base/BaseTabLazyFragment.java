package com.uu661.module.base;

import android.widget.Toast;

import com.umeng.analytics.MobclickAgent;

/**
 * 懒加载
 * Created by YoKeyword on 16/6/5.
 */
public abstract class BaseTabLazyFragment extends BaseFragment {
    // 再点一次退出程序时间设置
    private static final long WAIT_TIME = 2000L;
    private long TOUCH_TIME = 0;

    /**
     * 复选
     */
    public abstract void onTabReselected();

    /**
     * 处理回退事件
     *
     * @return
     */
    @Override
    public boolean onBackPressedSupport() {
        if (System.currentTimeMillis() - TOUCH_TIME < WAIT_TIME) {
            MobclickAgent.onKillProcess(_mActivity);
            _mActivity.finish();
            System.exit(0);
        } else {
            TOUCH_TIME = System.currentTimeMillis();
            Toast.makeText(_mActivity, "再按退出", Toast.LENGTH_SHORT).show();
        }
        return true;
    }

}
