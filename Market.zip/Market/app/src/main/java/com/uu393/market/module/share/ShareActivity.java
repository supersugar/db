package com.uu393.market.module.share;

import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.bumptech.glide.Glide;
import com.nineoldandroids.view.ViewPropertyAnimator;
import com.sina.weibo.sdk.api.ImageObject;
import com.sina.weibo.sdk.api.TextObject;
import com.sina.weibo.sdk.api.WebpageObject;
import com.sina.weibo.sdk.api.WeiboMultiMessage;
import com.sina.weibo.sdk.api.share.BaseResponse;
import com.sina.weibo.sdk.api.share.IWeiboHandler;
import com.sina.weibo.sdk.api.share.IWeiboShareAPI;
import com.sina.weibo.sdk.api.share.SendMultiMessageToWeiboRequest;
import com.sina.weibo.sdk.api.share.WeiboShareSDK;
import com.sina.weibo.sdk.auth.AuthInfo;
import com.sina.weibo.sdk.auth.Oauth2AccessToken;
import com.sina.weibo.sdk.auth.WeiboAuthListener;
import com.sina.weibo.sdk.auth.sso.SsoHandler;
import com.sina.weibo.sdk.exception.WeiboException;
import com.sina.weibo.sdk.utils.Utility;
import com.tencent.connect.share.QQShare;
import com.tencent.mm.opensdk.modelmsg.SendMessageToWX;
import com.tencent.mm.opensdk.modelmsg.WXMediaMessage;
import com.tencent.mm.opensdk.modelmsg.WXWebpageObject;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import com.tencent.open.utils.ThreadManager;
import com.tencent.tauth.IUiListener;
import com.tencent.tauth.Tencent;
import com.tencent.tauth.UiError;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.Constant;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.AppCollectRecordHelper;
import com.uu393.market.model.request.GDoThirdLogin;
import com.uu393.market.model.request.GGetGameDetail;
import com.uu393.market.model.response.BGame;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.center.JoinShareEarnActivity;
import com.uu393.market.module.home.AppGameDetailViewPagerAdapter;
import com.uu393.market.module.home.WrapContentHeightViewPager;
import com.uu393.market.module.wbshare.AccessTokenKeeper;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.Base64Helper;
import com.uu393.market.util.GlideRoundTransform;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.ToastUtil;

import java.io.ByteArrayOutputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

import static com.uu393.market.Constant.WB_GET_USER_INFO;
import static com.uu393.market.Constant.WB_SCOPE;

/**
 * =====================================================
 * Created by : wang xian
 * Created on : 2017/4/5
 * Description    : 分享界面
 * =====================================================
 */

public class ShareActivity extends BaseActivity implements IUiListener, IWeiboHandler.Response {
    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right_2)
    ImageButton mTitleBarRight2;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.app_icon)
    ImageView mAppIcon;
    @Bind(R.id.name)
    TextView mName;
    @Bind(R.id.tv_discount)
    TextView mTvDiscount;
    @Bind(R.id.tv_type_size)
    TextView mTvTypeSize;
    @Bind(R.id.tv_detail_bt)
    TextView mTvDetailBt;
    @Bind(R.id.tv_app_info)
    TextView mTvAppInfo;
    @Bind(R.id.iv_click_expand)
    ImageView mIvClickExpand;
    @Bind(R.id.bt_app_detail_share)
    TextView mBtAppDetailShare;
    @Bind(R.id.layout_click_expand)
    RelativeLayout mLayoutClickExpand;
    @Bind(R.id.layout_app_message)
    RelativeLayout mLayoutAppMessage;
    @Bind(R.id.tb_share)
    TabLayout mTbShare;
    @Bind(R.id.view_pager_share)
    WrapContentHeightViewPager mViewPagerShare;
    @Bind(R.id.layout_expand)
    LinearLayout mLayoutExpand;
    @Bind(R.id.et_share_text)
    EditText mEtShareText;
    @Bind(R.id.btn_copy_text)
    Button mBtnCopyText;
    @Bind(R.id.layout_share_wb)
    LinearLayout mLayoutShareWb;
    @Bind(R.id.layout_share_wx)
    LinearLayout mLayoutShareWx;
    @Bind(R.id.layout_share_wx_moments)
    LinearLayout mLayoutShareWxMoments;
    @Bind(R.id.layout_share_qq)
    LinearLayout mLayoutShareQq;
    @Bind(R.id.layout_share_qzone)
    LinearLayout mLayoutShareQzone;
    private String mGameId;
    private BGame mGame = new BGame();
    private AppGameDetailViewPagerAdapter adapter;
    private IWXAPI mWxApi;
    private Tencent mTencent;
//    private WbShareHandler shareHandler;
    private SsoHandler mSsoHandler;

    private IWeiboShareAPI mWeiboShareAPI = null;



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share);
        ButterKnife.bind(this);
        mWxApi = WXAPIFactory.createWXAPI(this, Constant.WX_APP_ID, true);
        mTencent = Tencent.createInstance(Constant.QQ_APP_ID, this);

//        WeiboShareSDK
        if (getIntent() != null) {
            mGameId = getIntent().getStringExtra("gameId");
        }
        doGetGameDetail();
        /*初始化选项卡*/
        AppGameDetailViewPagerAdapter adapter = new AppGameDetailViewPagerAdapter(getSupportFragmentManager(), mGameId);
        mViewPagerShare.setAdapter(adapter);
        mTbShare.setupWithViewPager(mViewPagerShare);

        //微博
//        shareHandler = new WbShareHandler(this);
//        shareHandler.registerApp();
        mWeiboShareAPI = WeiboShareSDK.createWeiboAPI(this,Constant.WB_APP_KEY);
        mWeiboShareAPI.registerApp();
        if (savedInstanceState !=null){
            mWeiboShareAPI.handleWeiboResponse( getIntent(),  this);
        }


    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mTitleBarRight.setChecked(false);

        Map<Object, Object> allAppCollectRecord = AppCollectRecordHelper.getInstance(App.mContext).getAllAppCollectRecord();
        if (allAppCollectRecord.isEmpty() || allAppCollectRecord == null) {
            return;
        }
        Set<Map.Entry<Object, Object>> entrySet = allAppCollectRecord.entrySet();
        Iterator<Map.Entry<Object, Object>> iterator = entrySet.iterator();
        Pattern pattern = Pattern.compile("^[1-9]\\d*$");
        while (iterator.hasNext()) {
            Object value = iterator.next().getValue();
            if (value != null) {
                if (value instanceof String) {
                    if (value instanceof String) {
                        if (pattern.matcher((String) value).matches()) {//匹配游戏id为正整数
                            if (mGameId.equals(value)) {
                                mTitleBarRight.setChecked(true);
                            }
                        }
                    }

                }
            }
        }

    }

    @OnClick({R.id.title_bar_left, R.id.title_bar_right_2, R.id.title_bar_right, R.id.layout_click_expand,
            R.id.btn_copy_text, R.id.layout_share_wb, R.id.layout_share_wx, R.id.layout_share_wx_moments, R.id.layout_share_qq, R.id.layout_share_qzone})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left://回退
                super.onBackPressedSupport();
                break;
            case R.id.title_bar_right_2://分享说明
                Intent intent = new Intent(ShareActivity.this, JoinShareEarnActivity.class);
                startActivity(intent);
                break;
            case R.id.title_bar_right://收藏
                if (mTitleBarRight.isChecked()) {

                    if (mGame != null) {
                        if (!mGame.getPackageName().equals("")) {
                            AppCollectRecordHelper.getInstance(App.mContext).addOneAppCollectRecord(mGame.getPackageName(), mGame.getId());
                            ToastUtil.showToast(App.mContext, "收藏成功");
                        }
                    }
                }else {
                    if (!mGame.getPackageName().equals("")) {
                        AppCollectRecordHelper.getInstance(App.mContext).removeOneAppCollectRecord(mGame.getPackageName());
                        ToastUtil.showToast(App.mContext, "取消收藏");
                    }

                }


                break;
            case R.id.layout_click_expand://点击展开详情
                String text = mBtAppDetailShare.getText().toString().trim();
                if (text.equals("展开")) {
                    mBtAppDetailShare.setText("收起");
//                    mIvClickExpand
                    ViewPropertyAnimator.animate(mIvClickExpand).rotation(180f);
                    mLayoutExpand.setVisibility(View.VISIBLE);

                } else {
                    mBtAppDetailShare.setText("展开");
                    ViewPropertyAnimator.animate(mIvClickExpand).rotation(360f);
                    mLayoutExpand.setVisibility(View.GONE);
                }

                break;
            case R.id.btn_copy_text://复制文本
                if (TextUtils.isEmpty(mEtShareText.getText().toString().trim())) {
                    ToastUtil.showToast(App.mContext, "请输入分享文案");
                } else {
                    ClipboardManager service = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    service.setText(mEtShareText.getText().toString());
                    ToastUtil.showToast(App.mContext, "已成功复制到粘贴板");
                }

                break;
            case R.id.layout_share_wb://微博分享
                    doShareWB();

                break;
            case R.id.layout_share_wx://微信分享
                doWXShare(SendMessageToWX.Req.WXSceneSession);
                break;
            case R.id.layout_share_wx_moments://朋友圈分享
                doWXShare(SendMessageToWX.Req.WXSceneTimeline);
                break;
            case R.id.layout_share_qq://QQ分享
                shareToQQToFriends();
                break;
            case R.id.layout_share_qzone://QQ空间分享
                shareToQZone();
                break;
        }
    }


    private void doGetGameDetail() {
        GGetGameDetail model = new GGetGameDetail(mGameId);
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetGameDetail(model, new JsonCallback<BGame>() {
            @Override
            public void onSuccess(BGame bGame, Call call, Response response) {

                mGame = bGame;
                int defaultAndError = ImageHelper.randomImage();
                Glide.with(App.mContext).load(mGame.getIcon())
                        .error(defaultAndError)
                        .placeholder(defaultAndError)
                        .transform(new GlideRoundTransform(App.mContext, 10))
                        .into(mAppIcon);

                mName.setText(mGame.getGameName());
                if (mGame.getDiscount() != null && mGame.getDiscount().equals("10")) {
                    mTvDiscount.setVisibility(View.GONE);
                } else {
                    mTvDiscount.setVisibility(View.VISIBLE);
                    mTvDiscount.setText(mGame.getDiscount() + "折");
                }
                mTvTypeSize.setText(mGame.getTypeName() + " / " + mGame.getSize());
                if (mGame.getTypeName().equals("BT游戏")) {
                    mTvDetailBt.setVisibility(View.VISIBLE);
                } else {
                    mTvDetailBt.setVisibility(View.GONE);
                }
                mTvAppInfo.setText(mGame.getGameInfo());

            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
            }

        });
    }
    //===============微信、朋友圈分享=======================
    private void doWXShare(int wx) {
        if (!mWxApi.isWXAppInstalled()){
            ToastUtil.showToast(App.mContext,"未安装微信");
            return;
        }

        if (mGame == null) return;
        WXWebpageObject webpageObject = new WXWebpageObject();
        webpageObject.webpageUrl = "http://www.shouyouzhu.com/";
        WXMediaMessage msg = new WXMediaMessage(webpageObject);
        msg.title = mGame.getGameName();//标题
        if (Base64Helper.decodeToHtml(mGame.getGameInfo()).length()>1024){
            msg.description = Base64Helper.decodeToHtml(mGame.getGameInfo()).substring(0,1024);
        }else {
            msg.description = Base64Helper.decodeToHtml(mGame.getGameInfo());
        }
        Bitmap thumb = BitmapFactory.decodeResource(getResources(), R.drawable.ic_logo);
        msg.thumbData = bmpToByteArray(thumb, true);//微信缩略图大小限制为32k一下，超过无法调起分享
        SendMessageToWX.Req req = new SendMessageToWX.Req();
        req.transaction = buildTransaction("uushouyou");
        req.scene = wx;
        req.message = msg;
        mWxApi.sendReq(req);
    }

    private String buildTransaction(final String type) {

        return (type == null) ? String.valueOf(System.currentTimeMillis()) : type + System.currentTimeMillis();
    }

    public static byte[] bmpToByteArray(final Bitmap bmp, final boolean needRecycle) {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, output);
        if (needRecycle) {
            bmp.recycle();
        }
        byte[] result = output.toByteArray();
        try {
            output.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    //^^^^^^^^^^^^^^^微信、朋友圈分享^^^^^^^^^^^^^^^^^^^^^^^

    //===============QQ空间=======================
    public void shareToQZone() {
        if (mGame == null) return;
        Bundle params = new Bundle();
        params.putInt(QQShare.SHARE_TO_QQ_KEY_TYPE, QQShare.SHARE_TO_QQ_TYPE_DEFAULT);
        params.putString(QQShare.SHARE_TO_QQ_TITLE, mGame.getGameName());
        params.putString(QQShare.SHARE_TO_QQ_SUMMARY, Base64Helper.decodeToHtml(mGame.getGameInfo()));
        params.putString(QQShare.SHARE_TO_QQ_TARGET_URL, "http://www.shouyouzhu.com/");
        params.putString(QQShare.SHARE_TO_QQ_IMAGE_URL, mGame.getIcon());
        params.putString(QQShare.SHARE_TO_QQ_APP_NAME, "UU手游");
        params.putInt(QQShare.SHARE_TO_QQ_EXT_INT, QQShare.SHARE_TO_QQ_FLAG_QZONE_AUTO_OPEN);
        mTencent.shareToQQ(this, params, this);
    }

    @Override
    public void onComplete(Object o) {
        ToastUtil.showToast(App.mContext, "分享成功");
    }

    @Override
    public void onError(UiError uiError) {
        ToastUtil.showToast(App.mContext, uiError.errorMessage);
    }

    @Override
    public void onCancel() {
        ToastUtil.showToast(App.mContext, "您已取消分享");
    }
    //^^^^^^^^^^^^^^^QQ空间^^^^^^^^^^^^^^^^^^^^^^^


    //===============QQ=======================

    public void shareToQQToFriends(){
        if (mGame == null) return;
        Bundle bundle = new Bundle();
        bundle.putString(QQShare.SHARE_TO_QQ_TARGET_URL, "http://www.shouyouzhu.com/");
        bundle.putString(QQShare.SHARE_TO_QQ_TITLE, mGame.getGameName());
        bundle.putString(QQShare.SHARE_TO_QQ_IMAGE_URL, mGame.getIcon());
        bundle.putString(QQShare.SHARE_TO_QQ_APP_NAME, "UU手游");
        bundle.putString(QQShare.SHARE_TO_QQ_SUMMARY, Base64Helper.decodeToHtml(mGame.getGameInfo()));

        mTencent.shareToQQ(this, bundle , BaseUiListener);
    }

    //^^^^^^^^^^^^^^^QQ^^^^^^^^^^^^^^^^^^^^^^^


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (mTencent != null) {
            Tencent.onActivityResultData(requestCode, resultCode, data, this);
        }
        super.onActivityResult(requestCode, resultCode, data);
    }



    IUiListener BaseUiListener = new IUiListener() {
        @Override
        public void onCancel() {
            ToastUtil.showToast(App.mContext, "您已取消分享");
        }
        @Override
        public void onComplete(Object response) {
            ToastUtil.showToast(App.mContext, "分享成功");
        }
        @Override
        public void onError(UiError e) {
            ToastUtil.showToast(App.mContext, e.errorMessage);
        }
    };


    //===============微博=======================
    private void doShareWB(){
        sendMessage(true,true);
    }

    /**
     * 第三方应用发送请求消息到微博，唤起微博分享界面。
     */
    private void sendMessage(boolean hasText, boolean hasImage) {
        sendMultiMessage(hasText, hasImage);
    }

    /**
     * 第三方应用发送请求消息到微博，唤起微博分享界面。
     */
    private void sendMultiMessage(boolean hasText, boolean hasImage) {


        WeiboMultiMessage weiboMessage = new WeiboMultiMessage();
        if (hasText) {
            weiboMessage.textObject = getTextObj();
        }
        if (hasImage) {
            weiboMessage.imageObject = getImageObj();
        }
        SendMultiMessageToWeiboRequest request = new SendMultiMessageToWeiboRequest();
        request.transaction = String.valueOf(System.currentTimeMillis());
        request.multiMessage = weiboMessage;
        AuthInfo authInfo = new AuthInfo(App.mContext, Constant.WB_APP_KEY, Constant.WB_REDIRECT_URL, Constant.WB_SCOPE);
        Oauth2AccessToken accessToken = AccessTokenKeeper.readAccessToken(getApplicationContext());
        String token = "";
        if (accessToken != null) {
            token = accessToken.getToken();
        }
        mWeiboShareAPI.sendRequest(this, request, authInfo, token, new WeiboAuthListener() {

            @Override
            public void onWeiboException( WeiboException arg0 ) {
                ToastUtil.showToast(App.mContext, "分享失败");
            }

            @Override
            public void onComplete( Bundle bundle ) {
                Oauth2AccessToken newToken = Oauth2AccessToken.parseAccessToken(bundle);
                AccessTokenKeeper.writeAccessToken(getApplicationContext(), newToken);
                ToastUtil.showToast(App.mContext, "分享成功");
            }

            @Override
            public void onCancel() {
                ToastUtil.showToast(App.mContext, "您已取消分享");
            }
        });

    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        mWeiboShareAPI.handleWeiboResponse(intent,this);
    }
    @Override
    public void onResponse(BaseResponse baseResponse) {
        if (baseResponse != null){
            switch (baseResponse.errCode){
            }
        }
    }

    /**
     * 获取分享的文本模板。
     */
    private String getSharedText() {
        int formatId = R.string.weibosdk_demo_share_text_template;
        String format = getString(formatId);
        String text = format;
        //防止数字超过微博规定
        if (mGame.getGameInfo().length()>120){
            text = mGame.getGameInfo().substring(0,120)+"#UU手游# http://www.shouyouzhu.com/";
        }else {
            text = mGame.getGameInfo()+"#UU手游# http://www.shouyouzhu.com/";
        }

        return text;
    }


    /**
     * 创建文本消息对象。
     * @return 文本消息对象。
     */
    private TextObject getTextObj() {
        TextObject textObject = new TextObject();
        textObject.text = getSharedText();
        textObject.title = "UU手游";
        textObject.actionUrl = "http://www.shouyouzhu.com/";
        return textObject;
    }

    /**
     * 创建图片消息对象。
     * @return 图片消息对象。
     */
    private ImageObject getImageObj() {
        ImageObject imageObject = new ImageObject();
        Bitmap  bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_logo);
        imageObject.setImageObject(bitmap);
        return imageObject;
    }
    /**
     * 创建多媒体（网页）消息对象。
     *
     * @return 多媒体（网页）消息对象。
     */
    private WebpageObject getWebpageObj() {
        WebpageObject mediaObject = new WebpageObject();
        mediaObject.identify = Utility.generateGUID();
        mediaObject.title ="测试title";
        mediaObject.description = "测试描述";
        Bitmap  bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_logo);
        // 设置 Bitmap 类型的图片到视频对象里         设置缩略图。 注意：最终压缩过的缩略图大小不得超过 32kb。
        mediaObject.setThumbImage(bitmap);
        mediaObject.actionUrl = "http://news.sina.com.cn/c/2013-10-22/021928494669.shtml";
        mediaObject.defaultText = "Webpage 默认文案";
        return mediaObject;
    }
    //^^^^^^^^^^^^^^^微博^^^^^^^^^^^^^^^^^^^^^^^
}
