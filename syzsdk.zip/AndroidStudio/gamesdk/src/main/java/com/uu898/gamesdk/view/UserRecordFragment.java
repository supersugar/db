package com.uu898.gamesdk.view;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.uu898.gamesdk.R;
import com.uu898.gamesdk.core.ResourceUtils;

/**
 * 交易记录页面
 * 由两部分组成:
 *  头部:点击可弹出pop,选择 消费记录 或 充值记录, 默认加载消费记录页面
 *  内容:FrameLayout的container,用来加载消费记录页和充值记录页
 *  消费记录页 UserPayRecordFragment
 *  充值记录页 UserRechargeMainFragment
 */
public class UserRecordFragment extends BaseFragment {

    private static final int TYPE_XF = 0;//消费
    private static final int TYPE_CZ = 1;//充值

    private View mTitleBar;
    private ImageButton mTitleBack;
    private TextView mTitleTv;

    private PopupWindow mPopupWindow;

    private int mCurrentType = TYPE_XF;

    public static UserRecordFragment newInstance() {
        Bundle args = new Bundle();
        UserRecordFragment fragment = new UserRecordFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_record"), container, false);
        return view;
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mTitleBar = view.findViewById(getId("ug_title_bar"));
        mTitleBack = (ImageButton) view.findViewById(getId("ug_bt_title_left"));
        mTitleTv = (TextView) view.findViewById(getId("ug_tv_title"));
        mTitleTv.setText("消费记录");


        mTitleTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupWindow();
            }
        });

        mTitleBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _mActivity.onBackPressed();
            }
        });

        loadRootFragment(R.id.fl_container, UserPayRecordFragment.newInstance());
    }

    private void showPopupWindow() {
        if(null!= mPopupWindow && mPopupWindow.isShowing()){
            mPopupWindow.dismiss();
            return;
        }
        Drawable up = getResources().getDrawable(R.drawable.ug_ic_title_up);
        up.setBounds(0, 0, up.getMinimumWidth(), up.getMinimumHeight());
        mTitleTv.setCompoundDrawables(null, null, up, null);

        View popupView = _mActivity.getLayoutInflater().inflate(R.layout.ug_record_pop, null);

        mPopupWindow = new PopupWindow(_mActivity);
        mPopupWindow.setContentView(popupView);
        mPopupWindow.setWidth(-1);
        mPopupWindow.setHeight(-2);
        //        mPopupWindow.setAnimationStyle(R.style.anim_popup_window);
        mPopupWindow.setBackgroundDrawable(_mActivity.getResources().getDrawable(R.drawable.ug_dialog_white_bg));
        mPopupWindow.setFocusable(true);
        mPopupWindow.setOutsideTouchable(true);

        mPopupWindow.showAsDropDown(mTitleBar);

        mPopupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                Drawable down = getResources().getDrawable(R.drawable.ug_ic_title_down);
                down.setBounds(0, 0, down.getMinimumWidth(), down.getMinimumHeight());
                mTitleTv.setCompoundDrawables(null, null, down, null);
            }
        });

        mPopupWindow.update();

        View tvXf = popupView.findViewById(R.id.ug_bt_xf);
        View tvCz = popupView.findViewById(R.id.ug_bt_cz);
        final ImageView ivXf = (ImageView) popupView.findViewById(R.id.ug_iv_xf_check);
        final ImageView ivCz = (ImageView) popupView.findViewById(R.id.ug_iv_cz_check);

        tvXf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCurrentType = TYPE_XF;
                mPopupWindow.dismiss();
                ivXf.setVisibility(View.VISIBLE);
                ivCz.setVisibility(View.GONE);
                mTitleTv.setText("消费记录");
                loadRootFragment(R.id.fl_container, UserPayRecordFragment.newInstance());
            }
        });
        tvCz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCurrentType = TYPE_CZ;
                mPopupWindow.dismiss();
                ivXf.setVisibility(View.GONE);
                ivCz.setVisibility(View.VISIBLE);
                mTitleTv.setText("充值记录");
                loadRootFragment(R.id.fl_container, UserRechargeMainFragment.newInstance());
            }
        });

        if(mCurrentType == TYPE_XF){
            ivXf.setVisibility(View.VISIBLE);
            ivCz.setVisibility(View.GONE);
        }else if(mCurrentType == TYPE_CZ){
            ivXf.setVisibility(View.GONE);
            ivCz.setVisibility(View.VISIBLE);
        }


    }


}
