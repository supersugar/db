package com.uu393.market.view.progressbutton;

import android.app.DownloadManager;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.GradientDrawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;

import com.lzy.okserver.download.DownloadService;
import com.uu393.market.R;
import com.uu393.market.module.home.ApkListAdapter;


public abstract class ProcessButton extends FlatButton {

    private double mProgress;//进度
    private double mMaxProgress;//最大进度值
    private double mMinProgress;//最小进度值

    private GradientDrawable mProgressBackground;//白色背景,灰色边框,圆角,下载的时候整个按钮的背景色
    private GradientDrawable mProgressDrawable;//灰色背景,圆角,下载的时候已下载的部分的颜色
    private GradientDrawable mCompleteDrawable;//结束时的背景
    private GradientDrawable mErrorDrawable;//其他状态的背景

    private int mTextColorNormal;//文本内容颜色：正常状态
    private int mTextColorLoading;//文本内容颜色：加载状态

    public ProcessButton(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context, attrs);
    }

    public ProcessButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public ProcessButton(Context context) {
        super(context);
        init(context, null);
    }

    private void init(Context context, AttributeSet attrs) {
        mMinProgress = 0;
        mMaxProgress = 100;

        mTextColorNormal = getColor(R.color.blue);
        mTextColorLoading = getColor(R.color.text_lv2);

        //白色背景,蓝色边框,圆角,下载的时候整个按钮的背景色
        mProgressBackground = (GradientDrawable) getDrawable(R.drawable.third_pb_progress_bg).mutate();
        mProgressBackground.setCornerRadius(getCornerRadius());

        //蓝色背景,圆角,下载的时候已下载的部分的颜色
        mProgressDrawable = (GradientDrawable) getDrawable(R.drawable.third_pb_progress).mutate();
        mProgressDrawable.setCornerRadius(getCornerRadius());

        mCompleteDrawable = (GradientDrawable) getDrawable(R.drawable.third_pb_complete).mutate();
        mCompleteDrawable.setCornerRadius(getCornerRadius());

        mErrorDrawable = (GradientDrawable) getDrawable(R.drawable.third_pb_error).mutate();
        mErrorDrawable.setCornerRadius(getCornerRadius());

        if (attrs != null) {
            TypedArray attr = getTypedArray(context, attrs, R.styleable.ProcessButton);
            if (null != attr) {
                try {
                    mTextColorNormal = attr.getColor(R.styleable.ProcessButton_pb_text_color_normal, mTextColorNormal);
                    mTextColorLoading = attr.getColor(R.styleable.ProcessButton_pb_text_color_loading, mTextColorLoading);
                } finally {
                    attr.recycle();
                }
            }
        }
    }


    public void setProgress(double progress) {
        mProgress = progress;
        if (mProgress > mMinProgress) {
            onProgress();
        }

        invalidate();
    }


    public void setProgress(String text) {
        setProgress(0, text);

    }

    public void setProgress(double progress, String text) {
        mProgress = progress;
        setText(text);
        if (mProgress == mMinProgress) {//下载
            setTextColor(mTextColorNormal);
            setBackgroundCompat(getNormalDrawable());
        } else if (mProgress == mMaxProgress) {
            setTextColor(mTextColorNormal);
            setBackgroundCompat(getNormalDrawable());
        } else if (mProgress < mMinProgress) {
            setTextColor(mTextColorNormal);
            setBackgroundCompat(getNormalDrawable());
        } else {
            setTextColor(mTextColorLoading);
            setBackgroundCompat(getProgressBackground());
        }
        invalidate();

    }


    protected void onProgress() {

    }


    @Override
    protected void onDraw(Canvas canvas) {
        // progress
        if (mProgress > mMinProgress && mProgress < mMaxProgress) {
            drawProgress(canvas);
        }

        super.onDraw(canvas);
    }

    public abstract void drawProgress(Canvas canvas);

    public double getProgress() {
        return mProgress;
    }

    public double getMaxProgress() {
        return mMaxProgress;
    }

    public double getMinProgress() {
        return mMinProgress;
    }

    public GradientDrawable getProgressDrawable() {
        return mProgressDrawable;
    }

    public GradientDrawable getCompleteDrawable() {
        return mCompleteDrawable;
    }

    public void setProgressDrawable(GradientDrawable progressDrawable) {
        mProgressDrawable = progressDrawable;
    }

    public void setCompleteDrawable(GradientDrawable completeDrawable) {
        mCompleteDrawable = completeDrawable;
    }

    public void setNormalText(CharSequence normalText) {
        super.setNormalText(normalText);
        if (mProgress == mMinProgress) {
            setText(normalText);
        }
    }

    public void setErrorDrawable(GradientDrawable errorDrawable) {
        mErrorDrawable = errorDrawable;
    }

    public GradientDrawable getProgressBackground() {
        return mProgressBackground;
    }

    @Override
    public Parcelable onSaveInstanceState() {
        Parcelable superState = super.onSaveInstanceState();
        SavedState savedState = new SavedState(superState);
        savedState.mProgress = mProgress;

        return savedState;
    }

    @Override
    public void onRestoreInstanceState(Parcelable state) {
        if (state instanceof SavedState) {
            SavedState savedState = (SavedState) state;
            mProgress = savedState.mProgress;
            super.onRestoreInstanceState(savedState.getSuperState());
            setProgress(mProgress);
        } else {
            super.onRestoreInstanceState(state);
        }
    }


    /**
     * A {@link android.os.Parcelable} representing the {@link ProcessButton}'s
     * state.
     */
    public static class SavedState extends BaseSavedState {

        private double mProgress;

        public SavedState(Parcelable parcel) {
            super(parcel);
        }

        private SavedState(Parcel in) {
            super(in);
            mProgress = in.readInt();
        }

        @Override
        public void writeToParcel(Parcel out, int flags) {
            super.writeToParcel(out, flags);
            out.writeDouble(mProgress);
        }

        public static final Creator<SavedState> CREATOR = new Creator<SavedState>() {

            @Override
            public SavedState createFromParcel(Parcel in) {
                return new SavedState(in);
            }

            @Override
            public SavedState[] newArray(int size) {
                return new SavedState[size];
            }
        };
    }
}
