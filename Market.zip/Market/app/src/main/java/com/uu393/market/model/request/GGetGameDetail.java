package com.uu393.market.model.request;

public class GGetGameDetail {

    public String id;//游戏id

    public GGetGameDetail(String id) {
        this.id = id;
    }
}
