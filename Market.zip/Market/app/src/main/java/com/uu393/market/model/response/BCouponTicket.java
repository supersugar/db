package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    :
 * =====================================================
 */

public class BCouponTicket implements Serializable {
    /**
     * vMoney : 123
     * condition : 20
     * gameName : 御剑情缘
     * gameID : 1
     * expireTime : 2017-04-11 00:00:00
     * explain:
     */

    private String vMoney;
    private String condition;
    private String gameName;
    private String gameID;
    private String expireTime;
    private String explain;

    public String getExplain() {
        return explain;
    }

    public void setExplain(String explain) {
        this.explain = explain;
    }

    public String getVMoney() {
        return vMoney;
    }

    public void setVMoney(String vMoney) {
        this.vMoney = vMoney;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }

    public String getGameID() {
        return gameID;
    }

    public void setGameID(String gameID) {
        this.gameID = gameID;
    }

    public String getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(String expireTime) {
        this.expireTime = expireTime;
    }
}
