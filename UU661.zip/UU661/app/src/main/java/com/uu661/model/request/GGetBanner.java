package com.uu661.model.request;

public class GGetBanner {

    public String imgCount = "";//广告图片位置id，首页广告图片轮换传1  图片数量，不传默认为3
    public int regStatus = 0;//

    public GGetBanner(int regStatus) {
        this.regStatus = regStatus;
    }
}
