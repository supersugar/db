package com.uu393.market.module.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.Constant;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GDoFindPassword;
import com.uu393.market.model.request.GGetPhoneCode;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ContactCustomerServicesUtils;
import com.uu393.market.util.RsaHelper;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

public class FindPassWrodActivity extends BaseActivity {

    @Bind(R.id.et_find_pass_account_input)
    EditText mEtFindPassAccountInput;
    @Bind(R.id.et_find_pass_code)
    EditText mEtFindPassCode;
    @Bind(R.id.tv_find_pass_get_code)
    Button mTvFindPassGetCode;
    @Bind(R.id.et_find_pass_set_new_pass)
    EditText mEtFindPassSetNewPass;
    @Bind(R.id.et_find_pass_verify_new_pass)
    EditText mEtFindPassVerifyNewPass;
    @Bind(R.id.btn_find_pass_go)
    Button mBtnFindPassGo;
    @Bind(R.id.tv_find_pass_contact)
    TextView mTvFindPassContact;
    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    private String mUserId;
    private String mEtPhoneCode;
    private String mNewPassword;
    private String mNewPasswordVerify;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.find_pass);
        ButterKnife.bind(this);
        initTitleBar();
    }

    private void initTitleBar() {
        mTitleBarRight.setVisibility(View.GONE);
        mTitleBarTitle.setText("找回密码");
    }

    @OnClick({R.id.title_bar_left, R.id.tv_find_pass_get_code, R.id.btn_find_pass_go, R.id.tv_find_pass_contact})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                super.onBackPressedSupport();
                break;
            case R.id.tv_find_pass_get_code://获取验证码
                doGetPhoneCode();
                break;
            case R.id.btn_find_pass_go://提交
                doFindPassword();
                break;
            case R.id.tv_find_pass_contact://联系客服
                ContactCustomerServicesUtils.doXiaoNeng();
                break;
        }
    }

    private void doGetPhoneCode() {
        mUserId = mEtFindPassAccountInput.getText().toString().trim();
        if (StringUtils.isEmpty(mUserId)) {
            ToastUtil.showToast(App.mContext, "请输入账号");
            return;
        }
        final CountDownTimer timer = new CountDownTimer(60000, 1000, mTvFindPassGetCode, "获取验证码");
        timer.start();
        GGetPhoneCode model = new GGetPhoneCode();
        model.setType(Constant.GET_PHONE_CODE_TYPE_7);//找回密码
        model.setPhoneNo("");
        model.setUserId(mUserId);
        TaskEngine.setTokenUseridPhoneState(1);//找回密码的获取验证码，不能传token
        TaskEngine.getInstance().doGetPhoneCode(model, new JsonCallback<Object>() {
            @Override
            public void onSuccess(Object bPhoneCode, Call call, Response response) {
                /*
                * Status 1 发送次数超过限制，请查看手机收到的验证码
                        2 手机号码格式不正确
                        3 该手机号在黑名单中
                        4 该手机号已被禁用
                        5 该用户没有绑定手机号
                * */
                ToastUtil.showToast(App.mContext, "短信验证码已发送至您的手机");

            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                timer.cancel();
                mTvFindPassGetCode.setEnabled(true);
                mTvFindPassGetCode.setText("获取验证码");
            }
        });
    }

    private void doFindPassword() {
        mUserId = mEtFindPassAccountInput.getText().toString().trim();
        mEtPhoneCode = mEtFindPassCode.getText().toString().trim();
        mNewPassword = mEtFindPassSetNewPass.getText().toString().trim();
        mNewPasswordVerify = mEtFindPassVerifyNewPass.getText().toString().trim();

        if (StringUtils.isEmpty(mUserId)) {
            ToastUtil.showToast(App.mContext, "请输入账号");
            return;
        }
        if (StringUtils.isEmpty(mEtPhoneCode)) {
            ToastUtil.showToast(App.mContext, "请输入验证码");
            return;
        }
        if (StringUtils.isEmpty(mNewPassword)) {
            ToastUtil.showToast(App.mContext, "请输入密码");
            return;
        }
        if (StringUtils.isEmpty(mNewPassword) || (!mNewPassword.equals(mNewPasswordVerify))) {
            ToastUtil.showToast(App.mContext, "两次密码输入不一致");
            return;
        }
        GDoFindPassword model = new GDoFindPassword();
        model.setUserId(mUserId);
        model.setCheckCode(mEtPhoneCode);
        model.setPassword(RsaHelper.encryptDataFromStr(mNewPasswordVerify, RsaHelper.RSA_PUBLIC_KEY));//密码需要加密
        model.setDecipheringType("0");
        TaskEngine.setTokenUseridPhoneState(1);//找回密码，token传 ""
        TaskEngine.getInstance().doFindPassword(model, new JsonCallback<Object>() {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                ToastUtil.showToast(App.mContext, "设置成功");
                FindPassWrodActivity.this.startActivity(new Intent(FindPassWrodActivity.this, LoginActivity.class));
                FindPassWrodActivity.this.finish();
            }
        });
    }
}
