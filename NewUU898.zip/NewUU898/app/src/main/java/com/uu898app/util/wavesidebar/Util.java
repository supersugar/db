package com.uu898app.util.wavesidebar;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.uu898app.model.response.BGame;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangbo on 2016/7/18.
 */
public class Util {

    private static final String s = "[{\"firstCharactor\":\"A\",\"type\":1},{\"firstCharactor\":\"B\",\"type\":1},{\"firstCharactor\":\"C\",\"type\":1},{\"firstCharactor\":\"D\",\"type\":1},{\"firstCharactor\":\"E\",\"type\":1},{\"firstCharactor\":\"F\",\"type\":1},{\"firstCharactor\":\"G\",\"type\":1},{\"firstCharactor\":\"H\",\"type\":1},{\"firstCharactor\":\"J\",\"type\":1},{\"firstCharactor\":\"K\",\"type\":1},{\"firstCharactor\":\"L\",\"type\":1},{\"firstCharactor\":\"M\",\"type\":1},{\"firstCharactor\":\"N\",\"type\":1},{\"firstCharactor\":\"P\",\"type\":1},{\"firstCharactor\":\"Q\",\"type\":1},{\"firstCharactor\":\"R\",\"type\":1},{\"firstCharactor\":\"S\",\"type\":1},{\"firstCharactor\":\"T\",\"type\":1},{\"firstCharactor\":\"W\",\"type\":1},{\"firstCharactor\":\"X\",\"type\":1},{\"firstCharactor\":\"Y\",\"type\":1},{\"firstCharactor\":\"Z\",\"type\":1}]";

    public static List<BGame> getAToZIndexList(){
        List<BGame> list = new ArrayList<BGame>();
        Type listType = new TypeToken<ArrayList<BGame>>() {}.getType();
        Gson gson = new Gson();
        list = gson.fromJson(s, listType);
        return list;
    }
}
