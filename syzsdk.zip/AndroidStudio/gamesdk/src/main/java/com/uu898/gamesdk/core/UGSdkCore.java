package com.uu898.gamesdk.core;

import android.app.Application;
import android.content.Intent;

import com.uu898.gamesdk.IUGSDK;
import com.uu898.gamesdk.UGActivity;
import com.uu898.gamesdk.support.listener.UGChangeAccountListener;
import com.uu898.gamesdk.support.listener.UGExitListener;
import com.uu898.gamesdk.support.listener.UGLoginListener;
import com.uu898.gamesdk.support.listener.UGPayListener;
import com.uu898.gamesdk.support.model.UGPayModel;
import com.uu898.gamesdk.support.result.UGPayResult;
import com.uu898.gamesdk.utils.AccountManager;

import org.xutils.x;

/**
 * Created by bo on 16/10/12.
 */

public class UGSdkCore implements IUGSDK {

    private static UGSdkCore instance = new UGSdkCore();

    private UGSdkCore() {

    }

    public static UGSdkCore getInstance() {
        return instance;
    }


    @Override
    public void init(Application application, String appId, String key, boolean debug) {
        x.Ext.init(application);
        x.Ext.setDebug(debug); // 开启debug会影响性能
        UGCoreHelper.init(appId, key);
    }

    @Override
    public void login(UGLoginListener listener) {
        if(null == listener){
            throw new RuntimeException("登陆回调接口UGLoginListener为必传参数");
        }
        ListenerCenter.getInstance().setLoginListener(listener);
        Intent intent = new Intent(x.app(), UGActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra(UGActivity.INTENT_KEY_TO, UGActivity.INTENT_VALUE_TO_LOGIN);
        x.app().startActivity(intent);
    }

    @Override
    public void pay(UGPayModel model, UGPayListener listener) {
        if(null == listener){
            throw new RuntimeException("支付回调接口UGPayListener为必传参数");
        }
        //未登陆不能支付
        if (!AccountManager.getInstance().getStatus().equals(AccountManager.Status.LOGIN)) {
            UGPayResult result = new UGPayResult();
            result.resultCode = UGPayResult.CODE_NOT_LOGIN;
            listener.onPayDone(result);
            return;
        }
        ListenerCenter.getInstance().setPayListener(listener);
        Intent intent = new Intent(x.app(), UGActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra(UGActivity.INTENT_KEY_TO, UGActivity.INTENT_VALUE_TO_CHECKOUT);
        intent.putExtra(UGActivity.INTENT_KEY_PAY_MODEL, model);
        x.app().startActivity(intent);
    }

    @Override
    public void exit(UGExitListener listener) {
        if(null == listener){
            throw new RuntimeException("退出回调接口UGExitListener为必传参数");
        }
        ListenerCenter.getInstance().setExitListener(listener);
        Intent intent = new Intent(x.app(), UGActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra(UGActivity.INTENT_KEY_TO, UGActivity.INTENT_VALUE_TO_EXIT);
        x.app().startActivity(intent);
    }

    @Override
    public void changeAccount(UGChangeAccountListener listener) {
        if(null == listener){
            throw new RuntimeException("切换账户回调接口UGExitListener为必传参数");
        }
        ListenerCenter.getInstance().setChangeAccountListener(listener);
    }

}
