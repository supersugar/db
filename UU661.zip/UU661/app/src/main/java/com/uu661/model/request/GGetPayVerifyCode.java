package com.uu661.model.request;

public class GGetPayVerifyCode {

    public static final int SMS = 1;//手机
    public static final int WX = 2;//微信

    private String orderNo;//
    private int validType;//

    public GGetPayVerifyCode(String orderNo, int validType) {
        this.orderNo = orderNo;
        this.validType = validType;
    }
}
