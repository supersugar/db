package com.uu661.util;

import android.content.Context;

import com.umeng.message.IUmengRegisterCallback;
import com.umeng.message.PushAgent;
import com.umeng.message.UTrack;
import com.uu661.util.log.L;

/**
 * 推送工具类
 * Created by bo on 17/2/27.
 */

public class PushUtil {

    private static final String ALIAS_TYPE = "UU661";
    private static final String EXTRA_KEY_ID = "id";
    private static final String EXTRA_KEY_NO = "periodNo";

    public static void init(Context context) {
        PushAgent mPushAgent = PushAgent.getInstance(context);
        mPushAgent.setDebugMode(false);//用mPushAgent.setDebugMode(false)关闭日志输出
        //注册推送服务，每次调用register方法都会回调该接口
        mPushAgent.register(new IUmengRegisterCallback() {
            @Override
            public void onSuccess(String deviceToken) {
                //注册成功会返回device token
                L.d("PushAgent deviceToken = " + deviceToken);
            }

            @Override
            public void onFailure(String s, String s1) {
            }
        });
        mPushAgent.setDisplayNotificationNumber(2);
//        UmengNotificationClickHandler notificationClickHandler = new UmengNotificationClickHandler() {
//            @Override
//            public void dealWithCustomAction(Context context, UMessage msg) {
//                Intent intent = new Intent(context, DiamondDetailActivity.class);
//                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                for (Map.Entry<String, String> entry : msg.extra.entrySet()) {
//                    String key = entry.getKey();
//                    String value = entry.getValue();
//                    if (key != null && key.equals(EXTRA_KEY_ID)) {
//                        intent.putExtra(DiamondDetailActivity.INTENT_KEY_COMMODITY_ID, Integer.valueOf(value));
//                    }
//                    if(key != null && key.equals(EXTRA_KEY_NO)){
//                        intent.putExtra(DiamondDetailActivity.INTENT_KEY_PERIOD_NO, Integer.valueOf(value));
//                    }
//                }
//                context.startActivity(intent);
//            }
//        };
//        mPushAgent.setNotificationClickHandler(notificationClickHandler);
    }

    /**
     * 在所有的Activity 的onCreate 方法或在应用的BaseActivity的onCreate方法中添加
     * 如果不调用此方法，不仅会导致按照"几天不活跃"条件来推送失效，还将导致广播发送不成功以及设备描述红色等问题发生。
     * 可以只在应用的主Activity中调用此方法，但是由于SDK的日志发送策略，有可能由于主activity的日志没有发送成功，而导致未统计到日活数据。
     *
     * @param context
     */
    public static void onAppStart(Context context) {
        PushAgent.getInstance(context).onAppStart();
    }

    /**
     * 添加alias
     *
     * @param alias
     */
    public static void addAlias(final String alias, Context context) {
        PushAgent mPushAgent = PushAgent.getInstance(context);
        mPushAgent.addAlias(alias, ALIAS_TYPE, new UTrack.ICallBack() {
            @Override
            public void onMessage(boolean isSuccess, String message) {
                L.d("addAlias = " + alias + " " + isSuccess + " " + message);
            }
        });
    }

    public static void removeAlias(final String alias, Context context) {
        PushAgent mPushAgent = PushAgent.getInstance(context);
        mPushAgent.removeAlias(alias, ALIAS_TYPE, new UTrack.ICallBack() {
            @Override
            public void onMessage(boolean isSuccess, String message) {
                L.d("removeAlias = " + alias + " " + isSuccess + " " + message);
            }
        });
    }
}
