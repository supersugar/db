package com.uu898app.model.request;

import com.uu898app.model.GBaseModel;

/**
 * Created by zhangbo on 2016/6/20.
 */
public class GGoodsDetail extends GBaseModel {

    /**
     * ssid : 6e3ff7a3df63c5eab8b28d67c662a25b
     * commodityNo : 123
     */

    private String commodityNo;

    public String getCommodityNo() {
        return commodityNo;
    }

    public void setCommodityNo(String commodityNo) {
        this.commodityNo = commodityNo;
    }
}
