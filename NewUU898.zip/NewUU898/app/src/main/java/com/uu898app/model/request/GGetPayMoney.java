package com.uu898app.model.request;

import com.uu898app.model.GBaseModel;

/**
 * 获取支付金额
 * Created by zhangbo on 2016/7/13.
 */
public class GGetPayMoney extends GBaseModel{

    public static final String TYPE_ZFB = "alipay";//支付宝
    public static final String TYPE_WX = "weixin";//微信
    public static final String TYPE_YL = "yinlian";//银联

    /**
     * chargeType :
     * chargeMoney :
     */

    private String chargeType;
    private String chargeMoney;

    public String getChargeType() {
        return chargeType;
    }

    public void setChargeType(String chargeType) {
        this.chargeType = chargeType;
    }

    public String getChargeMoney() {
        return chargeMoney;
    }

    public void setChargeMoney(String chargeMoney) {
        this.chargeMoney = chargeMoney;
    }
}
