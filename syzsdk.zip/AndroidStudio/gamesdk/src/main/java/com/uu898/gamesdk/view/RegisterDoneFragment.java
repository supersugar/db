package com.uu898.gamesdk.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class RegisterDoneFragment extends BaseFragment {

    private Button mBtNext;
    private Button mBtBack;

    public static RegisterDoneFragment newInstance() {
        Bundle args = new Bundle();
        RegisterDoneFragment fragment = new RegisterDoneFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        View view = inflater.inflate(getLayoutId("ug_register_done"), container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "注册成功");
        mBtNext = (Button) view.findViewById(getId("ug_bt_next"));
        mBtBack = (Button) view.findViewById(getId("ug_bt_back"));

        mBtNext.setOnClickListener(onClickListener);
        mBtBack.setOnClickListener(onClickListener);
    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(v.getId() == getId("ug_bt_next")){
                start(RegisterBindingFragment.newInstance(RegisterBindingFragment.TYPE_FIRST_BINDING));
            } else if(v.getId() == getId("ug_bt_back")){
                popTo(LoginFragment.class, false);
            }
        }
    };


}