package com.uu661.module.my;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.uu661.R;
import com.uu661.model.response.BMyOrder;
import com.uu661.module.MainActivity;
import com.uu661.module.home.DiamondDetailActivity;
import com.uu661.util.NoDoubleClickUtils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by bo on 16/11/4.
 */

public class MyOrderListAdapter extends RecyclerView.Adapter<MyOrderListAdapter.MyHolder> {


    @BindView(R.id.item_img) ImageView mItemImg;
    @BindView(R.id.item_tv1) TextView mItemTv1;
    @BindView(R.id.item_tv2) TextView mItemTv2;
    @BindView(R.id.item_tv3) TextView mItemTv3;
    @BindView(R.id.item_tv4) TextView mItemTv4;
    @BindView(R.id.item_bt) Button mItemBt;
    @BindView(R.id.item_parent) LinearLayout mItemParent;
    private Context mContext;
    private List<BMyOrder> data = new ArrayList<>();

    public MyOrderListAdapter(Context context) {
        this.mContext = context;
    }

    public void updateData(List<BMyOrder> data) {
        this.data = data;
        notifyDataSetChanged();
    }

    @Override
    public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_my_order, parent, false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(MyHolder holder, int position) {
        BMyOrder model = data.get(position);
        holder.bindItem(model);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }


    public class MyHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        @BindView(R.id.item_parent) View mItemParent;
        @BindView(R.id.item_img) ImageView mItemImg;
        @BindView(R.id.item_tv1) TextView mItemTv1;
        @BindView(R.id.item_tv2) TextView mItemTv2;
        @BindView(R.id.item_tv3) TextView mItemTv3;
        @BindView(R.id.item_tv4) TextView mItemTv4;
        @BindView(R.id.item_bt) Button mItemBt;

        private BMyOrder mModel;

        public MyHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);//用butterKnife绑定
        }


        void bindItem(BMyOrder model) {
            this.mModel = model;
            Glide.with(mContext).load(mModel.getImageUrl()).error(R.drawable.ic_diamond_temp).into(mItemImg);
            mItemTv1.setText(mModel.getTitle());
            mItemTv2.setText("订单时间 : " + mModel.getAddTime());
            mItemTv3.setText(Html.fromHtml("我已参与 : <font color='#ff3b51'>" + mModel.getBuyNum() + "</font> 人次"));
            mItemTv4.setText(mModel.getStatusMessage());

            if (mModel.getIsWin() == 1) {//中奖
                mItemTv4.setTextColor(mContext.getResources().getColor(R.color.red));
                mItemBt.setText("再次购买");
                mItemBt.setBackgroundResource(R.drawable.ic_shape_bt_red_white);
                mItemBt.setTextColor(mContext.getResources().getColor(R.color.red));
            } else if (mModel.getIsWin() == 0) {
                mItemTv4.setTextColor(mContext.getResources().getColor(R.color.blue));
                mItemBt.setText("继续夺钻");
                mItemBt.setBackgroundResource(R.drawable.ic_shape_bt_red);
                mItemBt.setTextColor(mContext.getResources().getColor(R.color.white));
            }

            mItemParent.setOnClickListener(this);
            mItemBt.setOnClickListener(this);
        }

        @OnClick({R.id.item_bt, R.id.item_parent})
        public void onClick(View view) {
            if (NoDoubleClickUtils.isDoubleClick()) {
                return;
            }
            switch (view.getId()) {
                case R.id.item_bt:
                    if (mModel.getIsWin() == 1) {//中奖,进入该商品最新一期
                        Intent intent = new Intent(mContext, DiamondDetailActivity.class);
                        intent.putExtra(DiamondDetailActivity.INTENT_KEY_COMMODITY_ID, mModel.getCommodityId());
                        intent.putExtra(DiamondDetailActivity.INTENT_KEY_PERIOD_NO, 0);
                        mContext.startActivity(intent);
                    } else if (mModel.getIsWin() == 0) {//回到首页
                        Intent intent = new Intent(mContext, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.putExtra(MainActivity.INTENT_KEY_CHECK_UPDATE, false);
                        mContext.startActivity(intent);
                    }
                    break;
                case R.id.item_parent:
                    Intent intent = new Intent(mContext, DiamondDetailActivity.class);
                    intent.putExtra(DiamondDetailActivity.INTENT_KEY_COMMODITY_ID, mModel.getCommodityId());
                    intent.putExtra(DiamondDetailActivity.INTENT_KEY_PERIOD_NO, mModel.getPeriodNo());
                    mContext.startActivity(intent);
                    break;
            }
        }



    }

}
