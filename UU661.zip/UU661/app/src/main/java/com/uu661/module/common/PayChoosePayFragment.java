package com.uu661.module.common;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.uu661.R;
import com.uu661.core.AccountManager;
import com.uu661.model.response.BUserInfo;
import com.uu661.module.base.BaseFragment;
import com.uu661.network.JsonCallback;
import com.uu661.network.TaskEngine;
import com.uu661.util.CommonUtils;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 钻石列表界面
 */
public class PayChoosePayFragment extends BaseFragment {


    @BindView(R.id.bt_ok) Button mBtOk;
    @BindView(R.id.check_wx) ImageView mCheckWx;
    @BindView(R.id.bt_wx) RelativeLayout mBtWx;
    @BindView(R.id.check_zfb) ImageView mCheckZfb;
    @BindView(R.id.bt_zfb) RelativeLayout mBtZfb;
    @BindView(R.id.tv_my_money_enable) TextView mTvMyMoneyEnable;
    @BindView(R.id.check_my_money) ImageView mCheckMyMoney;
    @BindView(R.id.bt_my_money) RelativeLayout mBtMyMoney;
    @BindView(R.id.view_my_money_enable) RelativeLayout mViewMyMoneyEnable;
    @BindView(R.id.tv_my_money_disable) TextView mTvMyMoneyDisable;
    @BindView(R.id.view_my_money_disable) RelativeLayout mViewMyMoneyDisable;

    private int mChoosePay;
    private int mFinalMoney;

    public static PayChoosePayFragment newInstance(int choosePay, int finalMoney) {
        PayChoosePayFragment fragment = new PayChoosePayFragment();
        Bundle args = new Bundle();
        args.putInt("choosePay", choosePay);
        args.putInt("finalMoney", finalMoney);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.pay_choose_pay_fragment, container, false);
        mChoosePay = getArguments().getInt("choosePay");
        mFinalMoney = getArguments().getInt("finalMoney");
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "选择支付方式", true);
        setUserMoney();
        setChoose();
    }

    @Override
    protected void onEnterAnimationEnd(Bundle savedInstanceState) {
        super.onEnterAnimationEnd(savedInstanceState);
        doGetUserInfo();
    }

    private void setChoose() {
        switch (mChoosePay){
            case PayFragment.PAY_USE_WX:
                mCheckWx.setVisibility(View.VISIBLE);
                mCheckZfb.setVisibility(View.GONE);
                mCheckMyMoney.setVisibility(View.GONE);
                break;
            case PayFragment.PAY_USE_ZFB:
                mCheckWx.setVisibility(View.GONE);
                mCheckZfb.setVisibility(View.VISIBLE);
                mCheckMyMoney.setVisibility(View.GONE);
                break;
            case PayFragment.PAY_USE_MONEY:
                mCheckWx.setVisibility(View.GONE);
                mCheckZfb.setVisibility(View.GONE);
                mCheckMyMoney.setVisibility(View.VISIBLE);
                break;
        }
    }

    private void setUserMoney() {
        BUserInfo userInfo = AccountManager.getInstance().getUserInfo();
        if (null != userInfo) {
            long myMoney = userInfo.money;
            mTvMyMoneyEnable.setText("UU898余额 : " + CommonUtils.fenToYuan(myMoney) + " 元");
            mTvMyMoneyDisable.setText("UU898余额 : " + CommonUtils.fenToYuan(myMoney) + " 元");
            if (mFinalMoney > myMoney) {// 余额不足的时候,不允许用余额支付
                mViewMyMoneyEnable.setVisibility(View.GONE);
                mViewMyMoneyDisable.setVisibility(View.VISIBLE);
            } else {
                mViewMyMoneyEnable.setVisibility(View.VISIBLE);
                mViewMyMoneyDisable.setVisibility(View.GONE);
            }
        }
    }

    private void doGetUserInfo() {
        TaskEngine.getInstance().doGetUserInfo(new JsonCallback<BUserInfo>(this) {
            @Override
            public void onSuccess(BUserInfo result, Call call, Response response) {
                if(!isVisible()){
                    return;
                }
                AccountManager.getInstance().saveUserInfo(result);
                setUserMoney();
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                //获取余额失败的时候,读取缓存的余额,至于是否能支付成功看服务器返回,大部分时候是缓存的余额是准确的
            }
        });
    }

    @OnClick({R.id.bt_ok, R.id.bt_wx, R.id.bt_zfb, R.id.bt_my_money})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.bt_ok:
                setResult();
                return;
            case R.id.bt_wx:
                mChoosePay = PayFragment.PAY_USE_WX;
                break;
            case R.id.bt_zfb:
                mChoosePay = PayFragment.PAY_USE_ZFB;
                break;
            case R.id.bt_my_money:
                mChoosePay = PayFragment.PAY_USE_MONEY;
                break;
        }
        setChoose();
        setResult();
    }

    // 设置传给上个Fragment的数据
    private void setResult(){
        Bundle bundle = new Bundle();
        bundle.putInt(PayFragment.BUNDLE_KEY_CHOOSE_PAY, mChoosePay);
        setFragmentResult(RESULT_OK, bundle);
//        _mActivity.onBackPressed();
        pop();
    }
}
