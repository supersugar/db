package com.uu898app.network;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.google.gson.Gson;
import com.uu898app.app.App;
import com.uu898app.model.BaseModel;
import com.uu898app.model.GBaseModel;
import com.uu898app.model.request.GBanner;
import com.uu898app.model.request.GGameID;
import com.uu898app.model.request.GGameList;
import com.uu898app.model.request.GGenAliPayNo;
import com.uu898app.model.request.GGenRechargeDKNo;
import com.uu898app.model.request.GGenRechargeNo;
import com.uu898app.model.request.GGenWxPayNo;
import com.uu898app.model.request.GGetPayMoney;
import com.uu898app.model.request.GGoods;
import com.uu898app.model.request.GGoodsDetail;
import com.uu898app.model.request.GLogin;
import com.uu898app.model.request.GOnlyId;
import com.uu898app.model.request.GPage;
import com.uu898app.model.request.GPhoneNo;
import com.uu898app.model.response.BBannerResponse;
import com.uu898app.model.response.BCheckUpdate;
import com.uu898app.model.response.BGame;
import com.uu898app.model.response.BGameArea;
import com.uu898app.model.response.BGameDKList;
import com.uu898app.model.response.BGameKind;
import com.uu898app.model.response.BGameServer;
import com.uu898app.model.response.BGoods;
import com.uu898app.model.response.BGoodsDetail;
import com.uu898app.model.response.BLogin;
import com.uu898app.model.response.BMessage;
import com.uu898app.model.response.BMobileData;
import com.uu898app.model.response.BOrderCommon;
import com.uu898app.model.response.BOrderGameDK;
import com.uu898app.model.response.BOrderRechargePhone;
import com.uu898app.model.response.BOrderRechargeQQ;
import com.uu898app.model.response.BPayMoney;
import com.uu898app.model.response.BPayNo;
import com.uu898app.model.response.BRechargeDKNoResult;
import com.uu898app.model.response.BRechargeNoResult;
import com.uu898app.model.response.BUserInfo;
import com.uu898app.model.response.BUserInfoIntegrity;
import com.uu898app.network.rxjava.RxResultHelper;
import com.uu898app.network.rxjava.RxSchedulerHelper;
import com.uu898app.util.log.L;

import java.util.List;

import okhttp3.ResponseBody;
import rx.Observable;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

/**
 * Created by zhangbo on 2016/6/22.
 */
public class TaskEngine {

    private static TaskEngine mTaskEngine;
    private Network mNetwork;

    private TaskEngine() {
        if (null == mNetwork) {
            mNetwork = Network.getInstance();
        }
    }

    public static TaskEngine getInstance() {
        if (null == mTaskEngine) {
            mTaskEngine = new TaskEngine();
        }
        return mTaskEngine;
    }


    //    Observable<ResponseBody> common(@Field("UU898_APP") String request);

    private String genReqeustString(String type, GBaseModel data) {
        BaseModel<GBaseModel> baseModel = new BaseModel<GBaseModel>();
        baseModel.setData(data);
        baseModel.setType(type);
        baseModel.setKey("app");
        baseModel.setMode("app");
        Gson gson = new Gson();
        String request = gson.toJson(baseModel);
        L.json(request);
        return request;
    }

    public Observable<ResponseBody> common(GBanner banner) {
        return mNetwork.getUUApi().common(genReqeustString(NetConstant.ApiType.App0070, banner)).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread());
    }


    public Observable<BLogin> login(GLogin login) {
        return Observable.just(login)//Just操作符将某个对象转化为Observable对象，并且将其发射出去，可以使一个数字、一个字符串、数组、Iterate对象等，是一种非常快捷的创建Observable对象的方法
                .flatMap(new Func1<GLogin, Observable<GLogin>>() {
                    @Override
                    public Observable<GLogin> call(GLogin gLogin) {
                        ConnectivityManager manager = (ConnectivityManager) App.mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
                        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
                        if (networkInfo == null || !networkInfo.isConnected()) {
                            return Observable.error(new Network.APIException("", "没有联网啦"));
                        } else {
                            return Observable.just(gLogin);
                        }
                    }
                }).map(new Func1<GLogin, String>() {
                    @Override
                    public String call(GLogin gLogin) {
                        return genReqeustString(NetConstant.ApiType.App0001, gLogin);
                    }
                }).flatMap(new Func1<String, Observable<BaseModel<BLogin>>>() {
                    @Override
                    public Observable<BaseModel<BLogin>> call(String s) {
                        return mNetwork.getUUApi().login(s);
                    }
                }).compose(mNetwork.<BLogin>applySchedulers());
    }


    public Observable<BLogin> logins(GLogin login) {
        return mNetwork.getUUApi().login(genReqeustString(NetConstant.ApiType.App0001, login)).compose(RxSchedulerHelper.<BaseModel<BLogin>>io_main()).compose(RxResultHelper.<BLogin>handleResult());
    }

    public Observable<BCheckUpdate> checkUpdate() {
        return mNetwork.getUUApi().checkUpdate(genReqeustString(NetConstant.ApiType.App0029, null)).compose(mNetwork.<BCheckUpdate>applySchedulers());
    }

    public Observable<BUserInfo> getUserInfo(GBaseModel model) {
        return mNetwork.getUUApi().getUserInfo(genReqeustString(NetConstant.ApiType.App0002, model)).compose(mNetwork.<BUserInfo>applySchedulers());
    }

    public Observable<List<BGame>> getGameList(GGameList model) {
        return mNetwork.getUUApi().getGameList(genReqeustString(NetConstant.ApiType.App0003, model)).compose(mNetwork.<List<BGame>>applySchedulers());
    }

    public Observable<List<BGameArea>> getGameAreaList(GOnlyId model) {
        return mNetwork.getUUApi().getGameAreaList(genReqeustString(NetConstant.ApiType.App0004, model)).compose(mNetwork.<List<BGameArea>>applySchedulers());
    }

    public Observable<List<BGameServer>> getGameServerList(GOnlyId model) {
        return mNetwork.getUUApi().getGameServerList(genReqeustString(NetConstant.ApiType.App0005, model)).compose(mNetwork.<List<BGameServer>>applySchedulers());
    }

    public Observable<List<BGameKind>> getGameKindList(GOnlyId model) {
        return mNetwork.getUUApi().getGameKindList(genReqeustString(NetConstant.ApiType.App0006, model)).compose(mNetwork.<List<BGameKind>>applySchedulers());
    }

    public Observable<BGoodsDetail> getGameDetail(GGoodsDetail model) {
        return mNetwork.getUUApi().getGameDetail(genReqeustString(NetConstant.ApiType.App0024, model)).compose(mNetwork.<BGoodsDetail>applySchedulers());
    }

    public Observable<BBannerResponse> getBanners(GBanner model) {
        return mNetwork.getUUApi().getBanners(genReqeustString(NetConstant.ApiType.App0070, model)).compose(mNetwork.<BBannerResponse>applySchedulers());
    }

    public Observable<List<BGoods>> getGoodsList(GGoods model) {
        return mNetwork.getUUApi().getGoodsList(genReqeustString(NetConstant.ApiType.App0008, model)).compose(mNetwork.<List<BGoods>>applySchedulers());
    }

    /**
     * 检查个人资料是否完善
     */
    public Observable<BUserInfoIntegrity> queryUserInfoIntegrity(GBaseModel model) {
        return mNetwork.getUUApi().queryUserInfoIntegrity(genReqeustString(NetConstant.ApiType.App0030, model)).compose(mNetwork.<BUserInfoIntegrity>applySchedulers());
    }

    /**
     * 支付宝生成订单号
     */
    public Observable<BPayNo> genAliPayNo(GGenAliPayNo model) {
        return mNetwork.getUUApi().genAliPayNo(genReqeustString(NetConstant.ApiType.App0033, model)).compose(mNetwork.<BPayNo>applySchedulers());
    }

    /**
     * 支付宝生成订单号(New)
     */
    public Observable<BPayNo> genAliPayNoNew(GGenAliPayNo model) {
        return mNetwork.getUUApi().genAliPayNo(genReqeustString(NetConstant.ApiType.App0086, model)).compose(mNetwork.<BPayNo>applySchedulers());
    }

    /**
     * 微信生成订单号
     */
    public Observable<BPayNo> genWxPayNo(GGenWxPayNo model) {
        return mNetwork.getUUApi().genWxPayNo(genReqeustString(NetConstant.ApiType.App0063, model)).compose(mNetwork.<BPayNo>applySchedulers());
    }

    /**
     * 获取充值金额
     */
    public Observable<BPayMoney> getPayMoney(GGetPayMoney model) {
        return mNetwork.getUUApi().getPayMoney(genReqeustString(NetConstant.ApiType.App0080, model)).compose(mNetwork.<BPayMoney>applySchedulers());
    }

    /***********账户**************/
    /**
     * 获取我的消息列表
     */
    public Observable<List<BMessage>> getMyMessages(GBaseModel model) {
        return mNetwork.getUUApi().getMyMessages(genReqeustString(NetConstant.ApiType.App0047, model)).compose(mNetwork.<List<BMessage>>applySchedulers());
    }


    /***********订单**************/
    /**
     * 我购买的商品(寄售、担保、账号)列表
     */
    public Observable<List<BOrderCommon>> getBuyCommonList(GPage model) {
        return mNetwork.getUUApi().getBuyCommonList(genReqeustString(NetConstant.ApiType.App0014, model)).compose(mNetwork.<List<BOrderCommon>>applySchedulers());
    }

    /**
     * 我购买的点卡列表
     */
    public Observable<List<BOrderGameDK>> getBuyCardList(GPage model) {
        return mNetwork.getUUApi().getBuyCardList(genReqeustString(NetConstant.ApiType.App0015, model)).compose(mNetwork.<List<BOrderGameDK>>applySchedulers());
    }

    /**
     * 我的手机话费充值订单列表
     */
    public Observable<List<BOrderRechargePhone>> getPhoneRechargeList(GPage model) {
        return mNetwork.getUUApi().getPhoneRechargeList(genReqeustString(NetConstant.ApiType.App0016, model)).compose(mNetwork.<List<BOrderRechargePhone>>applySchedulers());
    }

    /**
     * 我的QQ专区充值订单列表
     */
    public Observable<List<BOrderRechargeQQ>> getQQRechargeList(GPage model) {
        return mNetwork.getUUApi().getQQRechargeList(genReqeustString(NetConstant.ApiType.App0017, model)).compose(mNetwork.<List<BOrderRechargeQQ>>applySchedulers());
    }


    /***********充值*************/
    /**
     * 生成充值订单(话费/流量/QQ)
     */
    public Observable<BRechargeNoResult> genRechargeNo(GGenRechargeNo model) {
        return mNetwork.getUUApi().genRechargeNo(genReqeustString(NetConstant.ApiType.App0009, model)).compose(mNetwork.<BRechargeNoResult>applySchedulers());
    }

    /**
     * 获取点卡列表
     */
    public Observable<BGameDKList> getGameDkList(GGameID model) {
        return mNetwork.getUUApi().getGameDkList(genReqeustString(NetConstant.ApiType.App0011, model)).compose(mNetwork.<BGameDKList>applySchedulers());
    }

    /**
     * 生成点卡订单
     */
    public Observable<BRechargeDKNoResult> genRechargeDkNo(GGenRechargeDKNo model) {
        return mNetwork.getUUApi().genRechargeDkNo(genReqeustString(NetConstant.ApiType.App0012, model)).compose(mNetwork.<BRechargeDKNoResult>applySchedulers());
    }

    /**
     * 根据手机号,获取流量类型列表
     */
    public Observable<List<BMobileData>> getMobileDataList(GPhoneNo model) {
        return mNetwork.getUUApi().getMobileDataList(genReqeustString(NetConstant.ApiType.App0069, model)).compose(mNetwork.<List<BMobileData>>applySchedulers());
    }
}
