package com.uu898app.model.response;

/**
 * 充值订单号
 * Created by zhangbo on 2016/7/13.
 */
public class BPayNo {

    /**
     * orderNo : ""
     */

    private String orderNo;

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
}
