package com.uu898app.app;

import android.app.Application;
import android.content.Context;

import com.bugtags.library.Bugtags;
import com.bugtags.library.BugtagsOptions;
import com.uu898app.third.umeng.UUUmeng;
import com.uu898app.third.xiaoneng.XiaoNeng;
import com.uu898app.util.ManifestUtils;


public class App extends Application {

    private static final boolean DEBUG = true;//是否是debug模式

    public static Context mContext;

    @Override
    public void onCreate() {
        super.onCreate();
        mContext = this;
        XiaoNeng.getInstance().init(DEBUG);
        UUUmeng.init(DEBUG);
        configBugtags(DEBUG);
    }

    /**
     * 配置Bugtags
     * @param debug
     */
    private void configBugtags(boolean debug) {
        if(debug){
            return;
        }
        BugtagsOptions options = new BugtagsOptions.Builder().
                trackingLocation(true).//是否获取位置，默认 true
                trackingCrashLog(true).//是否收集crash，默认 true
                trackingConsoleLog(true).//是否收集console log，默认 true
                trackingUserSteps(true).//是否收集用户操作步骤，默认 true
                crashWithScreenshot(false).//收集闪退是否附带截图
                versionName(ManifestUtils.getVersionName(this)).
                versionCode(ManifestUtils.getVersionCode(this)).
                trackingNetworkURLFilter("(.*)").//自定义网络请求跟踪的 url 规则，默认 null
                build();
        Bugtags.start("f2dfaeffae7fa189206e651befa79f8f", this, Bugtags.BTGInvocationEventNone, options);
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }
}
