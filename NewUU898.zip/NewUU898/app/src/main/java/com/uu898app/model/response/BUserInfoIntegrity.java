package com.uu898app.model.response;

/**
 * Created by zhangbo on 2016/6/15.
 */
public class BUserInfoIntegrity {

    private static final String VALUE_INTEGRITY = "True";

    private String IsWanShan;

    public boolean isIntegrity(){
        return IsWanShan.equals(VALUE_INTEGRITY);
    }

    public String getIsWanShan() {
        return IsWanShan;
    }

    public void setIsWanShan(String isWanShan) {
        IsWanShan = isWanShan;
    }
}
