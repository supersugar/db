package com.uu898.gamesdk.model.response;

import java.util.ArrayList;

/**
 * Created by bo on 16/9/14.
 */
public class BSubAccount {

    public String id;//现在已登录的小号ID
    public ArrayList<SubAccount> list = new ArrayList<SubAccount>();

    public class SubAccount{
        public String id;
        public String alias;
    }
}
