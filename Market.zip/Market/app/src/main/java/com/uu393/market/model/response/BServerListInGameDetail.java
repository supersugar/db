package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    : 详情页游戏开服列表bean对象
 * =====================================================
 */

public class BServerListInGameDetail implements Serializable {
    /**
     {
     "id": "1",(服务器编号)
     "serverName": "356服",(服务器名称)
     "openTime": "2017-03-01 00:00:00"(开服时间)
     }
     */

    private String id;
    private String serverName;
    private String openTime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getServerName() {
        return serverName;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    public String getOpenTime() {
        return openTime;
    }

    public void setOpenTime(String openTime) {
        this.openTime = openTime;
    }
}
