package com.uu898app.model.response;

public class BGoodsDetail {


    /**
     * remark :
     * camp : 0
     * title : 100元=12911万金                  标题
     * price : 100.00                           商品价格
     * game : 41                                游戏id
     * area : 2106                              游戏区
     * server : 25713                           游戏服
     * areaServer : 完美国际2/至尊双线/凌月     游戏区服
     * commodityNo : CN20160707112134           商品编号
     * commoditytypeName : 游戏币               商品类型
     * commoditytype : -3                       商品类型id
     * leftTime : 29天                          剩余天数
     * number : 1                               库存数量
     * coinCount : 12911.0000
     * inputType : 0
     * singlePrice : 129.11万金/元
     * status : 1
     *
     * 作为买家
     * SelCreditStr : 2,0                       图标（0,0；第一个参数是黄钻个数，第二个是蓝钻个数）
     * selCompleteCount : 6878                  成交笔数
     * selCanselCount : 4                       取消笔数
     * selPercent : 99.94                       成交率
     *
     * 作为卖家
     * ConCreditStr : 0,3                       图标（0,0；第一个参数是黄钻个数，第二个是蓝钻个数）
     * conCompleteCount : 175                   成交笔数
     * conCanselCount : 0                       取消笔数
     * conPercent : 100                         成交率
     *
     * images :
     * creditImg : 1,2,3                        诚信保障
     *
     * creditImg（
             1：荐-uu898推荐商品
             2：赔-卖家已经交付押金
             3：寄-寄售交易，快速安全
             4：担-担保交易，快速安全
             5. 账-账号交易，
             6. 付-买家已付全款,求购
             7：礼-此物品交易成功有礼品赠送
     *
     */

    private String ConCreditStr;
    private String remark;
    private String conCanselCount;
    private String selCanselCount;
    private String conCompleteCount;
    private String camp;
    private String areaServer;
    private String title;//标题
    private String area;
    private String coinCount;
    private String commodityNo;
    private String inputType;
    private String commoditytypeName;
    private String SelCreditStr;
    private String singlePrice;
    private String status;
    private String selPercent;
    private String selCompleteCount;
    private String leftTime;
    private String number;
    private String game;
    private String commoditytype;
    private String conPercent;
    private String price;//商品价格
    private String images;
    private String server;
    private String creditImg;

    public String getConCreditStr() {
        return ConCreditStr;
    }

    public void setConCreditStr(String ConCreditStr) {
        this.ConCreditStr = ConCreditStr;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getConCanselCount() {
        return conCanselCount;
    }

    public void setConCanselCount(String conCanselCount) {
        this.conCanselCount = conCanselCount;
    }

    public String getSelCanselCount() {
        return selCanselCount;
    }

    public void setSelCanselCount(String selCanselCount) {
        this.selCanselCount = selCanselCount;
    }

    public String getConCompleteCount() {
        return conCompleteCount;
    }

    public void setConCompleteCount(String conCompleteCount) {
        this.conCompleteCount = conCompleteCount;
    }

    public String getCamp() {
        return camp;
    }

    public void setCamp(String camp) {
        this.camp = camp;
    }

    public String getAreaServer() {
        return areaServer;
    }

    public void setAreaServer(String areaServer) {
        this.areaServer = areaServer;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getCoinCount() {
        return coinCount;
    }

    public void setCoinCount(String coinCount) {
        this.coinCount = coinCount;
    }

    public String getCommodityNo() {
        return commodityNo;
    }

    public void setCommodityNo(String commodityNo) {
        this.commodityNo = commodityNo;
    }

    public String getInputType() {
        return inputType;
    }

    public void setInputType(String inputType) {
        this.inputType = inputType;
    }

    public String getCommoditytypeName() {
        return commoditytypeName;
    }

    public void setCommoditytypeName(String commoditytypeName) {
        this.commoditytypeName = commoditytypeName;
    }

    public String getSelCreditStr() {
        return SelCreditStr;
    }

    public void setSelCreditStr(String SelCreditStr) {
        this.SelCreditStr = SelCreditStr;
    }

    public String getSinglePrice() {
        return singlePrice;
    }

    public void setSinglePrice(String singlePrice) {
        this.singlePrice = singlePrice;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSelPercent() {
        return selPercent;
    }

    public void setSelPercent(String selPercent) {
        this.selPercent = selPercent;
    }

    public String getSelCompleteCount() {
        return selCompleteCount;
    }

    public void setSelCompleteCount(String selCompleteCount) {
        this.selCompleteCount = selCompleteCount;
    }

    public String getLeftTime() {
        return leftTime;
    }

    public void setLeftTime(String leftTime) {
        this.leftTime = leftTime;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getGame() {
        return game;
    }

    public void setGame(String game) {
        this.game = game;
    }

    public String getCommoditytype() {
        return commoditytype;
    }

    public void setCommoditytype(String commoditytype) {
        this.commoditytype = commoditytype;
    }

    public String getConPercent() {
        return conPercent;
    }

    public void setConPercent(String conPercent) {
        this.conPercent = conPercent;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getImages() {
        return images;
    }

    public void setImages(String images) {
        this.images = images;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    public String getCreditImg() {
        return creditImg;
    }

    public void setCreditImg(String creditImg) {
        this.creditImg = creditImg;
    }
}
