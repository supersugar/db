package com.uu898app.module.pay;

import android.os.Bundle;

import com.uu898app.R;
import com.uu898app.module.base.BaseActivity;

/**
 * 充值Activity
 */
public class PayActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base);
        if (savedInstanceState == null) {
            loadRootFragment(R.id.fl_container, PayFragment.newInstance());
        }
    }
}
