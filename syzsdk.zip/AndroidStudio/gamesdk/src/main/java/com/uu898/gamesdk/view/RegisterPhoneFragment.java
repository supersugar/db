package com.uu898.gamesdk.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.uu898.gamesdk.model.request.GGetSMSAuthCode;
import com.uu898.gamesdk.model.request.GRegister;
import com.uu898.gamesdk.model.response.BRegister;
import com.uu898.gamesdk.network.NetCallback;
import com.uu898.gamesdk.network.TaskEngine;
import com.uu898.gamesdk.utils.AccountManager;
import com.uu898.gamesdk.utils.CommonUtils;
import com.uu898.gamesdk.utils.CountDownTimer;
import com.uu898.gamesdk.utils.StringUtils;
import com.uu898.gamesdk.utils.ToastUtil;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class RegisterPhoneFragment extends BaseFragment {

    private EditText mEdtAccount;
    private EditText mEdtPassword;
    private EditText mEdtAuthCode;

    private Button mBtGetSMSCode;
    private Button mBtNext;
    private TextView mTvAgreement;

    public static RegisterPhoneFragment newInstance() {
        Bundle args = new Bundle();
        RegisterPhoneFragment fragment = new RegisterPhoneFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        View view = inflater.inflate(getLayoutId("ug_register_phone"), container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "手机号注册");

        mEdtAccount = (EditText) view.findViewById(getId("ug_edt_account"));
        mEdtPassword = (EditText) view.findViewById(getId("ug_edt_password"));
        mEdtAuthCode = (EditText) view.findViewById(getId("ug_edt_auth_code"));
        mBtGetSMSCode = (Button) view.findViewById(getId("ug_bt_get_sms_code"));
        mTvAgreement = (TextView) view.findViewById(getId("tv_agreement"));
        mBtNext = (Button) view.findViewById(getId("ug_bt_next"));

        mBtGetSMSCode.setOnClickListener(onClickListener);
        mTvAgreement.setOnClickListener(onClickListener);
        mBtNext.setOnClickListener(onClickListener);

    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v.getId() == getId("ug_bt_get_sms_code")) {
                verifyPhone();
            } else if (v.getId() == getId("ug_bt_next")) {
                verifyForm();
            } else if (v.getId() == getId("tv_agreement")) {
                start(WebAgreementFragment.newInstance());
            }
        }


    };

    private void verifyPhone() {
        String phone = mEdtAccount.getText().toString();

        if (StringUtils.isEmpty(phone)) {
            ToastUtil.showToast(_mActivity, "请输入手机号");
            return;
        }

        doGetSMSCode(phone);
    }

    private void doGetSMSCode(String phone) {
        GGetSMSAuthCode model = new GGetSMSAuthCode();
        model.setType(GGetSMSAuthCode.type_4);
        model.setPhoneNo(phone);
        TaskEngine.getInstance().doGetSMSAuthCode(model, new NetCallback(this) {

            @Override
            public void _onNext(Object o) {
                ToastUtil.showToast(_mActivity, "短信验证码已发送至您的手机");
                new CountDownTimer(60000, 1000, mBtGetSMSCode, "获取验证码").start();
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

    /**
     * 校验表单信息
     */
    private void verifyForm() {
        String account = mEdtAccount.getText().toString();
        String password = mEdtPassword.getText().toString();
        String authcode = mEdtAuthCode.getText().toString();


        if (StringUtils.isEmpty(account)) {
            ToastUtil.showToast(_mActivity, "请输入帐号");
            return;
        }
        if (StringUtils.isEmpty(password)) {
            ToastUtil.showToast(_mActivity, "请输入密码");
            return;
        }
        if (StringUtils.isEmpty(authcode)) {
            ToastUtil.showToast(_mActivity, "请输入验证码");
            return;
        }
        doRegister(account, password, authcode);
    }

    private void doRegister(final String account, String password, String authcode) {
        GRegister model = new GRegister();
        model.setUuid(CommonUtils.getDeviceId());
        model.setUserId(account);
        model.setPassword(CommonUtils.encryptString(password));
        model.setRegisterType(GRegister.REGISTER_TYPE_PHONE);
        model.setCheckCode(authcode);
        model.setToken("");

        TaskEngine.getInstance().doRegister(model, new NetCallback<BRegister>(this) {

            @Override
            public void _onNext(BRegister result) {
                ToastUtil.showToast(_mActivity, "注册成功");
                AccountManager.getInstance().saveLoginInfo(result.SSID, account, AccountManager.Status.REGISTER_DONE_NOT_LOGIN);
                popTo(LoginFragment.class, false);
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

}
