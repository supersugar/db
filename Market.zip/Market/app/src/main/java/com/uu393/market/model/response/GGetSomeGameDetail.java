package com.uu393.market.model.response;

/**
 * Created by Administrator on 2017/4/20.
 */

public class GGetSomeGameDetail {
    public String gameID;//游戏id

    public GGetSomeGameDetail(String gameID) {
        this.gameID = gameID;
    }
}
