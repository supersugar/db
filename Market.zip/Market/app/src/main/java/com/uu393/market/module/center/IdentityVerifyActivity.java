package com.uu393.market.module.center;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.Constant;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GDoVerifyPhoneCode;
import com.uu393.market.model.request.GGetPhoneCode;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.login.CountDownTimer;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ContactCustomerServicesUtils;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

//身份确认界面，忘记提现密码，更改提现密码
public class IdentityVerifyActivity extends BaseActivity {

    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    @Bind(R.id.tv_account_name)
    TextView mTvAccountName;
    @Bind(R.id.tv_account_bind_phone_number)
    TextView mTvAccountBindPhoneNumber;
    @Bind(R.id.et_code)
    EditText mEtCode;
    @Bind(R.id.bt_get_code)
    Button mBtGetCode;
    @Bind(R.id.bt_go)
    Button mBtGo;
    @Bind(R.id.tv_contact)
    TextView mTvContact;


    private String mAccountBindPhoneNumber;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_identity_verify);
        ButterKnife.bind(this);
        initTitleBar();
        initView();
    }
    private void initTitleBar() {
        mTitleBarRight.setVisibility(View.GONE);
        mTitleBarTitle.setText("身份验证");
    }
    private void initView() {
        String userId = (String) SPUtil.get(App.mContext, "userId", "");
        mTvAccountName.setText("当前用户名："+userId);
        String chkMobile = (String) SPUtil.get(App.mContext, "chkMobile", "");
        mAccountBindPhoneNumber=chkMobile;
        if (mAccountBindPhoneNumber!=null &&mAccountBindPhoneNumber.length()>7){
            String substring = mAccountBindPhoneNumber.substring(3, 7);
            mTvAccountBindPhoneNumber.setText("已绑定过的手机："+mAccountBindPhoneNumber.replace(substring,"****"));
        }
    }

    @OnClick({R.id.title_bar_left, R.id.bt_get_code, R.id.bt_go, R.id.tv_contact})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                super.onBackPressedSupport();
                break;
            case R.id.bt_get_code://获取短信验证码
                doGetPhoneCode(mBtGetCode);
                break;
            case R.id.bt_go://提交
                String code = mEtCode.getText().toString().trim();
                if (TextUtils.isEmpty(code)){
                    ToastUtil.showToast(App.mContext,"请输入验证码");
                    return;
                }
                GDoVerifyPhoneCode model = new GDoVerifyPhoneCode();
                model.setCheckCode(code);
                model.setUserId("");
                model.setCheckCode("");
                model.setType(Constant.GET_PHONE_CODE_TYPE_8);
                doVerifyPhoneCode(model);
                break;
            case R.id.tv_contact://客服
                ContactCustomerServicesUtils.doXiaoNeng();
                break;
        }
    }

    //获取手机验证码，传token就行APP009
    private void doGetPhoneCode(final Button button) {

        final CountDownTimer timer = new CountDownTimer(60000, 1000, button, "获取验证码");
        timer.start();
        GGetPhoneCode model = new GGetPhoneCode();
        model.setType(Constant.GET_PHONE_CODE_TYPE_8);//验证身份
        model.setPhoneNo("");
        model.setUserId("");
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetPhoneCode(model,new JsonCallback<Object>() {
            @Override
            public void onSuccess(Object bPhoneCode, Call call, Response response) {
                /*
                * Status 1 发送次数超过限制，请查看手机收到的验证码
                        2 手机号码格式不正确
                        3 该手机号在黑名单中
                        4 该手机号已被禁用
                        5 该用户没有绑定手机号
                * */
                ToastUtil.showToast(App.mContext,"短信验证码已发送至您的手机");

            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                timer.cancel();
                button.setEnabled(true);
                button.setText("获取验证码");
            }
        });
    }

    //检验手机验证码APP013
    private void doVerifyPhoneCode(GDoVerifyPhoneCode model){
        if (model==null){
            return;
        }
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doVerifyPhoneCode(model, new JsonCallback<Object>() {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                String result = null;
                try {
                    result = response.body().string();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                JSONObject jsonObject = null;
                String message = "";
                String status = "";
                try {
                    jsonObject = new JSONObject(result);
                    status = jsonObject.getString("status");
                    message = jsonObject.getString("message");
                    if (status.equals("0")) {
                        //提交验证码，成功后跳转
                        IdentityVerifyActivity.this.startActivity(new Intent(IdentityVerifyActivity.this,NewWithdrawPasswordActivity.class));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        });
    }
}
