package com.uu898app.module.buy;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uu898app.R;
import com.uu898app.module.base.BaseFragment;
import com.uu898app.module.helper.BuyHelper;
import com.uu898app.util.ToastUtil;
import com.uu898app.util.eventbus.EB;
import com.uu898app.util.eventbus.EventEmpty;
import com.uu898app.view.gamecustomview.GameCustomButton;
import com.uu898app.view.gamecustomview.GameCustomView;

import org.greenrobot.eventbus.Subscribe;

public class BuyCustomListFragment extends BaseFragment {
    private int mCurrentPosition = -1;
    private GameCustomView mGameCustomView;

    private BuyHelper mBuyHelper;

    public static BuyCustomListFragment newInstance() {
        Bundle args = new Bundle();
        BuyCustomListFragment fragment = new BuyCustomListFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.buy_custom_list, container, false);
        mBuyHelper = BuyHelper.getInstance();
        initView(view);
        return view;
    }

    private void initView(View view) {
        mGameCustomView = (GameCustomView) view.findViewById(R.id.game_custom_view);
        mGameCustomView.addButton(new GameCustomButton(_mActivity, "游戏"));
        mGameCustomView.addButton(new GameCustomButton(_mActivity, "物品类型"));
        mGameCustomView.addButton(new GameCustomButton(_mActivity, "游戏区"));
        mGameCustomView.addButton(new GameCustomButton(_mActivity, "游戏服"));

        mGameCustomView.setOnButtonSelectedListener(new GameCustomView.OnButtonSelectedListener() {
            @Override
            public boolean preOnClick(int position) {
                switch (position){
                    case 0:

                        break;
                    case 1:
                        if(null == BuyHelper.getInstance().getChooseGame()){
                            ToastUtil.showToast(_mActivity,"请选择游戏");
                            return false;
                        }
                        break;
                    case 2://选择游戏区
                        if(null == BuyHelper.getInstance().getChooseGame()){
                            ToastUtil.showToast(_mActivity,"请选择游戏");
                            return false;
                        }
                        if(null == BuyHelper.getInstance().getChooseGameKind()){
                            ToastUtil.showToast(_mActivity,"请选择物品类型");
                            return false;
                        }
                        break;
                    case 3:
                        if(null == BuyHelper.getInstance().getChooseGame()) {
                            ToastUtil.showToast(_mActivity, "请选择游戏");
                            return false;
                        }
                        if(null == BuyHelper.getInstance().getChooseGameKind()){
                            ToastUtil.showToast(_mActivity,"请选择物品类型");
                            return false;
                        }
                        if(null == BuyHelper.getInstance().getChooseGameArea()){
                            ToastUtil.showToast(_mActivity,"请选择游戏大区");
                            return false;
                        }
                        break;
                }
                return true;
            }

            @Override
            public void onButtonSelected(int position, int prePosition) {
                switch (position){
                    case 0:
                        EB.postEmpty(EB.TAG.LOAD_GAME_LIST);
                        break;
                    case 1:
                        EB.postEmpty(EB.TAG.LOAD_GAME_KIND_LIST);
                        break;
                    case 2://选择游戏区
                        EB.postEmpty(EB.TAG.LOAD_GAME_AREA_LIST);
                        break;
                    case 3:
                        EB.postEmpty(EB.TAG.LOAD_GAME_SERVER_LIST);
                        break;
                }

            }

            @Override
            public void clickHasValueButton(int position) {
                switch (position){
                    case 0:
                        mGameCustomView.resetItem(0);
                        mGameCustomView.resetItem(1);
                        mGameCustomView.resetItem(2);
                        mGameCustomView.resetItem(3);
                        mBuyHelper.setChooseGame(null);

                        break;
                    case 1:
                        mGameCustomView.resetItem(1);
                        mBuyHelper.setChooseGameKind(null);
                        break;
                    case 2://选择游戏区
                        mGameCustomView.resetItem(2);
                        mGameCustomView.resetItem(3);
                        mBuyHelper.setChooseGameArea(null);
                        break;
                    case 3:
                        break;
                }
            }

            @Override
            public void onButtonUnselected(int position) {

            }

            @Override
            public void onButtonReselected(int position) {

            }
        });

        setGame();
    }


    @Override
    public void onResume() {
        super.onResume();
        EB.register(this);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        EB.unregister(this);
    }

    @Subscribe
    public void onEvent(EventEmpty event) {
        switch (event.tag) {
            case EB.TAG.CHOOSE_GAME_DONE://游戏选择完毕
                setGame();
                break;
            case EB.TAG.CHOOSE_GAME_KIND_DONE://商品类型选择完毕
                mGameCustomView.setChooseValue(1, mBuyHelper.getChooseGameKind().getName());
                mGameCustomView.setCurrentItem(2);
                break;
            case EB.TAG.CHOOSE_GAME_AREA_DONE://游戏区选择完毕
                mGameCustomView.setChooseValue(2, mBuyHelper.getChooseGameArea().getName());
                mGameCustomView.setCurrentItem(3);
                break;
            case EB.TAG.CHOOSE_GAME_SERVER_DONE://游戏服选择完毕
                mGameCustomView.setChooseValue(3, mBuyHelper.getChooseGameService().getName());
                break;
            default:
                break;
        }
    }

    /**
     * 如果选择的有游戏的话,则设置游戏按钮
     */
    private void setGame(){
        if(null != mBuyHelper.getChooseGame()){
            mGameCustomView.setChooseValue(0, BuyHelper.getInstance().getChooseGame().getName());
            mGameCustomView.setCurrentItem(1);
        }else{
            mGameCustomView.setCurrentItem(0);
        }
    }

}
