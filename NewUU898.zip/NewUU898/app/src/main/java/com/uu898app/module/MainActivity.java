package com.uu898app.module;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;

import com.umeng.socialize.UMShareAPI;
import com.uu898app.R;
import com.uu898app.module.base.BaseActivity;
import com.uu898app.module.base.BaseLazyFragment;
import com.uu898app.module.root.RootCartFragment;
import com.uu898app.module.root.RootDiscoverFragment;
import com.uu898app.module.root.RootHomeFragment;
import com.uu898app.module.root.RootMyFragment;
import com.uu898app.util.eventbus.EB;
import com.uu898app.view.bottombar.BottomBar;
import com.uu898app.view.bottombar.BottomBarTab;

import me.yokeyword.fragmentation.SupportFragment;

public class MainActivity extends BaseActivity implements BaseLazyFragment.OnBackToFirstListener {

    public static final int FIRST = 0;
    public static final int SECOND = 1;
    public static final int THIRD = 2;
    public static final int FOURTH = 3;

    private SupportFragment[] mFragments = new SupportFragment[4];

    public static BottomBar mBottomBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_n);

        if (savedInstanceState == null) {
            mFragments[FIRST] = RootHomeFragment.newInstance();
            mFragments[SECOND] = RootDiscoverFragment.newInstance();
            mFragments[THIRD] = RootCartFragment.newInstance();
            mFragments[FOURTH] = RootMyFragment.newInstance();

            loadMultipleRootFragment(R.id.fl_container, FIRST,
                    mFragments[FIRST],
                    mFragments[SECOND],
                    mFragments[THIRD],
                    mFragments[FOURTH]);
        } else {
            // 这里库已经做了Fragment恢复,所有不需要额外的处理了, 不会出现重叠问题
            // 这里我们需要拿到mFragments的引用,也可以通过getSupportFragmentManager.getFragments()自行进行判断查找(效率更高些),用下面的方法查找更方便些
            mFragments[FIRST] = findFragment(RootHomeFragment.class);
            mFragments[SECOND] = findFragment(RootDiscoverFragment.class);
            mFragments[THIRD] = findFragment(RootCartFragment.class);
            mFragments[FOURTH] = findFragment(RootMyFragment.class);
        }

        initView();
//        requestPermissions();
    }

    private void requestPermissions() {
        String[] mPermissionList = new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,       //位置信息
                Manifest.permission.CALL_PHONE,                 //电话相关
                Manifest.permission.READ_LOGS,
                Manifest.permission.READ_PHONE_STATE,           //电话相关
                Manifest.permission.WRITE_EXTERNAL_STORAGE,     //外置存储卡
                Manifest.permission.SET_DEBUG_APP,
                Manifest.permission.SYSTEM_ALERT_WINDOW,
                Manifest.permission.GET_ACCOUNTS};              //联系人,通讯录
        ActivityCompat.requestPermissions(MainActivity.this, mPermissionList, 100);
    }


    private void initView() {
        mBottomBar = (BottomBar) findViewById(R.id.bottomBar);

        mBottomBar.addItem(new BottomBarTab(this, R.drawable.ic_tab_home, "首页"))
                .addItem(new BottomBarTab(this, R.drawable.ic_tab_discover, "发现"))
                .addItem(new BottomBarTab(this, R.drawable.ic_tab_cart, "购物车"))
                .addItem(new BottomBarTab(this, R.drawable.ic_tab_my, "我的"));

        mBottomBar.setOnTabSelectedListener(new BottomBar.OnTabSelectedListener() {
            @Override
            public void onTabSelected(int position, int prePosition) {
                System.out.println("当前位置" + position + " 前一个位置" + prePosition);
                showHideFragment(mFragments[position], mFragments[prePosition]);
            }

            @Override
            public void onTabUnselected(int position) {
                System.out.println("onTabUnselected" + position);

            }

            @Override
            public void onTabReselected(int position) {
                System.out.println("onTabReselected" + position);
                SupportFragment currentFragment = mFragments[position];
                int count = currentFragment.getChildFragmentManager().getBackStackEntryCount();

                /*// 如果不在该类别Fragment的主页,则回到主页;
                if (count > 1) {
                    if (currentFragment instanceof MultiFirstFragment) {
                        currentFragment.popToChild(FirstHomeFragment.class, false);
                    } else if (currentFragment instanceof MultiSecondFragment) {
                        currentFragment.popToChild(ViewPagerFragment.class, false);
                    } else if (currentFragment instanceof MultiThirdFragment) {
                        currentFragment.popToChild(BuyCustomFragment.class, false);
                    } else if (currentFragment instanceof MultiFourthFragment) {
                        currentFragment.popToChild(MeFragment.class, false);
                    }
                    return;
                }
                */
                // 这里推荐使用EventBus来实现 -> 解耦
                if (count == 1) {
                    EB.postEmpty(EB.TAG.A);
                }
            }
        });
    }

    @Override
    public void onBackToFirstFragment() {
        mBottomBar.setCurrentItem(0);
    }

    /**
     * 这个地方必须调用
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        UMShareAPI.get(this).onActivityResult(requestCode, resultCode, data);
    }

    //    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.menu_main, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        int id = item.getItemId();
//        if (id == R.id.action_settings) {
//            return true;
//        }
//        return super.onOptionsItemSelected(item);
//    }


}
