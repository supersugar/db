package com.uu393.market.model.request;

public class GGetGameList {

    /**
     * "platForm": "-1",（游戏平台，0app游戏  1h5游戏  -1所有游戏）
     "theme": "-1",（游戏题材  -1表示所有题材）
     "sort": "-1",（排序  -1默认排序  1折扣从低到高  2折扣从高到低）
     "isBT": "0",（是否搜索BT游戏，0否，1是）
     "isFirst": "0",（是否搜索首发游戏，0否，1是）
     */





    public String gameType = "";//游戏类型
    public String gameName = "";//游戏名称
    public String platForm = "";
    public String theme = "";
    public String sort = "";
    public String isBT = "";
    public String isFirst = "";

}
