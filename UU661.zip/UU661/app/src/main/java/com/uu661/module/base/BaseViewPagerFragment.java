package com.uu661.module.base;


import com.uu661.view.lazyviewpager.LazyFragmentPagerAdapter;

/**
 * Created by bo on 16/11/25.
 */

public abstract class BaseViewPagerFragment extends BaseFragment implements LazyFragmentPagerAdapter.Laziable{

    public abstract void refresh(boolean showLoading);
}
