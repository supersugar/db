package com.uu661.module;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.uu661.R;
import com.uu661.core.DialogCenter;
import com.uu661.model.response.BCoupon;
import com.uu661.module.base.BaseFragment;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;


public class TempTextFragment extends BaseFragment {

    String content = "";
    @BindView(R.id.bt1) Button mBt1;


    public static TempTextFragment newInstance(String content) {
        TempTextFragment fragment = new TempTextFragment();
        Bundle args = new Bundle();
        args.putString("content", content);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        content = getArguments().getString("content");
        View view = inflater.inflate(R.layout.temp_fragment, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @OnClick(R.id.bt1)
    public void onClick() {
        showDialog();
    }

    /**
     "id": "10478",
     "title": "仅限3元夺5U钻面值使用",
     "validTime": "长期有效",
     "remark": "体验完可到UU898商品列表页领取4U钻",
     "money": "300",
     "status": "1",
     "useCondition": "3.00元起用",
     "voucherMoney": "300"

     */
    private void showDialog(){
        BCoupon temp = new BCoupon();
        temp.title = "仅限3元夺5U钻面值使用";
        temp.voucherMoney = 300;
        temp.validTime = "长期有效";
        temp.remark = "体验完可到UU898商品列表页领取4U钻";
        temp.commodityNo = 239;
        DialogCenter.showLoginCouponPopDialog(_mActivity, temp);
    }
}
