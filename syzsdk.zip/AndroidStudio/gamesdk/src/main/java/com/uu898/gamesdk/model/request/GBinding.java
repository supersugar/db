package com.uu898.gamesdk.model.request;

import com.uu898.gamesdk.model.GBaseModel;

/**
 * Created by zhangbo on 2016/6/15.
 */
public class GBinding extends GBaseModel {


    private String phoneNo;//绑定的手机号
    private String checkCode;//短信验证码

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getCheckCode() {
        return checkCode;
    }

    public void setCheckCode(String checkCode) {
        this.checkCode = checkCode;
    }
}
