package com.uu393.market.module.search;

import android.Manifest;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentTransaction;

import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.module.MainActivity;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;

import org.greenrobot.eventbus.Subscribe;

import java.util.List;

import me.yokeyword.fragmentation.SupportActivity;
import me.yokeyword.fragmentation.SwipeBackLayout;
import me.yokeyword.fragmentation.anim.DefaultHorizontalAnimator;
import me.yokeyword.fragmentation.anim.FragmentAnimator;
import me.yokeyword.fragmentation_swipeback.SwipeBackActivity;
import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.EasyPermissions;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/14
 * Descrip    : 搜索界面容器
 * =====================================================
 */

public class SearchActivity extends SupportActivity implements EasyPermissions.PermissionCallbacks{
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        if (savedInstanceState == null) {
            loadRootFragment(R.id.fl_search_container, SearchFragment.newInstance());
        }
    }
    public FragmentAnimator onCreateFragmentAnimator() {
        return new DefaultHorizontalAnimator();
    }

    public void onResume() {
        super.onResume();
        EB.register(this);
        MobclickAgent.onResume(this);       //统计时长
    }
    public void onPause() {
        super.onPause();
        MobclickAgent.onPause(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EB.unregister(this);
    }
    @AfterPermissionGranted(100)
    private void requestPermissions() {
        String[] mPermissionList = new String[]{
                //                Manifest.permission.ACCESS_FINE_LOCATION,       //位置信息
                //                Manifest.permission.CALL_PHONE,                 //电话相关
                //                Manifest.permission.READ_LOGS,
                //                Manifest.permission.READ_PHONE_STATE,           //电话相关
                //                Manifest.permission.GET_ACCOUNTS,//联系人,通讯录
                //                Manifest.permission.SET_DEBUG_APP,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,};
        if (!EasyPermissions.hasPermissions(SearchActivity.this, mPermissionList)) {
            EasyPermissions.requestPermissions(SearchActivity.this,
                    "应用下载时需要保存到本地，为了保证核心功能的稳定性，请您同意授权权限", 100, mPermissionList);
        }

    }

    @Override
    public void onPermissionsGranted(int requestCode, List<String> perms) {
        //同意授权

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    @Override
    public void onPermissionsDenied(int requestCode, List<String> perms) {
        //取消授权时
    }
    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.REQUEST_SD_CARD_SEARCH://点击下载时申请sd卡权限
                requestPermissions();
                break;
        }
    }
}
