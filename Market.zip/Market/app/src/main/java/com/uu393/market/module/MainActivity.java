package com.uu393.market.module;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.lzy.okserver.download.DownloadInfo;
import com.lzy.okserver.download.DownloadManager;
import com.uu393.market.R;
import com.uu393.market.core.DownloadHelper;
import com.uu393.market.model.request.GDoCheckUpdate;
import com.uu393.market.model.response.BUpdate;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;

import org.greenrobot.eventbus.Subscribe;

import java.util.Iterator;
import java.util.List;

import cn.finalteam.toolsfinal.ManifestUtils;
import me.yokeyword.fragmentation.anim.DefaultHorizontalAnimator;
import me.yokeyword.fragmentation.anim.FragmentAnimator;
import okhttp3.Call;
import okhttp3.Response;
import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.AppSettingsDialog;
import pub.devrel.easypermissions.EasyPermissions;

/**
 * 主页
 */
public class MainActivity extends BaseActivity implements EasyPermissions.PermissionCallbacks {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (savedInstanceState == null) {
            loadRootFragment(R.id.fl_container, MainFragment.newInstance());
        }
        resumeDownload();
        //悬浮窗权限必须单独申请  SYSTEM_ALERT_WINDOW and WRITE_SETTINGS, 这两个权限比较特殊，
        // 不能通过代码申请方式获取，必须得用户打开软件设置页手动打开，才能授权
        //requestDrawOverLays();//放到进入H5游戏后
//        requestPermissions();
        //initDialog();//广告弹出框
        L.d(checkPhoneType());
        checkUpdate(this);
    }

    //请求悬浮窗权限
    public void requestDrawOverLays() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            String string = checkPhoneType().toString();//手机型号
            if (TextUtils.isEmpty(string)) return;
            String lowerCase = string.toLowerCase().trim().replace(" ", "");
            if (lowerCase.contains("huawei")) {
                showOverlayQuest(false);//不需请求也可显示浮球
            } else if (lowerCase.contains("r9splus")) {
                showOverlayQuest(false);//不需请求也可显示浮球
            } else {
                showOverlayQuest(true);
            }
        }
    }

    private void showOverlayQuest(boolean show) {
        if (show) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.canDrawOverlays(MainActivity.this)) {
                    AppSettingsDialog appSettingsDialog = new AppSettingsDialog.Builder(this, "为了您能使用悬浮球功能，请开启悬浮窗权限")
                            .setTitle("提示")
                            .setPositiveButton("去设置")
                            .setNegativeButton("取消", null)
                            .setRequestCode(100).build();
                    appSettingsDialog.show();
                }
            }
        }
    }

    private void initDialog() {
        View inflate = LayoutInflater.from(MainActivity.this).inflate(R.layout.dialog_start, null, false);
        ImageView ad = (ImageView) inflate.findViewById(R.id.iv_ad);
        ImageView ad_close = (ImageView) inflate.findViewById(R.id.iv_ad_close);

        final Dialog dialog = new Dialog(MainActivity.this, R.style.DialogStyle);
        dialog.setContentView(inflate);
        Window window = dialog.getWindow();
        window.setGravity(Gravity.CENTER);
        //获得窗体的属性
        WindowManager.LayoutParams lp = window.getAttributes();
        window.setAttributes(lp);
        dialog.show();//显示对话框
        ad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               /* Intent intent = new Intent(MainActivity.this, AppDetailActivity.class);
                intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_ID, "");//todo 游戏信息
                MainActivity.this.startActivity(intent);*/
            }
        });
        ad_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }


    /**
     * 提示恢复下载
     */
    private void resumeDownload() {
        final List<DownloadInfo> list = DownloadManager.getInstance().getAllTask();
        if (list == null || list.isEmpty()) {
            return;
        }
        boolean continueDownload = false;
        for (DownloadInfo temp : list) {
            if (temp.getState() == DownloadManager.PAUSE || temp.getState() == DownloadManager.WAITING || temp.getState() ==
                    DownloadManager.ERROR || temp.getState() == DownloadManager.NONE) {
                continueDownload = true;
                break;
            }
        }
        if (continueDownload && DownloadHelper.checkCanDownload(this)) {
            MaterialDialog.Builder builder = new MaterialDialog.Builder(this)
                    .content("发现有未下载完的应用，您是否要继续下载？")
                    .positiveText("是")
                    .negativeText("否")
                    .onPositive(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            //DownloadManager.getInstance().startAllTask();//开启全部坑能会出concurentException，okserver内部异常
                            if (!list.isEmpty()) {
                                Iterator<DownloadInfo> iterator = list.iterator();
                                while (iterator.hasNext()) {
                                    DownloadInfo downloadInfo = iterator.next();
                                    if (downloadInfo == null) {
                                        continue;
                                    }
                                    DownloadManager.getInstance().addTask(downloadInfo.getTaskKey(), downloadInfo.getRequest(), downloadInfo.getListener());
                                    requestPermissions();
                                }
                            }
                        }
                    });

            MaterialDialog dialog = builder.build();
            dialog.show();
        }
    }

    /**
     * 参数必须是Activity对象，因为创建Dialog对象需要Activity上下文对象
     */
    public void checkUpdate(final Activity context) {
        GDoCheckUpdate model = new GDoCheckUpdate();
        int versionCode = ManifestUtils.getVersionCode(context);
        model.setVersionCode(String.valueOf(versionCode));
        TaskEngine.getInstance().doCheckUpdate(model, new JsonCallback<BUpdate>() {
            @Override
            public void onSuccess(final BUpdate result, Call call, Response response) {
                if (null != result) {
                    int currentVersionCode = ManifestUtils.getVersionCode(context);
                    if (currentVersionCode >= result.versionCode) {
                        //没有新版本
                        return;
                    }
                    if (currentVersionCode < result.versionCode) {
                        new MaterialDialog.Builder(context)
                                .title("更新提示")
                                .content(result.updateInfo)
                                .positiveText("马上更新")
                                .negativeText(result.isForceUpdate == 0 ? "稍候再说" : "")
                                .negativeColor(context.getResources().getColor(R.color.text_lv2))
                                .onNegative(new MaterialDialog.SingleButtonCallback() {
                                    @Override
                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                        //不更新，无操作
                                    }
                                })
                                .cancelable(result.isForceUpdate == 0 ? true : false)//是否强制更新，0否  1是
                                .onPositive(new MaterialDialog.SingleButtonCallback() {
                                    @Override
                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                        Uri uri = Uri.parse(result.packageUrl);
                                        Intent intent = new Intent(Intent.ACTION_VIEW);
                                        intent.setData(uri);
                                        context.startActivity(intent);

                                    }
                                }).build().show();

                    }
                }
            }
        });
    }

    @Override
    public void onBackPressedSupport() {
        // 对于 4个类别的主Fragment内的回退back逻辑,已经在其onBackPressedSupport里各自处理了
        super.onBackPressedSupport();
    }

    @Override
    public FragmentAnimator onCreateFragmentAnimator() {
        // 设置横向(和安卓4.x动画相同)
        return new DefaultHorizontalAnimator();
    }

    @AfterPermissionGranted(100)
    private void requestPermissions() {
        String[] mPermissionList = new String[]{
                //                Manifest.permission.ACCESS_FINE_LOCATION,       //位置信息
                //                Manifest.permission.CALL_PHONE,                 //电话相关
                //                Manifest.permission.READ_LOGS,
                //                Manifest.permission.READ_PHONE_STATE,           //电话相关
                //                Manifest.permission.GET_ACCOUNTS,//联系人,通讯录
                //                Manifest.permission.SET_DEBUG_APP,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,};
        if (!EasyPermissions.hasPermissions(MainActivity.this, mPermissionList)) {
            EasyPermissions.requestPermissions(MainActivity.this,
                    "应用下载时需要保存到本地，为了保证核心功能的稳定性，请您同意授权权限", 100, mPermissionList);
        }

    }

    @Override
    public void onPermissionsGranted(int requestCode, List<String> perms) {
        //同意授权

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    @Override
    public void onPermissionsDenied(int requestCode, List<String> perms) {
        //取消授权时
    }

    /**
     * 检查手机类型， 是否是三星 小米 或 普通root机 普通非root机
     */
    public String checkPhoneType() {

        String phoneInfo = "\n手机型号:" + android.os.Build.MODEL
                + "\n系统版本:" + android.os.Build.VERSION.RELEASE
                + "\n产品型号:" + android.os.Build.PRODUCT
                + "\n版本显示:" + android.os.Build.DISPLAY
                + "\n系统定制商:" + android.os.Build.BRAND
                + "\n设备参数:" + android.os.Build.DEVICE
                + "\n开发代号:" + android.os.Build.VERSION.CODENAME
                + "\nSDK版本号:" + android.os.Build.VERSION.SDK_INT
                + "\nCPU类型:" + android.os.Build.CPU_ABI
                + "\n硬件类型:" + android.os.Build.HARDWARE
                + "\n主机:" + android.os.Build.HOST
                + "\n生产ID:" + android.os.Build.ID
                + "\nROM制造商:" + android.os.Build.MANUFACTURER // 这行返回的是rom定制商的名称
                ;
        return phoneInfo;
    }

    @Override
    protected void onResume() {
        super.onResume();
        EB.register(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        EB.unregister(this);
    }

    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.REQUEST_SD_CARD://点击下载时申请sd卡权限
                requestPermissions();
                break;
        }
    }
}
