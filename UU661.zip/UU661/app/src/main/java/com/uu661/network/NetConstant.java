package com.uu661.network;


import com.uu661.util.RsaHelper;

import java.security.PublicKey;

public class NetConstant {

    public static final String APP_KEY = "C7E9F8BA01F263439244141F366B60A7";


    public static final class URL {

        public static final String URL_898_TEST = "http://192.168.5.113:9090/Service/UZuanService.ashx?";
        //        public static final String URL_898_TEST = "http://service.uu898.com/Service/UZuanService.ashx?";
                public static final String URL_898_OFFICIAL = "http://service.uu898.com/Service/UZuanService.ashx?";

        public static final String URL_661_TEST = "http://192.168.5.113:8090/tools/testUzuanApp.ashx?";
        //        public static final String URL_661_TEST = "http://m.uu661.com/ashx/testUzuanApp.ashx?";
                public static final String URL_661_OFFICIAL = "http://m.uu661.com/ashx/testUzuanApp.ashx?";
    }

    public static final class WEB {

        //UU898用户协议
        public static final String USER_PROTOCOL = "http://html.uu898.com/protocol/userProtocol.htm";
        //忘记密码
        public static final String FORGET_PASSWORD = "http://user.uu898.com/login/RefindPwd";
        //充值
        public static final String CHARGE_MONEY = "http://user.uu898.com/account/chongzhi.aspx?";

    }

    public static final class Secret {
        public static final PublicKey RSA_PUBLIC_KEY = RsaHelper.decodePublicKeyFromXml
                ("<RSAKeyValue><Modulus>5slAeP+It12sX4tywHpMdzw7EqLaFpjhcyu1E4/9740QWMknMGs9lP9S4FeAqtGaZUSJ" +
                "/2bcSaDCLx67UQeMmqXRiM4YKZDB7PsRKZH8ZI+7FO4yD97p/SWvxpyzI6oqqjqSVOJYwypaRP/jrqCzKGWQ69MSHSTgkmDetrvjTFM" +
                "=</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>");

    }

    /**********************
     * 协议
     ****************************************/

    public static final class Api {
        //898
        public static final String GET_VERIFY_CODE = "uzuanapp00001";
        public static final String REGIST = "uzuanapp00002";
        public static final String LOGIN = "uzuanapp00003";
        public static final String GET_PAY_SETTING = "uzuanapp00004";
        public static final String THIRD_LOGIN = "uzuanapp00006";
        public static final String GET_COUPON_EVENT = "uzuanapp00007";
        //661
        public static final String GET_UPDATE = "uzuanapp10000";//获取版本更新
        public static final String GET_PAY_SIGN = "uzuanapp10001";//获取支付签名
        public static final String GET_USER_INFO = "uzuanapp10002";//获取用户信息
        public static final String GET_USER_VERIFY_INFO = "uzuanapp10003";//获取用户验证方式
        public static final String GET_PAY_VERIFY_CODE = "uzuanapp10004";//获取支付验证码

        public static final String GET_BANNERS = "uzuanapp20001";//获取轮播图片

        public static final String GET_DIAMOND_LIST = "uzuanapp60001";//获取钻石列表
        public static final String ALL_LUCKY_MAN_LIST = "uzuanapp60002";//全站获奖记录滚动显示
        public static final String GET_DIAMOND_INFO = "uzuanapp60003";//商品信息
        public static final String GET_DIAMOND_BUY_RECORD = "uzuanapp60004";//U钻每期购买记录
        public static final String GET_CALCULATE_DETAIL = "uzuanapp60005";//计算详情
        public static final String CREATE_UU_ORDER = "uzuanapp60006";//生成订单号
        public static final String GO_PAY = "uzuanapp60007";//使用余额支付
        public static final String GET_ORDER_DETAIL = "uzuanapp60008";//获取订单详情
        public static final String GET_ORDER_LIST = "uzuanapp60009";//获取订单记录
        public static final String GET_THIRD_ORDER_NO = "uzuanapp60010";//获取第三方支付方式订单号
        public static final String GET_DIAMOND_NUM = "uzuanapp60011";//U钻购买情况(返回已买和剩余人次)
        public static final String GET_DIAMOND_CODE_LIST = "uzuanapp60013";//夺钻号码列表

        public static final String GET_COUPON_LIST = "uzuanapp40001";//红包列表
        //        public static final String LOGIN = "uzuanapp60005";
        //        public static final String LOGIN = "uzuanapp60006";


    }


}
