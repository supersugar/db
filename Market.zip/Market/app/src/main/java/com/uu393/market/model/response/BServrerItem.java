package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * Created by Administrator on 2017/4/18.
 */

public class BServrerItem implements Serializable {




    /**
     * {
     "icon": "123456",（图标）
     "gameName": "大主宰"（游戏名称）
     "androidPackage": "Http:1213”,(安卓下载包地址)
     "id": "1”,(服务器编号)
     "serverName": "001服”,(服务器名称)
     "discount": "1”,(折扣)
     }

     */

    private String icon;
    private String gameName;
    private String androidPackage;
    private String id;
    private String serverName;
    private String discount;
    private String packageName;

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }

    public String getAndroidPackage() {
        return androidPackage;
    }

    public void setAndroidPackage(String androidPackage) {
        this.androidPackage = androidPackage;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getServerName() {
        return serverName;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }


}
