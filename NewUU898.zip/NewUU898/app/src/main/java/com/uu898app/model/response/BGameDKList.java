package com.uu898app.model.response;

import java.util.List;

/**
 * Created by zhangbo on 2016/7/19.
 */
public class BGameDKList {


    /**
     * price : 9.70
     * title : 10元点卡
     * IsAreaAndServer : False
     * cardNo : DK20120808155024-63892
     * point : 10
     * marketPrice : 10.00
     */

    private List<BGameDK> parVal;

    public List<BGameDK> getParVal() {
        return parVal;
    }

    public void setParVal(List<BGameDK> parVal) {
        this.parVal = parVal;
    }

    public static class BGameDK {
        private String price;
        private String title;
        private String IsAreaAndServer;
        private String cardNo;
        private String point;
        private String marketPrice;

        @Override
        public String toString() {
            return getTitle() + "\r\n" + "市场价 : "+ getMarketPrice() + "  " + "优惠价 : " + getPrice();
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getIsAreaAndServer() {
            return IsAreaAndServer;
        }

        public void setIsAreaAndServer(String IsAreaAndServer) {
            this.IsAreaAndServer = IsAreaAndServer;
        }

        public String getCardNo() {
            return cardNo;
        }

        public void setCardNo(String cardNo) {
            this.cardNo = cardNo;
        }

        public String getPoint() {
            return point;
        }

        public void setPoint(String point) {
            this.point = point;
        }

        public String getMarketPrice() {
            return marketPrice;
        }

        public void setMarketPrice(String marketPrice) {
            this.marketPrice = marketPrice;
        }
    }
}
