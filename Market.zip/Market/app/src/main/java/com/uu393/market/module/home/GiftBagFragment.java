package com.uu393.market.module.home;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GGetGameDetail;
import com.uu393.market.model.response.BGiftBagInfo;
import com.uu393.market.module.base.BaseViewPagerFragment;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import okhttp3.Call;
import okhttp3.Response;


public class GiftBagFragment extends BaseViewPagerFragment {


    @Bind(R.id.ptf_gift_bag)
    PullLoadMoreRecyclerView mPtfRecyclerView;


    //默认未登入
  private int doGetUserIsOn  =1;

    private GiftBagAdapter mGiftBagAdapter;
    private String mGameId;
    private List<BGiftBagInfo> mGifgBags = new ArrayList<>();
    public GiftBagFragment() {
        // Required empty public constructor
    }

    public static GiftBagFragment newInstance(String gameId) {
        GiftBagFragment fragment = new GiftBagFragment();
        Bundle bundle = new Bundle();
        bundle.putString("gameId",gameId);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_gift_bag, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (getArguments()!=null){
            mGameId = getArguments().getString("gameId");
        }

        initRecyclerView();
    }

    @Override
    public void refresh() {

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        getGiftBagList();
    }

    private void initRecyclerView() {
        mPtfRecyclerView.setLinearLayout();
        mGiftBagAdapter = new GiftBagFragment.GiftBagAdapter();
        mPtfRecyclerView.setPullRefreshEnable(false);
        mPtfRecyclerView.setPushRefreshEnable(false);
        mPtfRecyclerView.setAdapter(mGiftBagAdapter);
        mPtfRecyclerView.setOnPullLoadMoreListener(new PullLoadMoreRecyclerView.PullLoadMoreListener() {
            @Override
            public void onRefresh() {
                getGiftBagList();
                mPtfRecyclerView.setPullLoadMoreCompleted();
            }

            @Override
            public void onLoadMore() {

            }
        });
    }
    private void getGiftBagList(){
        if (TextUtils.isEmpty(mGameId)){
            return;
        }
        GGetGameDetail model = new GGetGameDetail(mGameId);//传入游戏id
        if (!SPUtil.get(App.mContext,"userId","").equals("") && !SPUtil.get(App.mContext,"uId","").equals("")){
            doGetUserIsOn = 2;
        }
        TaskEngine.setTokenUseridPhoneState(doGetUserIsOn);

        TaskEngine.getInstance().doGetGameGiftBaglist(model, new JsonCallback<List<BGiftBagInfo>>() {
            @Override
            public void onSuccess(List<BGiftBagInfo> bGiftBagInfos, Call call, Response response) {

                if (bGiftBagInfos==null||bGiftBagInfos.isEmpty()){
                    ToastUtil.showToast(App.mContext,"暂无礼包信息");
                }else {
                    mGifgBags.clear();
                    mGifgBags.addAll(bGiftBagInfos);
                    mGiftBagAdapter.refresh(mGifgBags);
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);

                ToastUtil.showToast(App.mContext,"e"+e);
            }
        });
    }
    // 礼包列表适配器
    public class GiftBagAdapter extends RecyclerView.Adapter<GiftBagFragment.GiftBagAdapter.GiftBagItemHolder> {
        private List<BGiftBagInfo> bags =new ArrayList<>();

        @Override
        public GiftBagAdapter.GiftBagItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_gift_bag, parent, false);

            return new GiftBagAdapter.GiftBagItemHolder(inflate);
        }

        @Override
        public void onBindViewHolder(GiftBagFragment.GiftBagAdapter.GiftBagItemHolder holder, final int position) {
         holder.bindItem(bags.get(position));
          holder.parent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //todo 传去参数 礼包详情

                    Intent intent = new Intent(_mActivity, NewGiftBagDetailActivity.class);
                    intent.putExtra("bagId",bags.get(position).getId());
                    _mActivity.startActivity(intent);
                }
            });
        }

        @Override
        public int getItemCount() {
            return bags.size();
        }

        public void refresh(List<BGiftBagInfo> bags){
            this.bags = bags;
            this.notifyDataSetChanged();
        }


        public class GiftBagItemHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
            private TextView name, count,totalCount, date, status;
            private ImageButton go;
            private View parent;
            private LinearLayout mGo_gamedetaile;
            private BGiftBagInfo mBGiftBagInfo;

            public GiftBagItemHolder(View itemView) {
                super(itemView);
                parent = itemView.findViewById(R.id.rl_gift_bag_item_parent);
                name = (TextView) itemView.findViewById(R.id.tv_gift_bag_name);
                totalCount = (TextView) itemView.findViewById(R.id.tv_gift_bag_total_count);
                count = (TextView) itemView.findViewById(R.id.tv_gift_bag_count);
                date = (TextView) itemView.findViewById(R.id.tv_gift_bag_date);
                status = (TextView) itemView.findViewById(R.id.tv_gift_bag_status);
                go = (ImageButton) itemView.findViewById(R.id.ib_gift_bag_item_go);
                parent.setOnClickListener(this);

            }

            private void bindItem(BGiftBagInfo bag) {
                mBGiftBagInfo = bag;
                name.setText(mBGiftBagInfo.getGiftName());
                totalCount.setText("剩余数量："+mBGiftBagInfo.getSurplusNumber()+" / ");
                count.setText(mBGiftBagInfo.getTotalNumber());
                date.setText(mBGiftBagInfo.getExpiredTime());

                if (mBGiftBagInfo.getIsReceive().equals("0") ||  doGetUserIsOn == 1){
                    status.setText("未领取");
                }
                if ("1".equals(mBGiftBagInfo.getIsReceive())) {
                    status.setText("已领取");
                }




            }

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(_mActivity, NewGiftBagDetailActivity.class);
                intent.putExtra("bagId",mBGiftBagInfo.getId());
                _mActivity.startActivity(intent);

            }
        }
    }
}
