package com.uu661.model.response;

import java.io.Serializable;

/**
 *
 */
public class BCoupon implements Serializable {

    public String id;//
    public String title;//
    public String validTime;//
    public String remark;//
    public int money;//余额
    public int voucherMoney;//原始价格
    public int status;//（1可用，2过期，3已使用）
    public int ifGet;//是否已领取
    public int ifOver;//是否已领完
    public String useCondition;//
    public int commodityNo;//商品编号  如果为-1位所有商品可用

}
