package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/3
 * Descrip    :
 * =====================================================
 */

public class BGiftBagDetail implements Serializable {

    /**
     * id : 1
     * giftName : 情人节礼包
     * totalNumber : 5000
     * surplusNumber : 3800
     * expiredTime : 2017-03-02 10:00:00
     * status : 0
     * giftInfo : 0
     * useMethod : 输入激活码
     * useScope : 全服通用
     * code : 已领取的兑换码
     * icon : fds.jpg
     */

    private String id;
    private String giftName;
    private String totalNumber;
    private String surplusNumber;
    private String expiredTime;
    private String status;
    private String giftInfo;
    private String useMethod;
    private String useScope;
    private String code;
    private String icon;
    private String receiverTime;

    public String getReceiverTime() {
        return receiverTime;
    }

    public void setReceiverTime(String receiverTime) {
        this.receiverTime = receiverTime;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGiftName() {
        return giftName;
    }

    public void setGiftName(String giftName) {
        this.giftName = giftName;
    }

    public String getTotalNumber() {
        return totalNumber;
    }

    public void setTotalNumber(String totalNumber) {
        this.totalNumber = totalNumber;
    }

    public String getSurplusNumber() {
        return surplusNumber;
    }

    public void setSurplusNumber(String surplusNumber) {
        this.surplusNumber = surplusNumber;
    }

    public String getExpiredTime() {
        return expiredTime;
    }

    public void setExpiredTime(String expiredTime) {
        this.expiredTime = expiredTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getGiftInfo() {
        return giftInfo;
    }

    public void setGiftInfo(String giftInfo) {
        this.giftInfo = giftInfo;
    }

    public String getUseMethod() {
        return useMethod;
    }

    public void setUseMethod(String useMethod) {
        this.useMethod = useMethod;
    }

    public String getUseScope() {
        return useScope;
    }

    public void setUseScope(String useScope) {
        this.useScope = useScope;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }
}
