package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * Created by bo on 16/9/14.
 */
public class BUpdate implements Serializable {

    public int isForceUpdate;//是否强制更新，0否  1是
    public int versionCode;//版本号
    public String versionName;//版本名称
    public String packageUrl;//下载地址
    public String updateInfo;//更新内容
}
