package com.uu661.model.response;

import java.io.Serializable;

/**
 * Created by bo on 16/9/14.
 */
public class BVerifyInfo implements Serializable {

    public static final int TYPE_ZF = 1;//支付密码验证
    public static final int TYPE_SMS = 2;//短信验证
    public static final int TYPE_WX = 3;//短信验证
    public static final int TYPE_ML = 6;//密令验证


    //默认验证方式，1：支付密码，2：手机，3：微信，6：UU密令
    private int defaultValidType;//默认验证方式

    //1 == true 没有任何绑定 0 == false 有至少一种绑定
    private int isBindNone;//是否没有任何绑定

    //1 == true 有绑定，0 == false 没有绑定
    private int isBindWeChat;//是否绑定微信验证
    private int isBindMobile;//是否绑定手机验证
    private int isBindUU;//是否绑定UU密令验证

    //
    private int isBindPassword;//是否绑定密码验证

    public int getDefaultValidType() {
        return defaultValidType;
    }

    public void setDefaultValidType(int defaultValidType) {
        this.defaultValidType = defaultValidType;
    }

    public boolean getIsBindNone() {
        return isBindNone == 1 ? true : false;
    }

    public void setIsBindNone(int isBindNone) {
        this.isBindNone = isBindNone;
    }

    public boolean getIsBindPassword() {
        return isBindPassword == 1 ? true : false;
    }

    public void setIsBindPassword(int isBindPassword) {
        this.isBindPassword = isBindPassword;
    }

    public boolean getIsBindWeChat() {
        return isBindWeChat == 1 ? true : false;
    }

    public void setIsBindWeChat(int isBindWeChat) {
        this.isBindWeChat = isBindWeChat;
    }

    public boolean getIsBindMobile() {
        return isBindMobile == 1 ? true : false;
    }

    public void setIsBindMobile(int isBindMobile) {
        this.isBindMobile = isBindMobile;
    }

    public boolean getIsBindUU() {
        return isBindUU == 1 ? true : false;
    }

    public void setIsBindUU(int isBindUU) {
        this.isBindUU = isBindUU;
    }
}
