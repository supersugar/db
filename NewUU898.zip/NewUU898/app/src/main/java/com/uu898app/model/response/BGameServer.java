package com.uu898app.model.response;

/**
 * Created by zhangbo on 2016/6/21.
 */
public class BGameServer {

    /**
     * firstCharactor : B
     * smCount : 0
     * areaID : 1681
     * endUpdateTime :
     * orderIndex : 0
     * sSelfTrade : false
     * suCount : 0
     * addtime : 2014/8/9 9:18:32
     * cuCount : 0
     * serverCamp : 0
     * ServerStatus : 0
     * isFree : 0
     * cmCount : 0
     * name : 白虹贯日/义薄云天/灵动九天
     * ID : 10818
     * attributes : 0
     * sUpdating : false
     * pinyin : baihongguanri/yiboyuntian/lingdongjiutian
     */

    private String firstCharactor;
    private int smCount;
    private int areaID;
    private String endUpdateTime;
    private int orderIndex;
    private boolean sSelfTrade;
    private int suCount;
    private String addtime;
    private int cuCount;
    private int serverCamp;
    private int ServerStatus;
    private int isFree;
    private int cmCount;
    private String name;
    private int ID;
    private int attributes;
    private boolean sUpdating;
    private String pinyin;

    public String getFirstCharactor() {
        return firstCharactor;
    }

    public void setFirstCharactor(String firstCharactor) {
        this.firstCharactor = firstCharactor;
    }

    public int getSmCount() {
        return smCount;
    }

    public void setSmCount(int smCount) {
        this.smCount = smCount;
    }

    public int getAreaID() {
        return areaID;
    }

    public void setAreaID(int areaID) {
        this.areaID = areaID;
    }

    public String getEndUpdateTime() {
        return endUpdateTime;
    }

    public void setEndUpdateTime(String endUpdateTime) {
        this.endUpdateTime = endUpdateTime;
    }

    public int getOrderIndex() {
        return orderIndex;
    }

    public void setOrderIndex(int orderIndex) {
        this.orderIndex = orderIndex;
    }

    public boolean isSSelfTrade() {
        return sSelfTrade;
    }

    public void setSSelfTrade(boolean sSelfTrade) {
        this.sSelfTrade = sSelfTrade;
    }

    public int getSuCount() {
        return suCount;
    }

    public void setSuCount(int suCount) {
        this.suCount = suCount;
    }

    public String getAddtime() {
        return addtime;
    }

    public void setAddtime(String addtime) {
        this.addtime = addtime;
    }

    public int getCuCount() {
        return cuCount;
    }

    public void setCuCount(int cuCount) {
        this.cuCount = cuCount;
    }

    public int getServerCamp() {
        return serverCamp;
    }

    public void setServerCamp(int serverCamp) {
        this.serverCamp = serverCamp;
    }

    public int getServerStatus() {
        return ServerStatus;
    }

    public void setServerStatus(int ServerStatus) {
        this.ServerStatus = ServerStatus;
    }

    public int getIsFree() {
        return isFree;
    }

    public void setIsFree(int isFree) {
        this.isFree = isFree;
    }

    public int getCmCount() {
        return cmCount;
    }

    public void setCmCount(int cmCount) {
        this.cmCount = cmCount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getAttributes() {
        return attributes;
    }

    public void setAttributes(int attributes) {
        this.attributes = attributes;
    }

    public boolean isSUpdating() {
        return sUpdating;
    }

    public void setSUpdating(boolean sUpdating) {
        this.sUpdating = sUpdating;
    }

    public String getPinyin() {
        return pinyin;
    }

    public void setPinyin(String pinyin) {
        this.pinyin = pinyin;
    }
}
