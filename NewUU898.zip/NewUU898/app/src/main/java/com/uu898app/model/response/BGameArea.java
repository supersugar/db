package com.uu898app.model.response;

/**
 * Created by zhangbo on 2016/6/21.
 */
public class BGameArea {
    /**
     * ID : 792
     * gameID : 41
     * name : 电信3-6
     * areaIndex : 7
     * firstCharactor : D
     * pinyin : dianxin3-6
     */

    private int ID;
    private int gameID;
    private String name;
    private int areaIndex;
    private String firstCharactor;
    private String pinyin;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getGameID() {
        return gameID;
    }

    public void setGameID(int gameID) {
        this.gameID = gameID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAreaIndex() {
        return areaIndex;
    }

    public void setAreaIndex(int areaIndex) {
        this.areaIndex = areaIndex;
    }

    public String getFirstCharactor() {
        return firstCharactor;
    }

    public void setFirstCharactor(String firstCharactor) {
        this.firstCharactor = firstCharactor;
    }

    public String getPinyin() {
        return pinyin;
    }

    public void setPinyin(String pinyin) {
        this.pinyin = pinyin;
    }
}
