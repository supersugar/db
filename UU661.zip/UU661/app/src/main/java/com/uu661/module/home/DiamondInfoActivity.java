package com.uu661.module.home;

import android.os.Bundle;

import com.uu661.R;
import com.uu661.module.base.BaseSwipeBackActivity;

public class DiamondInfoActivity extends BaseSwipeBackActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (savedInstanceState == null) {
            loadRootFragment(R.id.fl_container, DiamondInfoFragment.newInstance());
        }
    }
}
