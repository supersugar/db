package com.uu898app.model.response;

/**
 * Created by zhangbo on 2016/7/4.
 */
public class BGoods {
    /**
     * ID : 97249674
     * server : 25194
     * commodityNo : CN20160704114521-04960
     * commodityType : -3
     * coinCount : 21300.0
     * coinUnit : 10000
     * businessType : 3
     * price : 100.0
     * number : 5
     * title : 100元=21300万金★手工打造，安全可靠★★安全赔付，找回立刻赔★
     * addtime : 2016/7/4 11:43:47
     * deadTime : 2016/8/3 11:44:00
     * camp : 0
     * area : 1606
     * game : 41
     * images :
     * commodityTypeName : 游戏币
     * campName :
     * serverName : 天仙
     * areaName : 辉煌双线
     * gameName : 完美国际2
     * scale : 1元=213万金
     * scaleByJin : 0.0047元/万金
     * unitName : 万金
     * inputType : 0
     */

    private int ID;
    private int server;
    private String commodityNo;
    private int commodityType;
    private double coinCount;
    private int coinUnit;
    private int businessType;
    private double price;
    private int number;
    private String title;
    private String addtime;
    private String deadTime;
    private int camp;
    private int area;
    private int game;
    private String images;
    private String commodityTypeName;
    private String campName;
    private String serverName;
    private String areaName;
    private String gameName;
    private String scale;
    private String scaleByJin;
    private String unitName;
    private String inputType;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getServer() {
        return server;
    }

    public void setServer(int server) {
        this.server = server;
    }

    public String getCommodityNo() {
        return commodityNo;
    }

    public void setCommodityNo(String commodityNo) {
        this.commodityNo = commodityNo;
    }

    public int getCommodityType() {
        return commodityType;
    }

    public void setCommodityType(int commodityType) {
        this.commodityType = commodityType;
    }

    public double getCoinCount() {
        return coinCount;
    }

    public void setCoinCount(double coinCount) {
        this.coinCount = coinCount;
    }

    public int getCoinUnit() {
        return coinUnit;
    }

    public void setCoinUnit(int coinUnit) {
        this.coinUnit = coinUnit;
    }

    public int getBusinessType() {
        return businessType;
    }

    public void setBusinessType(int businessType) {
        this.businessType = businessType;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAddtime() {
        return addtime;
    }

    public void setAddtime(String addtime) {
        this.addtime = addtime;
    }

    public String getDeadTime() {
        return deadTime;
    }

    public void setDeadTime(String deadTime) {
        this.deadTime = deadTime;
    }

    public int getCamp() {
        return camp;
    }

    public void setCamp(int camp) {
        this.camp = camp;
    }

    public int getArea() {
        return area;
    }

    public void setArea(int area) {
        this.area = area;
    }

    public int getGame() {
        return game;
    }

    public void setGame(int game) {
        this.game = game;
    }

    public String getImages() {
        return images;
    }

    public void setImages(String images) {
        this.images = images;
    }

    public String getCommodityTypeName() {
        return commodityTypeName;
    }

    public void setCommodityTypeName(String commodityTypeName) {
        this.commodityTypeName = commodityTypeName;
    }

    public String getCampName() {
        return campName;
    }

    public void setCampName(String campName) {
        this.campName = campName;
    }

    public String getServerName() {
        return serverName;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }

    public String getScale() {
        return scale;
    }

    public void setScale(String scale) {
        this.scale = scale;
    }

    public String getScaleByJin() {
        return scaleByJin;
    }

    public void setScaleByJin(String scaleByJin) {
        this.scaleByJin = scaleByJin;
    }

    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public String getInputType() {
        return inputType;
    }

    public void setInputType(String inputType) {
        this.inputType = inputType;
    }
}
