package com.uu393.market.module.login;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.lzy.okgo.request.BaseRequest;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.Constant;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.BaseModel;
import com.uu393.market.model.request.GDoAddPlayedGame;
import com.uu393.market.model.request.GDoLogin;
import com.uu393.market.model.request.GDoRegister;
import com.uu393.market.model.request.GGetPhoneCode;
import com.uu393.market.model.response.BUserInfo;
import com.uu393.market.model.response.BUserToken;
import com.uu393.market.module.base.BaseFragment;
import com.uu393.market.module.h5game.H5WebViewActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.RsaHelper;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/16
 * Descrip    :
 * =====================================================
 */

public class PhoneRegisterFragment extends BaseFragment {

    @Bind(R.id.et_register_phone_number)
    EditText mEtRegisterPhoneNumber;
    @Bind(R.id.et_register_phone_code)
    EditText mEtRegisterPhoneCode;
    @Bind(R.id.tv_register_phone_get_code)
    Button mTvRegisterPhoneGetCode;
    @Bind(R.id.et_register_phone_set_pass)
    EditText mEtRegisterPhoneSetPass;
    @Bind(R.id.et_register_phone_verify_pass)
    EditText mEtRegisterPhoneVerifyPass;
    @Bind(R.id.btn_phone_register_login)
    Button mBtnPhoneRegisterLogin;
    private String mPhoneNumber;
    private String mPhoneCode;
    private String mPassWord;
    private String mPassWordVerify;
    private String mGameId;
    private String APPID;
    private String mGameUrl;
    public static PhoneRegisterFragment newInstance() {
        PhoneRegisterFragment fragment = new PhoneRegisterFragment();
        fragment.setArguments(new Bundle());
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.register_phone_acount, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }

    @OnClick({R.id.tv_register_phone_get_code, R.id.btn_phone_register_login})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_register_phone_get_code://获取验证码
                doGetPhoneCode();
                break;
            case R.id.btn_phone_register_login://注册成功，立即登录
                doLogin();
                break;
        }
    }

    /**
     * "password": "123456",（密码）
     * "userId": "18600520720",（用户名）
     * "registerType":"phone",（phone手机注册，custom自定义注册）
     * "checkCode": "859645",（验证码，registerType为phone时为手机验证码，为custom时为图片验证码）
     * "checkCodeToken": "8596fdsfdsfdsfds45",（如果registerType为custom则传token，token为获取图片验证码接口返回的token）
     * "decipheringType": "0"（设备类型：0安卓  1 IOS）
     */
    private void doLogin() {
        mPhoneNumber = mEtRegisterPhoneNumber.getText().toString();
        mPhoneCode = mEtRegisterPhoneCode.getText().toString();
        mPassWord = mEtRegisterPhoneSetPass.getText().toString();
        mPassWordVerify = mEtRegisterPhoneVerifyPass.getText().toString();

        if (StringUtils.isEmpty(mPhoneNumber) ) {
            ToastUtil.showToast(App.mContext, "请输入手机号");
            return;
        }
        if (StringUtils.isEmpty(mPhoneCode)) {
            ToastUtil.showToast(App.mContext, "请输入验证码");
            return;
        }
        if (StringUtils.isEmpty(mPassWord)) {
            ToastUtil.showToast(App.mContext, "请输入密码");
            return;
        }
        if (StringUtils.isEmpty(mPassWordVerify) || !mPassWord.equals(mPassWordVerify)) {
            ToastUtil.showToast(App.mContext, "两次密码输入不一致");
            return;
        }
        GDoRegister model = new GDoRegister();
        model.setRegisterType(Constant.REGISTER_TYPE_PHONE);//phone手机注册，custom自定义注册）
        model.setUserId(mPhoneNumber);
        model.setPassword(RsaHelper.encryptDataFromStr(mPassWord, RsaHelper.RSA_PUBLIC_KEY));
        model.setCheckCode(mPhoneCode);
        model.setDecipheringType("0");
        model.setCheckCodeToken("");
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doRegister(model, new JsonCallback<BUserToken>() {
            @Override
            public void onSuccess(BUserToken bUserToken, Call call, Response response) {

                mGameId = (String) SPUtil.get(App.mContext,"GameId","");
                APPID = (String) SPUtil.get(App.mContext,"APPID","");
                mGameUrl = (String) SPUtil.get(App.mContext,"GameUrl","");
                if (!TextUtils.isEmpty(mGameId)){
                    //todo 登录请求一次，获取用户数据
                    final GDoLogin model = new GDoLogin();
                    model.setUserId(mPhoneNumber);
                    model.setPassword(RsaHelper.encryptDataFromStr(mPassWordVerify, RsaHelper.RSA_PUBLIC_KEY));
                    model.setDecipheringType("0");
                    TaskEngine.setTokenUseridPhoneState(1);
                    TaskEngine.getInstance().doLogin(model, new JsonCallback<BUserInfo>() {
                        @Override
                        public void onSuccess(BUserInfo bUserInfo, Call call, Response response) {
                            MobclickAgent.onProfileSignIn("uushouyou",bUserInfo.getUserId());//友盟统计用户登录
                            SPUtil.put(App.mContext, "isLogin", true);
                            SPUtil.put(App.mContext, "loginType", "0");
                            SPUtil.put(App.mContext, "thirdUserId", "");
                            SPUtil.put(App.mContext, "token", bUserInfo.getToken());
                            SPUtil.put(App.mContext, "userId", bUserInfo.getUserId());
                            SPUtil.put(App.mContext, "uId", bUserInfo.getUId());
                            SPUtil.put(App.mContext, "chkMobile", bUserInfo.getChkMobile());

                            Intent intent = new Intent();
                            intent.putExtra("gameId",mGameId);
                            intent.putExtra("APPID",APPID);
                            intent.putExtra("url",mGameUrl);
                            intent.setClass(getActivity(),H5WebViewActivity.class);
                            startActivity(intent);
                            SPUtil.put(App.mContext, "GameId", "");
                            SPUtil.put(App.mContext, "APPID", "");
                            SPUtil.put(App.mContext, "GameUrl", "");
                            EB.postEmpty(EB.TAG.REGISTER_SUCCESS);
                        }

                    });
                }else {
                    ToastUtil.showToast(App.mContext, "注册成功，返回登录");
                    EB.postEmpty(EB.TAG.REGISTER_SUCCESS);
                }
            }
        });
    }

    //获取手机验证码
    private void doGetPhoneCode() {
        mPhoneNumber = mEtRegisterPhoneNumber.getText().toString();
        if (StringUtils.isEmpty(mPhoneNumber) ) {
            ToastUtil.showToast(App.mContext, "请输入手机号");
            return;
        }
        final CountDownTimer timer = new CountDownTimer(60000, 1000, mTvRegisterPhoneGetCode, "获取验证码");
        timer.start();
        GGetPhoneCode model = new GGetPhoneCode();
        model.setType(Constant.GET_PHONE_CODE_TYPE_4);//手机注册
        model.setPhoneNo(mPhoneNumber);
        model.setUserId("");
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetPhoneCode(model, new JsonCallback<Object>() {
            @Override
            public void onSuccess(Object bPhoneCode, Call call, Response response) {
                /*
                * Status 1 发送次数超过限制，请查看手机收到的验证码
                        2 手机号码格式不正确
                        3 该手机号在黑名单中
                        4 该手机号已被禁用
                        5 该用户没有绑定手机号
                * */
                ToastUtil.showToast(App.mContext,"短信验证码已发送至您的手机");

            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                timer.cancel();
                mTvRegisterPhoneGetCode.setEnabled(true);
                mTvRegisterPhoneGetCode.setText("获取验证码");
            }
        });
    }
    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart("PhoneRegisterFragment");
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("PhoneRegisterFragment");
    }
}
