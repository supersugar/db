package com.uu661.module.discovery;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.uu661.R;
import com.uu661.core.AccountManager;
import com.uu661.module.base.BaseFragment;
import com.uu661.module.base.BaseTabLazyFragment;
import com.uu661.util.log.L;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;


public class DiscoveryFragment extends BaseTabLazyFragment {


    @BindView(R.id.bt_one) RelativeLayout mBtOne;
    @BindView(R.id.bt_two) RelativeLayout mBtTwo;

    public static DiscoveryFragment newInstance() {
        DiscoveryFragment fragment = new DiscoveryFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.discovery_fragment, null);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "发现", false);

    }

    @Override
    public void onSupportVisible() {
        super.onSupportVisible();
        int temp = 0;
        if(null != AccountManager.getInstance().getUserInfo()){
            temp = AccountManager.getInstance().getUserInfo().showStatus;
        }
        if(temp == 1){//展示每日参与夺钻免费领红包入口
            mBtOne.setVisibility(View.VISIBLE);
        }else{
            mBtOne.setVisibility(View.GONE);
        }
    }

    @Override
    public void onLazyInitView(@Nullable Bundle savedInstanceState) {

    }

    @Override
    public void onTabReselected() {

    }


    public void refresh() {
        L.d("refresh()" + this);
    }

    @OnClick({R.id.bt_one, R.id.bt_two})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.bt_one:
                BaseFragment parent1 = (BaseFragment) getParentFragment();
                parent1.start(DiscoveryCouponEvent.newInstance());
                break;
            case R.id.bt_two:
                BaseFragment parent = (BaseFragment) getParentFragment();
                parent.start(DiscoveryDetailFragment.newInstance());
                break;
        }
    }
}
