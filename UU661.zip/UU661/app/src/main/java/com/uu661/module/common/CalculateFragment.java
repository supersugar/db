package com.uu661.module.common;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.lcodecore.tkrefreshlayout.RefreshListenerAdapter;
import com.lcodecore.tkrefreshlayout.TwinklingRefreshLayout;
import com.uu661.R;
import com.uu661.model.request.GGetDiamondInfo;
import com.uu661.model.response.BCalculate;
import com.uu661.module.base.BaseFragment;
import com.uu661.network.JsonCallback;
import com.uu661.network.TaskEngine;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;


public class CalculateFragment extends BaseFragment {

    @BindView(R.id.calculate_tv_one) TextView mCalculateTvOne;
    @BindView(R.id.calculate_bt_one_exp) TextView mCalculateBtOneExp;
    @BindView(R.id.calculate_view_list_recycle_view) RecyclerView mRecycleView;
    @BindView(R.id.calculate_view_list) LinearLayout mCalculateViewList;
    @BindView(R.id.calculate_tv_two) TextView mCalculateTvTwo;
    @BindView(R.id.calculate_tv_three) TextView mCalculateTvThree;
    @BindView(R.id.refreshLayout) TwinklingRefreshLayout mRefreshLayout;

    private int mId;
    private int mPeriodNo;

    private BCalculate mCalculate;
    private MyAdapter mAdapter;

    private boolean isExp = false;//是否是展开状态,默认是false

    public static CalculateFragment newInstance(int id, int periodNo) {
        CalculateFragment fragment = new CalculateFragment();
        Bundle args = new Bundle();
        args.putInt("id", id);
        args.putInt("periodNo", periodNo);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mId = getArguments().getInt("id");
        mPeriodNo = getArguments().getInt("periodNo");
        View view = inflater.inflate(R.layout.calculate_fragment, null);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "计算详情", true);
        initRefreshLayout();
        initRecycleView();
        doGetCalculateDetail();
    }

    private void initRefreshLayout() {
        //以下代码是使用黑色转圈Loading
        //        ProgressLayout headerView = new ProgressLayout(_mActivity);
        //        mRefreshLayout.setHeaderView(headerView);
        mRefreshLayout.setEnableLoadmore(false);
        mRefreshLayout.setEnableOverScroll(false);//是否允许越界回弹

        mRefreshLayout.setOnRefreshListener(new RefreshListenerAdapter() {
            @Override
            public void onRefresh(final TwinklingRefreshLayout refreshLayout) {
                doGetCalculateDetail();
            }
        });
    }

    private void initRecycleView() {
        //参与记录recycleView
        LinearLayoutManager manager = new LinearLayoutManager(_mActivity) {
            @Override
            public boolean canScrollVertically() {
                return false;
            }
        };
        mRecycleView.setLayoutManager(manager);
        mAdapter = new MyAdapter(_mActivity);
        mRecycleView.setAdapter(mAdapter);
    }

    private void doGetCalculateDetail() {
        TaskEngine.getInstance().doGetCalculateDetail(new GGetDiamondInfo(mId, mPeriodNo), null, new JsonCallback<BCalculate>(this) {
            @Override
            public void onSuccess(BCalculate result, Call call, Response response) {
                if(!isVisible()){
                    return;
                }
                mCalculate = result;
                setContent();
                mAdapter.updateData(result.getListData());
            }

            @Override
            public void onAfter(BCalculate bCalculate, Exception e) {
                super.onAfter(bCalculate, e);
                if(!isVisible()){
                    return;
                }
                mRefreshLayout.finishRefreshing();
            }
        });
    }

    private void setContent() {
        mCalculateTvOne.setText(Html.fromHtml("=<font color='#fc5669'>" + mCalculate.getCaiPiaoList().getTotalSum() + "</font>"));
        mCalculateTvTwo.setText(Html.fromHtml("=<font color='#fc5669'>" + mCalculate.getCaiPiaoList().getCaipiaoStr() + "</font> " +
                "(" + mCalculate.getCaiPiaoList().getCaipiaoPeriod() + ")"));
        mCalculateTvThree.setText(Html.fromHtml("幸运号码 : <font color='#fc5669'>" + mCalculate.getCaiPiaoList().getLuckNumStr() + "</font>"));
    }

    @OnClick(R.id.calculate_bt_one_exp)
    public void onClick() {
        if (isExp == false) {
            //折叠中
            mCalculateViewList.setVisibility(View.VISIBLE);
            isExp = true;
            mCalculateBtOneExp.setText("收起↑");
        } else {
            //展开中
            mCalculateViewList.setVisibility(View.GONE);
            isExp = false;
            mCalculateBtOneExp.setText("展开↓");
        }
    }


    public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyHolder> {


        private Context mContext;
        private List<BCalculate.ListDataBean> data = new ArrayList<>();

        public MyAdapter(Context context) {
            this.mContext = context;
        }

        public void updateData(List<BCalculate.ListDataBean> data) {
            this.data = data;
            notifyDataSetChanged();
        }

        @Override
        public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_calculate, parent, false);
            return new MyHolder(view);
        }

        @Override
        public void onBindViewHolder(MyHolder holder, int position) {
            BCalculate.ListDataBean gameModel = data.get(position);
            holder.bindItem(gameModel);
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        public class MyHolder extends RecyclerView.ViewHolder {

            @BindView(R.id.tv_one) TextView mTvOne;
            @BindView(R.id.tv_two) TextView mTvTwo;

            private BCalculate.ListDataBean mModel;

            public MyHolder(View view) {
                super(view);
                ButterKnife.bind(this, view);//用butterKnife绑定
            }


            void bindItem(BCalculate.ListDataBean model) {
                this.mModel = model;
                //"=<font color='#fc5669'>"
                mTvOne.setText(Html.fromHtml(model.getPayTime() + " <font color='#fc5669'>➡" + model.getTimeStr() + "</font>"));
                mTvTwo.setText(model.getUu898UserId());
            }

        }

    }
}
