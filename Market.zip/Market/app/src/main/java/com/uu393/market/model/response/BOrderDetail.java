package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/3
 * Descrip    :
 * =====================================================
 */

public class BOrderDetail implements Serializable {

    /**
     * orderNo : 2016092700001
     * title : 600元宝
     * addTime : 2016-09-27 15:15:15
     * price : 26.32
     * status : 0
     * number : 12
     * describe : 的发生发的是
     * totalMoney : 26.32
     * discount : 4.5
     */

    private String orderNo;
    private String title;
    private String addTime;
    private String price;
    private String status;
    private String number;
    private String describe;
    private String totalMoney;
    private String discount;

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {
        this.describe = describe;
    }

    public String getTotalMoney() {
        return totalMoney;
    }

    public void setTotalMoney(String totalMoney) {
        this.totalMoney = totalMoney;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }
}
