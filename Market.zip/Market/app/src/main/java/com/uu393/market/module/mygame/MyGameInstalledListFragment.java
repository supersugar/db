package com.uu393.market.module.mygame;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.InstalledHelper;
import com.uu393.market.model.request.GGetGameDetail;
import com.uu393.market.model.request.GGetMultiGameDetail;
import com.uu393.market.model.response.BGame;
import com.uu393.market.module.base.BaseViewPagerFragment;
import com.uu393.market.module.center.CollectGameActivity;
import com.uu393.market.module.manager.DoneAdapter;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.GlideRoundTransform;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.eventbus.EventString;
import com.uu393.market.util.log.L;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;
import org.greenrobot.eventbus.Subscribe;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import cn.finalteam.toolsfinal.ApkUtils;
import okhttp3.Call;
import okhttp3.Response;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/14
 * Descrip    : 我的游戏列表碎片
 * =====================================================
 */

public class MyGameInstalledListFragment extends BaseViewPagerFragment {
    private View mMygameNoResultView;
    private PullLoadMoreRecyclerView mRecyclerView;
    private List<String> mAllInstalledApp = Collections.synchronizedList(new ArrayList<String>());
    private MyInstalledGameAdapter mInstalledAdapter;
    private Map<Object,Object> allInstalledRecord;
    private int i=0;

    List<BGame> mGameList;
    public static MyGameInstalledListFragment newInstance(){
        MyGameInstalledListFragment fragment = new MyGameInstalledListFragment();
        Bundle bundle = new Bundle();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_mygame_installed_list,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mGameList = new ArrayList<>();

        mMygameNoResultView = view.findViewById(R.id.mygame_no_result_view);
        mRecyclerView = (PullLoadMoreRecyclerView) view.findViewById(R.id.rv_mygame_list);//可以加载更多的RecyclerView,有结果
        initRecyclerView();
//        checkAppInstalled();
    }
    //从记录安装过的游戏的缓存文件中，通过游戏包名判断游戏是否安装


    @Override
    public void onStart() {
        super.onStart();
        checkAppInstalled();
    }



    private void checkAppInstalled() {
        allInstalledRecord = InstalledHelper.getInstance(App.mContext).getAllInstalledRecord();//初始化时，加载缓存中所有记录
        mAllInstalledApp.clear();
        for (Map.Entry<Object,Object> entry : allInstalledRecord.entrySet()){
            String  gameId = (String) entry.getValue();
            String  gamePackage = (String) entry.getKey();
            if (ApkUtils.isAvilible(App.mContext, gamePackage)){//如果游戏已经被卸载，则从列表的数据源有中删除一条数据
                mAllInstalledApp.add(gameId);
Log.d("---------------","---------------mAllInstalledApp="+mAllInstalledApp);
                doGetGameList(mAllInstalledApp);
            }

        }
        /*if (mAllInstalledApp.isEmpty())return;
        for ( i = 0;i<mAllInstalledApp.size();i++){
            String  bGameID = mAllInstalledApp.get(i);
            GGetGameDetail model = new GGetGameDetail(bGameID);
            TaskEngine.setTokenUseridPhoneState(1);
            TaskEngine.getInstance().doGetGameDetail(model, new JsonCallback<BGame>() {
                @Override
                public void onSuccess(BGame bGame, Call call, Response response) {
                    String packageName = bGame.getPackageName();
                    if (!ApkUtils.isAvilible(App.mContext, packageName)){//如果游戏已经被卸载，则从列表的数据源有中删除一条数据
                        mAllInstalledApp.remove(i);
                    }
                }
                @Override
                public void onError(Call call, Response response, Exception e) {
                    super.onError(call, response, e);

                }
            });
        }*/
    }

    private void initRecyclerView() {

        mRecyclerView.setLinearLayout();
        mInstalledAdapter = new MyInstalledGameAdapter(_mActivity);
        mRecyclerView.setPullRefreshEnable(false);
        mRecyclerView.setPushRefreshEnable(false);
        mRecyclerView.setIsLoadMore(false);

        mRecyclerView.setAdapter(mInstalledAdapter);
        allInstalledRecord = InstalledHelper.getInstance(App.mContext).getAllInstalledRecord();//初始化时，加载缓存中所有记录
        showResult(allInstalledRecord!=null&!allInstalledRecord.isEmpty());
    }


    private void showResult(Boolean hasResult){
        if (hasResult){
            mInstalledAdapter.refresh();
            mRecyclerView.setVisibility(View.VISIBLE);
            mMygameNoResultView.setVisibility(View.GONE);

        }else {
            mInstalledAdapter.refresh();
            mRecyclerView.setVisibility(View.GONE);
            mMygameNoResultView.setVisibility(View.VISIBLE);

        }
    }

    @Override
    public void refresh() {
        checkAppInstalled();
        mInstalledAdapter.refresh();
        showResult(allInstalledRecord!=null&&mAllInstalledApp.size()!=0);
        Log.d("refresh","刷新了-->MyGameInstalledListFragment");
    }
    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart("MyGameInstalledListFragment");
        EB.register(this);
        refresh();
        checkAppInstalled();
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("MyGameInstalledListFragment");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        L.d("onDestroy");
        EB.unregister(this);
    }

    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.INSTALLED_APP_PACKAGE_NAME://安装apk完成

                String installPackageName = ((EventString) event).result;
                allInstalledRecord = InstalledHelper.getInstance(App.mContext).getAllInstalledRecord();
                boolean containsKey = allInstalledRecord.containsKey(installPackageName);
                if (containsKey||ApkUtils.isAvilible(App.mContext,installPackageName)){
                    //添加一条记录
                    mAllInstalledApp.add((String) allInstalledRecord.get(installPackageName));
                }else {//没有的话，缓存中删除一条记录
                    InstalledHelper.getInstance(App.mContext).removeOneInstalledRecord(installPackageName);
                }

                refresh();
                break;
            /*case EB.TAG.UNINSTALLED_APP_PACKAGE_NAME://卸载apk完成
                String uninstallPackageName = ((EventString) event).result;
                allInstalledRecord = InstalledHelper.getInstance(App.mContext).getAllInstalledRecord();
                if (allInstalledRecord.containsKey(uninstallPackageName)){
                    BGame newUninstallGame = (BGame) allInstalledRecord.get(uninstallPackageName);
                    mAllInstalledApp.remove(newUninstallGame);
                    InstalledHelper.getInstance(App.mContext).removeOneInstalledRecord(uninstallPackageName);//删除一条记录
                }
                refresh();
                break;*/
            default:
                break;
        }
    }

    private void doGetGameList(List<String> ids) {
        if (ids == null || ids.isEmpty()) {
            showResult(false);
            return;
        }
        GGetMultiGameDetail model = new GGetMultiGameDetail();
        model.setId("" + ids.toString().replace("[", "").replace("]", "").trim());//多个ID
        showLoadToast();
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetMultiGameDetail(model, new JsonCallback<List<BGame>>() {
            @Override
            public void onSuccess(List<BGame> bGames, Call call, Response response) {
                hideLoadToast();
                if (null == bGames || bGames.isEmpty()) {
                    showResult(false);
                } else {
                    mGameList.clear();
                    mGameList.addAll(bGames);
                    showResult(true);
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
                showResult(false);
            }

            @Override
            public void onAfter(List<BGame> bGames, Exception e) {
                super.onAfter(bGames, e);
                hideLoadToast();
                mRecyclerView.setPullLoadMoreCompleted();
                mInstalledAdapter.setData(mGameList);
            }
        });
    }

}
