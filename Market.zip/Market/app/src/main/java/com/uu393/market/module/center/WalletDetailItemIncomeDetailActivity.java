package com.uu393.market.module.center;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.R;
import com.uu393.market.model.request.GGetWalletIncomeDetail;
import com.uu393.market.model.response.BWalletIncomeDetail;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ContactCustomerServicesUtils;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/*收取货款详情页
* */
public class WalletDetailItemIncomeDetailActivity extends BaseActivity {

    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    @Bind(R.id.tv_item_title)
    TextView mTvItemTitle;
    @Bind(R.id.tv_item_status)
    TextView mTvItemStatus;
    @Bind(R.id.tv_item_time)
    TextView mTvItemTime;
    @Bind(R.id.tv_item_money)
    TextView mTvItemMoney;
    @Bind(R.id.tv_order_number)
    TextView mTvOrderNumber;
    @Bind(R.id.tv_contact)
    TextView mTvContact;
    @Bind(R.id.tv_income_type)
    TextView mTvIncomeType;
    @Bind(R.id.tv_pay_type)
    TextView mTvPayType;

    private String mOrderNo;//订单编号
    private BWalletIncomeDetail mIncomeDetail;
    private String mOrderStatusText;//订单状态文本

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallet_detail_income_item_detail);
        ButterKnife.bind(this);
        initTitleBar();
        if (getIntent() != null) {
            mOrderNo = getIntent().getStringExtra("key_fund_order_no");
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        GGetWalletIncomeDetail model= new GGetWalletIncomeDetail();
        model.setTradeNo(mOrderNo);
        doGetWalletIncomeDetail(model);
    }

    private void initView(BWalletIncomeDetail incomeDetail) {
        if (incomeDetail==null) return;
        mTvItemTitle.setText(incomeDetail.getGameName());//游戏名字
        String status = incomeDetail.getStatus();
        switch (status){
            case "0":
                mOrderStatusText = "等待客服处理";
                break;
            case "1":
                mOrderStatusText = "处理完成";
                break;
            case "2":
                mOrderStatusText = "订单已取消";
                break;
            case "3":
                mOrderStatusText = "延时提现";
                break;
        }
        mTvItemStatus.setText(mOrderStatusText);//状态  （状态  0等待客服处理   1处理完成  2订单已取消  3延时提现）
        mTvItemTime.setText(incomeDetail.getAddTime());//时间
        String incomeDetailMoney = incomeDetail.getMoney();
        if (incomeDetailMoney.contains("+")){
            mTvItemMoney.setTextColor(getResources().getColor(R.color.green));
        }else if (incomeDetailMoney.contains("-")){
            mTvItemMoney.setTextColor(getResources().getColor(R.color.text_lv2));
        }
        mTvItemMoney.setText(incomeDetailMoney+"元");//金额
        mTvOrderNumber.setText("订单编号："+mOrderNo);//订单编号
        mTvIncomeType.setText("收入方式：分享"+incomeDetail.getGameName());//收入方式：分享XXX游戏
        mTvPayType.setText("支付类型："+incomeDetail.getPayType());//支付类型

    }

    private void initTitleBar() {
        mTitleBarRight.setVisibility(View.GONE);
        mTitleBarTitle.setText("收取货款明细");
    }

    @OnClick({R.id.title_bar_left, R.id.tv_contact})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                super.onBackPressedSupport();
                break;
            case R.id.tv_contact:
                ContactCustomerServicesUtils.doXiaoNeng();
                break;
        }
    }

    //获取收取货款详情APP049
    private void doGetWalletIncomeDetail(GGetWalletIncomeDetail model){
        if (model==null) return;
        showLoadToast(WalletDetailItemIncomeDetailActivity.this);
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetWalletIncomeDetail(model, new JsonCallback<BWalletIncomeDetail>() {
            @Override
            public void onSuccess(BWalletIncomeDetail bWalletIncomeDetail, Call call, Response response) {
                hideLoadToast();
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
            }

            @Override
            public void onAfter(BWalletIncomeDetail bWalletIncomeDetail, Exception e) {
                super.onAfter(bWalletIncomeDetail, e);
                if (bWalletIncomeDetail!=null){
                    mIncomeDetail = bWalletIncomeDetail;
                    initView(mIncomeDetail);
                }
            }
        });
    }
}
