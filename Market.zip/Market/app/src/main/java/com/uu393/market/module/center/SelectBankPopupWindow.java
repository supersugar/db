package com.uu393.market.module.center;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.response.BBankInfo;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.ScreenUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/8
 * Description    : 银行选择弹窗
 * =====================================================
 */

public class SelectBankPopupWindow implements View.OnClickListener {
    private Activity mActivity;
    private ImageView mIvClose;//关闭按钮
    private TextView mTvTitle;//弹窗标题
    private RecyclerView mRecyclerList;//列表
    private final View view;//弹框主视图
    private PopupWindow popupWindow;
    private SelectBankAdapter mAdapter;
    private int lastPosition;

    public SelectBankPopupWindow(Activity context, int lastPosition) {
        this.mActivity = context;
        this.lastPosition = lastPosition;
        view = LayoutInflater.from(mActivity).inflate(R.layout.popwindow_bank_select, null, false);
        mIvClose = (ImageView) view.findViewById(R.id.iv_close);
        mTvTitle = (TextView) view.findViewById(R.id.tv_title);
        mRecyclerList = (RecyclerView) view.findViewById(R.id.recycler_view);
        initView();
    }

    private void initView() {
        //点击事件
        mIvClose.setOnClickListener(this);
        mRecyclerList.setLayoutManager(new LinearLayoutManager(mActivity, LinearLayoutManager.VERTICAL, false));
        mAdapter = new SelectBankAdapter(lastPosition);
        mRecyclerList.setAdapter(mAdapter);
    }

    public SelectBankAdapter getAdapter() {
        return mAdapter;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_close://关闭弹窗
                hideSelectWindow();
                break;
        }
    }

    //底部弹出
    public void showSelectWindowFromBottom() {
        int screenHeight = ScreenUtils.getScreenHeight(mActivity);
        popupWindow = new PopupWindow(view, ViewGroup.LayoutParams.MATCH_PARENT, screenHeight * 2 / 3, true);

        popupWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popupWindow.setAnimationStyle(android.R.style.Animation_InputMethod);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setFocusable(true);
        WindowManager.LayoutParams lp = mActivity.getWindow().getAttributes();
        lp.alpha = 0.5f;
        mActivity.getWindow().setAttributes(lp);
        popupWindow.showAtLocation(mActivity.getWindow().getDecorView(), Gravity.CENTER | Gravity.BOTTOM, 0, 0);
        popupWindow.update();
        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                WindowManager.LayoutParams lp = mActivity.getWindow().getAttributes();
                lp.alpha = 1.0f;
                mActivity.getWindow().setAttributes(lp);
            }
        });

    }

    //隐藏弹窗
    public void hideSelectWindow() {
        if (popupWindow != null && popupWindow.isShowing()) {
            popupWindow.dismiss();
            popupWindow = null;
        }
    }

    //列表适配器
    public static class SelectBankAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        /*private List<Integer> resIds = new ArrayList<>();
        private List<String> names = new ArrayList<>();*/
        private OnItemSelectedListener mItemSelectedListener;
        private int preposition;
        private List<BBankInfo> mBanks;

        public SelectBankAdapter(int preposition) {
            mBanks = new ArrayList<>();
            this.preposition = preposition;
            /*names.add("中国工商银行");
            names.add("中国农业银行");
            names.add("中国建设银行");
            names.add("招商银行");
            names.add("中国银行");
            names.add("交通银行");
            names.add("中国邮政储蓄银行");
            names.add("平安银行");
            names.add("光大银行");
            names.add("兴业银行");
            names.add("中信银行");

            resIds.add(R.drawable.ic_bank_icbc);
            resIds.add(R.drawable.ic_bank_abc);
            resIds.add(R.drawable.ic_bank_ccb);
            resIds.add(R.drawable.ic_bank_cmbc);
            resIds.add(R.drawable.ic_bank_boc);
            resIds.add(R.drawable.ic_bank_bocommu);
            resIds.add(R.drawable.ic_bank_psbc);
            resIds.add(R.drawable.ic_bank_pab);
            resIds.add(R.drawable.ic_bank_ceb);
            resIds.add(R.drawable.ic_bank_cib);
            resIds.add(R.drawable.ic_bank_cncb);*/
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_select_bank, parent, false);
            return new SelectBankViewHolder(inflate);
        }

        @Override
        public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
            if (holder != null) {
                ((SelectBankViewHolder) holder).bindItem(mBanks.get(position).getIcon(), mBanks.get(position).getBankName(), position == preposition ? true : false);
                if (mItemSelectedListener != null) {
                    ((SelectBankViewHolder) holder).item.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            preposition = position;
                            notifyDataSetChanged();
                            mItemSelectedListener.onItemSelectedListener(position, mBanks.get(position));

                        }
                    });
                }
            }

        }

        @Override
        public int getItemCount() {
            return mBanks.size();
        }


        public void refreshItem(List<BBankInfo> bankInfos) {
            if (bankInfos != null) {
                mBanks.clear();
                mBanks.addAll(bankInfos);
            }
            this.notifyDataSetChanged();
        }

        public void setOnItemSelectedListener(OnItemSelectedListener listener) {
            this.mItemSelectedListener = listener;
        }

        public interface OnItemSelectedListener {
            void onItemSelectedListener(int position, BBankInfo bankInfo);
        }

        //列表单项view holder
        public class SelectBankViewHolder extends RecyclerView.ViewHolder {
            private ImageView ivBankIcon, ivSelectedIndicator;
            private TextView tvBankName;
            private View item;

            public SelectBankViewHolder(View itemView) {
                super(itemView);
                ivBankIcon = (ImageView) itemView.findViewById(R.id.iv_item_select_bank_icon);
                ivSelectedIndicator = (ImageView) itemView.findViewById(R.id.iv_item_select_bank_select_indicator);
                tvBankName = (TextView) itemView.findViewById(R.id.tv_item_select_bank_name);
                item = itemView.findViewById(R.id.item_select_bank);
            }

            public void bindItem(String resId, String name, boolean isselected) {
                int defaultAndError = ImageHelper.randomImage();
                Glide.with(App.mContext).load(resId)
                        .error(defaultAndError)
                        .placeholder(defaultAndError)
                        .into(ivBankIcon);
                tvBankName.setText(name);
                ivSelectedIndicator.setVisibility(isselected == true ? View.VISIBLE : View.INVISIBLE);
            }
        }
    }
}
