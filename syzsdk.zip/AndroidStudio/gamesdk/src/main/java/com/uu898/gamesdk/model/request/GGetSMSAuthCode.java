package com.uu898.gamesdk.model.request;

import com.uu898.gamesdk.model.GBaseModel;

public class GGetSMSAuthCode extends GBaseModel {

    /**
     * 1 绑定手机短信验证码
     * 2 修改绑定手机验证码
     * 3 完善资料验证码
     * 4 手机注册验证码
     * 5 获取用户账户信息验证码
     * 6 手机登录验证码
     * 7 找回登录密码验证码
     * 8 修改密码验证码
     */
    public static final int type_1 = 1;
    public static final int type_2 = 2;
    public static final int type_3 = 3;
    public static final int type_4 = 4;
    public static final int type_5 = 5;
    public static final int type_6 = 6;
    public static final int type_7 = 7;
    public static final int type_8 = 8;

    //SSID、phoneNo、userId说明：
    // 如果用户没有登录并且需要发送用户绑定的手机验证码，则传userId；
    // 如果用户已登录，则传SSID；
    // 如果直接给手机号发送验证码则传phoneNo

    private int Type;
    private String phoneNo = "";
    private String userId = "";//找回登陆密码的时候,需要填写

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getType() {
        return Type;
    }

    public void setType(int type) {
        Type = type;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }
}
