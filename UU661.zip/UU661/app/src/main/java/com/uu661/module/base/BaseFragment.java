package com.uu661.module.base;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.TextView;

import com.uu661.R;
import com.uu661.util.LoadingUtil;

import butterknife.ButterKnife;
import butterknife.Unbinder;
import me.yokeyword.fragmentation.SupportFragment;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class BaseFragment extends SupportFragment {

    private Unbinder unbinder;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        unbinder = ButterKnife.bind(this, view);
    }

    public View initTitleBar(View v, String title, boolean showBack) {
        TextView tvTitle = (TextView) v.findViewById(R.id.title_bar_title);
        tvTitle.setText(title);
        v.findViewById(R.id.title_bar_left).setVisibility(showBack ? View.VISIBLE : View.GONE);
        v.findViewById(R.id.title_bar_left).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _mActivity.onBackPressed();
            }
        });
        return v.findViewById(R.id.title_bar);
    }

    public void showLoadToast() {
//        if(!LoadToast.getInstance(_mActivity).isShow()){
//        }
        LoadingUtil.showLoading(_mActivity);
    }

    public void hideLoadToast() {
        LoadingUtil.hideLoading(_mActivity);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
        hideLoadToast();
    }

}
