package com.uu393.market.util;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;

import com.uu393.market.Constant;
import com.uu393.market.app.App;

import cn.xiaoneng.uiapi.Ntalker;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/10
 * Description    :
 * =====================================================
 */

public class ContactCustomerServicesUtils {
    public static void doXiaoNeng() {
        Ntalker.getInstance().startChat(App.mContext, Constant.SETTINGID_ZIXUN,"咨询客服",null,null,null);
    }
    public static void joinQQGroup(Activity activity) {
        String key = "PMm4_ttyITQJoqlL_xnrbwtlSOPriIk7";//QQ群
        Intent intent = new Intent();
        intent.setData(Uri.parse("mqqopensdkapi://bizAgent/qm/qr?url=http%3A%2F%2Fqm.qq.com%2Fcgi-bin%2Fqm%2Fqr%3Ffrom%3Dapp%26p%3Dandroid%26k%3D" + key));
        // 此Flag可根据具体产品需要自定义，如设置，则在加群界面按返回，返回手Q主界面，不设置，按返回会返回到呼起产品界面    //intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            activity.startActivity(intent);

        } catch (Exception e) {
            // 未安装手Q或安装的版本不支持
            ToastUtil.showToast(App.mContext,"您未安装手机QQ，或者版本不支持");
        }
    }
}
