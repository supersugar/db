package com.uu661.model.request;

public class GGetThirdOrderNo {

    public static final int AliPay = 1;//支付宝
    public static final int WeXin = 2;//微信支付

    public String killOrderNo;//
    public int payType;//
    public String voucherId;//优惠券id
}
