package com.uu898.gamesdk.view;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.uu898.gamesdk.R;
import com.uu898.gamesdk.UGActivity;
import com.uu898.gamesdk.core.ListenerCenter;
import com.uu898.gamesdk.core.ResourceUtils;
import com.uu898.gamesdk.model.GBaseModel;
import com.uu898.gamesdk.model.response.BSubAccount;
import com.uu898.gamesdk.network.NetCallback;
import com.uu898.gamesdk.network.TaskEngine;
import com.uu898.gamesdk.utils.AccountManager;

import org.xutils.x;

import java.util.ArrayList;
import java.util.List;

/**
 * 小号列表界面
 */
public class UserSubAccountListFragment extends BaseFragment {

    private ListView mListView;
    private MyAdapter mAdapter;
    private List<BSubAccount.SubAccount> mList = new ArrayList<>();

    private String mStatus;

    public static UserSubAccountListFragment newInstance() {
        Bundle args = new Bundle();
        UserSubAccountListFragment fragment = new UserSubAccountListFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        View view = inflater.inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_sub_account_list"), container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initTitleBar(view, "小号管理");

        mListView = (ListView) view.findViewById(getId("ug_list_view"));
        mAdapter = new MyAdapter();
        mListView.setAdapter(mAdapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                showChangeSubAccount();
            }
        });

        view.findViewById(getId("ug_bt_add")).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start(UserSubAccountAddFragment.newInstance());
            }
        });

        doGetOrders();
   }



    private void doGetOrders() {


        TaskEngine.getInstance().doGetSubAccountList (new GBaseModel(), new NetCallback<BSubAccount>() {
            @Override
            public void _onNext(BSubAccount result) {

                mList = result.list;
                mAdapter.notifyDataSetChanged();
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }


    private class MyAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return mList.size();
        }

        @Override
        public Object getItem(int position) {
            return mList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            ViewHolder holder = null;
            if (null == convertView) {
                convertView = LayoutInflater.from(_mActivity).inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_sub_account_item"), null);
                holder = new ViewHolder();
                holder.name = (TextView) convertView.findViewById(getId("name"));
                holder.checked = (ImageView) convertView.findViewById(getId("checked"));
//                holder.price = (TextView) convertView.findViewById(getId("ug_order_item_price"));
//                holder.status = (TextView) convertView.findViewById(getId("ug_order_item_status"));
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }
            holder.name.setText(mList.get(position).alias);
//            holder.time.setText(mList.get(position).AddTime);

            return convertView;
        }

        private class ViewHolder {
            TextView name;
            ImageView checked;
        }
    }


    private void showChangeSubAccount() {
        final Dialog dialog = new Dialog(_mActivity, R.style.Dialog);
        View view = _mActivity.getLayoutInflater().inflate(R.layout.ug_change_account, null);
        dialog.addContentView(view, new ViewGroup.LayoutParams(-2, -2));
        dialog.show();

        Button mBtGo = (Button) view.findViewById(getId("ug_bt_go"));
        Button mBtCancel = (Button) view.findViewById(getId("ug_bt_cancel"));
        mBtGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AccountManager.getInstance().setStatus(AccountManager.Status.LOGOUT, AccountManager.getInstance().getCurrentUserID());
                _mActivity.finish();
                if (null != ListenerCenter.getInstance().getChangeAccountListener()) {
                    ListenerCenter.getInstance().getChangeAccountListener().onChange();
                }
                Intent intent = new Intent(x.app(), UGActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra(UGActivity.INTENT_KEY_TO, UGActivity.INTENT_VALUE_TO_LOGIN);
                startActivity(intent);
            }
        });
        mBtCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }

}
