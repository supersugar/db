package com.uu898app.model.response;

/**
 * Created by zhangbo on 2016/7/11.
 */
public class BOrderGameDK {

    /**
     * rowId : 1
     * Sequence : MCD20160719152942-62244
     * name : 传奇3
     * Number : 1
     * price : 9.7
     * tradeTime : 2016/7/19 15:29:00
     * title : 10元点卡
     * point : 10
     * cardType : 0
     * status : 5
     * statusName : 支付超时，已取消
     */

    private int rowId;
    private String Sequence;
    private String name;
    private int Number;
    private double price;
    private String tradeTime;
    private String title;
    private String point;
    private int cardType;
    private int status;
    private String statusName;

    public int getRowId() {
        return rowId;
    }

    public void setRowId(int rowId) {
        this.rowId = rowId;
    }

    public String getSequence() {
        return Sequence;
    }

    public void setSequence(String Sequence) {
        this.Sequence = Sequence;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumber() {
        return Number;
    }

    public void setNumber(int Number) {
        this.Number = Number;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getTradeTime() {
        return tradeTime;
    }

    public void setTradeTime(String tradeTime) {
        this.tradeTime = tradeTime;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPoint() {
        return point;
    }

    public void setPoint(String point) {
        this.point = point;
    }

    public int getCardType() {
        return cardType;
    }

    public void setCardType(int cardType) {
        this.cardType = cardType;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }
}
