package com.uu898app.model.response;

import java.util.List;

/**
 * Created by zhangbo on 2016/7/1.
 */
public class BBannerResponse {
    private List<BBanner> banner;

    public List<BBanner> getBanner() {
        return banner;
    }

    public void setBanner(List<BBanner> banner) {
        this.banner = banner;
    }
}
