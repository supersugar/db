package com.uu898app.adapter;

import android.text.Html;
import android.text.Spanned;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.uu898app.R;
import com.uu898app.model.response.BGoods;

import java.util.List;

/**
 *
 */
public class GoodsListAdapter extends BaseQuickAdapter<BGoods> {

    public GoodsListAdapter(List<BGoods> data) {
        super(R.layout.buy_goods_list_item, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, BGoods item) {
        helper.setText(R.id.tv_title, item.getTitle());
        helper.setText(R.id.tv_price, String.valueOf(item.getPrice()));
        helper.setText(R.id.tv_number, "库存：" + String.valueOf(item.getNumber()));
        helper.setText(R.id.tv_commodity_type_name, "物品类型：" + item.getCommodityTypeName());
        helper.setText(R.id.tv_area, "游戏区服：" + item.getGameName() + "/" + item.getAreaName() + "/" + item.getServerName());


        if (item.getInputType().equals("0")) {
            helper.setVisible(R.id.layout_good_unitprice, true);
            Spanned text = Html.fromHtml(item.getScale() + "<font color='#FF6801'>" + " || " + "</font>" + item.getScaleByJin());
            helper.setText(R.id.tv_unit_price_value, text);
        } else {
            helper.setVisible(R.id.layout_good_unitprice, false);
        }
    }


}
