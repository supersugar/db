package com.uu393.market.module;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.InstalledHelper;
import com.uu393.market.core.PlayedHelper;
import com.uu393.market.model.response.BGame;
import com.uu393.market.module.base.BaseFragment;
import com.uu393.market.module.base.BaseTabLazyFragment;
import com.uu393.market.module.center.UserCenterFragment;
import com.uu393.market.module.h5game.H5GameFragment;
import com.uu393.market.module.home.HomeFragment;
import com.uu393.market.module.home.HomeFragmentNew;
import com.uu393.market.module.login.LoginActivity;
import com.uu393.market.module.more.AboutFragment;
import com.uu393.market.module.mygame.MyGameFragment;
import com.uu393.market.module.search.SearchActivity;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.eventbus.EventObject;
import com.uu393.market.util.log.L;
import com.uu393.market.view.bottombar.BottomBar;
import com.uu393.market.view.bottombar.BottomBarTab;

import org.greenrobot.eventbus.Subscribe;


/**
 * Created by bo on 16/11/10.
 */

public class MainFragment extends BaseFragment {

    public static final int FIRST = 0;
    public static final int SECOND = 1;
    public static final int THIRD = 2;
    public static final int FOURTH = 3;

    private BaseTabLazyFragment[] mFragments = new BaseTabLazyFragment[4];

    public static BottomBar mBottomBar;
    private Boolean hasClickCenter;
    private int mPrePosition;

    public static MainFragment newInstance() {

        Bundle args = new Bundle();

        MainFragment fragment = new MainFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.main_fragment, container, false);

        if (savedInstanceState == null) {
            mFragments[FIRST] = HomeFragmentNew.newInstance();
//            mFragments[FIRST] = HomeFragment.newInstance();
//            mFragments[SECOND] = SearchFragment.newInstance();//1.0版本，1.1去除底部导航
            mFragments[SECOND] = H5GameFragment.newInstance();//1.1版本新增
            //mFragments[THIRD] = ManagerFragmentSimple.newInstance();//1.0版本，1.1去除底部导航
            mFragments[THIRD] = MyGameFragment.newInstance();//1.1版本新增
            //mFragments[FOURTH] = MoreFragment.newInstance();
            mFragments[FOURTH] = UserCenterFragment.newInstance();

            loadMultipleRootFragment(R.id.fl_container, FIRST,
                    mFragments[FIRST],
                    mFragments[SECOND],
                    mFragments[THIRD],
                    mFragments[FOURTH]);
        } else {
            // 这里库已经做了Fragment恢复,所有不需要额外的处理了, 不会出现重叠问题
            // 这里我们需要拿到mFragments的引用,也可以通过getSupportFragmentManager.getFragments()自行进行判断查找(效率更高些),用下面的方法查找更方便些
            mFragments[FIRST] = findChildFragment(HomeFragmentNew.class);
            //mFragments[SECOND] = findFragment(SearchFragment.class);
            mFragments[SECOND] = findChildFragment(H5GameFragment.class);
            //mFragments[THIRD] = findFragment(ManagerFragmentSimple.class);
            mFragments[THIRD] = findChildFragment(MyGameFragment.class);
            mFragments[FOURTH] = findChildFragment(UserCenterFragment.class);
        }

        initView(view);
        return view;
    }


    private void initView(View view) {
        mBottomBar = (BottomBar) view.findViewById(R.id.bottomBar);

        mBottomBar.addItem(new BottomBarTab(_mActivity, R.drawable.ic_tab_home, R.drawable.ic_tab_home_pressed, "首页"))
                // .addItem(new BottomBarTab(_mActivity, R.drawable.ic_tab_search, R.drawable.ic_tab_search_pressed,"搜索"))//1.1去除
                .addItem(new BottomBarTab(_mActivity, R.drawable.ic_tab_h5, R.drawable.ic_tab_h5_pressed, "H5游戏"))
                //.addItem(new BottomBarTab(_mActivity, R.drawable.ic_tab_manager, R.drawable.ic_tab_manager_pressed,"管理"))
                .addItem(new BottomBarTab(_mActivity, R.drawable.ic_tab_mygame, R.drawable.ic_tab_mygame_pressed, "我的游戏"))
                .addItem(new BottomBarTab(_mActivity, R.drawable.ic_tab_mine, R.drawable.ic_tab_mine_pressed, "我的"));

        mBottomBar.setOnTabSelectedListener(new BottomBar.OnTabSelectedListener() {
            @Override
            public void onTabSelected(int position, int prePosition) {
                L.d("当前位置" + position + " 前一个位置" + prePosition);
                mPrePosition = prePosition;
                BaseTabLazyFragment currentFragment = mFragments[position];
                if (position == 3) {
                    if (!(boolean) SPUtil.get(App.mContext, "isLogin", false)) {//未登录
                        _mActivity.startActivity(new Intent(_mActivity, LoginActivity.class));
                        mBottomBar.setCurrentItem(prePosition);
                        SPUtil.put(App.mContext,SPUtil.KEY_HAS_CLICK_CENTER,true);//这里保存点击过个人中心，等登录成功后，切换主视图选中项为个人中心
                    }else {
                        showHideFragment(mFragments[position], mFragments[prePosition]);
                        currentFragment.onTabReselected();
                    }
                }else {
                    showHideFragment(mFragments[position], mFragments[prePosition]);
                }
            }

            @Override
            public void onTabUnselected(int position) {
                L.d("onTabUnselected" + position);
            }

            @Override
            public void onTabReselected(int position) {
                L.d("onTabReselected" + position);
                BaseTabLazyFragment currentFragment = mFragments[position];
                if (position == 3) {
                    if (!(boolean) SPUtil.get(App.mContext, "isLogin", false)) {
                        _mActivity.startActivity(new Intent(_mActivity, LoginActivity.class));
                        showHideFragment(mFragments[0], mFragments[position]);
                        mBottomBar.setCurrentItem(0);
                    }else {
                        currentFragment.onTabReselected();
                    }
                }else {
                    currentFragment.onTabReselected();
                }
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        EB.register(this);
        L.d("onResume()");
        if ( mBottomBar.getCurrentItemPosition()==3){
            if (!(boolean) SPUtil.get(App.mContext, "isLogin", false)) {
                showHideFragment(mFragments[0], mFragments[3]);
                mBottomBar.setCurrentItem(0);
            }else {
                BaseTabLazyFragment currentFragment = mFragments[3];//刷新个人中心数据
                currentFragment.onTabReselected();
            }
        }
        Boolean hasClickCenter = (Boolean) SPUtil.get(App.mContext, SPUtil.KEY_HAS_CLICK_CENTER, false);
        if (hasClickCenter){
            if ((boolean) SPUtil.get(App.mContext, "isLogin", false)) {
                showHideFragment(mFragments[3], mFragments[mPrePosition]);
                mBottomBar.setCurrentItem(3);
                SPUtil.put(App.mContext,SPUtil.KEY_HAS_CLICK_CENTER,false);
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EB.unregister(this);
    }

    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.GO_SEARCH:
                //mBottomBar.setCurrentItem(0);//1.0首页点击搜索框,切换底部tab到搜索页；1.1后改变
                Intent intent = new Intent(_mActivity, SearchActivity.class);
                startActivity(intent);//跳转到搜索页面
                break;
            case EB.TAG.GO_SEARCH_RESULT://搜索完后进入搜索结果页
                EventObject<BaseFragment> eb = (EventObject<BaseFragment>) event;
                BaseFragment searchResult = eb.result;
                start(searchResult);
                break;
            case EB.TAG.CLICK_INSATLL://点击了安装按钮
                BGame game = ((EventObject<BGame>) event).result;
                if (game != null) {
                    // 在安装记录的缓存文件中添加一条记录
                    InstalledHelper.getInstance(App.mContext).addOneInstalledRecord(game.getPackageName(), game.getId());
                    L.d("play", "打开了：：" + game.getPackageName());
                }
                break;
            case EB.TAG.CLICK_PLAY://打开游戏
                BGame gameModel = ((EventObject<BGame>) event).result;
                // 在玩过记录的缓存文件中添加一条记录
                if (gameModel != null) {
                    PlayedHelper.getInstance(App.mContext).addOnePlayedRecord(gameModel.getPackageName(), gameModel.getId());
                    L.d("play", "打开了：：" + gameModel.getPackageName());
                }
                break;
            case EB.TAG.SHOW_APP_HOME:
                mBottomBar.setCurrentItem(0);
                break;
            default:
                break;
        }
    }
}
