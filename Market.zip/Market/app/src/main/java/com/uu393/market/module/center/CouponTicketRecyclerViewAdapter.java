package com.uu393.market.module.center;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.response.BCouponTicket;
import com.uu393.market.module.home.AppDetailActivity;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.EB;

import java.util.ArrayList;
import java.util.List;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/11
 * Description    :
 * =====================================================
 */

public class CouponTicketRecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Activity mActivity;
    private List<BCouponTicket> mTickets = new ArrayList<>();
    public CouponTicketRecyclerViewAdapter(Activity activity) {
        this.mActivity = activity;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_coupon_ticket_recycler_view, parent, false);
        return new CouponTicketViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder != null && holder instanceof CouponTicketViewHolder) {
            if (mTickets.get(position)!=null){
                ((CouponTicketViewHolder) holder).bindItem(position,mTickets.get(position));
            }
        }
    }

    @Override
    public int getItemCount() {
        return mTickets.size();
    }

    public void refresh(List<BCouponTicket> data){
        this.mTickets.clear();
        this.mTickets.addAll(data);
        this.notifyDataSetChanged();
    }

    public class CouponTicketViewHolder extends RecyclerView.ViewHolder {
        private TextView titleLeft, title, description, time, use;
        private View itemView;
        public CouponTicketViewHolder(View itemView) {
            super(itemView);
            this.itemView = itemView;
            titleLeft = (TextView) itemView.findViewById(R.id.tv_coupon_ticket_title_left);
            title = (TextView) itemView.findViewById(R.id.tv_coupon_ticket_title);
            description = (TextView) itemView.findViewById(R.id.tv_coupon_ticket_description);
            time = (TextView) itemView.findViewById(R.id.tv_coupon_ticket_time);
            use = (TextView) itemView.findViewById(R.id.tv_coupon_ticket_use);
        }

        public void bindItem(final int position, final BCouponTicket ticket) {
            /*titleLeft.setText("¥40\n首充券");
            title.setText("手游猪首充优惠券");
            description.setText("满50元使用。可用于游戏充值");
            time.setText("有效期至：2017-04-30");*/
            if (ticket!=null){
                titleLeft.setText("¥"+ticket.getVMoney()+"\n优惠券");
                String gameName = ticket.getGameName();
                String explain = ticket.getExplain();
                String gameID = ticket.getGameID();
                if (gameID==null) return;
                if ("-1".equals(gameID.trim().replace(" ",""))){
                    title.setText("手游猪游戏通用");
                    itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (mActivity!=null){
                                EB.postEmpty(EB.TAG.SHOW_APP_HOME);//显示UU手游首页
                                mActivity.finish();
                            }
                        }
                    });
                }else {
                    if (TextUtils.isEmpty(explain)){
                        title.setText(gameName+"-优惠券");
                    } else {
                        title.setText(gameName+"-"+explain);
                    }

                    itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (TextUtils.isEmpty(ticket.getGameID())){
                                ToastUtil.showToast(App.mContext,"游戏信息有误");
                                return;
                            }
                            Intent intent = new Intent(mActivity,AppDetailActivity.class);
                            intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_ID,ticket.getGameID());
                            mActivity.startActivity(intent);
                        }
                    });
                }
                description.setText("满"+ticket.getCondition()+"元使用。可用于游戏充值");
                time.setText("有效期至："+ticket.getExpireTime());

            }

        }
    }
}
