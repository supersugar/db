package com.uu898app.util.dropdownmenu;

import java.util.List;

/**
 * author: baiiu
 * date: on 16/2/19 18:09
 * description:
 */
public class FilterType {
    public String desc;
    public List<String> child;
}
