package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    : 通过游戏名字获取开服列表请求bean
 * =====================================================
 */

public class GGetServerListByGameName {
    /**
     * gameName :
     */

    private String gameName;

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }
}
