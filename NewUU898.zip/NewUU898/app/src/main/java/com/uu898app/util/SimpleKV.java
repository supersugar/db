package com.uu898app.util;

/**
 * Created by zhangbo on 2016/7/8.
 */
public class SimpleKV {

    public String key;
    public String value;

    public SimpleKV(String key, String value) {
        this.key = key;
        this.value = value;
    }

    @Override
    public String toString() {
        return this.value;
    }
}
