package com.uu393.market.module.center;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;

import com.uu393.market.Constant;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GDoJoinShareEarn;
import com.uu393.market.model.request.GGetPhoneCode;
import com.uu393.market.model.response.BUserIsBindPhone;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.login.CountDownTimer;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.IPUtils;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.ToastUtil;

import okhttp3.Call;
import okhttp3.Response;

/**
 * 参加分享赚界面
 * */
public class JoinShareEarnActivity extends BaseActivity implements View.OnClickListener {
    private Button mBtnJoinShare;
    private boolean mIsBindPhone =false;//用户是否有手机号
    private boolean mIsShareUser = false;//用户是否是分享赚用户
    private String mBindPhoneNumber;//用户手机号
    private String mIp;
    private Activity mActivity;
    private PopupWindow mPopJoinShareSuccess;
    private PopupWindow mPopJoinShareBindPhone;
    private WebView mWbJoinShare;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_share_earn);
        mActivity = this;
        mBtnJoinShare = (Button) findViewById(R.id.btn_join_share);
        mWbJoinShare = (WebView) findViewById(R.id.wb_join_share);
        mIp = IPUtils.getIPAddress(App.mContext);
        mWbJoinShare.getSettings().setJavaScriptEnabled(true);
        mWbJoinShare.setWebViewClient(new WebViewClient());
        mWbJoinShare.setWebChromeClient(new WebChromeClient());
        mWbJoinShare.loadUrl("http://192.168.5.52:8090/APPMarket/APPView/JoinShareSale");
    }

    @Override
    protected void onResume() {
        super.onResume();
        doGetUserIsBindPhone();

        mBtnJoinShare.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() ==R.id.btn_join_share){
            if (mIsBindPhone){
                if (mIsShareUser){
                }else {
                    GDoJoinShareEarn model = new GDoJoinShareEarn();
                    model.setCode("");
                    model.setPhoneNo("");
                    model.setIp(mIp);
                    doJoinShareEarn(model);//直接参加
                }
            }else {//弹出绑定手机框
                showBindPhonePop();
            }
        }
    }

    //未绑定手机时弹出绑定手机弹窗
    private void showBindPhonePop(){
        View inflate = LayoutInflater.from(mActivity).inflate(R.layout.popupwindow_join_share_bind, null, false);
        if (mPopJoinShareBindPhone == null){
            mPopJoinShareBindPhone = new PopupWindow(inflate, ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        mPopJoinShareBindPhone.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        mPopJoinShareBindPhone.setAnimationStyle(android.R.style.Animation_InputMethod);
        mPopJoinShareBindPhone.setOutsideTouchable(true);
        mPopJoinShareBindPhone.setFocusable(true);
        WindowManager.LayoutParams lp = JoinShareEarnActivity.this.getWindow().getAttributes();
        lp.alpha = 0.5f;
        mActivity.getWindow().setAttributes(lp);
        mPopJoinShareBindPhone.showAtLocation(mActivity.getWindow().getDecorView(), Gravity.CENTER , 0, 0);
        mPopJoinShareBindPhone.update();
        mPopJoinShareBindPhone.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                WindowManager.LayoutParams lp = mActivity.getWindow().getAttributes();
                lp.alpha = 1.0f;
                mActivity.getWindow().setAttributes(lp);
            }
        });
        final EditText etPopPhoneNumber = (EditText) inflate.findViewById(R.id.et_join_share_pop_phone_number);
        final EditText etPopPhoneCode = (EditText) inflate.findViewById(R.id.et_join_share_pop_code);
        final Button btnPopGetCode = (Button) inflate.findViewById(R.id.btn_join_share_pop_get_code);
        Button btnPopCommitBind = (Button) inflate.findViewById(R.id.btn_join_share_pop_commit_bind);

        btnPopGetCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mBindPhoneNumber = etPopPhoneNumber.getText().toString().trim().replace(" ", "");
                if (TextUtils.isEmpty(mBindPhoneNumber)){
                    ToastUtil.showToast(App.mContext,"请输入手机号");
                    return;
                }else {
                    doGetPhoneCode(btnPopGetCode, Constant.GET_PHONE_CODE_TYPE_10);
                }

            }
        });
        btnPopCommitBind.setOnClickListener(new View.OnClickListener() {//提交参加分享赚
            @Override
            public void onClick(View v) {
                String phoneNumber = etPopPhoneNumber.getText().toString().trim();
                if (TextUtils.isEmpty(phoneNumber)){
                    ToastUtil.showToast(App.mContext,"请输入手机号");
                    return;
                }else {
                    mBindPhoneNumber = phoneNumber;
                }
                String phoneCode = etPopPhoneCode.getText().toString().trim().replace(" ", "");
                if (TextUtils.isEmpty(phoneCode)){
                    ToastUtil.showToast(App.mContext,"请输入验证码");
                    return;
                }else {
                    GDoJoinShareEarn model = new GDoJoinShareEarn();
                    model.setCode(phoneCode);
                    model.setPhoneNo(mBindPhoneNumber);
                    model.setIp(mIp);
                    doJoinShareEarn(model);
                }
            }
        });

    }

    //绑定成功弹窗
    private void showJoinSuccessPop(){
        View inflate = LayoutInflater.from(mActivity).inflate(R.layout.popupwindow_join_share_success, null, false);
        if (mPopJoinShareSuccess ==null){
            mPopJoinShareSuccess = new PopupWindow(inflate, ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        mPopJoinShareSuccess.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        mPopJoinShareSuccess.setAnimationStyle(android.R.style.Animation_InputMethod);
        mPopJoinShareSuccess.setOutsideTouchable(true);
        mPopJoinShareSuccess.setFocusable(true);
        WindowManager.LayoutParams lp = JoinShareEarnActivity.this.getWindow().getAttributes();
        lp.alpha = 0.5f;
        mActivity.getWindow().setAttributes(lp);
        mPopJoinShareSuccess.showAtLocation(mActivity.getWindow().getDecorView(), Gravity.CENTER , 0, 0);
        mPopJoinShareSuccess.update();
        mPopJoinShareSuccess.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                WindowManager.LayoutParams lp = mActivity.getWindow().getAttributes();
                lp.alpha = 1.0f;
                mActivity.getWindow().setAttributes(lp);
            }
        });
        Button btnPopGoEarn = (Button) inflate.findViewById(R.id.btn_join_share_pop_go_earn);
        btnPopGoEarn.setOnClickListener(new View.OnClickListener() {//去赚钱
            @Override
            public void onClick(View v) {
                mPopJoinShareSuccess.dismiss();
            }
        });
    }

    //获取用户是否绑定手机号APP058
    private void doGetUserIsBindPhone() {
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetUserIsBindPhone(new JsonCallback<BUserIsBindPhone>() {
            @Override
            public void onSuccess(BUserIsBindPhone bUserIsBindPhone, Call call, Response response) {
                if (bUserIsBindPhone != null) {
                    String isBindPhone = bUserIsBindPhone.getIsBindPhone();
                    if (TextUtils.isEmpty(isBindPhone)) {
                        mIsBindPhone = false;//未绑定
                    } else {
                        mIsBindPhone = true;//已绑定
                        SPUtil.put(App.mContext,"chkMobile",""+bUserIsBindPhone.getIsBindPhone());
                    }

                    String isShareSale = bUserIsBindPhone.getIsShareSale();
                    if (!TextUtils.isEmpty(isShareSale)){
                        if ("true".equals(isShareSale.toLowerCase().trim().replace(" ",""))){
                            mIsShareUser = true;
                            mBtnJoinShare.setVisibility(View.GONE);
                        }else {
                            mIsShareUser = false;
                            mBtnJoinShare.setVisibility(View.VISIBLE);
                        }
                    }
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
            }
        });
    }

    //参加分享赚活动APP051
    private void doJoinShareEarn(GDoJoinShareEarn model){
        if (model ==null){
            return;
        }
        if (TextUtils.isEmpty(model.getPhoneNo())){
            TaskEngine.setTokenUseridPhoneState(2);
        }else {
            TaskEngine.setTokenUseridPhoneState(2);
        }
        TaskEngine.getInstance().doJoinShareEarn(model, new JsonCallback<Object>() {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                if (mPopJoinShareBindPhone!=null &&mPopJoinShareBindPhone.isShowing()){
                    mPopJoinShareBindPhone.dismiss();
                }
                doGetUserIsBindPhone();//参加成功后，刷新该数据
                showJoinSuccessPop();
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                if (mPopJoinShareBindPhone!=null &&mPopJoinShareBindPhone.isShowing()){
                    mPopJoinShareBindPhone.dismiss();
                }
            }
        });

    }


    /**
     * 获取手机验证码
     *
     * @param btnGetCode :按钮
     */
    private void doGetPhoneCode(final Button btnGetCode, @NonNull String getCodeType) {

        final CountDownTimer timer = new CountDownTimer(60000, 1000, btnGetCode, "获取验证码");
        timer.start();

        GGetPhoneCode model = new GGetPhoneCode();
        model.setType(getCodeType);
        model.setUserId("");
        model.setPhoneNo(mBindPhoneNumber);
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetPhoneCode(model, new JsonCallback<Object>() {
            @Override
            public void onSuccess(Object bPhoneCode, Call call, Response response) {
                /*
                * Status 1 发送次数超过限制，请查看手机收到的验证码
                        2 手机号码格式不正确
                        3 该手机号在黑名单中
                        4 该手机号已被禁用
                        5 该用户没有绑定手机号
                * */
                ToastUtil.showToast(App.mContext, "短信验证码已发送至您的手机");

            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                timer.cancel();
                btnGetCode.setEnabled(true);
                btnGetCode.setText("获取验证码");
            }
        });
    }
}
