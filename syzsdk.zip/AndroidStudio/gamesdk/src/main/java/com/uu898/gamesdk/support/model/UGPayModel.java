package com.uu898.gamesdk.support.model;

import java.io.Serializable;

/**
 * Created by bo on 16/9/29.
 */

public class UGPayModel implements Serializable {

    public String cpOrderNo;//cp订单号
    public String title;//商品标题
    public int originalPrice;//单个商品原价(分)
    public int number = 1;//数量
    public String describe;//商品描述
    public String productID;//商品编号
    public String reserved;//保留字段
}
