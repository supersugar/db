package com.uu393.market.module.center;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.alipay.sdk.app.PayTask;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GDoCommitChargeOrderInfo;
import com.uu393.market.model.response.BChargeOrderInfo;
import com.uu393.market.module.alipay.AliPayResult;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.CommonUtils;
import com.uu393.market.util.ContactCustomerServicesUtils;
import com.uu393.market.util.IPUtils;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.log.L;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.finalteam.toolsfinal.DeviceUtils;
import okhttp3.Call;
import okhttp3.Response;

public class ChargeMoneyActivity extends BaseActivity {

    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    @Bind(R.id.recycler_view_charge_money)
    RecyclerView mRecyclerViewChargeMoney;
    @Bind(R.id.et_charge_money_self_define)
    EditText mEtChargeMoneySelfDefine;
    @Bind(R.id.layout_charge_wx)
    LinearLayout mLayoutChargeWx;
    @Bind(R.id.layout_charge_ali)
    LinearLayout mLayoutChargeAli;
    @Bind(R.id.tv_contact)
    TextView mTvContact;

    private String mChargeMoneyCount = "50";//默认选中的充值金额
    private String mPayType = "";//支付类型：微信14，支付宝13
    private ChargeMoneyRecyclerViewAdapter mSelectMoneyAdapter;
    private String mCustomMoney;
    private String mPhoneIP = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_charge_money);
        ButterKnife.bind(this);
        initTitleBar();
        initRecyclerView();
        if (!TextUtils.isEmpty(IPUtils.getIPAddress(App.mContext))) {
            L.d("IP：：==" + IPUtils.getIPAddress(App.mContext));
            mPhoneIP = IPUtils.getIPAddress(App.mContext);
        }


        mEtChargeMoneySelfDefine.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!TextUtils.isEmpty(s.toString())) {
                    mSelectMoneyAdapter.setCurrentItem(-1);
                    mChargeMoneyCount = "";
                } else {//为空时

                }
            }
        });
    }

    private void initRecyclerView() {
        mRecyclerViewChargeMoney.setLayoutManager(new GridLayoutManager(this, 3));
        if (mSelectMoneyAdapter == null) {
            mSelectMoneyAdapter = new ChargeMoneyRecyclerViewAdapter(2);
        }
        mRecyclerViewChargeMoney.setAdapter(mSelectMoneyAdapter);
        mSelectMoneyAdapter.setOnItemSelectedListener(new ChargeMoneyRecyclerViewAdapter.OnItemSelectedListener() {
            @Override
            public void onItemSelectedListener(int position, String content) {
                mEtChargeMoneySelfDefine.getText().clear();
                mEtChargeMoneySelfDefine.clearFocus();
                mEtChargeMoneySelfDefine.setFocusable(false);
                ToastUtil.showToast(App.mContext, "当前位置" + position + "    " + content + "元");
                mChargeMoneyCount = content;
                if (DeviceUtils.isActiveSoftInput(App.mContext)) {
                    DeviceUtils.hideInputSoftFromWindowMethod(App.mContext, mEtChargeMoneySelfDefine);
                }
            }
        });
    }

    private void initTitleBar() {
        mTitleBarRight.setVisibility(View.GONE);
        mTitleBarTitle.setText("充值");
    }

    @OnClick({R.id.title_bar_left, R.id.layout_charge_wx, R.id.layout_charge_ali, R.id.tv_contact, R.id.et_charge_money_self_define})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left://返回
                super.onBackPressedSupport();
                break;
            case R.id.layout_charge_wx://微信支付
                //需要先判断有没有安装微信
                if (!CommonUtils.isWeixinInstall(App.mContext)) {
                    ToastUtil.showToast(App.mContext, "请安装微信客户端");
                    return;
                }
                mCustomMoney = mEtChargeMoneySelfDefine.getText().toString().trim();
                if (!TextUtils.isEmpty(mCustomMoney)) {
                    if (!TextUtils.isEmpty(mCustomMoney)) {
                        //自定义金额要正则判断
                        if (StringUtils.isRealMoney(mCustomMoney)) {
                            mChargeMoneyCount = mCustomMoney;
                        } else {
                            ToastUtil.showToast(App.mContext, "请输入正确的金额");
                            return;
                        }
                    }
                }
                if (TextUtils.isEmpty(mChargeMoneyCount)) {
                    ToastUtil.showToast(App.mContext, "金额不能为空");
                    return;
                }
                ToastUtil.showToast(App.mContext, "选择微信支付，支付金额=" + mChargeMoneyCount + "元");
                mPayType = "14";
                GDoCommitChargeOrderInfo modelWx = new GDoCommitChargeOrderInfo();
                modelWx.setPayType(mPayType);
                modelWx.setPayType(mChargeMoneyCount);
                modelWx.setIp(mPhoneIP);
                doCommitChargeOrderInfo(modelWx, mPayType);
                break;
            case R.id.layout_charge_ali://支付宝支付
                mCustomMoney = mEtChargeMoneySelfDefine.getText().toString().trim();
                if (!TextUtils.isEmpty(mCustomMoney)) {
                    if (!TextUtils.isEmpty(mCustomMoney)) {
                        //自定义金额要正则判断
                        if (StringUtils.isRealMoney(mCustomMoney)) {
                            mChargeMoneyCount = mCustomMoney;
                        } else {
                            ToastUtil.showToast(App.mContext, "请输入正确的金额");
                            return;
                        }
                    }
                }
                if (TextUtils.isEmpty(mChargeMoneyCount)) {
                    ToastUtil.showToast(App.mContext, "金额不能为空");
                    return;
                }
                ToastUtil.showToast(App.mContext, "选择支付宝支付，支付金额=" + mChargeMoneyCount + "元");
                mPayType = "13";
                GDoCommitChargeOrderInfo modelAli = new GDoCommitChargeOrderInfo();
                modelAli.setPayType(mPayType);
                modelAli.setPrice(mChargeMoneyCount);
                modelAli.setIp(mPhoneIP);
                doCommitChargeOrderInfo(modelAli, mPayType);
                break;
            case R.id.tv_contact://联系客服
                ContactCustomerServicesUtils.doXiaoNeng();
                break;
            case R.id.et_charge_money_self_define://自定义金额输入框
                mEtChargeMoneySelfDefine.setFocusable(true);
                mEtChargeMoneySelfDefine.setFocusableInTouchMode(true);
                mEtChargeMoneySelfDefine.requestFocus();
                if (!DeviceUtils.isActiveSoftInput(App.mContext))
                    DeviceUtils.showInputSoftFromWindowMethod(App.mContext, mEtChargeMoneySelfDefine);
                break;
        }
    }

    //获取支付宝交易订单号，签名后订单信息
    private void doCommitChargeOrderInfo(GDoCommitChargeOrderInfo model, final String payType) {
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doCommitChargeOrderInfo(model, new JsonCallback<BChargeOrderInfo>() {
            @Override
            public void onSuccess(BChargeOrderInfo bChargeOrderInfo, Call call, Response response) {
                if (bChargeOrderInfo != null) {
                    if ("13".equals(payType)) {
                        doAliPay(bChargeOrderInfo.getTradeOrderNo());
                    } else if ("14".equals(payType)) {

                    }
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                ToastUtil.showToast(App.mContext, "获取支付订单失败");
            }
        });
    }

    private void doAliPay(final String signOrderNo) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                PayTask payTask = new PayTask(ChargeMoneyActivity.this);
                String result = payTask.pay(signOrderNo, true);
                Message message = mHandler.obtainMessage();
                message.what = 99;
                message.obj = result;
                mHandler.sendMessage(message);
            }
        }).start();
    }

    private  Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == 99) {
                AliPayResult aliPayResult = new AliPayResult((String) msg.obj);
                String resultStatus = aliPayResult.getResultStatus();
                // 判断resultStatus 为“9000”则代表支付成功，具体状态码代表含义可参考接口文档
                if (TextUtils.equals(resultStatus, "9000")) {
                    ToastUtil.showToast(App.mContext, "支付完成,请稍等...");
                    Intent intent = new Intent();
                    intent.setClass(ChargeMoneyActivity.this,ChargeMoneyStateActivity.class);
                    ChargeMoneyActivity.this.startActivity(intent);
                } else {
                    // 判断resultStatus 为非"9000"则代表可能支付失败
                    // "8000"代表支付结果因为支付渠道原因或者系统原因还在等待支付结果确认，最终交易是否成功以服务端异步通知为准（小概率状态）
                    if (TextUtils.equals(resultStatus, "8000")) {
                        ToastUtil.showToast(App.mContext, "支付结果确认中...");
                        Intent intent = new Intent();
                        intent.setClass(ChargeMoneyActivity.this,ChargeMoneyStateActivity.class);
                        ChargeMoneyActivity.this.startActivity(intent);
                    } else if (TextUtils.equals(resultStatus, "6001")) {
                        ToastUtil.showToast(App.mContext, "支付取消");

                    } else {
                        // 其他值就可以判断为支付失败，包括用户主动取消支付，或者系统返回的错误
                        ToastUtil.showToast(App.mContext, "支付失败");
                    }
                }
            }
        }
    };

    public static class ChargeMoneyRecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private int currentItem = -1;
        private OnItemSelectedListener mListener;
        private String[] prices = {"5", "10", "50", "100", "500", "1000"};
        private String currentPrice = "";

        public ChargeMoneyRecyclerViewAdapter(int selectItem) {
            if (-1 < selectItem && selectItem < prices.length) {
                currentItem = selectItem;
            }
        }

        public void setCurrentItem(int selectItem) {
            if (selectItem < prices.length) {
                this.currentItem = selectItem;
            }
            this.notifyDataSetChanged();
        }

        public int getCurrentItem() {
            return this.currentItem;
        }

        public String getCurrentPrice() {
            if (currentItem != -1) {
                return prices[currentItem];
            }
            return "";
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_charge_money, parent, false);
            return new ChargeMoneyViewHolder(view);
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
            if (holder != null && holder instanceof ChargeMoneyViewHolder) {
                ((ChargeMoneyViewHolder) holder).textView.setText(prices[position] + "元");
                if (position == currentItem) {
                    ((ChargeMoneyViewHolder) holder).textView.setBackgroundResource(R.drawable.shape_corner_solid_blue_big);
                    ((ChargeMoneyViewHolder) holder).textView.setTextColor(App.mContext.getResources().getColor(R.color.white));
                } else {
                    ((ChargeMoneyViewHolder) holder).textView.setBackgroundResource(R.drawable.shape_corner_stroke_grey);
                    ((ChargeMoneyViewHolder) holder).textView.setTextColor(App.mContext.getResources().getColor(R.color.text_lv3));
                }


                ((ChargeMoneyViewHolder) holder).textView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        setCurrentItem(position);
                        if (mListener != null)
                            mListener.onItemSelectedListener(position, prices[position]);
                    }
                });


            }
        }

        @Override
        public int getItemCount() {
            return prices.length;
        }

        public class ChargeMoneyViewHolder extends RecyclerView.ViewHolder {
            private TextView textView;

            public ChargeMoneyViewHolder(View itemView) {
                super(itemView);
                textView = (TextView) itemView;
            }
        }

        public interface OnItemSelectedListener {
            void onItemSelectedListener(int position, String content);
        }

        public void setOnItemSelectedListener(OnItemSelectedListener listener) {
            this.mListener = listener;
        }
    }
}
