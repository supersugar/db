package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/14
 * Description    :
 * =====================================================
 */

public class BShareOrderDetail implements Serializable {
    /**
     {
     "gameName":"dddd",（游戏名称）
     "title":"aaaa",（商品名称）
     "completeTime":"2017-04-10 00:00:00",（时间）
     "orderNo":"10",（用户订单唯一编号）
     "originalMoney":"10",（商品原价）
     "totalMoney":"10",（实际价格）
     "inCome":"10",（收入）
     "status":"已完成"(状态）
     }
     */

    private String appName;
    private String title;
    private String completeTime;
    private String orderNo;
    private String originalMoney;
    private String totalMoney;
    private String inCome;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    private String status;

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCompleteTime() {
        return completeTime;
    }

    public void setCompleteTime(String completeTime) {
        this.completeTime = completeTime;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getOriginalMoney() {
        return originalMoney;
    }

    public void setOriginalMoney(String originalMoney) {
        this.originalMoney = originalMoney;
    }

    public String getTotalMoney() {
        return totalMoney;
    }

    public void setTotalMoney(String totalMoney) {
        this.totalMoney = totalMoney;
    }

    public String getInCome() {
        return inCome;
    }

    public void setInCome(String inCome) {
        this.inCome = inCome;
    }
}
