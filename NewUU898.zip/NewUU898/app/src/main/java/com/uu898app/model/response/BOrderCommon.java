package com.uu898app.model.response;

/**
 * Created by zhangbo on 2016/7/11.
 */
public class BOrderCommon {


    /**
     * gameID : 156
     * statusName : 支付超时，交易失败
     * selfTrade : false
     * userid : 13203713938
     * gameName : 第九大陆
     * gameAccountName : W
     * payTime :
     * title : 鲯鳅  10条装
     * coinUnit : 0
     * commodityNo : CN20160703155007-89817
     * showname : UU898客服
     * IsGoldmedals : false
     * yajin : false
     * commodityTypeName : 装备
     * campName :
     * status : 4
     * uqstatus : 0
     * commodityType : -2
     * serverName : 岁月大陆
     * complainNo :
     * businessTypeName : 寄售交易
     * price : 10
     * orderNo : 1559612568
     * areaName : 岁月大陆
     * orderNumber : 1
     * kefuqq :
     * images : uploadFiles/gameIDImgs/2016/0204/CN20160204182847-05617-28-57.jpg
     * kefuId : 172
     * completeTime :
     * pj : 0
     * gameaccount : Mobile
     * IsRecommend : false
     * addTime : 2016/7/4 14:30:59
     */

    private int gameID;
    private String statusName;
    private boolean selfTrade;
    private String userid;
    private String gameName;
    private String gameAccountName;
    private String payTime;
    private String title;
    private int coinUnit;
    private String commodityNo;
    private String showname;
    private boolean IsGoldmedals;
    private boolean yajin;
    private String commodityTypeName;
    private String campName;
    private int status;
    private int uqstatus;
    private int commodityType;
    private String serverName;
    private String complainNo;
    private String businessTypeName;
    private int price;
    private String orderNo;
    private String areaName;
    private int orderNumber;
    private String kefuqq;
    private String images;
    private int kefuId;
    private String completeTime;
    private int pj;
    private String gameaccount;
    private boolean IsRecommend;
    private String addTime;

    public int getGameID() {
        return gameID;
    }

    public void setGameID(int gameID) {
        this.gameID = gameID;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public boolean isSelfTrade() {
        return selfTrade;
    }

    public void setSelfTrade(boolean selfTrade) {
        this.selfTrade = selfTrade;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }

    public String getGameAccountName() {
        return gameAccountName;
    }

    public void setGameAccountName(String gameAccountName) {
        this.gameAccountName = gameAccountName;
    }

    public String getPayTime() {
        return payTime;
    }

    public void setPayTime(String payTime) {
        this.payTime = payTime;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getCoinUnit() {
        return coinUnit;
    }

    public void setCoinUnit(int coinUnit) {
        this.coinUnit = coinUnit;
    }

    public String getCommodityNo() {
        return commodityNo;
    }

    public void setCommodityNo(String commodityNo) {
        this.commodityNo = commodityNo;
    }

    public String getShowname() {
        return showname;
    }

    public void setShowname(String showname) {
        this.showname = showname;
    }

    public boolean isIsGoldmedals() {
        return IsGoldmedals;
    }

    public void setIsGoldmedals(boolean IsGoldmedals) {
        this.IsGoldmedals = IsGoldmedals;
    }

    public boolean isYajin() {
        return yajin;
    }

    public void setYajin(boolean yajin) {
        this.yajin = yajin;
    }

    public String getCommodityTypeName() {
        return commodityTypeName;
    }

    public void setCommodityTypeName(String commodityTypeName) {
        this.commodityTypeName = commodityTypeName;
    }

    public String getCampName() {
        return campName;
    }

    public void setCampName(String campName) {
        this.campName = campName;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getUqstatus() {
        return uqstatus;
    }

    public void setUqstatus(int uqstatus) {
        this.uqstatus = uqstatus;
    }

    public int getCommodityType() {
        return commodityType;
    }

    public void setCommodityType(int commodityType) {
        this.commodityType = commodityType;
    }

    public String getServerName() {
        return serverName;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    public String getComplainNo() {
        return complainNo;
    }

    public void setComplainNo(String complainNo) {
        this.complainNo = complainNo;
    }

    public String getBusinessTypeName() {
        return businessTypeName;
    }

    public void setBusinessTypeName(String businessTypeName) {
        this.businessTypeName = businessTypeName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public int getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(int orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getKefuqq() {
        return kefuqq;
    }

    public void setKefuqq(String kefuqq) {
        this.kefuqq = kefuqq;
    }

    public String getImages() {
        return images;
    }

    public void setImages(String images) {
        this.images = images;
    }

    public int getKefuId() {
        return kefuId;
    }

    public void setKefuId(int kefuId) {
        this.kefuId = kefuId;
    }

    public String getCompleteTime() {
        return completeTime;
    }

    public void setCompleteTime(String completeTime) {
        this.completeTime = completeTime;
    }

    public int getPj() {
        return pj;
    }

    public void setPj(int pj) {
        this.pj = pj;
    }

    public String getGameaccount() {
        return gameaccount;
    }

    public void setGameaccount(String gameaccount) {
        this.gameaccount = gameaccount;
    }

    public boolean isIsRecommend() {
        return IsRecommend;
    }

    public void setIsRecommend(boolean IsRecommend) {
        this.IsRecommend = IsRecommend;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }
}
