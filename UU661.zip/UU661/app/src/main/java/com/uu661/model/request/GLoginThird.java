package com.uu661.model.request;

import java.io.Serializable;

public class GLoginThird implements Serializable {

    public static final String TYPE_QQ = "qq";//登陆类型，qq，sina，zhifubao

    public String loginType;//
    public String loginThirdId;//
    public String qqUnionid;//
    public String accessToken;//

}
