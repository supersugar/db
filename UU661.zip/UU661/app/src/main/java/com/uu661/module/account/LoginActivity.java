package com.uu661.module.account;

import android.os.Bundle;

import com.uu661.R;
import com.uu661.module.base.BaseSwipeBackActivity;

public class LoginActivity extends BaseSwipeBackActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (savedInstanceState == null) {
            loadRootFragment(R.id.fl_container, LoginFragment.newInstance());
        }
    }
}
