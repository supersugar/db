package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/22
 * Descrip    :
 * =====================================================
 */

public class BH5ZaiWan implements Serializable{


    /**
     * id : 123
     * icon : 123456
     * gameName : 大主宰
     * androidPackage : Http:1213
     * APPID : 1213
     */

    private String id;
    private String icon;
    private String gameName;
    private String androidPackage;
    private String APPID;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }

    public String getAndroidPackage() {
        return androidPackage;
    }

    public void setAndroidPackage(String androidPackage) {
        this.androidPackage = androidPackage;
    }

    public String getAPPID() {
        return APPID;
    }

    public void setAPPID(String APPID) {
        this.APPID = APPID;
    }
}
