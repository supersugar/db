package com.uu393.market.module.center;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GGetShareFormMore;
import com.uu393.market.model.request.GGetShareOrderList;
import com.uu393.market.model.response.BShareFormMore;
import com.uu393.market.module.base.BaseViewPagerFragment;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.eventbus.EventObject;

import org.greenrobot.eventbus.Subscribe;

import butterknife.Bind;
import butterknife.ButterKnife;
import okhttp3.Call;
import okhttp3.Response;

/**
 * @author wangxian
 *         分享赚更多数据游戏种类 记录碎片
 *         A simple {@link Fragment} subclass.
 */
public class ShareReportFormMoreGameKindRecordFragment extends BaseViewPagerFragment {
    private static final String KEY_GAME_KIND = "game_kind";
    private static final String KEY_GET_SHARE_MORE = "get_share_more";

    @Bind(R.id.tv_installed_number)
    TextView mTvInstalledNumber;
    @Bind(R.id.tv_active_number)
    TextView mTvActiveNumber;
    @Bind(R.id.tv_game_installed_number)
    TextView mTvGameInstalledNumber;
    @Bind(R.id.tv_new_user)
    TextView mTvNewUser;
    @Bind(R.id.tv_payed_user)
    TextView mTvPayedUser;
    @Bind(R.id.tv_payed_number)
    TextView mTvPayedNumber;
    @Bind(R.id.ll_open)
    LinearLayout mLlOpen;
    @Bind(R.id.tv_function_not_open_message)
    TextView mTvFunctionNotOpenMessage;
    @Bind(R.id.ll_no_open)
    LinearLayout mLlNoOpen;

    private String mKind;//tab种类：安卓，H5游戏
    private BShareFormMore mShareFormMore;
    private GGetShareFormMore mGetShareFormMore;
    public ShareReportFormMoreGameKindRecordFragment() {
    }

    public static ShareReportFormMoreGameKindRecordFragment newInstance(String gameKind,BShareFormMore shareFormMore) {
        ShareReportFormMoreGameKindRecordFragment fragment = new ShareReportFormMoreGameKindRecordFragment();
        Bundle bundle = new Bundle();
        bundle.putString(KEY_GAME_KIND, gameKind);
        bundle.putSerializable(KEY_GET_SHARE_MORE,shareFormMore);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mKind = getArguments().getString(KEY_GAME_KIND);
            mShareFormMore = (BShareFormMore) getArguments().getSerializable(KEY_GET_SHARE_MORE);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_share_report_form_more_game_kind_record, container, false);
        ButterKnife.bind(this, view);
        if ("H5游戏".equals(mKind)) {
            showFunctionOpen(false);
        }else {
            showFunctionOpen(true);
        }
        return view;
    }
    //显示是否开通功能
    private void showFunctionOpen(boolean hasOpen) {
        if (hasOpen) {
            mLlOpen.setVisibility(View.VISIBLE);
            mLlNoOpen.setVisibility(View.GONE);
        } else {
            mLlNoOpen.setVisibility(View.VISIBLE);
            mLlOpen.setVisibility(View.GONE);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(mShareFormMore);
    }

    private void initView(BShareFormMore shareFormMore) {
        if (shareFormMore!=null){
            mTvInstalledNumber.setText(""+shareFormMore.getUUSYInstall());//UU手游安装数
            mTvActiveNumber.setText(""+shareFormMore.getUUSYActive());//活跃数（应用市场）
            mTvGameInstalledNumber.setText(""+shareFormMore.getSDKInstall());//游戏安装数
            mTvNewUser.setText(""+shareFormMore.getNewUser());//新增用户
            mTvPayedUser.setText(""+shareFormMore.getPaymentCount());//付费用户
            mTvPayedNumber.setText("¥"+shareFormMore.getPaymentMoney());//付费总金额
        }else {
            mTvInstalledNumber.setText("无");//UU手游安装数
            mTvActiveNumber.setText("无");//活跃数（应用市场）
            mTvGameInstalledNumber.setText("无");//游戏安装数
            mTvNewUser.setText("无");//新增用户
            mTvPayedUser.setText("无");//付费用户
            mTvPayedNumber.setText("无");//付费总金额
        }

    }

    @Override
    public void refresh() {
        doGetShareFormMore(mGetShareFormMore);//刷新数据
        initView(mShareFormMore);
        if (mShareFormMore!=null){
            EB.postObject(EB.TAG.REFRESH_IN_SHARE_MORE_ACTIVITY,mShareFormMore);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        EB.register(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EB.unregister(this);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }
    @Subscribe
    public void onEvent(BaseEvent event){
        switch (event.tag){
            case EB.TAG.REFRESH_IN_SHARE_MORE_FRAGMENT://刷新界面
                if (event instanceof EventObject){
                    Object result = ((EventObject) event).result;
                    if (result!=null &&result instanceof GGetShareFormMore){
                        mGetShareFormMore = (GGetShareFormMore) result;
                        this.refresh();
                    }
                }
                break;

        }
    }

    /*获取分享赚更多数据：APP054
    */
    private void doGetShareFormMore(GGetShareFormMore model) {
        if (model == null) return;
        showLoadToast();
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetShareFormMore(model, new JsonCallback<BShareFormMore>() {
            @Override
            public void onSuccess(BShareFormMore bShareFormMore, Call call, Response response) {
                hideLoadToast();
                if (bShareFormMore != null) {
                    mShareFormMore = bShareFormMore;
                } else {
                    ToastUtil.showToast(App.mContext, "未获取到分享信息");
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
            }
        });

    }
}
