package com.uu898.gamesdk.support.listener;

public interface UGLoginListener {
    public void onSuccess(String token, String uid);
}
