package com.uu898app.module.home;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.uu898app.R;
import com.uu898app.adapter.GameAdapter;
import com.uu898app.model.GBaseModel;
import com.uu898app.model.request.GGameList;
import com.uu898app.model.request.GLogin;
import com.uu898app.model.response.BGame;
import com.uu898app.model.response.BLogin;
import com.uu898app.model.response.BUserInfo;
import com.uu898app.module.base.BaseFragment;
import com.uu898app.module.buy.BuyActivity;
import com.uu898app.module.helper.AccountManager;
import com.uu898app.module.helper.BuyHelper;
import com.uu898app.module.helper.ToolbarHelper;
import com.uu898app.module.helper.UiHelper;
import com.uu898app.network.TaskEngine;
import com.uu898app.network.rxjava.RxSubscriber;
import com.uu898app.util.ToastUtil;
import com.uu898app.util.eventbus.EB;
import com.uu898app.util.eventbus.EventEmpty;
import com.uu898app.view.SpaceItemDecoration;
import com.uu898app.view.banner.Banner;

import org.greenrobot.eventbus.Subscribe;

import java.util.List;

import cn.finalteam.toolsfinal.DeviceUtils;
import rx.functions.Action1;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class HomeFragment extends BaseFragment {

    private SwipeRefreshLayout mSwipeRefreshLayout;
    private RecyclerView mRecyclerView;
    private GameAdapter mAdapter;
    private boolean mInAtTop = true;
    private int mScrollTotal;
    private Toolbar toolbar;

    private View mBannerLayout;
    private Banner mBannerView;
    private Button mBtToRecharge;

    public static HomeFragment newInstance() {
        Bundle args = new Bundle();
        HomeFragment fragment = new HomeFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.home_fragment, container, false);
    }

    @Override

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        toolbar = (Toolbar) view.findViewById(R.id.toolbar);
        new ToolbarHelper.Builder(toolbar,this, _mActivity)
                .title("我要买")
                .subTitle(AccountManager.getInstance().getUserId())
                .showXiaoNeng(true)
                .showHierarchy(false)
                .build();

        toolbar.setNavigationIcon(UiHelper.getColorFilterDwawable(R.drawable.ic_account_circle_white_24dp));
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start(TestFragment.newInstance());
            }
        });

        mRecyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        mSwipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.refresh_layout);

        mSwipeRefreshLayout.setColorSchemeResources(R.color.colorPrimary);
        mSwipeRefreshLayout.setOnRefreshListener(onRefreshListener);

        GridLayoutManager manager = new GridLayoutManager(_mActivity, 2);
        mRecyclerView.setLayoutManager(manager);
        mAdapter = new GameAdapter(null);
        mAdapter.openLoadAnimation();
        View header = LayoutInflater.from(_mActivity).inflate(R.layout.home_header_view, null);
        header.setOnClickListener(v ->
            {
                BuyHelper.getInstance().resetChooseResult();
                startActivity(new Intent(_mActivity, BuyActivity.class));
            });
        mAdapter.addHeaderView(header);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.addItemDecoration(new SpaceItemDecoration(DeviceUtils.dip2px(_mActivity,1)));
        mRecyclerView.addOnItemTouchListener(new OnItemClickListener( ){

            @Override
            public void SimpleOnItemClick(BaseQuickAdapter adapter, View view, int position) {
                BuyHelper.getInstance().setChooseGame((BGame) mAdapter.getItem(position));
                startActivity(new Intent(_mActivity, BuyActivity.class));
            }
        });
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                mScrollTotal += dy;
                if (mScrollTotal <= 0) {
                    mInAtTop = true;
                } else {
                    mInAtTop = false;
                }
            }
        });

        doGetGameList();
        autoLogin();
    }


    SwipeRefreshLayout.OnRefreshListener onRefreshListener = new SwipeRefreshLayout.OnRefreshListener() {
        @Override
        public void onRefresh() {
            doGetGameList();
        }
    };

    @Override
    public void onResume() {
        super.onResume();
        EB.register(this);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        EB.unregister(this);
    }

    @Subscribe
    public void onEvent(EventEmpty event) {
        switch (event.tag) {
            case EB.TAG.A:
                if (mInAtTop) {
                    doGetGameList();
                } else {
                    mRecyclerView.smoothScrollToPosition(0);
                }
                break;
            case EB.TAG.LOGIN_SUCCESS:
                toolbar.setSubtitle(AccountManager.getInstance().getUserId());
                break;
            default:
                break;
        }
    }


    private void doGetGameList() {
        mSwipeRefreshLayout.post(new Runnable() {
            @Override
            public void run() {
                mSwipeRefreshLayout.setRefreshing(true);
                GGameList gameList = new GGameList();
                gameList.setIshot("1");
                gameList.setSSID(AccountManager.getInstance().getSSID());

                TaskEngine.getInstance().getGameList(gameList).subscribe(new RxSubscriber<List<BGame>>() {
                    @Override
                    public void _onNext(List<BGame> bGames) {
                        Log.d("xx", bGames.size() + "");
                        if(bGames.size() > 2){
                            bGames.get(0).setItemType(BGame.MULTI_TYPE_BIG);
                            bGames.get(1).setItemType(BGame.MULTI_TYPE_BIG);
                        }
                        mAdapter.setNewData(bGames);
                        mSwipeRefreshLayout.setRefreshing(false);
                    }

                    @Override
                    public void _onError(String msg) {

                    }
                });
            }
        });
    }

    /**
     * 自动登陆
     */
    private void autoLogin() {
        final GLogin model = AccountManager.getInstance().getSaveGLogin();
        if (AccountManager.getInstance().isAutoLogin() && null != model) {
            TaskEngine.getInstance().logins(model).subscribe(new RxSubscriber<BLogin>(this, true) {
                @Override
                public void _onNext(final BLogin bLogin) {
                    TaskEngine.getInstance().getUserInfo(new GBaseModel(bLogin.getSSID())).subscribe(new Action1<BUserInfo>() {
                        @Override
                        public void call(BUserInfo bUserInfo) {
                            Snackbar.make(mSwipeRefreshLayout, "自动登陆成功", Snackbar.LENGTH_SHORT).show();
                            AccountManager.getInstance().saveLoginInfo(bLogin.getSSID(), bLogin.getUserid());
                            AccountManager.getInstance().setStatus(AccountManager.Status.LOGIN);
                            EB.postEmpty(EB.TAG.LOGIN_SUCCESS);
                        }
                    });
                }

                @Override
                public void _onError(String msg) {
                    ToastUtil.showToast(_mActivity, msg);
                }
            });
        }
    }
}
