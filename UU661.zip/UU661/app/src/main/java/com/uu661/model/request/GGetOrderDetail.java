package com.uu661.model.request;

public class GGetOrderDetail {

    private String killOrderNo;//

    public GGetOrderDetail(String killOrderNo) {
        this.killOrderNo = killOrderNo;
    }
}
