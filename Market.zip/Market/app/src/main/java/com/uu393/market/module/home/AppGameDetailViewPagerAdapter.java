package com.uu393.market.module.home;


import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.ViewGroup;

import com.uu393.market.view.lazyviewpager.LazyFragmentPagerAdapter;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/28
 * Descrip    :
 * =====================================================
 */

public class AppGameDetailViewPagerAdapter extends LazyFragmentPagerAdapter {
    private String[] titles = {"游戏介绍","开服表","游戏礼包"};
    private String mGameId;
    public AppGameDetailViewPagerAdapter(FragmentManager fm,String gameId) {
        super(fm);
        this.mGameId = gameId;
    }

    @Override
    protected Fragment getItem(ViewGroup container, int position) {
        if (position==0){
            return GameMessageFragment.newInstance(mGameId);//游戏介绍
        }else if (position==1){
            return OpenServiceFragment.newInstance(mGameId);//开服表
        }else if (position==2){
            return GiftBagFragment.newInstance(mGameId);//礼包
        }else {
            return null;
        }

    }

    @Override
    public int getCount() {
        return titles.length;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return titles[position];
    }

}
