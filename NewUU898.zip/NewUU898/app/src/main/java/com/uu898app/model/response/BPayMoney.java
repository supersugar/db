package com.uu898app.model.response;

/**
 * Created by zhangbo on 2016/7/13.
 */
public class BPayMoney {

    /**
     * money : 101
     */

    private String money;

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }
}
