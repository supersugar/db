package com.uu393.market.module.center;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.R;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.view.lazyviewpager.LazyFragmentPagerAdapter;


import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/*钱包明细*/
public class WalletDetailActivity extends BaseActivity {

    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    @Bind(R.id.tab_layout_wallet_detail)
    TabLayout mTabLayoutWalletDetail;
    @Bind(R.id.vp_wallet_detail)
    ViewPager mVpWalletDetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallet_detail);
        ButterKnife.bind(this);
        initTitle();
        initViewPager();
    }
    private void initTitle() {
        mTitleBarRight.setVisibility(View.GONE);
        mTitleBarTitle.setText("钱包明细");
    }

    private void initViewPager() {
        mVpWalletDetail.setAdapter(new MyPagerAdapter(getSupportFragmentManager()));
        mTabLayoutWalletDetail.setupWithViewPager(mVpWalletDetail);
    }

    @OnClick(R.id.title_bar_left)
    public void onClick() {
        super.onBackPressedSupport();
    }

    public class MyPagerAdapter extends LazyFragmentPagerAdapter {
        //-1全部   0充值   1提现   3收入   30支出
        private String[] titles ={"全部","充值","提现","收入","支出"};


        public MyPagerAdapter(FragmentManager fm) {
            super(fm);

        }

        @Override
        public int getCount() {
            return titles.length;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return titles[position];
        }

        @Override
        protected Fragment getItem(ViewGroup container, int position) {
            WalletDetailAllFragment fragment = WalletDetailAllFragment.newInstance(titles[position]);
            return fragment;
        }
    }
}
