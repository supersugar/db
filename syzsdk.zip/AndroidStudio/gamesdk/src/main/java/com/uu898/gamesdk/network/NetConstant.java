package com.uu898.gamesdk.network;


import com.uu898.gamesdk.utils.RsaHelper;

import java.security.PublicKey;

public class NetConstant {

    public static final class URL {

        public static final String URL_SYZ_OFFICAL = "http://www.shouyouzhu.com/Service/SDKService.ashx";
        public static final String URL_SYZ_TEST = "http://192.168.5.52:9090/Service/SDKService.ashx";
        public static final String URL_SYZ_AGREEMENT = "http://api.shouyouzhu.com/SDK/SDKView/SDKAgreement";
        public static final String URL_SYZ_KEFU = "http://api.shouyouzhu.com/SDK/SDKView/SDKCustomService";
    }

    public static final class Secret {
        //手游猪
        public static final PublicKey RSA_PUBLIC_KEY_SYZ = RsaHelper.decodePublicKeyFromXml
                ("<RSAKeyValue><Modulus>vrF4CrJflpvSWyHhWZlKnWX/7LHhJ89YgQG583b6+zyCkpY6in38ud6Y" +
                "/U30L6uf97bsS3kkuqv9vKpLXoXjBz4dWN3Hm+wqOqM7e/B2HglLRyUWxo7DM5LMAtfasE9ClIrQgJB+2R/yGV" +
                "+gARX8L3mK3kpny6ZcYEI3M6ZR2U8=</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>");
    }

    public static final class OTHER {
        public static final String POST_SYZ = "SYZ_APP";
        public static final String POST_SYZ_SUB = "syzsdk";
    }

    /**********************
     * 协议
     * 账户相关
     * 获取图片验证码              sdk001
     * 用户注册                   sdk002
     * 获取手机验证码              sdk003
     * 绑定手机                   sdk004
     * 用户登录                   sdk005
     * 重置用户密码                sdk007
     * 校验手机验证码              sdk008
     * 换绑手机                   sdk009
     * 修改密码                   sdk011
     * <p>
     * 用户信息(登陆后)
     * 获取用户信息                sdk006
     * 获取消息列表                sdk016
     * 删除消息                   sdk017
     * 获取消息详情                sdk018
     * <p>
     * 支付相关(登陆后)
     * 提交订单                   sdk010
     * 获取订单列表                sdk012
     * 获取支付详情                sdk013
     * 获取支付状态                sdk014
     * 订单继续支付                sdk015  未使用
     * <p>
     * 消息相关(登陆后)
     ****************************************/

    public static final class ApiType {

        public static final String GET_IMAGE_AUTH_CODE = "sdk001";
        public static final String REGISTER = "sdk002";
        public static final String GET_SMS_AUTH_CODE = "sdk003";
        public static final String BINDING_PHONE = "sdk004";
        public static final String LOGIN = "sdk005";
        public static final String RESET_PASSWORD = "sdk007";
        public static final String VERIFY_CURRENT_PHONE = "sdk008";
        public static final String CHANGE_BINDING_PHONE = "sdk009";
        public static final String PAY = "sdk010";
        public static final String CHANGE_PASSWORD = "sdk011";
        public static final String GET_ORDER_LIST = "sdk012";
        public static final String GET_ORDER_DETAIL = "sdk013";
        public static final String GET_ORDER_STATUS = "sdk014";
        public static final String PAY_CONTINUE = "sdk015";
        public static final String GET_MESSAGE_LIST = "sdk016";
        public static final String DELETE_MESSAGES = "sdk017";
        public static final String GET_MESSAGE_DETAIL = "sdk018";
        public static final String GET_PAY_MONEY = "sdk019";

        public static final String GET_USER_INFO = "sdk020";//获取用户信息
        public static final String GET_RECHARGE_LIST = "sdk021";//充值列表
        public static final String DO_UNBINDING = "sdk022";//解绑手机
//        public static final String DO_UNBINDING = "sdk023";//
        public static final String GET_GIFT_LIST = "sdk024";//获取礼包列表
        public static final String GET_GIFT_DETAIL = "sdk025";//获取礼包详情
        public static final String GET_GIFT_DODE = "sdk026";//获取礼包兑换码
        public static final String GET_SUB_ACCOUNT_LIST = "sdk027";//获取小号列表
        public static final String ADD_SUB_ACCOUNT = "sdk028";//添加小号
    }


}
