package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    :
 * =====================================================
 */

public class GDoBindBank {
    /**
     {
     "bankId":"1",（银行id）
     "account":"15548",（银行账号）
     "accountName":"张三",（银行开户姓名）
     "payPassword":"45684525",（提现密码，加密）
     "code":"154687",（手机验证码）
     }
     */
    /**
     *  {
     "bankId":"1",（银行id）
     "account":"15548",（银行账号）
     "accountName":"张三",（银行开户姓名）
     "payPassword":"45684525",（提现密码，加密）
     "code":"154687",（手机验证码）
     "decipheringType": "0"（设备类型：0安卓  1 IOS）
     "ip": "0.0.0.0"（ip地址）
     "phoneNo": "12345"（要绑定的手机号，如果用户本身已经绑定手机号，则这传空字符串，如果本身没有绑定手机号，则传输入的手机号）
     }
     * */


    private String bankId;
    private String account;
    private String accountName;
    private String payPassword;
    private String code;
    private String decipheringType;
    private String ip;
    private String phoneNo;

    public String getBankId() {
        return bankId;
    }

    public void setBankId(String bankId) {
        this.bankId = bankId;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getPayPassword() {
        return payPassword;
    }

    public void setPayPassword(String payPassword) {
        this.payPassword = payPassword;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDecipheringType() {
        return decipheringType;
    }

    public void setDecipheringType(String decipheringType) {
        this.decipheringType = decipheringType;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }


}
