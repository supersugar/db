package com.uu661.module.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uu661.R;
import com.uu661.module.base.BaseFragment;

import butterknife.ButterKnife;


public class DiamondInfoFragment extends BaseFragment {


    public static DiamondInfoFragment newInstance() {
        DiamondInfoFragment fragment = new DiamondInfoFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.home_diamond_info, null);
        ButterKnife.bind(this, view);
        initTitleBar(view,"U钻详情", true);
        return view;
    }



}
