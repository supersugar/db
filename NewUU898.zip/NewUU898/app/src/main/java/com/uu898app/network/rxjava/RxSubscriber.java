package com.uu898app.network.rxjava;

import com.google.gson.JsonParseException;
import com.uu898app.module.base.BaseFragment;
import com.uu898app.network.Network;
import com.uu898app.util.log.L;

import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import rx.Subscriber;

/**
 * Created by zhangbo on 2016/6/30.
 */
public abstract class RxSubscriber<T> extends Subscriber<T> {

    private BaseFragment mFragment;
    private boolean mShowLoading;

    public RxSubscriber() {
    }

    public RxSubscriber(BaseFragment fragment, boolean showLoading) {
        this.mFragment = fragment;
        this.mShowLoading = showLoading;
    }

    @Override
    public void onStart() {
        super.onStart();
        L.d("onStart()");
        if(null != mFragment && mShowLoading){
            mFragment.showLoadToast();
        }
    }

    @Override
    public void onCompleted() {
        if(null != mFragment){
            mFragment.hideLoadToast();
        }
    }

    @Override
    public void onError(Throwable e) {
        if(null != mFragment){
            mFragment.hideLoadToast();
        }
        e.printStackTrace();
        String error_msg = "";
        if (e instanceof Network.APIException) {
            Network.APIException exception = (Network.APIException) e;
            error_msg = e.getMessage();
        } else if (e instanceof SocketTimeoutException) {
            error_msg = "请求数据超时,请稍后重试";
        } else if (e instanceof ConnectException) {
            error_msg = "网络中断,请检查您的网络状态";
        } else if (e instanceof JsonParseException) {
            error_msg = "数据解析错误";
        } else if (e instanceof UnknownHostException) {
            error_msg = "没有联网~~";
        }else{
            L.e(e.getMessage());
        }
        _onError(error_msg);
    }

    @Override
    public void onNext(T t) {
        if(null != mFragment){
            mFragment.hideLoadToast();
        }
        _onNext(t);
    }

    public abstract void _onNext(T t);

    public abstract void _onError(String msg);
}
