package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    :
 * =====================================================
 */

public class GDoChangeWithdrawPassword {
    /**
     * {
     "payPassword":"45684525",（提现密码，加密）
     }
     */

    private String payPassword;

    public String getPayPassword() {
        return payPassword;
    }

    public void setPayPassword(String payPassword) {
        this.payPassword = payPassword;
    }
}
