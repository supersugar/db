package com.uu393.market.module.center;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.R;
import com.uu393.market.model.response.BCouponTicket;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.view.loadtoast.LoadToast;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;

import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

public class CouponTicketActivity extends BaseActivity implements View.OnClickListener {

    private ImageButton mTitleBarLeft;
    private ToggleButton mTitleBarRight;
    private TextView mTitleBarTitle;
    private PullLoadMoreRecyclerView mRecyclerViewCouponTicket;
    private View mNoResultView;
    private Button mBtnNoResult;
    private CouponTicketRecyclerViewAdapter mTicketAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coupon_ticket);
        mTitleBarLeft = (ImageButton) findViewById(R.id.title_bar_left);
        mTitleBarRight = (ToggleButton) findViewById(R.id.title_bar_right);
        mTitleBarTitle = (TextView) findViewById(R.id.title_bar_title);
        mRecyclerViewCouponTicket = (PullLoadMoreRecyclerView) findViewById(R.id.recycler_view_coupon_ticket);
        mNoResultView = findViewById(R.id.no_result_view);
        mBtnNoResult = (Button) findViewById(R.id.bt_no_result);
        initTitleBar();
        initRecyclerView();
        mBtnNoResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doGetCouponTicketList();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        doGetCouponTicketList();
    }

    private void initRecyclerView() {
        mRecyclerViewCouponTicket.setPullRefreshEnable(true);
        mRecyclerViewCouponTicket.setPushRefreshEnable(false);
        mRecyclerViewCouponTicket.setLinearLayout();
        mTicketAdapter = new CouponTicketRecyclerViewAdapter(CouponTicketActivity.this);
        mRecyclerViewCouponTicket.setAdapter(mTicketAdapter);
        mRecyclerViewCouponTicket.setOnPullLoadMoreListener(new PullLoadMoreRecyclerView.PullLoadMoreListener() {
            @Override
            public void onRefresh() {
                doGetCouponTicketList();
            }

            @Override
            public void onLoadMore() {

            }
        });
    }

    private void initTitleBar() {
        mTitleBarLeft.setOnClickListener(this);
        mTitleBarRight.setVisibility(View.GONE);
        mTitleBarTitle.setText("我的优惠券");
    }

    private void showResult(boolean hasResult) {
        if (hasResult) {
            mRecyclerViewCouponTicket.setVisibility(View.VISIBLE);
            mNoResultView.setVisibility(View.GONE);
        } else {
            mRecyclerViewCouponTicket.setVisibility(View.GONE);
            mNoResultView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onClick(View v) {
        super.onBackPressedSupport();
    }

    private void doGetCouponTicketList() {
        showLoadToast(CouponTicketActivity.this);
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetCouponTicketList(new JsonCallback<List<BCouponTicket>>() {
            @Override
            public void onSuccess(List<BCouponTicket> tickets, Call call, Response response) {
                hideLoadToast();
                if (tickets != null && !tickets.isEmpty()) {
                    mRecyclerViewCouponTicket.setPullLoadMoreCompleted();
                    mTicketAdapter.refresh(tickets);
                    showResult(true);
                } else {
                    mRecyclerViewCouponTicket.setPullLoadMoreCompleted();
                    showResult(false);
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
                mRecyclerViewCouponTicket.setPullLoadMoreCompleted();
                showResult(false);
            }
        });

    }
}
