package com.uu898.gamesdk.model.request;

import com.uu898.gamesdk.model.GBaseModel;

/**
 * Created by zhangbo on 2016/6/15.
 */
public class GPay extends GBaseModel {

    public static final String PAY_TYPE_ZFB = "13";
    public static final String PAY_TYPE_WX = "14";

    private String cpOrderNo;//cp订单号
    private String Title;//商品标题
    private String Price;//单个商品价格（分）
    private String PayType;//支付类型，13：支付宝，14：微信
    private String IP;//Ip地址
    private String Number;//数量
    private String OriginalPrice;//单个商品原价(分)
    private String Describe;//商品描述
    private String ProductID;//商品编号
    private String Reserved;//这是订单保留字段, 100个字符

    public String getCpOrderNo() {
        return cpOrderNo;
    }

    public void setCpOrderNo(String cpOrderNo) {
        this.cpOrderNo = cpOrderNo;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }

    public String getPayType() {
        return PayType;
    }

    public void setPayType(String payType) {
        PayType = payType;
    }

    public String getIP() {
        return IP;
    }

    public void setIP(String IP) {
        this.IP = IP;
    }

    public String getNumber() {
        return Number;
    }

    public void setNumber(String number) {
        Number = number;
    }

    public String getOriginalPrice() {
        return OriginalPrice;
    }

    public void setOriginalPrice(String originalPrice) {
        OriginalPrice = originalPrice;
    }

    public String getDescribe() {
        return Describe;
    }

    public void setDescribe(String describe) {
        Describe = describe;
    }

    public String getProductID() {
        return ProductID;
    }

    public void setProductID(String productID) {
        ProductID = productID;
    }

    public String getReserved() {
        return Reserved;
    }

    public void setReserved(String reserved) {
        Reserved = reserved;
    }
}
