package com.uu661.module.home;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afollestad.materialdialogs.MaterialDialog;
import com.ms.square.android.expandabletextview.ExpandableTextView;
import com.uu661.R;
import com.uu661.model.response.BBuyRecord;
import com.uu661.model.response.BDiamondCodeList;
import com.uu661.util.NoDoubleClickUtils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by bo on 16/11/4.
 */

public class DiamondBuyRecordAdapter extends RecyclerView.Adapter<DiamondBuyRecordAdapter.MyHolder> {


    private Activity mActivity;
    private List<BBuyRecord> data = new ArrayList<>();

    public DiamondBuyRecordAdapter(Activity context) {
        this.mActivity = context;
    }

    public void updateData(List<BBuyRecord> data) {
        this.data = data;
        notifyDataSetChanged();
    }

    @Override
    public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_home_diamond_buy_record, parent, false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(MyHolder holder, int position) {
        BBuyRecord gameModel = data.get(position);
        holder.bindItem(gameModel);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        @BindView(R.id.item_tv_one) TextView mItemTvOne;
        @BindView(R.id.item_tv_two) TextView mItemTvTwo;
        @BindView(R.id.item_tv_three) TextView mItemTvThree;
        @BindView(R.id.item_tv_four) TextView mItemTvFour;
        @BindView(R.id.item_parent) RelativeLayout mItemParent;

        private BBuyRecord mModel;

        public MyHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);//用butterKnife绑定
        }


        void bindItem(BBuyRecord model) {
            this.mModel = model;
            mItemTvOne.setText(model.getUu898UserId());
            mItemTvTwo.setText("(" + model.getCity() + " IP : " + model.getIP() + ")");
            mItemTvThree.setText(Html.fromHtml("参与了" + "<font color='#fc5669'>" + model.getBuyNum() + "</font>人次"));
            mItemTvFour.setText(model.getAddTime());

            mItemParent.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            if (NoDoubleClickUtils.isDoubleClick()) {
                return;
            }
            switch (v.getId()) {
                case R.id.item_parent:
                    if(null != onViewClickListener){
                        onViewClickListener.onItemClick(mModel);
                    }
                    break;
            }
        }
    }

    public void showCustomView(BDiamondCodeList model) {
        MaterialDialog dialog = new MaterialDialog.Builder(mActivity)
                .customView(R.layout.dialog_diamond_code_list, true)
                .build();

        ImageView close = (ImageView) dialog.getCustomView().findViewById(R.id.img_close);
        ExpandableTextView expTv  = (ExpandableTextView) dialog.getCustomView().findViewById(R.id.expand_tv);
        TextView onlyOneTv  = (TextView) dialog.getCustomView().findViewById(R.id.only_one_tv);

        if(model.killCodeCount == 1){
            expTv.setVisibility(View.GONE);
            onlyOneTv.setVisibility(View.VISIBLE);
            onlyOneTv.setText(model.killCodeList);
        }else{
            expTv.setVisibility(View.VISIBLE);
            onlyOneTv.setVisibility(View.GONE);
            String temp = model.killCodeList.replace(",", "   ");
            expTv.setText(temp);
        }

        dialog.show();
    }

    public interface OnViewClickListener{

        void onItemClick(BBuyRecord model);
    }

    private OnViewClickListener onViewClickListener;

    public OnViewClickListener getOnViewClickListener() {
        return onViewClickListener;
    }

    public void setOnViewClickListener(OnViewClickListener onViewClickListener) {
        this.onViewClickListener = onViewClickListener;
    }

}
