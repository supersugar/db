package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * Created by Administrator on 2017/4/18.
 */

public class BServerDay implements Serializable {

    private String day;

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }
}
