package com.uu393.market.module.search;

import android.Manifest;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.uu393.market.R;
import com.uu393.market.model.PageModel;
import com.uu393.market.model.request.GGetServerListByGameName;
import com.uu393.market.model.request.GGetServerListByTime;
import com.uu393.market.model.response.BServerListByGameName;
import com.uu393.market.model.response.BServerListByTime;
import com.uu393.market.module.MainActivity;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.bt.BTGameActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.DateUtils;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;

import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.finalteam.toolsfinal.DeviceUtils;
import okhttp3.Call;
import okhttp3.Response;
import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.EasyPermissions;

import static com.uu393.market.util.DateUtils.DATE_SMALL_STR;


public class SearchOpenServiceActivity extends BaseActivity implements EasyPermissions.PermissionCallbacks {

    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.et_service_search_content)
    EditText mEtServiceSearchContent;
    @Bind(R.id.iv_service_search_button)
    ImageView mIvServiceSearchButton;
    @Bind(R.id.layout_service_search)
    RelativeLayout mLayoutServiceSearch;
    @Bind(R.id.rv_service_no_search)
    PullLoadMoreRecyclerView mRvServiceNoSearch;
    @Bind(R.id.iv_service_no_search_foreshow)
    ImageView mIvServiceNoSearchForeshow;
    @Bind(R.id.tv_service_search_result_key_hint)
    TextView mTvServiceSearchResultKeyHint;
    @Bind(R.id.tv_service_search_result_key)
    TextView mTvServiceSearchResultKey;
    @Bind(R.id.layout_key)
    RelativeLayout mLayoutKey;
    @Bind(R.id.rv_service_search_result)
    PullLoadMoreRecyclerView mRvServiceSearchResult;
    @Bind(R.id.layout_service_search_result)
    RelativeLayout mLayoutServiceSearchResult;
    @Bind(R.id.edit_text_clear)
    ImageView mEditTextClear;
    @Bind(R.id.search_no_result_view)
    LinearLayout searchNoResultView;

    private RelativeLayout mLayoutServiceNoSearch;

    private int whatDay = 1;

    private  String mNowDayTime;
    private  String mNextDayTime;
    private  String mNextTwoDayTime;

    private String mChangeBeginTime;
    private String mChangeEndTime;

    String name;


    SearchOpenServiceNormalAdapter adapter;
    List<BServerListByTime> mSByTimeList;
    List<BServerListByTime> mSByTimeList2;
    Map<String, List<BServerListByTime>> map = new HashMap<>();


    List<BServerListByGameName> listBServerListByGameName = new ArrayList<>();
    SearchSomeOneOpenServiceAdapter mSearchSomeByNameListAdapter;

    private int mPageIndex = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_open_service);
        ButterKnife.bind(this);

        mLayoutServiceNoSearch = (RelativeLayout) findViewById(R.id.layout_service_no_search);

        mSByTimeList = new ArrayList<>();
        mSByTimeList2 = new ArrayList<>();

        mRvServiceNoSearch.setLinearLayout();
        mRvServiceNoSearch.setRefreshing(true);
        adapter = new SearchOpenServiceNormalAdapter(this);

        mRvServiceSearchResult.setPushRefreshEnable(false);
        mRvServiceSearchResult.setPullRefreshEnable(false);
        mRvServiceSearchResult.setLinearLayout();
        mRvServiceSearchResult.setRefreshing(false);
        mSearchSomeByNameListAdapter = new SearchSomeOneOpenServiceAdapter(this);
        mRvServiceSearchResult.setAdapter(mSearchSomeByNameListAdapter);
        mRvServiceNoSearch.setAdapter(adapter);


//        mNowDayTime = DateUtils.getNowTime(DATE_SMALL_STR);
//        mNextDayTime = DateUtils.getNextDay(DATE_SMALL_STR);
//        mNextTwoDayTime = DateUtils.getNextTwoDay(DATE_SMALL_STR);

        mNowDayTime = "2017-06-15";
        mNextDayTime = "2017-06-16";
        mNextTwoDayTime = "2017-06-17";

        mChangeBeginTime = mNowDayTime;
        mChangeEndTime = mNextDayTime;

        doGetGamesByTime(false, mChangeBeginTime,mChangeEndTime);
        mRvServiceNoSearch.setOnPullLoadMoreListener(new PullLoadMoreRecyclerView.PullLoadMoreListener() {
            @Override
            public void onRefresh() {
                doGetGamesByTime(false,mChangeBeginTime,mChangeEndTime);
            }

            @Override
            public void onLoadMore() {
                doGetGamesByTime(true,mChangeBeginTime,mChangeEndTime);
            }
        });


        mEtServiceSearchContent.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (StringUtils.isEmpty(s.toString())) {
                    mEditTextClear.setVisibility(View.GONE);
                    //隐藏输入法
                    DeviceUtils.hideInputSoftFromWindowMethod(SearchOpenServiceActivity.this, mEtServiceSearchContent);
                } else {
                    mEditTextClear.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        EB.register(this);
        adapter.refreshView();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EB.unregister(this);
    }

    private void doGetGamesByTime(final boolean loadMore, String mBeginTime, String mEndTime) {

        GGetServerListByTime model = new GGetServerListByTime();
        model.setBeginTime(mBeginTime);
        model.setEndTime(mEndTime);

        if(loadMore == false){
            showLoadToast(SearchOpenServiceActivity.this);
        }
        searchNoResultView.setVisibility(View.GONE);

        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetServerListByTime(model,new JsonCallback<List<BServerListByTime>>() {
            @Override
            public void onSuccess(List<BServerListByTime> mBServerListByTime, Call call, Response response) {

                if (mBServerListByTime != null&& !mBServerListByTime.isEmpty() ){
                    mSByTimeList.clear();
                    mSByTimeList.addAll(mBServerListByTime);
                }else{
                    ToastUtil.showToast(SearchOpenServiceActivity.this,"没有数据");
                }
            }

            @Override
            public void onAfter(List<BServerListByTime> bServerListByTimes, Exception e) {
                super.onAfter(bServerListByTimes, e);
                mRvServiceNoSearch.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        adapter.refresh(mSByTimeList,whatDay);
                        mRvServiceNoSearch.setPullLoadMoreCompleted();
                    }
                }, 100);
                hideLoadToast();
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
            }
        });

    }


    public void doGetServerListByGameName(final String name) {
        mTvServiceSearchResultKey.setText(name);
        mLayoutServiceNoSearch.setVisibility(View.GONE);
        showLoadToast(SearchOpenServiceActivity.this);
        GGetServerListByGameName gGetServerListByGameName = new GGetServerListByGameName();
        gGetServerListByGameName.setGameName(name);
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetServerListByGameName(gGetServerListByGameName, new JsonCallback<List<BServerListByGameName>>() {
            @Override
            public void onSuccess(List<BServerListByGameName> bServerListByGameNames, Call call, Response response) {

                if (bServerListByGameNames != null && !bServerListByGameNames.isEmpty()){
                    listBServerListByGameName.clear();
                    listBServerListByGameName.addAll(bServerListByGameNames);
                    mSearchSomeByNameListAdapter.refresh(listBServerListByGameName);
                    mRvServiceSearchResult.setAdapter(mSearchSomeByNameListAdapter);
                    mLayoutServiceNoSearch.setVisibility(View.GONE);
                    searchNoResultView.setVisibility(View.GONE);
                    if (listBServerListByGameName != null && !listBServerListByGameName.isEmpty()) {
                        mLayoutServiceSearchResult.setVisibility(View.VISIBLE);
                    }
                }
                hideLoadToast();
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
            }
        });


    }



    @OnClick({R.id.title_bar_left, R.id.iv_service_search_button, R.id.iv_service_no_search_foreshow, R.id.edit_text_clear})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                super.onBackPressedSupport();
                break;
            case R.id.iv_service_search_button:
                //搜索
                 name = mEtServiceSearchContent.getText().toString();
                if (name.isEmpty()) {
                    Toast.makeText(this, "请输入您要搜索的游戏名称！", Toast.LENGTH_SHORT).show();
                    return;
                }
                searchNoResultView.setVisibility(View.VISIBLE);
                doGetServerListByGameName(name);
                break;
            case R.id.iv_service_no_search_foreshow:
                //明日预告
                if (whatDay == 1) {
                    mChangeBeginTime = mNextDayTime;
                    mChangeEndTime = mNextTwoDayTime;
                    mIvServiceNoSearchForeshow.setImageResource(R.drawable.jrkf);
                    doGetGamesByTime(false,mChangeBeginTime,mChangeEndTime);

                    whatDay = 2;
                } else if (whatDay == 2) {
                    mIvServiceNoSearchForeshow.setImageResource(R.drawable.ic_foreshow);
                    mChangeBeginTime = mNowDayTime;
                    mChangeEndTime = mNextDayTime;
                    doGetGamesByTime(false,mChangeBeginTime,mChangeEndTime);
                    whatDay = 1;
                }

                break;
            case R.id.edit_text_clear:
                //清理搜索框文字
                mEtServiceSearchContent.setText("");
                listBServerListByGameName.clear();
                DeviceUtils.hideInputSoftFromWindowMethod(this, mEtServiceSearchContent);
                mLayoutServiceNoSearch.setVisibility(View.VISIBLE);
                mLayoutServiceSearchResult.setVisibility(View.GONE);
                searchNoResultView.setVisibility(View.GONE);

                if (whatDay == 1) {
                    mChangeBeginTime = mNowDayTime;
                    mChangeEndTime = mNextDayTime;
                    mIvServiceNoSearchForeshow.setImageResource(R.drawable.ic_foreshow);
                    doGetGamesByTime(false,mChangeBeginTime,mChangeEndTime);
                } else if (whatDay == 2) {
                    mChangeBeginTime = mNextDayTime;
                    mChangeEndTime = mNextTwoDayTime;
                    mIvServiceNoSearchForeshow.setImageResource(R.drawable.jrkf);
                    doGetGamesByTime(false,mChangeBeginTime,mChangeEndTime);
                }
                mIvServiceNoSearchForeshow.setVisibility(View.VISIBLE);
                break;

        }
    }

    @AfterPermissionGranted(100)
    private void requestPermissions() {
        String[] mPermissionList = new String[]{
                //                Manifest.permission.ACCESS_FINE_LOCATION,       //位置信息
                //                Manifest.permission.CALL_PHONE,                 //电话相关
                //                Manifest.permission.READ_LOGS,
                //                Manifest.permission.READ_PHONE_STATE,           //电话相关
                //                Manifest.permission.GET_ACCOUNTS,//联系人,通讯录
                //                Manifest.permission.SET_DEBUG_APP,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,};
        if (!EasyPermissions.hasPermissions(SearchOpenServiceActivity.this, mPermissionList)) {
            EasyPermissions.requestPermissions(SearchOpenServiceActivity.this,
                    "应用下载时需要保存到本地，为了保证核心功能的稳定性，请您同意授权权限", 100, mPermissionList);
        }

    }

    @Override
    public void onPermissionsGranted(int requestCode, List<String> perms) {
        //同意授权

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    @Override
    public void onPermissionsDenied(int requestCode, List<String> perms) {
        //取消授权时
    }

    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.REQUEST_SD_CARD_SEARCH_OPEN_SERVICE://点击下载时申请sd卡权限
                requestPermissions();
                break;
        }
    }


}
