package com.uu393.market.module.manager;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.uu393.market.module.base.BaseViewPagerFragment;
import com.uu393.market.util.log.L;

public class TempTextFragment extends BaseViewPagerFragment {

    String content = "";
    public static TempTextFragment newInstance(String content) {
        TempTextFragment fragment = new TempTextFragment();
        Bundle args = new Bundle();
        args.putString("content", content);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        content = getArguments().getString("content");
        TextView tv = new TextView(_mActivity);
        tv.setText(content);
        L.d("onCreateView " + this);
        return tv;
    }

//    @Override
//    public void onResume() {
//        super.onResume();
//        L.d("onResume " + this);
//    }
//
//    @Override
//    public void onHiddenChanged(boolean hidden) {
//        super.onHiddenChanged(hidden);
//        L.d("onHiddenChanged" + hidden + this);
//    }

    @Override
    public void refresh() {
        L.d("refresh()" + this);
    }
}
