package com.uu661.module.home;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afollestad.materialdialogs.MaterialDialog;
import com.bumptech.glide.Glide;
import com.flipboard.bottomsheet.BottomSheetLayout;
import com.lcodecore.tkrefreshlayout.RefreshListenerAdapter;
import com.lcodecore.tkrefreshlayout.TwinklingRefreshLayout;
import com.ms.square.android.expandabletextview.ExpandableTextView;
import com.uu661.R;
import com.uu661.core.AccountManager;
import com.uu661.model.PageModel;
import com.uu661.model.request.GGetDiamondCodeList;
import com.uu661.model.request.GGetDiamondInfo;
import com.uu661.model.response.BBuyRecord;
import com.uu661.model.response.BDiamondCodeList;
import com.uu661.model.response.BDiamondInfo;
import com.uu661.model.response.BLuckyManDetail;
import com.uu661.module.ChooseNumView;
import com.uu661.module.account.LoginActivity;
import com.uu661.module.base.BaseFragment;
import com.uu661.module.common.CalculateFragment;
import com.uu661.network.JsonCallback;
import com.uu661.network.TaskEngine;
import com.uu661.util.NoDoubleClickUtils;
import com.uu661.util.log.L;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.iwgang.countdownview.CountdownView;
import ezy.ui.layout.LoadingLayout;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 钻石列表界面
 */
public class DiamondDetailFragment extends BaseFragment {

    @BindView(R.id.info_img) ImageView mInfoImg;
    @BindView(R.id.info_tv_title) TextView mInfoTvTitle;
    @BindView(R.id.info_view_lucky) RelativeLayout mInfoViewLucky;
    @BindView(R.id.info_view_my_ma) RelativeLayout mInfoViewMyMa;
    @BindView(R.id.info_go_login) TextView mInfoGoLogin;
    @BindView(R.id.info_view_need_login) RelativeLayout mInfoViewNeedLogin;
    @BindView(R.id.info_view_my_no_ma) RelativeLayout mInfoViewMyNoMa;
    @BindView(R.id.info_bt_see_detail) RelativeLayout mInfoBtSeeDetail;
    @BindView(R.id.info_bt_see_last) RelativeLayout mInfoBtSeeLast;
    @BindView(R.id.join_recycler_view) RecyclerView mJoinRecyclerView;
    @BindView(R.id.join_recycler_view_footer) View mJoinRecyclerViewFooter;
    @BindView(R.id.info_bottom_bt_go_new) Button mInfoBottomBtGoNew;
    @BindView(R.id.info_bottom_view_can_not_buy) RelativeLayout mInfoBottomViewCanNotBuy;
    @BindView(R.id.info_bottom_bt_buy) Button mInfoBottomBtBuy;
    @BindView(R.id.info_bottom_view_can_buy) RelativeLayout mInfoBottomViewCanBuy;
    @BindView(R.id.title_bar_left) ImageButton mTitleBarLeft;
    @BindView(R.id.title_bar_right) Button mTitleBarRight;
    @BindView(R.id.title_bar_title) TextView mTitleBarTitle;
    @BindView(R.id.title_bar) RelativeLayout mTitleBar;
    @BindView(R.id.info_tv_period_no) TextView mInfoTvPeriodNo;
    @BindView(R.id.info_progress_bar) ProgressBar mInfoProgressBar;
    @BindView(R.id.info_tv_total) TextView mInfoTvTotal;
    @BindView(R.id.info_tv_left) TextView mInfoTvLeft;
    @BindView(R.id.info_view_center_can_buy) LinearLayout mInfoViewCenterCanBuy;
    @BindView(R.id.info_view_center_count_down) RelativeLayout mInfoViewCenterCountDown;
    @BindView(R.id.refreshLayout) TwinklingRefreshLayout mRefreshLayout;
    @BindView(R.id.nested_scroll_view) NestedScrollView mNestedScrollView;
    @BindView(R.id.info_count_down_view) CountdownView mInfoCountDownView;
    @BindView(R.id.info_view_center_count_down_jsz) TextView mInfoViewCenterCountDownJsz;
    @BindView(R.id.info_view_center_count_down_djs) LinearLayout mInfoViewCenterCountDownDjs;
    @BindView(R.id.info_center_bt_count_down) Button mInfoCenterBtCountDown;
    @BindView(R.id.info_view_center_count_down_period_no) TextView mInfoViewCenterCountDownPeriodNo;

    @BindView(R.id.info_view_lucky_tv_one) TextView mInfoViewLuckyTvOne;
    @BindView(R.id.info_view_lucky_tv_two) TextView mInfoViewLuckyTvTwo;
    @BindView(R.id.info_view_lucky_tv_three) TextView mInfoViewLuckyTvThree;
    @BindView(R.id.info_view_lucky_tv_four) TextView mInfoViewLuckyTvFour;
    @BindView(R.id.info_view_lucky_tv_lucky_no) TextView mInfoViewLuckyTvLuckyNo;

    @BindView(R.id.info_view_lucky_expand_tv) ExpandableTextView mInfoViewLuckyExpandTv;
    @BindView(R.id.info_bottom_sheet) BottomSheetLayout mInfoBottomSheet;
    @BindView(R.id.info_view_my_ma_expandable_tv) ExpandableTextView mInfoViewMyMaExpandableTv;
    @BindView(R.id.info_view_lucky_bt_jsxq) Button mInfoViewLuckyBtJsxq;
    @BindView(R.id.expandable_text) TextView mExpandableText;
    @BindView(R.id.expand_collapse) ImageButton mExpandCollapse;

    @BindView(R.id.lv1_loading) LinearLayout mLv1Loading;
    @BindView(R.id.retry_button) TextView mRetryButton;
    @BindView(R.id.lv1_error) LinearLayout mLv1Error;


    private int mCommodityId;//
    private int mPeriodNo;//

    private BDiamondInfo mDiamondInfo;
    private LoadingLayout vLoading;
    private DiamondBuyRecordAdapter mAdapter;
    private ChooseNumView mChooseNumView;


    public static DiamondDetailFragment newInstance(int commodityId, int periodNo) {
        DiamondDetailFragment fragment = new DiamondDetailFragment();
        Bundle args = new Bundle();
        args.putInt("commodityId", commodityId);
        args.putInt("periodNo", periodNo);
        fragment.setArguments(args);

        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mCommodityId = getArguments().getInt("commodityId");
        mPeriodNo = getArguments().getInt("periodNo");
        View view = inflater.inflate(R.layout.home_diamond_detail, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initRefreshLayout();
        initRecycleView();
        initChooseNumView();
        showStatusView(0);
    }

    @Override
    public void onSupportVisible() {
        super.onSupportVisible();
        L.d("onSupportVisible()");
        doGetDiamondInfo(false, false);
        AccountManager.getInstance().whetherShowAfterLoginCouponDialog(_mActivity);
    }

    /**
     * 展示状态view
     * 0  loading
     * 1  success
     * 2  error
     */
    private void showStatusView(int status) {
        if (null == mLv1Loading || null == mInfoBottomSheet || null == mLv1Error) {
            return;
        }
        switch (status) {
            case 0:
                mLv1Loading.setVisibility(View.VISIBLE);
                mInfoBottomSheet.setVisibility(View.GONE);
                mLv1Error.setVisibility(View.GONE);
                break;
            case 1:
                mLv1Loading.setVisibility(View.GONE);
                mInfoBottomSheet.setVisibility(View.VISIBLE);
                mLv1Error.setVisibility(View.GONE);
                break;
            case 2:
                mLv1Loading.setVisibility(View.GONE);
                mInfoBottomSheet.setVisibility(View.GONE);
                mLv1Error.setVisibility(View.VISIBLE);
                break;
        }
    }


    private void initRefreshLayout() {
        //以下代码是使用黑色转圈Loading
        //        ProgressLayout headerView = new ProgressLayout(_mActivity);
        //        mRefreshLayout.setHeaderView(headerView);
        mRefreshLayout.setEnableLoadmore(true);
        mRefreshLayout.setEnableOverScroll(true);//是否允许越界回弹
        mRefreshLayout.setAutoLoadMore(true);
        mRefreshLayout.setOverScrollRefreshShow(false);

        mRefreshLayout.setOnRefreshListener(new RefreshListenerAdapter() {
            @Override
            public void onRefresh(final TwinklingRefreshLayout refreshLayout) {
                doGetDiamondInfo(false, false);
            }

            @Override
            public void onLoadMore(TwinklingRefreshLayout refreshLayout) {
                super.onLoadMore(refreshLayout);
                doGetDiamondBuyRecord();
            }
        });
    }

    private void initRecycleView() {
        //参与记录recycleView
        LinearLayoutManager manager = new LinearLayoutManager(_mActivity);
        mJoinRecyclerView.setLayoutManager(manager);
        mAdapter = new DiamondBuyRecordAdapter(_mActivity);
        mJoinRecyclerView.setAdapter(mAdapter);
        mAdapter.setOnViewClickListener(new DiamondBuyRecordAdapter.OnViewClickListener() {
            @Override
            public void onItemClick(BBuyRecord record) {
                GGetDiamondCodeList model = new GGetDiamondCodeList();
                model.commodityId = record.getCommodityId();
                model.killOrderNo = record.getKillOrderNo();
                model.userId = record.getUserId();
                model.periodNo = record.getPeriodNo();
                TaskEngine.getInstance().doGetDiamondCodeList(model, new JsonCallback<BDiamondCodeList>() {
                    @Override
                    public void onSuccess(BDiamondCodeList result, Call call, Response response) {
                        if(!isResumed()){
                            return;
                        }
                        MaterialDialog dialog = new MaterialDialog.Builder(_mActivity)
                                .customView(R.layout.dialog_diamond_code_list, true)
                                .build();

                        ImageView close = (ImageView) dialog.getCustomView().findViewById(R.id.img_close);
                        ExpandableTextView expTv  = (ExpandableTextView) dialog.getCustomView().findViewById(R.id.expand_tv);
                        TextView onlyOneTv  = (TextView) dialog.getCustomView().findViewById(R.id.only_one_tv);

                        if(result.killCodeCount == 1){
                            expTv.setVisibility(View.GONE);
                            onlyOneTv.setVisibility(View.VISIBLE);
                            onlyOneTv.setText(result.killCodeList);
                        }else{
                            expTv.setVisibility(View.VISIBLE);
                            onlyOneTv.setVisibility(View.GONE);
                            String temp = result.killCodeList.replace(",", "   ");
                            expTv.setText(temp);
                        }

                        dialog.show();
                    }
                });
            }
        });
    }

    private void initChooseNumView() {
        mChooseNumView = new ChooseNumView(_mActivity, mInfoBottomSheet);
        mChooseNumView.setOnChooseDoneListener(new ChooseNumView.OnChooseDoneListener() {
            @Override
            public void onChooseDone(int num) {
                L.d("购买" + num);
            }

            @Override
            public void showOrHideSoftInput(boolean show, View v) {
                if (show && null != v) {
                    showSoftInput(v);
                } else {
                    hideSoftInput();
                }
            }
        });
    }


    private void doGetDiamondInfo(final boolean showBottomBuyView, boolean showLoading) {
        //一下期号是幸运用户夺钻码比较多的一期
        //                mCommodityId = 239;
        //                mPeriodNo = 701040094;
        TaskEngine.getInstance().doGetDiamondInfo(new GGetDiamondInfo(mCommodityId, mPeriodNo), new JsonCallback<BDiamondInfo>
                (showLoading ? this : null) {

            @Override
            public void onSuccess(BDiamondInfo result, Call call, Response response) {
                L.d("isDetached() = " + isDetached());
                L.d("isVisible() = " + isVisible());
                if(!isVisible()){
                    return;
                }
                if(null == result){
                    return;
                }
                showStatusView(1);
                mDiamondInfo = result;
                resetRecordData();
                setContentView();
                doGetDiamondBuyRecord();
                if (showBottomBuyView) {//需要弹出数量选择框
                    //通知MainFragment弹出框
                    mChooseNumView.updateData(result);
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                showStatusView(2);
            }

            @Override
            public void onAfter(BDiamondInfo bDiamondInfo, Exception e) {
                super.onAfter(bDiamondInfo, e);
                L.d("isDetached() = " + isDetached());
                L.d("isVisible() = " + isVisible());
                if(!isVisible()){
                    return;
                }
                if (null != mNestedScrollView) {
                    mNestedScrollView.scrollTo(0, 0);
                }
                //延迟200毫秒结束刷新效果,不然视觉看起来会卡顿,因为延迟结束,所以肯恩fragment结束了,但是还未刷新,这时候可能会有null异常,要判断一下
                mRefreshLayout.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (null != mRefreshLayout) {
                            mRefreshLayout.finishRefreshing();
                        }
                    }
                }, 200);

            }
        });
    }

    private int mCurrentRecordIndex = 1;
    private int mRecordTotalPage = -1;
    private List<BBuyRecord> mRecords = new ArrayList<>();

    private void resetRecordData() {
        mCurrentRecordIndex = 1;
        mRecordTotalPage = -1;
        mRecords.clear();
        mAdapter.updateData(mRecords);
        mRefreshLayout.setAutoLoadMore(true);
        mRefreshLayout.setEnableLoadmore(true);
        mJoinRecyclerViewFooter.setVisibility(View.GONE);
    }

    private void doGetDiamondBuyRecord() {
        PageModel model = new PageModel();
        model.pageIndex = mCurrentRecordIndex;
        model.pageSize = 10;
        TaskEngine.getInstance().doGetDiamondBuyRecord(new GGetDiamondInfo(mDiamondInfo.getCommodityInfo().getId(), mDiamondInfo
                .getCommodityInfo().getPeriodNo()), model, new JsonCallback<List<BBuyRecord>>() {
            @Override
            public void onSuccess(List<BBuyRecord> result, Call call, Response response) {
                L.d("isDetached() = " + isDetached());
                L.d("isVisible() = " + isVisible());
                if(!isVisible()){
                    return;
                }
                if (null != result && !result.isEmpty()) {
                    mCurrentRecordIndex++;//成功且有数据,当前页码+1
                    mRecords.addAll(result);
                    mAdapter.updateData(mRecords);
                }
            }

            @Override
            public void onGetPage(PageModel page) {
                super.onGetPage(page);
                mRecordTotalPage = page.pageCount;
            }

            @Override
            public void onAfter(List<BBuyRecord> bBuyRecords, Exception e) {
                L.d("isDetached() = " + isDetached());
                L.d("isVisible() = " + isVisible());
                if(!isVisible()){
                    return;
                }
                super.onAfter(bBuyRecords, e);
                if (null != mRefreshLayout) {
                    mRefreshLayout.finishLoadmore();
                    if (mRecordTotalPage > 0 && mRecordTotalPage == mCurrentRecordIndex - 1) {
                        mJoinRecyclerViewFooter.setVisibility(View.VISIBLE);
                        mRefreshLayout.setAutoLoadMore(false);
                        mRefreshLayout.setEnableLoadmore(false);
                    }
                }
            }
        });
    }

    private void setContentView() {
        Glide.with(_mActivity).load(mDiamondInfo.getCommodityInfo().getImageUrl()).error(R.drawable.ic_diamond_temp).into(mInfoImg);

        mInfoTvTitle.setText(mDiamondInfo.getCommodityInfo().getTitle());

        mInfoBottomBtBuy.setText("立即" + mDiamondInfo.getCommodityInfo().getUnitPrice() + "元夺钻");
        /**
         * 根据periodStatus判断如何显示界面
         * 1 正在进行中 2 已买满(fulltime有值) 3 已开奖(opentime有值)
         */
        switch (mDiamondInfo.getCommodityInfo().getPeriodStatus()) {
            case 1://正在进行中 info_view_center_can_buy显示
                L.d("periodStatus = 1 mInfoViewCenterCanBuy显示");
                mInfoViewCenterCanBuy.setVisibility(View.VISIBLE);
                mInfoViewCenterCountDown.setVisibility(View.GONE);
                mInfoViewLucky.setVisibility(View.GONE);
                mInfoBottomViewCanBuy.setVisibility(View.VISIBLE);
                mInfoBottomViewCanNotBuy.setVisibility(View.GONE);
                // 显示期号/进度条/总需人次/剩余人次
                setInfoViewCenterCanBuy();
                break;
            case 2://已买满,未开奖,倒计时中
                L.d("periodStatus = 2 mInfoViewCenterCountDown显示");
                mInfoViewCenterCanBuy.setVisibility(View.GONE);
                mInfoViewCenterCountDown.setVisibility(View.VISIBLE);
                mInfoViewLucky.setVisibility(View.GONE);
                mInfoBottomViewCanBuy.setVisibility(View.GONE);
                mInfoBottomViewCanNotBuy.setVisibility(View.VISIBLE);
                // 显示倒计时
                setCountDown();
                break;
            case 3://已开奖,去新的一期吧
                L.d("periodStatus = 3 mInfoViewLucky显示");
                mInfoViewCenterCanBuy.setVisibility(View.GONE);
                mInfoViewCenterCountDown.setVisibility(View.GONE);
                mInfoViewLucky.setVisibility(View.VISIBLE);
                mInfoBottomViewCanBuy.setVisibility(View.GONE);
                mInfoBottomViewCanNotBuy.setVisibility(View.VISIBLE);
                // 显示幸运用户信息
                setLucky();
                break;
            default:
                break;
        }

        /**
         * 根据是否登录判断如何显示界面
         * 登录:隐藏登录按钮/根据有没有码显示码
         * 未登录:有码无码隐藏,显示登录按钮
         */
        if (AccountManager.getInstance().isLogin()) {//已登录,需要判断有码还是无码
            mInfoViewNeedLogin.setVisibility(View.GONE);//隐藏提示登录view
            if (null == mDiamondInfo.getMyCodeList() || mDiamondInfo.getMyCodeList().isEmpty()) {
                mInfoViewMyNoMa.setVisibility(View.VISIBLE);//无码view可见
                mInfoViewMyMa.setVisibility(View.GONE);//有码view隐藏
            } else {
                mInfoViewMyNoMa.setVisibility(View.GONE);//无码view隐藏
                mInfoViewMyMa.setVisibility(View.VISIBLE);//有码view可见
                // 显示登录状态后我的夺钻码
                String temp = mDiamondInfo.getMyCodeList().replace(",", "   ");
                mInfoViewMyMaExpandableTv.setText(temp);

            }
        } else {//未登录
            mInfoViewNeedLogin.setVisibility(View.VISIBLE);
            mInfoViewMyMa.setVisibility(View.GONE);
            mInfoViewMyNoMa.setVisibility(View.GONE);
            mInfoGoLogin.setText(Html.fromHtml("您还未登录，<font color='#0fabff'>请登录 </font>后查看您的夺钻码"));
        }

        /**
         * 根据是否有上一期期号节点判断是否显示查看上期揭晓结果按钮
         */
        if (mDiamondInfo.getBeforePeriodNo() <= 0) {
            mInfoBtSeeLast.setVisibility(View.GONE);
        } else {
            mInfoBtSeeLast.setVisibility(View.VISIBLE);
        }

    }

    /**
     * 显示幸运用户信息
     */
    private void setLucky() {
        BLuckyManDetail model = mDiamondInfo.getWinnerInfo();
        if (null != model) {
            //Html.fromHtml("参与人次" + "<font color='#0fabff'>" + mDiamondInfo.getCommodityInfo().getTotalCount() "</font>")
            mInfoViewLuckyTvOne.setText(Html.fromHtml("恭喜 <font color='#fc5699'>" + model.getUu898UserId() + "</font> 获得了本期奖品"));
            mInfoViewLuckyTvTwo.setText(Html.fromHtml("获奖者本期参与<font color='#fc5699'>" + model.getBuyNum() + "</font>人次夺钻码为："));
            mInfoViewLuckyTvThree.setText(Html.fromHtml("揭晓时间 : <font color='#9b9b9b'>" + mDiamondInfo.getCommodityInfo().getOpenTime() +
                    "</font>"));
            mInfoViewLuckyTvFour.setText(Html.fromHtml("夺钻时间 : <font color='#9b9b9b'>" + model.getKillTime() + "</font>"));
            mInfoViewLuckyTvLuckyNo.setText(String.valueOf(model.getCode()));

            String temp = model.getWinCodeList().replace(",", "   ");
            mInfoViewLuckyExpandTv.setText(temp);
        }
    }

    /**
     * 显示倒计时
     */
    private void setCountDown() {
        //根据倒计时的时间判断显示已揭晓还是未揭晓,未揭晓显示倒计时
        mInfoViewCenterCountDownPeriodNo.setText("期号 : " + mDiamondInfo.getCommodityInfo().getPeriodNo());
        if (mDiamondInfo.getDelay() > 0) {
            mInfoViewCenterCountDownJsz.setVisibility(View.GONE);
            mInfoViewCenterCountDownDjs.setVisibility(View.VISIBLE);
            long time = mDiamondInfo.getDelay() * 1000;
            mInfoCountDownView.start(time);
            delayRequest(time);
        } else {
            mInfoViewCenterCountDownJsz.setVisibility(View.VISIBLE);
            mInfoViewCenterCountDownDjs.setVisibility(View.GONE);
            delayRequest(3000);
        }
    }

    private void delayRequest(long time) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isVisible() || null == mRefreshLayout || null == mInfoViewCenterCountDownJsz || null == mInfoViewCenterCountDownDjs) {
                    L.d("DiamondDetailFragment可能结束掉了,不再请求订单详情");
                    return;//可能页面已经结束掉了
                }
                mInfoViewCenterCountDownJsz.setVisibility(View.VISIBLE);
                mInfoViewCenterCountDownDjs.setVisibility(View.GONE);
                mRefreshLayout.startRefresh();
            }
        }, time);
    }

    /**
     * 显示期号/进度条/总需人次/剩余人次
     */
    private void setInfoViewCenterCanBuy() {
        mInfoTvPeriodNo.setText("期号" + mDiamondInfo.getCommodityInfo().getPeriodNo());
        mInfoTvTotal.setText(Html.fromHtml("总需人次" + "<font color='#0fabff'>" + mDiamondInfo.getCommodityInfo().getTotalCount() +
                "</font>"));
        mInfoTvLeft.setText(Html.fromHtml("剩余人次" + "<font color='#0fabff'>" + mDiamondInfo.getCommodityInfo().getLeftCount() + "</font>"));
        mInfoProgressBar.setMax(mDiamondInfo.getCommodityInfo().getTotalCount());
        mInfoProgressBar.setProgress(mDiamondInfo.getCommodityInfo().getAlreadySold());

        //        ViewAnimator
        //                .animate(mInfoProgressBar)
        ////                .translationX(0f ,1f)
        //                .pivotX(0)
        //                .scaleX(0,1f)
        //                .accelerate()
        //                .duration(500)
        //                .start();
    }

    @OnClick({R.id.info_view_need_login, R.id.info_bt_see_detail, R.id.info_view_lucky_bt_jsxq, R.id.info_bt_see_last, R.id
            .info_bottom_bt_go_new, R.id.info_bottom_bt_buy, R.id.title_bar_left, R.id.retry_button, R.id.info_center_bt_count_down})
    public void onClick(View view) {
        if (NoDoubleClickUtils.isDoubleClick()) {
            return;
        }
        switch (view.getId()) {
            case R.id.info_view_need_login://需要登录
                startActivity(new Intent(_mActivity, LoginActivity.class));
                break;
            case R.id.info_bt_see_detail://查看U钻详情
                start(DiamondInfoFragment.newInstance());
                break;
            case R.id.info_view_lucky_bt_jsxq://幸运用户计算详情
            case R.id.info_center_bt_count_down://倒计时计算详情
                start(CalculateFragment.newInstance(mDiamondInfo.getCommodityInfo().getId(), mDiamondInfo.getCommodityInfo().getPeriodNo
                        ()));
                break;
            case R.id.info_bt_see_last://查看上期
                mCommodityId = mDiamondInfo.getCommodityInfo().getId();
                mPeriodNo = mDiamondInfo.getBeforePeriodNo();
                mRefreshLayout.startRefresh();
                break;
            case R.id.info_bottom_bt_go_new://去最新一期
                Intent intent2 = new Intent(_mActivity, DiamondDetailActivity.class);
                intent2.putExtra(DiamondDetailActivity.INTENT_KEY_COMMODITY_ID, mDiamondInfo.getCommodityInfo().getId());
                intent2.putExtra(DiamondDetailActivity.INTENT_KEY_PERIOD_NO, 0);
                startActivity(intent2);
                break;
            case R.id.info_bottom_bt_buy://买买买
                if (!AccountManager.getInstance().isLogin()) {//未登录
                    startActivity(new Intent(_mActivity, LoginActivity.class));
                    return;
                }
                //购买前要获取当前钻石的最新一期
                mCommodityId = mDiamondInfo.getCommodityInfo().getId();
                mPeriodNo = 0;
                doGetDiamondInfo(true, true);
                break;
            case R.id.title_bar_left://返回
                _mActivity.onBackPressed();
                break;
            case R.id.retry_button://重试
                doGetDiamondInfo(false, true);
                break;
        }
    }
}
