package com.uu393.market.module.base;

import android.app.Activity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

//import com.squareup.leakcanary.RefWatcher;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.view.loadtoast.LoadToast;

import me.yokeyword.fragmentation.SupportFragment;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class BaseFragment extends SupportFragment {

    private LoadToast mLoadToast;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mLoadToast = new LoadToast(_mActivity);
    }

    public View initTitleBar(View v, String title, boolean showBack) {
        TextView tvTitle = (TextView) v.findViewById(R.id.title_bar_title);
        tvTitle.setText(title);
        v.findViewById(R.id.title_bar_left).setVisibility(showBack ? View.VISIBLE : View.GONE);
        v.findViewById(R.id.title_bar_left).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _mActivity.onBackPressed();
            }
        });
        return v.findViewById(R.id.title_bar);
    }

    protected void initToolbarMenu(Toolbar toolbar) {
        toolbar.inflateMenu(R.menu.menu_hierarchy);
        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_hierarchy:
                        _mActivity.showFragmentStackHierarchyView();
                        break;
                }
                return true;
            }
        });
    }

    public void showLoadToast() {
        mLoadToast.show();
    }

    public void hideLoadToast() {
        mLoadToast.success();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
//        RefWatcher refWatcher = App.getRefWatcher(_mActivity);
//        if (refWatcher != null) {
//            refWatcher.watch(this);
//        }
    }
}
