package com.uu661.module.common;

import android.os.Bundle;

import com.uu661.R;
import com.uu661.module.base.BaseSwipeBackActivity;

/**
 * Created by YoKeyword on 16/4/19.
 */
public class WebActivity extends BaseSwipeBackActivity {

    public static final String INTENT_KEY_URL = "intent_key_url";
    public static final String INTENT_KEY_TITLE = "intent_key_title";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String url = getIntent().getStringExtra(INTENT_KEY_URL);
        String title = getIntent().getStringExtra(INTENT_KEY_TITLE);
        if (savedInstanceState == null) {
            loadRootFragment(R.id.fl_container, WebFragment.newInstance(url,title));
        }
    }
}
