package com.uu898.gamesdk.model.request;

import com.uu898.gamesdk.model.GBaseModel;

/**
 * Created by zhangbo on 2016/6/15.
 */
public class GDeleteMessages extends GBaseModel {

    // "ID": "1,2,3,4",（ID列表）
    private String ID;//id列表

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }
}
