package com.uu661.model.response;

import java.io.Serializable;
import java.util.List;

/**
 * 计算详情
 */
public class BCalculate implements Serializable {

    /**
     * {
         "listData": [
                 {
                 "payTime": "2017/2/49: 17: 48",
                 "periodNo": "702040012",
                 "killOrderNo": "1000928831",
                 "buyNum": "1",
                 "commodityId": "231",
                 "userId": "1001815",
                 "title": "100U钻【可兑换全站任意商品】",
                 "name": "1001815",
                 "uu898UserId": "10****15",
                 "nickName": "风亦有情"
                 }
            ],
         "caipiaoList": {
             "caipiaoStr": "00000",
             "caipiaoPeriod": "获取失败",
             "yushuStr": "等待揭晓",
             "luckNumStr": "1",
             "totalSum": "1836572214"
         }
     }
     */

    private CaiPiaoListBean caipiaoList;
    private List<ListDataBean> listData;

    public CaiPiaoListBean getCaiPiaoList() {
        return caipiaoList;
    }

    public void setCaiPiaoList(CaiPiaoListBean caipiaoList) {
        this.caipiaoList = caipiaoList;
    }

    public List<ListDataBean> getListData() {
        return listData;
    }

    public void setListData(List<ListDataBean> listData) {
        this.listData = listData;
    }

    public static class CaiPiaoListBean {
        /**
         * caipiaoStr : 00000
         * caipiaoPeriod : 获取失败
         * yushuStr : 等待揭晓
         * luckNumStr : 1
         * totalSum : 1836572214
         */

        private String caipiaoStr;
        private String caipiaoPeriod;
        private String yushuStr;
        private String luckNumStr;
        private String totalSum;

        public String getCaipiaoStr() {
            return caipiaoStr;
        }

        public void setCaipiaoStr(String caipiaoStr) {
            this.caipiaoStr = caipiaoStr;
        }

        public String getCaipiaoPeriod() {
            return caipiaoPeriod;
        }

        public void setCaipiaoPeriod(String caipiaoPeriod) {
            this.caipiaoPeriod = caipiaoPeriod;
        }

        public String getYushuStr() {
            return yushuStr;
        }

        public void setYushuStr(String yushuStr) {
            this.yushuStr = yushuStr;
        }

        public String getLuckNumStr() {
            return luckNumStr;
        }

        public void setLuckNumStr(String luckNumStr) {
            this.luckNumStr = luckNumStr;
        }

        public String getTotalSum() {
            return totalSum;
        }

        public void setTotalSum(String totalSum) {
            this.totalSum = totalSum;
        }
    }

    public static class ListDataBean {
        /**
         * payTime : 2017/2/49: 17: 48
         * periodNo : 702040012
         * killOrderNo : 1000928831
         * buyNum : 1
         * commodityId : 231
         * userId : 1001815
         * title : 100U钻【可兑换全站任意商品】
         * name : 1001815
         * uu898UserId : 10****15
         * nickName : 风亦有情
         */

        private String payTime;
        private String periodNo;
        private String killOrderNo;
        private int buyNum;
        private int commodityId;
        private String userId;
        private String title;
        private String name;
        private String uu898UserId;
        private String nickName;
        private String timeStr;

        public String getPayTime() {
            return payTime;
        }

        public void setPayTime(String payTime) {
            this.payTime = payTime;
        }

        public String getPeriodNo() {
            return periodNo;
        }

        public void setPeriodNo(String periodNo) {
            this.periodNo = periodNo;
        }

        public String getKillOrderNo() {
            return killOrderNo;
        }

        public void setKillOrderNo(String killOrderNo) {
            this.killOrderNo = killOrderNo;
        }

        public int getBuyNum() {
            return buyNum;
        }

        public void setBuyNum(int buyNum) {
            this.buyNum = buyNum;
        }

        public int getCommodityId() {
            return commodityId;
        }

        public void setCommodityId(int commodityId) {
            this.commodityId = commodityId;
        }

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getUu898UserId() {
            return uu898UserId;
        }

        public void setUu898UserId(String uu898UserId) {
            this.uu898UserId = uu898UserId;
        }

        public String getNickName() {
            return nickName;
        }

        public void setNickName(String nickName) {
            this.nickName = nickName;
        }

        public String getTimeStr() {
            return timeStr;
        }

        public void setTimeStr(String timeStr) {
            this.timeStr = timeStr;
        }
    }
}
