package com.uu661.core;

import android.app.Activity;

import com.orhanobut.hawk.Hawk;
import com.uu661.model.response.BLogin;
import com.uu661.model.response.BUserInfo;
import com.uu661.util.StringUtils;
import com.uu661.util.log.L;

/**
 * Created by zhangbo on 2016/7/1.
 */
public class AccountManager {

    private static final String SP_KEY_LOGIN_INFO = "login_info";
    private static final String SP_KEY_USER_INFO = "user_info";
    private static final String SP_KEY_SHOW_AFTER_LOGIN_COUPON_DIALOG = "show_after_login_coupon_dialog";
    private static final String SP_KEY_IS_SHOW_STATUS_CHANGED = "is_show_status_changed";

    public enum Status {
        LOGIN, LOGOUT
    }

    private final static AccountManager INSTANCE = new AccountManager();

    private Status mStatus = Status.LOGOUT;

    public AccountManager() {
    }

    public static AccountManager getInstance() {
        return INSTANCE;
    }

    /**
     * 判断用户是否为登录状态
     * @return
     */
    public boolean isLogin() {
        if(!StringUtils.isEmpty(getLoginInfo().token)){
            mStatus = Status.LOGIN;
        }else{
            mStatus = Status.LOGOUT;
        }
        return mStatus == Status.LOGIN ? true : false;
    }

    /**
     * 保存登陆成功后信息
     * 登录成功后调用
     * @param login
     */
    public void saveLoginInfo(BLogin login) {
        mStatus = Status.LOGIN;
        Hawk.put(SP_KEY_LOGIN_INFO, login);
        /* 20170324添加
         * 普通账号登陆成功/第三方登陆成功/注册成功/第三方绑定账号成功
         * 需要判断 hbStatus 字段,是否要弹出红包dialog
         * 0:失败;1:成功（成功时给弹窗）;2:已赠送,3:不符合赠送条件;4:此红包已经不发放
         */
        if(login.hbStatus == 1){
            Hawk.put(SP_KEY_SHOW_AFTER_LOGIN_COUPON_DIALOG, true);
            L.d("存入弹出红包开关 true");
        }
    }

    /**
     * 登出
     * 删除token/删除用户信息
     */
    public void logout() {
        mStatus = Status.LOGOUT;
        Hawk.delete(SP_KEY_LOGIN_INFO);
        Hawk.delete(SP_KEY_USER_INFO);
    }

    /**
     * 获取登陆信息
     * @return
     */
    public BLogin getLoginInfo() {
        return  Hawk.get(SP_KEY_LOGIN_INFO, new BLogin());
    }

    /**
     * 判断用户登录完成后是否需要弹出红包的dialog
     * @param activity
     */
    public void whetherShowAfterLoginCouponDialog(Activity activity) {

        BLogin model = null;
        boolean needShow = Hawk.get(SP_KEY_SHOW_AFTER_LOGIN_COUPON_DIALOG, false);
        if(needShow){
            L.d("needShow = " + needShow);
            model = getLoginInfo();
        }
        if(null != model && null!= model.coupon && !model.coupon.isEmpty()){//弹出对话框
            DialogCenter.showLoginCouponPopDialog(activity, model.coupon.get(0));
            Hawk.put(SP_KEY_SHOW_AFTER_LOGIN_COUPON_DIALOG, false);
            L.d("关闭弹出红包开关");
        }
    }


    /**
     * 保存用户信息
     * @param userInfo
     */
    public void saveUserInfo(BUserInfo userInfo) {
        Hawk.put(SP_KEY_USER_INFO, userInfo);
    }

    /**
     * 获取用户信息
     * @return
     */
    public BUserInfo getUserInfo(){
       return Hawk.get(SP_KEY_USER_INFO);
    }

    /**
     * 获取用户信息里showStatus状态值是否发生了改变
     * @return
     */
    public boolean getIsShowStatusChanged(){
        return Hawk.get(SP_KEY_IS_SHOW_STATUS_CHANGED, false);
    }

    /**
     * 设置用户信息showStatus值是否发生了改变
     * @param isChanged
     * @return
     */
    public boolean setIsShowStatusChanged(boolean isChanged){
        return Hawk.put(SP_KEY_IS_SHOW_STATUS_CHANGED, isChanged);
    }

}
