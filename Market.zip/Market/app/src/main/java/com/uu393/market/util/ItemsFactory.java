package com.uu393.market.util;

import com.uu393.market.model.response.BGame;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by bo on 16/12/1.
 */

public class ItemsFactory {

    public static ArrayList<com.uu393.market.model.response.BGame> getSameApps() {
        ArrayList<com.uu393.market.model.response.BGame> apks = new ArrayList<>();
        BGame apkInfo1 = new BGame();
        apkInfo1.setGameName("美丽加");
        apkInfo1.setIcon("http://pic3.apk8.com/small2/14325422596306671.png");
        apkInfo1.setAndroidPackage("http://download.apk8.com/d2/soft/meilijia.apk");
        apks.add(apkInfo1);
        BGame apkInfo2 = new BGame();
        apkInfo2.setGameName("果然方便");
        apkInfo2.setIcon("http://pic3.apk8.com/small2/14313175771828369.png");
        apkInfo2.setAndroidPackage("http://download.apk8.com/d2/soft/guoranfangbian.apk");
        apks.add(apkInfo2);
        BGame apkInfo3 = new BGame();
        apkInfo3.setGameName("薄荷");
        apkInfo3.setIcon("http://pic3.apk8.com/small2/14308183888151824.png");
        apkInfo3.setAndroidPackage("http://download.apk8.com/d2/soft/bohe.apk");
        apks.add(apkInfo3);
        BGame apkInfo4 = new BGame();
        apkInfo4.setGameName("GG助手");
        apkInfo4.setIcon("http://pic3.apk8.com/small2/14302008166714263.png");
        apkInfo4.setAndroidPackage("http://download.apk8.com/d2/soft/GGzhushou.apk");
        apks.add(apkInfo4);
        BGame apkInfo5 = new BGame();
        apkInfo5.setGameName("红包惠锁屏");
        apkInfo5.setIcon("http://pic3.apk8.com/small2/14307106593913848.png");
        apkInfo5.setAndroidPackage("http://download.apk8.com/d2/soft/hongbaohuisuoping.apk");
        apks.add(apkInfo5);
        BGame apkInfo6 = new BGame();
        apkInfo6.setGameName("快的打车");
        apkInfo6.setIcon("http://up.apk8.com/small1/1439955061264.png");
        apkInfo6.setAndroidPackage("http://download.apk8.com/soft/2015/%E5%BF%AB%E7%9A%84%E6%89%93%E8%BD%A6.apk");
        apks.add(apkInfo6);
        BGame apkInfo7 = new BGame();
        apkInfo7.setGameName("叮当快药");
        apkInfo7.setIcon("http://pic3.apk8.com/small2/14315954626414886.png");
        apkInfo7.setAndroidPackage("http://d2.apk8.com:8020/soft/dingdangkuaiyao.apk");
        apks.add(apkInfo7);
        BGame apkInfo8 = new BGame();
        apkInfo8.setGameName("悦跑圈");
        apkInfo8.setIcon("http://pic3.apk8.com/small2/14298490191525146.jpg");
        apkInfo8.setAndroidPackage("http://d2.apk8.com:8020/soft/yuepaoquan.apk");
        apks.add(apkInfo8);
        BGame apkInfo9 = new BGame();
        apkInfo9.setGameName("悠悠导航");
        apkInfo9.setIcon("http://pic3.apk8.com/small2/14152456988840667.png");
        apkInfo9.setAndroidPackage("http://d2.apk8.com:8020/soft/%E6%82%A0%E6%82%A0%E5%AF%BC%E8%88%AA2.3.32.1.apk");
        apks.add(apkInfo9);
        BGame apkInfo10 = new BGame();
        apkInfo10.setGameName("虎牙直播");
        apkInfo10.setIcon("http://up.apk8.com/small1/1439892235841.jpg");
        apkInfo10.setAndroidPackage("http://download.apk8.com/down4/soft/hyzb.apk");
        apks.add(apkInfo10);

        BGame apkInfo11 = new BGame();
        apkInfo11.setGameName("10微信");
        apkInfo11.setIcon("http://image.coolapk.com/apk_logo/2016/0112/12202_1452611297_1315.png");
        apkInfo11.setAndroidPackage("http://42.236.95.14/imtt.dd.qq.com/16891/E2AA12C9F231D40A772D85C55E0E2BBC" +
                ".apk?mkey=5832f39fc23d1a86&f=8d88&c=0&fsname=com.tencent.mm_6.3.31_940.apk&csr=4d5s&p=.apk");
        apks.add(apkInfo11);

        BGame apkInfo12 = new BGame();
        apkInfo12.setGameName("11GooglePlay");
        apkInfo12.setIcon("http://image.coolapk.com/apk_logo/2016/0408/257251_1460047459_672.png");
        apkInfo12.setAndroidPackage("http://42.236.95.16/imtt.dd.qq.com/16891/4E7243574E0232A4251A29D9ECE0353C" +
                ".apk?mkey=5832f31cc23d1a86&f=1d58&c=0&fsname=com.android.vending_7.1.25.I-all[0][PR]137772785_80712500.apk&csr=4d5s&p=" +
                ".apk");
        apks.add(apkInfo12);

        BGame apkInfo13 = new BGame();
        apkInfo13.setGameName("12网易云音乐");
        apkInfo13.setIcon("http://image.coolapk.com/apk_logo/2016/1011/0_1476178706_4511.png.t.png");
        apkInfo13.setAndroidPackage("http://182.118.63.37/imtt.dd.qq.com/16891/F12A6FA96C5339C4A65A03C96D72E070" +
                ".apk?mkey=5832f0edc23d1a86&f=858&c=0&fsname=com.netease.cloudmusic_3.7.4_82.apk&csr=4d5s&p=.apk");
        apks.add(apkInfo13);
        return apks;
    }

    public static List<String> getSameLabels() {
        List<String> mLabels = new ArrayList<String>();
        mLabels.add("倚天屠龙记");
        mLabels.add("新大主宰");
        mLabels.add("逍遥西游");
        mLabels.add("仙逆");
        mLabels.add("无双剑姬");
        mLabels.add("完美世界3D");
        mLabels.add("天子");
        mLabels.add("天天有喜");
        return mLabels;
    }

}
