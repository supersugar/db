package com.uu393.market.module.home;

import android.Manifest;
import android.os.Bundle;
import android.support.annotation.NonNull;

import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.module.MainActivity;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;

import org.greenrobot.eventbus.Subscribe;

import java.util.List;

import me.yokeyword.fragmentation.SwipeBackLayout;
import me.yokeyword.fragmentation.anim.DefaultHorizontalAnimator;
import me.yokeyword.fragmentation.anim.FragmentAnimator;
import me.yokeyword.fragmentation_swipeback.SwipeBackActivity;
import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.EasyPermissions;

/**
 * Created by YoKeyword on 16/4/19.
 */
public class AppDetailActivity extends SwipeBackActivity implements EasyPermissions.PermissionCallbacks {

    public static final String INTENT_KEY_GAME_ID = "intent_key_game_id";
    public static final String INTENT_KEY_GAME_PACKAGENAME= "intent_key_game_packagename";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String gameId = getIntent().getStringExtra(INTENT_KEY_GAME_ID);
        String gamePackageName= getIntent().getStringExtra(INTENT_KEY_GAME_PACKAGENAME);
        String noView =  getIntent().getStringExtra("NoView");

        if (savedInstanceState == null) {
            loadRootFragment(R.id.fl_container, AppGameDetailFragment.newInstance(gameId,gamePackageName,noView));
        }
        getSwipeBackLayout().setEdgeOrientation(SwipeBackLayout.EDGE_LEFT);
    }

    @Override
    public boolean swipeBackPriority() {
        return super.swipeBackPriority();
    }

    public FragmentAnimator onCreateFragmentAnimator() {
        return new DefaultHorizontalAnimator();
    }

    public void onResume() {
        super.onResume();
        EB.register(this);
        MobclickAgent.onResume(this);       //统计时长
    }
    public void onPause() {
        super.onPause();
        MobclickAgent.onPause(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EB.unregister(this);
    }

    @AfterPermissionGranted(100)
    private void requestPermissions() {
        String[] mPermissionList = new String[]{
                //                Manifest.permission.ACCESS_FINE_LOCATION,       //位置信息
                //                Manifest.permission.CALL_PHONE,                 //电话相关
                //                Manifest.permission.READ_LOGS,
                //                Manifest.permission.READ_PHONE_STATE,           //电话相关
                //                Manifest.permission.GET_ACCOUNTS,//联系人,通讯录
                //                Manifest.permission.SET_DEBUG_APP,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,};
        if (!EasyPermissions.hasPermissions(AppDetailActivity.this, mPermissionList)) {
            EasyPermissions.requestPermissions(AppDetailActivity.this,
                    "应用下载时需要保存到本地，为了保证核心功能的稳定性，请您同意授权权限", 100, mPermissionList);
        }

    }

    @Override
    public void onPermissionsGranted(int requestCode, List<String> perms) {
        //同意授权

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    @Override
    public void onPermissionsDenied(int requestCode, List<String> perms) {
        //取消授权时
    }

    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.REQUEST_SD_CARD_APP_DETAIL://点击下载时申请sd卡权限
                requestPermissions();
                break;
        }
    }
}
