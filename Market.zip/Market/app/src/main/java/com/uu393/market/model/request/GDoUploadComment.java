package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/10
 * Descrip    :
 * =====================================================
 */

public class GDoUploadComment {
    /**
     * {
     "comment": "12345",（UUSY中Comment存储的信息）
     }
     */

    private String comment;

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
