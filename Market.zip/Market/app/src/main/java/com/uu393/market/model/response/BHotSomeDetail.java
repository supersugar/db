package com.uu393.market.model.response;

/**
 * Created by Administrator on 2017/4/20.
 */

public class BHotSomeDetail {

    /**
     * "id": "1”,(活动id)
     "title": "最热活动”,(活动标题)
     "addTime": "2017-04-14 00:00:00”,(发布时间)

     */
    private String id;
    private String title;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }

    private String addTime;

}
