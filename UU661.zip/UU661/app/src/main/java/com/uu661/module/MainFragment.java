package com.uu661.module;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.flipboard.bottomsheet.BottomSheetLayout;
import com.uu661.R;
import com.uu661.app.App;
import com.uu661.core.AccountManager;
import com.uu661.model.response.BDiamondInfo;
import com.uu661.model.response.BPaySetting;
import com.uu661.module.account.LoginActivity;
import com.uu661.module.base.BaseFragment;
import com.uu661.module.base.BaseTabLazyFragment;
import com.uu661.module.discovery.DiscoveryFragment;
import com.uu661.module.home.HomeFragment;
import com.uu661.module.my.MyFragment;
import com.uu661.network.JsonCallback;
import com.uu661.network.TaskEngine;
import com.uu661.util.eventbus.BaseEvent;
import com.uu661.util.eventbus.EB;
import com.uu661.util.eventbus.EventObject;
import com.uu661.util.log.L;
import com.uu661.view.bottombar.BottomBar;
import com.uu661.view.bottombar.BottomBarTab;

import org.greenrobot.eventbus.Subscribe;

import butterknife.BindView;
import butterknife.ButterKnife;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Created by bo on 16/11/10.
 */

public class MainFragment extends BaseFragment {

    public static final int FIRST = 0;
    public static final int SECOND = 1;
    public static final int THIRD = 2;
    public static final int FOURTH = 3;

    @BindView(R.id.main_bottom_sheet) BottomSheetLayout mMainBottomSheet;
    @BindView(R.id.bottomBar) BottomBar mBottomBar;

    private BaseTabLazyFragment[] mFragments = new BaseTabLazyFragment[3];

    private ChooseNumView mChooseNumView;

    public static MainFragment newInstance() {
        Bundle args = new Bundle();
        MainFragment fragment = new MainFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.main_fragment, container, false);

        if (savedInstanceState == null) {
            mFragments[FIRST] = HomeFragment.newInstance();
            mFragments[SECOND] = DiscoveryFragment.newInstance();
            mFragments[THIRD] = MyFragment.newInstance();

            loadMultipleRootFragment(R.id.fl_container, FIRST, mFragments[FIRST], mFragments[SECOND], mFragments[THIRD]);
        } else {
            // 这里库已经做了Fragment恢复,所有不需要额外的处理了, 不会出现重叠问题
            // 这里我们需要拿到mFragments的引用,也可以通过getSupportFragmentManager.getFragments()自行进行判断查找(效率更高些),用下面的方法查找更方便些
            mFragments[FIRST] = findChildFragment(HomeFragment.class);
            mFragments[SECOND] = findChildFragment(DiscoveryFragment.class);
            mFragments[THIRD] = findChildFragment(MyFragment.class);
        }
        ButterKnife.bind(this, view);
        initView(view);
        initChooseNumView();
//        getPaySetting();
        return view;
    }

    private void initView(View view) {
        mBottomBar.addItem(new BottomBarTab(_mActivity, R.drawable.ic_tab_home, R.drawable.ic_tab_home_pressed, "夺钻专区")).addItem(new
                BottomBarTab(_mActivity, R.drawable.ic_tab_discovery, R.drawable.ic_tab_discovery_pressed, "发现")).addItem(new
                BottomBarTab(_mActivity, R.drawable.ic_tab_my, R.drawable.ic_tab_my_pressed, "我的"));

        mBottomBar.setOnTabSelectedListener(new BottomBar.OnTabSelectedListener() {

            @Override
            public boolean preSelected(int position) {
                if (position == 2) {
                    if (!AccountManager.getInstance().isLogin()) {//未登录
                        startActivityForResult(new Intent(_mActivity, LoginActivity.class), 1);
                        return false;
                    }
                }
                return true;
            }

            @Override
            public void onTabSelected(int position, int prePosition) {
                L.d("当前位置" + position + " 前一个位置" + prePosition);
                //如果是点击位置2,即"我的",需要先判断登录状态
                showHideFragment(mFragments[position], mFragments[prePosition]);
            }

            @Override
            public void onTabUnselected(int position) {
            }

            @Override
            public void onTabReselected(int position) {
                L.d("onTabReselected" + position);
                BaseTabLazyFragment currentFragment = mFragments[position];
                if (null != currentFragment) {
                    currentFragment.onTabReselected();
                }
            }

        });
    }


    private void initChooseNumView() {
        mChooseNumView = new ChooseNumView(_mActivity, mMainBottomSheet);
        mChooseNumView.setOnChooseDoneListener(new ChooseNumView.OnChooseDoneListener() {
            @Override
            public void onChooseDone(int num) {
                L.d("购买" + num);
            }

            @Override
            public void showOrHideSoftInput(boolean show, View v) {
                if (show && null != v) {
                    showSoftInput(v);
                } else {
                    hideSoftInput();
                }
            }
        });
    }


    public void getPaySetting() {
        TaskEngine.getInstance().doGetPaySetting(new JsonCallback<BPaySetting>() {
            @Override
            public void onSuccess(BPaySetting result, Call call, Response response) {
                App.PAY_SETTING = result.userPayStatus;
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        L.d("onActivityResult requestCode = " + requestCode + " resultCode = " + resultCode);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            mBottomBar.setCurrentItem(2);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        EB.register(this);
        L.d("onResume()");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EB.unregister(this);
    }

    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.GO_HOME://首页点击搜索框,切换底部tab到搜索页
                mBottomBar.setCurrentItem(0);
                break;

            case EB.TAG.SHOW_MAIN_BOTTOM_VIEW://首页钻石列表,点击parent,进入详情
                EventObject eventObject = (EventObject) event;
                final BDiamondInfo info = (BDiamondInfo) eventObject.result;
                mChooseNumView.updateData(info);
                break;
            default:
                break;
        }
    }

}
