package com.uu393.market.module.mygame;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.lzy.okserver.download.DownloadInfo;
import com.lzy.okserver.download.DownloadManager;
import com.lzy.okserver.download.DownloadService;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GGetGameDetail;
import com.uu393.market.model.response.BGame;
import com.uu393.market.module.home.AppDetailActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ApkUtils;
import com.uu393.market.util.DensityUtils;
import com.uu393.market.util.GlideRoundTransform;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.view.progressbutton.SubmitProcessButton;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

public class MyPlayedGameAdapter extends RecyclerView.Adapter<MyPlayedGameAdapter.ApkHolder> {
    private Activity mContext;
    private List<String> mGames = new ArrayList<>();
    private List<BGame> mGameList = new ArrayList<>();

    public MyPlayedGameAdapter(Activity mContext, List<String> mGameIDs){
        this.mContext = mContext;
        this.mGames = mGameIDs;
    }

    public void setData(List<BGame> list){
        this.mGameList = list;
        notifyDataSetChanged();
    }

    @Override
    public ApkHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_mygame_installed, parent, false);
        return new ApkHolder(view);
    }

    @Override
    public void onBindViewHolder(final ApkHolder holder, final int position) {

        holder.bindItem(mGameList.get(position));
    }

    @Override
    public int getItemCount() {
        return mGameList.size();
    }

    public class ApkHolder extends RecyclerView.ViewHolder  {
        private View itemView;
        private BGame gameModel;
        private ImageView icon;
        private ImageButton ib_select;
        private TextView name;
        private TextView discount;
        private TextView size;
        private TextView appMessage;
        private SubmitProcessButton downloadBt;

        public ApkHolder(View view) {
            super(view);
            itemView = view.findViewById(R.id.rl_mygame_installed_parent);
            icon = (ImageView) view.findViewById(R.id.iv_installed_app_icon);
            ib_select = (ImageButton) view.findViewById(R.id.ib_installed_select);
            name = (TextView) view.findViewById(R.id.tv_installed_app_name);
            discount = (TextView) view.findViewById(R.id.tv_installed_app_discount);
            size = (TextView) view.findViewById(R.id.tv_installed_app_kind);
            appMessage = (TextView) view.findViewById(R.id.tv_installed_app_message);
            downloadBt = (SubmitProcessButton) view.findViewById(R.id.spb_installed_bt);

            int defaultAndError = ImageHelper.randomImage();
            icon.setImageResource(defaultAndError);
        }

        public void bindItem(BGame bGame) {
                    ApkHolder.this.gameModel = bGame;
                    if (gameModel!=null){
                        int defaultAndError = ImageHelper.randomImage();
                        Glide.with(App.mContext).load(gameModel.getIcon()).error(defaultAndError).placeholder(defaultAndError).transform(new
                                GlideRoundTransform(App.mContext, 10)).into(icon);
                        name.setText(gameModel.getGameName());
                        if (gameModel.getDiscount().equals("10")) {
                            discount.setVisibility(View.GONE);
                        } else {
                            discount.setVisibility(View.VISIBLE);
                            discount.setText(gameModel.getDiscount() + "折");
                        }
                        size.setText(gameModel.getTypeName()+"/"+gameModel.getSize()+"M");
                        appMessage.setText(gameModel.getGameInfo());
                        if (ApkUtils.hasInstalled(mContext,gameModel.getPackageName())){
                            downloadBt.setProgress("打开");
                            downloadBt.setTextColor(mContext.getResources().getColor(R.color.white));
                            downloadBt.setBackground(mContext.getResources().getDrawable(R.drawable.third_pb_green));
                            //downloadBt.setBackgroundColor(mContext.getResources().getColor(R.color.green));
                        }else {
                            downloadBt.setProgress("安装");
                            downloadBt.setTextColor(mContext.getResources().getColor(R.color.white));
                            downloadBt.setBackground(mContext.getResources().getDrawable(R.drawable.third_pb_complete));
                            //downloadBt.setBackgroundColor(mContext.getResources().getColor(R.color.blue));
                        }

                        downloadBt.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                String text = downloadBt.getText().toString();
                                if (text.equals("打开")) {
                                    //EB.postObject(EB.TAG.CLICK_PLAY,gameModel);
                                    ApkUtils.launchApp(mContext, gameModel.getPackageName());
                                }else if (text.equals("安装")){
                                    DownloadInfo downloadInfo = DownloadService.getDownloadManager().getDownloadInfo(gameModel.getId());
                                    if (downloadInfo!=null){
                                        String targetPath = downloadInfo.getTargetPath();
                                        File temp = new File(targetPath);
                                        if (temp.exists()) {
                                            ApkUtils.install(mContext, temp);
                                            EB.postObject(EB.TAG.CLICK_INSATLL,gameModel);
                                        } else {
                                            DownloadManager.getInstance().removeTask(gameModel.getId(), true);
                                            ToastUtil.showToast(mContext, "安装包可能被删除了，请重新下载");
                                            notifyDataSetChanged();
                                        }
                                    }else {
                                        DownloadManager.getInstance().removeTask(gameModel.getId(), true);
                                        ToastUtil.showToast(mContext, "安装包可能被删除了，请重新下载");
                                        notifyDataSetChanged();
                                    }

                                }
                            }
                        });
                        itemView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent intent = new Intent(mContext, AppDetailActivity.class);
                                intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_ID, gameModel.getId());
                                intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_PACKAGENAME, gameModel.getPackageName());
                                mContext.startActivity(intent);
                            }
                        });
                        ib_select.setVisibility(View.GONE);
                        //玩过游戏中没有选择按钮
                    /*ib_select.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            final View inflate = LayoutInflater.from(mContext).inflate(R.layout.popwindow_mygame, null, false);
                            View uninstall = inflate.findViewById(R.id.tv_mygame_select_uninstall);
                            View update = inflate.findViewById(R.id.tv_mygame_select_update);

                            final PopupWindow popupWindow = new PopupWindow(inflate, DensityUtils.dp2px(mContext,55),DensityUtils.dp2px(mContext,54));
                            popupWindow.setFocusable(true);
                            popupWindow.setOutsideTouchable(true);
                            popupWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                            popupWindow.setAnimationStyle(android.R.style.Animation_InputMethod);
                            popupWindow.showAsDropDown(ib_select,- DensityUtils.dp2px(App.mContext, 35),0);

                            uninstall.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {//卸载游戏
                                    if (ApkUtils.hasInstalled(mContext, bGame.getPackageName())){
                                        popupWindow.dismiss();
                                        ApkUtils.uninstall(mContext,bGame.getPackageName());
                                    }
                                }
                            });

                            update.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    //更新游戏
                                }
                            });
                        }
                    });*/
                    }






        }

    }

    public void refresh(){
        this.notifyDataSetChanged();
    }
}