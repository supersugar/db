package com.uu393.market.core;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.uu393.market.module.manager.DoneAdapter;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;

/**
 * Created by bo on 16/12/28.
 */

public class AppInstallReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        //接收安装广播
        if (intent.getAction().equals("android.intent.action.PACKAGE_ADDED")) {
            String packageName = intent.getDataString();
            //package:com.uu898app包名的程序
            L.d("安装了:" +packageName + "包名的程序");
            EB.postEmpty(EB.TAG.APP_INSTALL);
            packageName = packageName.substring(packageName.indexOf(":") + 1, packageName.length());


            EB.postString(EB.TAG.INSTALLED_APP_PACKAGE_NAME,packageName);
            DownloadHelper.deleteFileByPackageName(context, packageName);// TODO: 2017/2/18 安装完成后自动删除安装包
        }
        //接收卸载广播
        if (intent.getAction().equals("android.intent.action.PACKAGE_REMOVED")) {
            String packageName = intent.getDataString();
            L.d("卸载了:"  + packageName + "包名的程序");
            EB.postEmpty(EB.TAG.APP_INSTALL);
            packageName = packageName.substring(packageName.indexOf(":") + 1, packageName.length());
            EB.postString(EB.TAG.UNINSTALLED_APP_PACKAGE_NAME,packageName);
        }
    }
}
