package com.uu393.market.module.center.timepicker.listener;

/**
 * Created by Administrator on 2017/4/12.
 */


public interface OnFinishPListener {
    public void OnFinish(Object o);
}