package com.uu393.market.model;

/**
 * Created by zhangbo on 2016/5/14.
 */
public class BaseModel<T> {


    /**
     * {
         "mode": "app",
         "type": " app001",
         "token":"98A6F5470454F0DB5619AC50808ACAA8",
         "deviceId": "a3432ggfd343bc",
         "signature": "b7d9900502d692893da4ad",
         "data": {}
        }
     */

    private String mode;
    private String type;
    private String token;
    private String deviceId;
    private String signature;
    private String message;
    private String status;
    private PageModel page;
    private T data;

    public BaseModel() {
    }

    public boolean isSuccess() {
        return status.equals("0");
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public PageModel getPage() {
        return page;
    }

    public void setPage(PageModel page) {
        this.page = page;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
