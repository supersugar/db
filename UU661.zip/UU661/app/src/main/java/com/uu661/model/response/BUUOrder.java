package com.uu661.model.response;

import java.io.Serializable;

/**
 * Created by bo on 16/9/14.
 */
public class BUUOrder implements Serializable {

    public String killOrderNo;//订单号
    public int payAmount;//金额
    public int needPayCode;//0不需要验证码，1需要验证码

    public boolean getNeedPayCode() {
        return needPayCode == 0 ? false : true;
    }
}
