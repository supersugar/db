package com.uu393.market.module.home;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.response.BHotActivity;
import com.uu393.market.util.GlideRoundTransform;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.ToastUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * =====================================================
 * Created by : wang xian
 * Created on : 2017/4/5
 * Description    : 热门活动列表适配器
 * =====================================================
 */

public class HotAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<BHotActivity> BHotActivity = new ArrayList<>();
    Activity mContext;

    public HotAdapter( Activity mContext){
            this.mContext = mContext;
    }

    public void updateData(List<BHotActivity> bHotActivity){
                this.BHotActivity = bHotActivity;
                notifyDataSetChanged();
    }



    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_hot_activities, parent, false);

        return new HotViewHolder(inflate);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder!=null&&holder instanceof HotViewHolder){
            ((HotViewHolder) holder).bindItem(position);
        }
    }

    @Override
    public int getItemCount() {
        return BHotActivity.size();
    }
    public class HotViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private ImageView appImg;
        private TextView title,time;
        private View item;
        BHotActivity BHotData;
        public HotViewHolder(View itemView) {
            super(itemView);
            appImg = (ImageView) itemView.findViewById(R.id.iv_hot_item_img);
            title = (TextView) itemView.findViewById(R.id.tv_hot_item_title);
            time = (TextView) itemView.findViewById(R.id.tv_hot_item_time);
            item = itemView.findViewById(R.id.layout_hot_item);
            item.setOnClickListener(this);
        }
        
        public void bindItem(int position){
            BHotData = BHotActivity.get(position);


            int defaultAndError = ImageHelper.randomImage();
            Glide.with(App.mContext).load(BHotData.getIcon())
                    .error(defaultAndError)
                    .placeholder(defaultAndError)
                    .transform(new GlideRoundTransform(App.mContext,10))
                    .into(appImg);
            title.setText(BHotData.getTitle());
            time.setText(BHotData.getBeginTime());
        }

        @Override
        public void onClick(View v) {
            //todo 活动详情页
            Intent intent = new Intent(mContext,HotActionDetailsActivity.class);
            intent.putExtra("id",BHotData.getId());
            intent.putExtra("noView","1");
            mContext.startActivity(intent);
        }
    }
}
