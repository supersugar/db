package com.uu393.market.model;

/**
 * Created by bo on 16/12/6.
 */

public class PageModel {

    public int index;
    public int size = 20;

    public PageModel(int i) {
        index = i;
    }
}
