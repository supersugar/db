package com.uu898app.model.request;

import com.uu898app.model.GBaseModel;

/**
 * Created by zhangbo on 2016/6/20.
 */
public class GPhoneNo extends GBaseModel {

    private String phoneNo;

    public GPhoneNo() {
    }

    public GPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }
}
