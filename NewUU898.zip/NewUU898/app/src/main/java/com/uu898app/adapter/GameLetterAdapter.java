package com.uu898app.adapter;


import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.uu898app.R;
import com.uu898app.model.response.BGame;

import java.util.List;

import cc.solart.turbo.BaseTurboAdapter;
import cc.solart.turbo.BaseViewHolder;

public class GameLetterAdapter extends BaseTurboAdapter<BGame, BaseViewHolder> {

    public GameLetterAdapter(Context context) {
        super(context);
    }

    public GameLetterAdapter(Context context, List<BGame> data) {
        super(context, data);
    }

    @Override
    protected int getDefItemViewType(int position) {
        BGame model = getItem(position);
        return model.getType();
    }

    @Override
    protected BaseViewHolder onCreateDefViewHolder(ViewGroup parent, int viewType) {
        if (viewType == 1)
            return new PinnedHolder(inflateItemView(R.layout.common_game_item_header, parent));
        else
            return new CityHolder(inflateItemView(R.layout.common_game_item_content, parent));
    }


    @Override
    protected void convert(BaseViewHolder holder, BGame item) {
        if (holder instanceof CityHolder) {
            ((CityHolder) holder).city_name.setText(item.getName());
        }else {
            ((PinnedHolder) holder).city_tip.setText(item.getFirstCharactor());
        }
    }

    public int getLetterPosition(String letter){
        for (int i = 0 ; i < getData().size(); i++){
            if(getData().get(i).getType() ==1 && getData().get(i).getFirstCharactor().equals(letter)){
                return i;
            }
        }
        return -1;
    }

    class CityHolder extends BaseViewHolder {

        TextView city_name;

        public CityHolder(View view) {
            super(view);
            city_name = findViewById(R.id.tv);
        }
    }


    class PinnedHolder extends BaseViewHolder {

        TextView city_tip;

        public PinnedHolder(View view) {
            super(view);
            city_tip = findViewById(R.id.tv);
        }
    }
}
