package com.uu898app.module.base;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;

import com.uu898app.module.root.RootHomeFragment;


/**
 * 懒加载
 * Created by YoKeyword on 16/6/5.
 */
public abstract class BaseLazyFragment extends BaseFragment {
    private boolean mInited = false;
    protected OnBackToFirstListener mBackToFirstListener;
    private Bundle mSavedInstanceState;

    public interface OnBackToFirstListener {
        void onBackToFirstFragment();
    }

    /**
     * 懒加载
     */
    protected abstract void initLazyView(@Nullable Bundle savedInstanceState);

    @Override
    public void onAttach(Activity context) {
        super.onAttach(context);
        if (context instanceof OnBackToFirstListener) {
            mBackToFirstListener = (OnBackToFirstListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnBackToFirstListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mBackToFirstListener = null;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mSavedInstanceState = savedInstanceState;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (savedInstanceState == null) {
            if (!isHidden()) {//可见
                mInited = true;
                initLazyView(null);
            }
        } else {
            // isSupportHidden()仅在saveIns tanceState!=null时有意义,是库帮助记录Fragment状态的方法
            if (!isSupportHidden()) {
                mInited = true;
                initLazyView(savedInstanceState);
            }
        }
    }



    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!mInited && !hidden) {
            mInited = true;
            initLazyView(mSavedInstanceState);
        }
    }

    /**
     * 处理回退事件
     *
     * @return
     */
    @Override
    public boolean onBackPressedSupport() {
        if (getChildFragmentManager().getBackStackEntryCount() > 1) {
            popChild();
        } else {
            if (this instanceof RootHomeFragment) {   // 如果是 第一个Fragment 则退出app
                _mActivity.finish();
            } else {                                    // 如果不是,则回到第一个Fragment
                mBackToFirstListener.onBackToFirstFragment();
            }
        }
        return true;
    }

}
