package com.uu661.module.common;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alipay.sdk.app.PayTask;
import com.flipboard.bottomsheet.BottomSheetLayout;
import com.flipboard.bottomsheet.OnSheetDismissedListener;
import com.google.gson.Gson;
import com.lzy.okgo.request.BaseRequest;
import com.uu661.R;
import com.uu661.app.App;
import com.uu661.core.AccountManager;
import com.uu661.model.BaseModel;
import com.uu661.model.request.GGetCouponList;
import com.uu661.model.request.GGetPaySign;
import com.uu661.model.request.GGetThirdOrderNo;
import com.uu661.model.request.GGoPay;
import com.uu661.model.response.BCoupon;
import com.uu661.model.response.BDiamond;
import com.uu661.model.response.BPaySign;
import com.uu661.model.response.BThirdOrder;
import com.uu661.model.response.BUUOrder;
import com.uu661.model.response.BUserInfo;
import com.uu661.model.response.BVerifyInfo;
import com.uu661.module.ChooseVerifyView;
import com.uu661.module.base.BaseFragment;
import com.uu661.network.JsonCallback;
import com.uu661.network.NetConstant;
import com.uu661.network.TaskEngine;
import com.uu661.util.CommonUtils;
import com.uu661.util.NoDoubleClickUtils;
import com.uu661.util.StringUtils;
import com.uu661.util.ToastUtil;
import com.uu661.util.log.L;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.finalteam.toolsfinal.coder.MD5Coder;
import okhttp3.Call;
import okhttp3.Response;


public class PayFragment extends BaseFragment {

    public static final int PAY_USE_ZFB = 0;    //使用支付宝支付
    public static final int PAY_USE_WX = 1;     //使用微信支付
    public static final int PAY_USE_MONEY = 2;  //使用余额支付

    public static final int REQ_CODE_CHOOSE_PAY = 0;  //选择支付方式
    public static final int REQ_CODE_CHOOSE_COUPON = 1;  //选择红包\

    public static final String BUNDLE_KEY_CHOOSE_PAY = "bundle_key_choose_pay";  //选择红包
    public static final String BUNDLE_KEY_CHOOSE_COUPON = "bundle_key_choose_coupon";  //选择红包


    @BindView(R.id.pay_tv_total_money) TextView mPayTvTotalMoney;
    @BindView(R.id.pay_bottom_sheet) BottomSheetLayout mPayBottomSheet;
    @BindView(R.id.pay_tv_order_no) TextView mPayTvOrderNo;
    @BindView(R.id.pay_tv_order_detail) TextView mPayTvOrderDetail;
    @BindView(R.id.pay_tv_red) TextView mPayTvCoupon;
    @BindView(R.id.pay_bt_choose_red) RelativeLayout mPayBtChooseRed;
    @BindView(R.id.pay_tv_which_pay) TextView mPayTvWhichPay;
    @BindView(R.id.pay_bt_choose_pay) RelativeLayout mPayBtChoosePay;
    @BindView(R.id.pay_tv_true_money) TextView mPayTvFinalMoney;
    @BindView(R.id.submit_bt) Button mSubmitBt;


    private BDiamond mDiamond;
    private BUUOrder mUUOrder;
    private int mBuyNum;

    private ChooseVerifyView mChooseVerifyView;
    private String mMd5;
    private long mCurrentTime;

    private int mChoosePayUse = PAY_USE_ZFB;//默认使用支付宝支付
    private BCoupon mCurrentCoupon;//当前选择的优惠券
    private int mFinalMoney = 0;
    private boolean mNeedVerify = true;//是否需要验证码

    /**
     * @param order   订单对象
     * @param diamond
     * @param num
     * @return
     */
    public static PayFragment newInstance(BUUOrder order, BDiamond diamond, int num) {
        PayFragment fragment = new PayFragment();
        Bundle args = new Bundle();
        args.putSerializable("order", order);
        args.putSerializable("diamond", diamond);
        args.putSerializable("num", num);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mUUOrder = (BUUOrder) getArguments().getSerializable("order");
        mDiamond = (BDiamond) getArguments().getSerializable("diamond");
        mBuyNum = getArguments().getInt("num");
        View view = inflater.inflate(R.layout.pay_fragment, null);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "收银台", true);
        mChooseVerifyView = new ChooseVerifyView(_mActivity, mPayBottomSheet);
        mChooseVerifyView.setOrderNo(mUUOrder.killOrderNo);
        mChooseVerifyView.setOnSubmitListener(onSubmitListener);
        setContent();
    }

    //入栈动画 结束时,回调
    @Override
    protected void onEnterAnimationEnd(Bundle savedInstanceState) {
        super.onEnterAnimationEnd(savedInstanceState);
        doGetCouponList();
    }

    private void setContent() {
        mPayTvOrderNo.setText("商品编号 : " + mUUOrder.killOrderNo);
        //        mPayTvOrderDetail.setText("商品信息 : " + mDiamond.getTitle());
        mPayTvOrderDetail.setText(Html.fromHtml("商品信息 : <font color='#fc5669'>" + mDiamond.getPrice() + "</font>U钻(购买" + mBuyNum + "人次)"));
        mPayTvTotalMoney.setText("￥" + CommonUtils.fenToYuan(mUUOrder.payAmount));
        mPayTvFinalMoney.setText("￥" + CommonUtils.fenToYuan(mUUOrder.payAmount));
        setChoosePay();
    }

    private ChooseVerifyView.ChooseVerifyViewListener onSubmitListener = new ChooseVerifyView.ChooseVerifyViewListener() {
        @Override
        public void onSubmit(int type, String password) {
            //发起余额支付,首先要获取签名
            doGetPaySign(type, password);
            hideSoftInput();
        }

        @Override
        public void showOrHideSoftInput(boolean show, View v) {
            if (show && null != v) {
                showSoftInput(v);
            } else {
                hideSoftInput();
            }
        }
    };

    // 目标Fragment调用setFragmentResult()后，在其出栈时，会回调该方法
    @Override
    public void onFragmentResult(int requestCode, int resultCode, Bundle data) {
        super.onFragmentResult(requestCode, resultCode, data);
        if (requestCode == REQ_CODE_CHOOSE_PAY && resultCode == RESULT_OK) {
            // 在此通过Bundle data 获取返回的数据
            mChoosePayUse = data.getInt(BUNDLE_KEY_CHOOSE_PAY);
            setChoosePay();
        }
        if (requestCode == REQ_CODE_CHOOSE_COUPON && resultCode == RESULT_OK) {
            // 在此通过Bundle data 获取返回的数据
            mCurrentCoupon = (BCoupon) data.getSerializable(BUNDLE_KEY_CHOOSE_COUPON);
            setCoupon(mCurrentCoupon);
        }
    }

    @Override
    public boolean onBackPressedSupport() {
        if (null != mPayBottomSheet && mPayBottomSheet.isSheetShowing()) {
            mPayBottomSheet.dismissSheet();
            return true;
        }
        return super.onBackPressedSupport();
    }

    private void setChoosePay() {
        String temp = "";
        if (mChoosePayUse == PAY_USE_WX) {
            temp = "微信";
        } else if (mChoosePayUse == PAY_USE_ZFB) {
            //(1为app支付，0为网页支付)
            if(App.PAY_SETTING == 1){
                temp = "支付宝";
            }else {
                temp = "支付宝网页";
            }
        } else if (mChoosePayUse == PAY_USE_MONEY) {
            temp = "UU898余额";
        }
        mPayTvWhichPay.setText(temp);
    }

    /**
     * 获取红包列表
     */
    private void doGetCouponList() {
        GGetCouponList model = new GGetCouponList();
        model.isValid = 1;
        model.orderNo = mUUOrder.killOrderNo;
        TaskEngine.getInstance().doGetCouponList(model, new JsonCallback<List<BCoupon>>(this) {
            @Override
            public void onSuccess(List<BCoupon> result, Call call, Response response) {
                if (null != result && !result.isEmpty()) {
                    //取第一个显示
                    setCoupon(result.get(0));
                } else {
                    setCoupon(null);
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                setCoupon(null);
            }
        });
    }

    /**
     * 设置代金券信息,设置完之后要设置实际金额
     * 如果红包可以完全抵扣要支付的金额,则只使用红包购买,不显示选择支付方式按钮
     * 如果红包的余额比要支付的金额大,则只扣除要支付的那部分钱
     *
     * @param model
     */
    private void setCoupon(BCoupon model) {
        mCurrentCoupon = model;
        if (null == mCurrentCoupon) {//无可用优惠券
            mPayBtChoosePay.setVisibility(View.VISIBLE);
            mPayBtChooseRed.setEnabled(false);//选择红包按钮不可点击
            mPayTvCoupon.setText("无可使用的红包");
            mNeedVerify = true;
            mFinalMoney = mUUOrder.payAmount;
        } else {
            if (StringUtils.isEmpty(model.id)) {//id无值,说明有可用红包,但是主动选择不使用
                mPayBtChoosePay.setVisibility(View.VISIBLE);
                mPayBtChooseRed.setEnabled(true);//选择红包按钮不可点击
                mPayTvCoupon.setText("不使用红包");
                mNeedVerify = true;
                mFinalMoney = mUUOrder.payAmount;
            } else {
                mPayBtChooseRed.setEnabled(true);//可选择红包
                String temp = "";//显示文字
                //需要判断选择的红包是不是比需要支付的钱多
                if (model.money > mUUOrder.payAmount) {
                    mPayBtChoosePay.setVisibility(View.GONE);//只使用红包购买
                    temp = model.title + " - ￥" + CommonUtils.fenToYuan(mUUOrder.payAmount);//只抵扣要支付的金额
                    mNeedVerify = false;
                    mFinalMoney = 0;
                    mChoosePayUse = PAY_USE_MONEY;
                } else if (model.money == mUUOrder.payAmount) {
                    mPayBtChoosePay.setVisibility(View.GONE);//只使用红包购买
                    temp = model.title + " - ￥" + CommonUtils.fenToYuan(model.money);
                    mNeedVerify = false;
                    mFinalMoney = 0;
                    mChoosePayUse = PAY_USE_MONEY;
                } else {
                    mPayBtChoosePay.setVisibility(View.VISIBLE);//混合支付
                    temp = model.title + " - ￥" + CommonUtils.fenToYuan(model.money);
                    mNeedVerify = true;
                    mFinalMoney = mUUOrder.payAmount - model.money;
                }
                mPayTvCoupon.setText(temp);
            }
        }
        mPayTvFinalMoney.setText("￥" + CommonUtils.fenToYuan(mFinalMoney));
        //每次切换完代金券之后,判断当前的支付方式是不是余额支付,如果是的话,要看余额是不是够支付
        if (mChoosePayUse == PAY_USE_MONEY) {
            BUserInfo userInfo = AccountManager.getInstance().getUserInfo();
            if (null != userInfo && mFinalMoney > userInfo.money) {
                ToastUtil.showToast(_mActivity, "余额不足，已为您切换至其他支付方式");
                mChoosePayUse = PAY_USE_ZFB;
            }
        }
        setChoosePay();
    }

    /**
     * 获取签名
     *
     * @param type
     * @param password
     */
    private void doGetPaySign(int type, String password) {
        genJsonForSign(type, password);
    }

    /**
     * 生成获取签名的json
     *
     * @param type
     * @param password
     */
    private void genJsonForSign(final int type, final String password) {
        showLoadToast();
        GGoPay model = new GGoPay();
        mCurrentTime = System.currentTimeMillis();
        model.timespan = mCurrentTime;
        model.jsonForSignature = "";
        model.signature = "";
        model.payCode = password;
        model.validType = type;
        model.killOrderNo = mUUOrder.killOrderNo;
        model.voucherId = null != mCurrentCoupon ? mCurrentCoupon.id : "";

        BaseModel<GGoPay> baseModel = new BaseModel<GGoPay>();
        baseModel.setPlatform("apk");//固定
        baseModel.setAppId("1");//固定
        baseModel.setDeviceId(CommonUtils.getDeviceId());
        baseModel.setToken(AccountManager.getInstance().getLoginInfo().token);
        baseModel.setType(NetConstant.Api.GO_PAY);
        baseModel.setData(model);
        Gson gson = new Gson();
        String request = gson.toJson(baseModel);
        L.json(request);
        mMd5 = MD5Coder.getMD5Code(request);

        GGetPaySign getPaySign = new GGetPaySign();
        getPaySign.jsonForSignature = mMd5;
        getPaySign.payCode = password;
        getPaySign.timespan = mCurrentTime;

        TaskEngine.getInstance().doGetPaySign(getPaySign, new JsonCallback<BPaySign>() {
            @Override
            public void onSuccess(BPaySign result, Call call, Response response) {
                doGoPay(type, password, result.signature);
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
                ToastUtil.showToast(_mActivity, "获取支付签名失败");
            }
        });
    }

    /**
     * 余额支付
     *
     * @param type
     * @param password
     * @param signature
     */
    private void doGoPay(final int type, String password, String signature) {
        GGoPay model = new GGoPay();
        model.timespan = mCurrentTime;
        model.jsonForSignature = mMd5;
        model.signature = signature;
        model.payCode = password;
        model.validType = type;
        model.killOrderNo = mUUOrder.killOrderNo;
        model.voucherId = null != mCurrentCoupon ? mCurrentCoupon.id : "";

        TaskEngine.getInstance().doGoPay(model, new JsonCallback<Object>() {
            @Override
            public void onSuccess(Object o, Call call, Response response) {
                mChooseVerifyView.handleSuccess();
                goPayResult();
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                /*
                 "type": "uzuanapp60007",
                 "status": "ERROR000406",
                 "message": "验证码验证失败",
                 */
                if (e instanceof APIException && ((APIException) e).getCode().equals("ERROR000406")) {
                    mChooseVerifyView.handleVerifyCodeError(type, e.getMessage());
                }
            }

            @Override
            public void onAfter(Object o, Exception e) {
                super.onAfter(o, e);
                hideLoadToast();
            }
        });
    }

    /**
     * 去往支付结果页,并结束掉当前页面
     */
    private void goPayResult() {
        startWithPop(PayResultFragment.newInstance(mDiamond, mUUOrder.killOrderNo));
    }

    @OnClick({R.id.pay_bt_choose_red, R.id.pay_bt_choose_pay, R.id.submit_bt})
    public void onClick(View view) {
        if (null == mUUOrder) {
            return;
        }
        if (NoDoubleClickUtils.isDoubleClick()) {
            return;
        }
        switch (view.getId()) {
            case R.id.submit_bt://提交按钮
                //先判断提交方式
                if (mChoosePayUse == PAY_USE_ZFB) {
                    if(App.PAY_SETTING == 1){
                        doGetAilPayOrderNo();
                    }else{
                        doAliWapPay();
                    }
                } else if (mChoosePayUse == PAY_USE_WX) {
                    doGetWxPayOrderNo();
                } else if (mChoosePayUse == PAY_USE_MONEY) {
                    //首先获取用户可用的验证方式
                    if (StringUtils.isEmpty(mUUOrder.killOrderNo)) {
                        ToastUtil.showToast(_mActivity, "生成订单失败");
                        return;
                    }
                    if (!mUUOrder.getNeedPayCode()) {//不需要验证码
                        doGetPaySign(0, "");
                        return;
                    }
                    TaskEngine.getInstance().doGetUserVerifyInfo(new JsonCallback<BVerifyInfo>() {
                        @Override
                        public void onBefore(BaseRequest request) {
                            super.onBefore(request);
                            showLoadToast();
                        }

                        @Override
                        public void onSuccess(BVerifyInfo result, Call call, Response response) {
                            hideLoadToast();
                            //默认验证方式，1：支付密码，2：手机，3：微信，6：UU密令
                            //                                                BVerifyInfo temp = new BVerifyInfo();
                            //                                                temp.setIsBindNone(0);
                            //                                                temp.setDefaultValidType(3);
                            //                                                temp.setIsBindPassword(1);
                            //                                                temp.setIsBindUU(1);
                            //                                                temp.setIsBindWeChat(1);
                            //                                                temp.setIsBindMobile(1);
                            //                                                result = temp;
                            if (result.getIsBindNone()) {//没有任何绑定,则直接发起支付
                                doGetPaySign(0, "");
                                return;
                            }
                            if (mNeedVerify == false) {//不需要验证
                                doGetPaySign(result.getDefaultValidType(), "");
                                return;
                            }
                            mChooseVerifyView.updateData(result);
                            mPayBottomSheet.showWithSheetView(mChooseVerifyView);
                            mPayBottomSheet.addOnSheetDismissedListener(new OnSheetDismissedListener() {
                                @Override
                                public void onDismissed(BottomSheetLayout bottomSheetLayout) {
                                    hideSoftInput();
                                }
                            });
                            mPayBottomSheet.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    mPayBottomSheet.expandSheet();
                                }
                            }, 50);
                        }

                        @Override
                        public void onError(Call call, Response response, Exception e) {
                            super.onError(call, response, e);
                            hideLoadToast();
                        }
                    });
                }
                break;
            case R.id.pay_bt_choose_red:
                //进入选择红包界面
                startForResult(PayChooseCouponFragment.newInstance(mUUOrder.killOrderNo, mCurrentCoupon), REQ_CODE_CHOOSE_COUPON);
                break;
            case R.id.pay_bt_choose_pay:
                //进入选择支付方式界面,需要传递实际支付金额
                startForResult(PayChoosePayFragment.newInstance(mChoosePayUse, mFinalMoney), REQ_CODE_CHOOSE_PAY);
                break;
        }
    }

    private void doGetWxPayOrderNo() {
        GGetThirdOrderNo model = new GGetThirdOrderNo();
        model.killOrderNo = mUUOrder.killOrderNo;
        model.voucherId = null != mCurrentCoupon ? mCurrentCoupon.id : "";
        model.payType = GGetThirdOrderNo.WeXin;
        TaskEngine.getInstance().doGetThirdOrderNo(model, new JsonCallback<BThirdOrder>(this) {
            @Override
            public void onSuccess(final BThirdOrder result, Call call, Response response) {
                //                RequestMsg msg = new RequestMsg();
                //                msg.setTokenId(result.get("token_id"));//token_id为服务端预下单返回
                //                msg.setTradeType(MainApplication.WX_APP_TYPE); //app支付类型
                //                msg.setAppId("appid");//appid为商户自己在微信开放平台的应用appid
                //                PayPlugin.unifiedAppPay(_mActivity, msg);
            }
        });
    }

    private void doGetAilPayOrderNo() {
        GGetThirdOrderNo model = new GGetThirdOrderNo();
        model.killOrderNo = mUUOrder.killOrderNo;
        model.voucherId = null != mCurrentCoupon ? mCurrentCoupon.id : "";
        model.payType = GGetThirdOrderNo.AliPay;
        TaskEngine.getInstance().doGetThirdOrderNo(model, new JsonCallback<BThirdOrder>(this) {
            @Override
            public void onSuccess(final BThirdOrder result, Call call, Response response) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        String payResult = new PayTask(_mActivity).pay(result.signOrderNo, false);
                        Message msg = new Message();
                        msg.what = 1;
                        msg.obj = payResult;
                        mHandler.sendMessage(msg);

                    }
                }).start();
            }
        });
    }

    private Handler mHandler = new Handler() {
        @SuppressWarnings("unused")
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1: {
                    AliPayResult payResult = new AliPayResult((String) msg.obj);
                    String resultInfo = payResult.getResult();// 同步返回需要验证的信息
                    String resultStatus = payResult.getResultStatus();
                    // 判断resultStatus 为“9000”则代表支付成功，具体状态码代表含义可参考接口文档
                    if (TextUtils.equals(resultStatus, "9000")) {
                        ToastUtil.showToast(_mActivity, "支付成功");
                        goPayResult();
                    } else if (TextUtils.equals(resultStatus, "6001")) {
                        ToastUtil.showToast(_mActivity, "取消支付");
                    } else if (TextUtils.equals(resultStatus, "8000") || TextUtils.equals(resultStatus, "6004")) {
                        ToastUtil.showToast(_mActivity, "支付宝结果码" + resultStatus);
                        goPayResult();
                    } else {
                        ToastUtil.showToast(_mActivity, "支付失败 支付结果码 = " + resultStatus);
                    }
                    break;
                }
                default:
                    break;
            }
        }
    };

    private void doAliWapPay() {
        StringBuilder sb = new StringBuilder();
        sb.append("http://m.uu661.com/page/partnerPay_app.aspx?");
        /**
         *  model.killOrderNo = mUUOrder.killOrderNo;
             model.voucherId = null != mCurrentCoupon ? mCurrentCoupon.id : "";
             model.payType = GGetThirdOrderNo.AliPay;

         http://m.uu661.com/page/partnerPay_app.aspx?
         o=1007407091
         &ct=1
         &deviceId=45DD3C68-523B-464F-A4FC-E2660ED65D45
         &token=87FA8AE2040B12E501BF085B86FFA64C
         &vid=(null)
         */
        BUserInfo userInfo = AccountManager.getInstance().getUserInfo();
        if (null != userInfo) {
            sb.append("o=").append(mUUOrder.killOrderNo);
            sb.append("&ct=").append("1");
            sb.append("&deviceId=").append(CommonUtils.getDeviceId());
            sb.append("&token=").append(AccountManager.getInstance().getLoginInfo().token);
            sb.append("&vid=").append(null != mCurrentCoupon ? mCurrentCoupon.id : "");

            Intent intent = new Intent(_mActivity, WebActivity.class);
            intent.putExtra(WebActivity.INTENT_KEY_URL, sb.toString());
            intent.putExtra(WebActivity.INTENT_KEY_TITLE, "支付");
            startActivityForResult(intent, 19);

        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 19 && resultCode == RESULT_OK) {
            goPayResult();
        }
    }

}
