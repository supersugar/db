package com.uu898app.module.buy;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.uu898app.R;
import com.uu898app.adapter.GameLetterAdapter;
import com.uu898app.model.request.GGameList;
import com.uu898app.model.request.GOnlyId;
import com.uu898app.model.response.BGame;
import com.uu898app.model.response.BGameArea;
import com.uu898app.model.response.BGameKind;
import com.uu898app.model.response.BGameServer;
import com.uu898app.module.base.BaseFragment;
import com.uu898app.module.helper.AccountManager;
import com.uu898app.module.helper.BuyHelper;
import com.uu898app.network.TaskEngine;
import com.uu898app.network.rxjava.RxSubscriber;
import com.uu898app.util.cache.UUCache;
import com.uu898app.util.cache.UUCacheConstant;
import com.uu898app.util.eventbus.EB;
import com.uu898app.util.eventbus.EventEmpty;
import com.uu898app.util.log.L;
import com.uu898app.util.wavesidebar.LetterComparator;
import com.uu898app.util.wavesidebar.PinnedHeaderDecoration;
import com.uu898app.util.wavesidebar.Util;
import com.uu898app.view.wavesidebar.WaveSideBarView;

import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by YoKeyword on 16/2/9.
 */
public class BuyCustomContentFragment extends BaseFragment {

    private static final int CURRENT_DATA_TYPE_GAME = 0;
    private static final int CURRENT_DATA_TYPE_GAME_KIND = 1;
    private static final int CURRENT_DATA_TYPE_GAME_AREA = 2;
    private static final int CURRENT_DATA_TYPE_GAME_SERVER = 3;

    private int mCurrentDataType = -1;

    private TextView mTvContent;
    private Button mBtnNext;

    private String mMenu;

    private SwipeRefreshLayout mSwipeRefreshLayout;
    private RecyclerView mRecyclerViewForGame;
    private RecyclerView mRecyclerViewForOther;
    private WaveSideBarView mSideBarView;

    private UUCache mCache;
    private GameLetterAdapter mGameAdapter;
    private List<BGame> mGameList;

    public static BuyCustomContentFragment newInstance() {

        Bundle args = new Bundle();
        BuyCustomContentFragment fragment = new BuyCustomContentFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.buy_custom_content, container, false);
        mCache = UUCache.get(_mActivity);

        mRecyclerViewForGame = (RecyclerView) view.findViewById(R.id.recycler_view_game);
        mRecyclerViewForOther = (RecyclerView) view.findViewById(R.id.recycler_view_other);
        mSwipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.refresh_layout);
        mSideBarView = (WaveSideBarView) view.findViewById(R.id.side_view);

        mSwipeRefreshLayout.setColorSchemeResources(R.color.colorPrimary);
        mSwipeRefreshLayout.setEnabled(false);

        initRecycleViewForGame();
        initRecycleViewForOther();

        return view;
    }



    private void initRecycleViewForGame() {
        mRecyclerViewForGame.setLayoutManager(new LinearLayoutManager(_mActivity));

        final PinnedHeaderDecoration decoration = new PinnedHeaderDecoration();
        decoration.registerTypePinnedHeader(1, new PinnedHeaderDecoration.PinnedHeaderCreator() {
            @Override
            public boolean create(RecyclerView parent, int adapterPosition) {
                return true;
            }
        });
        mRecyclerViewForGame.addItemDecoration(decoration);

        mSideBarView.setOnTouchLetterChangeListener(new WaveSideBarView.OnTouchLetterChangeListener() {
            @Override
            public void onLetterChange(String letter) {
                int pos = mGameAdapter.getLetterPosition(letter);
                if (pos != -1) {
                    mRecyclerViewForGame.scrollToPosition(pos);
                }
            }
        });

        mGameAdapter = new GameLetterAdapter(_mActivity);
        mRecyclerViewForGame.setAdapter(mGameAdapter);
        mGameAdapter.addOnItemClickListener(new cc.solart.turbo.OnItemClickListener() {
            @Override
            public void onItemClick(RecyclerView.ViewHolder vh, int position) {
                //点击的位置包含index
//                L.d(mGameList.get(position).getName() + " id = " + mGameList.get(position).getID());
//                if (!mGameList.isEmpty() && mGameList.get(position).getID() != 0) {
//                    EB.postObject(EB.TAG.SELECT_GAME_DONE, mGameList.get(position));
//                    _mActivity.finish();
//                }
                BuyHelper.getInstance().setChooseGame(mGameList.get(position));
                EB.postEmpty(EB.TAG.CHOOSE_GAME_DONE);
            }
        });
    }

    private void initRecycleViewForOther() {
        mRecyclerViewForOther.setLayoutManager(new LinearLayoutManager(_mActivity));
        mRecyclerViewForOther.addOnItemTouchListener(onItemClickListener);
    }

    OnItemClickListener onItemClickListener = new OnItemClickListener() {
        @Override
        public void SimpleOnItemClick(BaseQuickAdapter baseQuickAdapter, View view, int i) {
            BaseQuickAdapter adapter = (BaseQuickAdapter) mRecyclerViewForOther.getAdapter();
            switch (mCurrentDataType){
                case CURRENT_DATA_TYPE_GAME:

                    break;
                case CURRENT_DATA_TYPE_GAME_KIND:
                    BuyHelper.getInstance().setChooseGameKind((BGameKind) adapter.getItem(i));
                    EB.postEmpty(EB.TAG.CHOOSE_GAME_KIND_DONE);
                    break;
                case CURRENT_DATA_TYPE_GAME_AREA:
                    BuyHelper.getInstance().setChooseGameArea((BGameArea) adapter.getItem(i));
                    EB.postEmpty(EB.TAG.CHOOSE_GAME_AREA_DONE);
                    break;
                case CURRENT_DATA_TYPE_GAME_SERVER:
                    BuyHelper.getInstance().setChooseGameServer((BGameServer) adapter.getItem(i));
                    EB.postEmpty(EB.TAG.CHOOSE_GAME_SERVER_DONE);
                    //搜索
                    BuyCustomFragment parentFragment = (BuyCustomFragment) getParentFragment();
                    if(null != parentFragment){
                        parentFragment.start(GoodsListFragment.newInstance());
                    }
                    break;
            }
        }
    };

    /**
     * 展示游戏列表
     */
    private void showGameList(){
        mRecyclerViewForGame.setVisibility(View.VISIBLE);
        mRecyclerViewForOther.setVisibility(View.GONE);
        mSideBarView.setVisibility(View.VISIBLE);
    }

    private void showOtherList(){
        mRecyclerViewForGame.setVisibility(View.GONE);
        mRecyclerViewForOther.setVisibility(View.VISIBLE);
        mSideBarView.setVisibility(View.GONE);
    }

    @Override
    public void onResume() {
        super.onResume();
        EB.register(this);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        EB.unregister(this);
    }

    @Subscribe
    public void onEvent(EventEmpty event) {
        switch (event.tag) {
            case EB.TAG.LOAD_GAME_LIST:
                mCurrentDataType = CURRENT_DATA_TYPE_GAME;
                showGameList();
                doGetGameList();
                break;
            case EB.TAG.LOAD_GAME_KIND_LIST:
                mCurrentDataType = CURRENT_DATA_TYPE_GAME_KIND;
                showOtherList();
                doGetGameKindList();
                break;
            case EB.TAG.LOAD_GAME_AREA_LIST:
                mCurrentDataType = CURRENT_DATA_TYPE_GAME_AREA;
                showOtherList();
                doGetGameAreaList();
                break;
            case EB.TAG.LOAD_GAME_SERVER_LIST:
                mCurrentDataType = CURRENT_DATA_TYPE_GAME_SERVER;
                showOtherList();
                doGetGameServerList();
                break;
            default:
                break;
        }
    }

    private void doGetGameList() {
        Object cache = mCache.getAsObject(UUCacheConstant.KEY_GAMES_WITH_INDEX);
        if(null != cache){
            mGameList = (List<BGame>) cache;
            mGameAdapter.resetData(mGameList);
            L.d("从缓存取出游戏列表数据");
            return;
        }
        GGameList gameList = new GGameList();
        gameList.setIshot("0");
        gameList.setSSID(AccountManager.getInstance().getSSID());
        TaskEngine.getInstance().getGameList(gameList).subscribe(new RxSubscriber<List<BGame>>() {
            @Override
            public void _onNext(final List<BGame> bGames) {
                //服务器返回的数据,要加上首字母list
                bGames.addAll(0, Util.getAToZIndexList());
                Collections.sort(bGames, new LetterComparator());
                mGameList = bGames;
                mGameAdapter.resetData(mGameList);
                mCache.put(UUCacheConstant.KEY_GAMES_WITH_INDEX, (ArrayList)mGameList, UUCache.TIME_HOUR);
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

    private void doGetGameKindList() {
        GOnlyId model = new GOnlyId(BuyHelper.getInstance().getChooseGame().getID());
        TaskEngine.getInstance().getGameKindList(model).subscribe(new RxSubscriber<List<BGameKind>>(BuyCustomContentFragment.this, true) {
            @Override
            public void _onNext(List<BGameKind> bGames) {
                final GameKindAdapter gameAdapter = new GameKindAdapter(bGames);
                mRecyclerViewForOther.setAdapter(gameAdapter);
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

    private void doGetGameAreaList() {
        GOnlyId model = new GOnlyId(BuyHelper.getInstance().getChooseGame().getID());
        TaskEngine.getInstance().getGameAreaList(model).subscribe(new RxSubscriber<List<BGameArea>>(BuyCustomContentFragment.this, true) {
            @Override
            public void _onNext(List<BGameArea> bGames) {
                final GameAreaAdapter gameAdapter = new GameAreaAdapter(bGames);
                mRecyclerViewForOther.setAdapter(gameAdapter);
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

    private void doGetGameServerList() {
        GOnlyId model = new GOnlyId(BuyHelper.getInstance().getChooseGameArea().getID());
        TaskEngine.getInstance().getGameServerList(model).subscribe(new RxSubscriber<List<BGameServer>>(BuyCustomContentFragment.this, true) {
            @Override
            public void _onNext(List<BGameServer> bGames) {
                final GameServerAdapter gameAdapter = new GameServerAdapter(bGames);
                mRecyclerViewForOther.setAdapter(gameAdapter);
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }


    private class GameAdapter extends BaseQuickAdapter<BGame> {
        public GameAdapter( List<BGame> data) {
            super(R.layout.buy_step_item, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, BGame item) {
            helper.setText(R.id.tv_name, item.getName());
        }
    }

    private class GameKindAdapter extends BaseQuickAdapter<BGameKind> {
        public GameKindAdapter( List<BGameKind> data) {
            super(R.layout.buy_step_item, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, BGameKind item) {
            helper.setText(R.id.tv_name, item.getName());
        }
    }

    private class GameAreaAdapter extends BaseQuickAdapter<BGameArea> {
        public GameAreaAdapter( List<BGameArea> data) {
            super(R.layout.buy_step_item, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, BGameArea item) {
            helper.setText(R.id.tv_name, item.getName());
        }
    }

    private class GameServerAdapter extends BaseQuickAdapter<BGameServer> {
        public GameServerAdapter( List<BGameServer> data) {
            super(R.layout.buy_step_item, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, BGameServer item) {
            helper.setText(R.id.tv_name, item.getName());
        }
    }

}
