package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/24
 * Description    :
 * =====================================================
 */

public class GDoVerifyPhoneCode {
    /**
     {
     "userId":"zzgxl",（用户唯一标识码，与phoneNo，SSID不同时存在值，详见接口尾说明）
     "type":"1",（见接口尾说明）
     "phoneNo": "13256823654",（手机号，userId，SSID不同时存在值，详见接口尾说明）
     "checkCode": "456987"（手机验证码）
     }
     */

    private String userId;
    private String type;
    private String phoneNo;
    private String checkCode;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getCheckCode() {
        return checkCode;
    }

    public void setCheckCode(String checkCode) {
        this.checkCode = checkCode;
    }
}
