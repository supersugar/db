package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    :
 * =====================================================
 */

public class BWalletWithdrawDetail implements Serializable {

    /**
     * money : 100.00
     * actMoney : 98.00
     * bankName : 中国建设银行
     * failReason :
     * completeTime : 2016-08-19 14:36:54
     * status : 1
     * addTime : 2016-08-19 14:36:38
     */

    private String money;
    private String actMoney;
    private String bankName;
    private String failReason;
    private String completeTime;
    private String status;
    private String addTime;

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getActMoney() {
        return actMoney;
    }

    public void setActMoney(String actMoney) {
        this.actMoney = actMoney;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getFailReason() {
        return failReason;
    }

    public void setFailReason(String failReason) {
        this.failReason = failReason;
    }

    public String getCompleteTime() {
        return completeTime;
    }

    public void setCompleteTime(String completeTime) {
        this.completeTime = completeTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }
}
