package com.uu661.view;

import android.graphics.Rect;
import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by bo on 16/8/23.
 */
public class SpaceItemDecoration extends RecyclerView.ItemDecoration {

    private int space;

    public SpaceItemDecoration(int space) {
        this.space = space;
    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
//        outRect.left = space;
//        outRect.choose_diamond_num = space;
        if ((parent.getChildLayoutPosition(view)-1) % 2 == 0) {//第二列
            outRect.left = space;
            outRect.bottom = space;
        }else{
            outRect.bottom = space;
        }


    }

}
