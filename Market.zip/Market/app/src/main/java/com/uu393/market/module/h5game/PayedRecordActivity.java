package com.uu393.market.module.h5game;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import com.uu393.market.R;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.base.BaseViewPagerFragment;
import com.uu393.market.view.lazyviewpager.LazyFragmentPagerAdapter;

import java.util.HashMap;
import java.util.Map;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class PayedRecordActivity extends BaseActivity {

    @Bind(R.id.ib_payed_record_go_back)
    ImageButton mIbPayedRecordGoBack;
    @Bind(R.id.tl_payed_record)
    TabLayout mTlPayedRecord;
    @Bind(R.id.vp_payed_record)
    ViewPager mVpPayedRecord;
    private PayedRecordPagerAdapter mPagerAdapter;
    private int mCurrentFragmentIndex;
    private Map<Integer, BaseViewPagerFragment> fragmentsMap = new HashMap<>();
    private String APPID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payed_record);
        APPID = getIntent().getStringExtra("APPID");
        ButterKnife.bind(this);

        initViewPager();
    }

    private void initViewPager() {
        mPagerAdapter = new PayedRecordPagerAdapter(getSupportFragmentManager());
        mVpPayedRecord.setAdapter(mPagerAdapter);
        mTlPayedRecord.setupWithViewPager(mVpPayedRecord);
        mVpPayedRecord.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                mCurrentFragmentIndex = position;
                if (!fragmentsMap.isEmpty()&&fragmentsMap.get(mCurrentFragmentIndex)!=null){
                    fragmentsMap.get(mCurrentFragmentIndex).refresh();
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshCurrentGameFragment();
    }

    private void refreshCurrentGameFragment() {
        if (!fragmentsMap.isEmpty() && null != fragmentsMap.get(mCurrentFragmentIndex)) {
            fragmentsMap.get(mCurrentFragmentIndex).refresh();
        }
    }

    public class PayedRecordPagerAdapter extends LazyFragmentPagerAdapter {
        private String[] kinds = {"所有订单", "充值成功"};

        public PayedRecordPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        protected Fragment getItem(ViewGroup container, int position) {
            PayedRecordFragment fragment = PayedRecordFragment.newInstance(kinds[position],APPID);
            fragmentsMap.put(position, fragment);
            return fragment;
        }

        @Override
        public int getCount() {
            return kinds.length;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return kinds[position];
        }
    }


    @OnClick(R.id.ib_payed_record_go_back)
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ib_payed_record_go_back:
                this.finish();
                break;
            default:
                break;
        }
    }
}
