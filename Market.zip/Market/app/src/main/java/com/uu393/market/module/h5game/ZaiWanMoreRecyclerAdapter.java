package com.uu393.market.module.h5game;

import android.app.Activity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.response.BGame;
import com.uu393.market.model.response.BH5Game;
import com.uu393.market.model.response.BH5ZaiWan;
import com.uu393.market.model.response.BH5ZaiWanAll;
import com.uu393.market.module.home.ApkListAdapter;
import com.uu393.market.util.DateUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/22
 * Descrip    :
 * =====================================================
 */

public class ZaiWanMoreRecyclerAdapter extends RecyclerView.Adapter<ZaiWanMoreRecyclerAdapter.ZaiWanMoreHolder>{
    private List<BH5ZaiWanAll> mGames;
    private Activity activity;
    public ZaiWanMoreRecyclerAdapter(Activity activity){
        mGames = new ArrayList<>();
        this.activity = activity;
    }

    @Override
    public ZaiWanMoreHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_h5game_zaiwan_more, null, false);
        return new ZaiWanMoreHolder(view);
    }

    @Override
    public void onBindViewHolder(ZaiWanMoreHolder holder, int position) {
        holder.bindItem(mGames.get(position));
    }

    @Override
    public int getItemCount() {
        return mGames.size();
    }
    public void refresh(List<BH5ZaiWanAll> mGames){
        this.mGames = mGames;
        this.notifyDataSetChanged();
    }

    class ZaiWanMoreHolder extends RecyclerView.ViewHolder{
        private TextView zaiwanDate;
        private RecyclerView zaiwanInItem;
        private final H5ApkListAdapter adapter;
        private List<BH5Game> games;

        public ZaiWanMoreHolder(View itemView) {
            super(itemView);

            games = new ArrayList<>();
            zaiwanDate = (TextView) itemView.findViewById(R.id.tv_zaiwan_more_date);
            zaiwanInItem = (RecyclerView) itemView.findViewById(R.id.rv_zaiwan_more_in_item);

            zaiwanInItem.setLayoutManager(new FullyLinearLayoutManager(App.mContext, LinearLayoutManager.VERTICAL,false));
            adapter = new H5ApkListAdapter(activity);
            zaiwanInItem.setAdapter(adapter);
        }
        public void bindItem(BH5ZaiWanAll bh5game){
            String playTime = bh5game.getPlayTime();
            Date date = DateUtils.parse(playTime, "yyyy/MM/dd HH:mm:ss");
            SimpleDateFormat format = new SimpleDateFormat("yyyy年MM月dd日");
            if(format.format(date).equals(format.format(new Date()))){
                zaiwanDate.setText("今天");
            }else {
                zaiwanDate.setText(format.format(date));
            }
            if (bh5game.getGameList()!=null&&!bh5game.getGameList().isEmpty()){
                games.clear();
                for (BH5ZaiWanAll.GameListBean game:bh5game.getGameList()){
                    //todo 将在玩所有列表中游戏对象转化为h5游戏对象
                    BH5Game gameModel = new BH5Game();
                    gameModel.setIcon(game.getIcon());
                    gameModel.setGameName(game.getGameName());
                    gameModel.setId(game.getId());
                    gameModel.setTypeName(game.getTypeName());
                    gameModel.setAPPID(game.getAPPID());
                    gameModel.setAndroidPackage(game.getAndroidPackage());

                    games.add(gameModel);
                }
                adapter.updateData(games);
            }
        }
    }


}
