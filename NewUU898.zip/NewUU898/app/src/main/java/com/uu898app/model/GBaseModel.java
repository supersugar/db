package com.uu898app.model;


import com.uu898app.module.helper.AccountManager;

/**
 * Created by zhangbo on 2016/6/20.
 */
public class GBaseModel {
    private String SSID = AccountManager.getInstance().getSSID();

    public GBaseModel() {
    }

    public GBaseModel(String SSID) {
        this.SSID = SSID;
    }

    public String getSSID() {
        return SSID;
    }

    public void setSSID(String SSID) {
        this.SSID = SSID;
    }
}
