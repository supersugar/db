package com.uu393.market.module.login;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.R;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;

import org.greenrobot.eventbus.Subscribe;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class RegisterActivity extends BaseActivity {

    @Bind(R.id.tl_register)
    TabLayout mTlRegister;
    @Bind(R.id.vp_register)
    ViewPager mVpRegister;
    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_account);
        ButterKnife.bind(this);
        initTitleBar();
        initTabLayout();
    }
    private void initTitleBar() {
        mTitleBarRight.setVisibility(View.GONE);
        mTitleBarTitle.setText("注册账号");
    }

    private void initTabLayout() {
        mVpRegister.setAdapter(new RegisterPagerAdapter(getSupportFragmentManager()));
        mTlRegister.setupWithViewPager(mVpRegister);
    }

    @OnClick(R.id.title_bar_left)
    public void onClick() {
        super.onBackPressed();
    }

    @Override
    public void onResume() {
        super.onResume();
        EB.register(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EB.unregister(this);
    }

    //处理event事件
    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.REGISTER_SUCCESS:
                this.finish();
                break;
            default:
                break;
        }
    }
}
