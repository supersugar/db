package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    :
 * =====================================================
 */

public class BWithdrawAccountInfo implements Serializable {
    /**
     * {
     * "bankName":"工商银行",（银行名称）
     * "account":"65879",（银行账号）
     * "money":"5698",（可提现余额）
     * "prompt":"提现金额6小时内到账",（提示）
     * "chargeRate":"0.0055"（银行转账手续费率）
     * "minCharge":"2"（最小手续费（元））
     * "maxCharge":"20"（最大手续费（元））
     * "isTX":"true"（是否套现，当时套现时展示文字恶意套现收取总金额2%银行转账手续费）
     * "icon":"http://djedwawe "（银行图标）
     * }
     */

    private String bankName;
    private String account;
    private String money;
    private String prompt;
    private String chargeRate;
    private String minCharge;
    private String maxCharge;

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    private String icon;

    public String getIsTX() {
        return isTX;
    }

    public void setIsTX(String isTX) {
        this.isTX = isTX;
    }

    private String isTX;

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    private String accountName;

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getPrompt() {
        return prompt;
    }

    public void setPrompt(String prompt) {
        this.prompt = prompt;
    }

    public String getChargeRate() {
        return chargeRate;
    }

    public void setChargeRate(String chargeRate) {
        this.chargeRate = chargeRate;
    }

    public String getMinCharge() {
        return minCharge;
    }

    public void setMinCharge(String minCharge) {
        this.minCharge = minCharge;
    }

    public String getMaxCharge() {
        return maxCharge;
    }

    public void setMaxCharge(String maxCharge) {
        this.maxCharge = maxCharge;
    }
}
