package com.uu393.market.module.home;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.response.BServerListInGameDetail;
import com.uu393.market.util.ToastUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/28
 * Descrip    :
 * =====================================================
 */

public class OpenServiceRecyclerAdapter extends RecyclerView.Adapter<OpenServiceRecyclerAdapter.OpenServerceHolder> {

    List<BServerListInGameDetail> bServerListInGameDetails = new ArrayList<>();

    private Context mContext;

    public OpenServiceRecyclerAdapter(Context mContext){
        this.mContext = mContext;

    }

    public void updateData(List<BServerListInGameDetail> list){
        this.bServerListInGameDetails = list;
        notifyDataSetChanged();
    }

    @Override
    public OpenServiceRecyclerAdapter.OpenServerceHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_open_service, parent, false);
        return new OpenServerceHolder(view);
    }

    @Override
    public void onBindViewHolder(OpenServerceHolder holder, int position) {
        holder.bindItem(position);
    }

    @Override
    public int getItemCount() {
            return bServerListInGameDetails.size();
    }

    class OpenServerceHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        private Boolean isChex = true;
        private TextView serviceName;
        private ImageView serviceAlert;
        private View serviceParent;
        private LinearLayout mGetWoringMessage;
        public OpenServerceHolder(View itemView) {
            super(itemView);
            serviceName = (TextView) itemView.findViewById(R.id.tv_item_open_service_name);
            serviceAlert = (ImageView) itemView.findViewById(R.id.iv_item_open_service_alert);
            serviceParent = itemView.findViewById(R.id.item_open_service_parent);
            mGetWoringMessage = (LinearLayout) itemView.findViewById(R.id.item_open_service_parent);
            mGetWoringMessage.setOnClickListener(this);
        }

        public void bindItem(int position){
            /**
             * "serverName": "356服",(服务器名称)
             "openTime": "2017-03-01 00:00:00"(开服时间)
             */
            serviceName.setText(bServerListInGameDetails.get(position).getServerName()+" "+bServerListInGameDetails.get(position).getOpenTime());

        }

        @Override
        public void onClick(View v) {
            if (isChex){
                mGetWoringMessage.setBackgroundResource(R.drawable.shape_corner_stroke_solid_blue);
                serviceAlert.setImageResource(R.drawable.ic_open_service_alert);
                Toast.makeText(mContext,"已添加到开服提醒",Toast.LENGTH_SHORT).show();
                isChex = false;
            }else {
                mGetWoringMessage.setBackgroundResource(R.drawable.shape_corner_stroke_solid_grey);
                serviceAlert.setImageResource(R.drawable.ic_open_service);
                Toast.makeText(mContext,"已取消开服提醒",Toast.LENGTH_SHORT).show();
                isChex = true;
            }

        }
    }
    public void refresh(){
        this.notifyDataSetChanged();
    }
}
