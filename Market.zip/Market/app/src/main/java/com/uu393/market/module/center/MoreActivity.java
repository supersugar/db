package com.uu393.market.module.center;

import android.os.Bundle;

import com.uu393.market.R;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.more.MoreFragment;

public class MoreActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more);
        if (savedInstanceState==null){
            loadRootFragment(R.id.more_activity_container, MoreFragment.newInstance());
        }
    }
}
