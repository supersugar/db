package com.uu393.market.module.mygame;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.InstalledHelper;
import com.uu393.market.core.PlayedHelper;
import com.uu393.market.model.response.BGame;
import com.uu393.market.module.base.BaseTabLazyFragment;
import com.uu393.market.module.manager.ManagerActivity;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.eventbus.EventObject;
import com.uu393.market.util.eventbus.EventString;
import com.uu393.market.util.log.L;

import org.greenrobot.eventbus.Subscribe;

import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/14
 * Descrip    : 我的游戏界面
 * =====================================================
 */
public class MyGameFragment extends BaseTabLazyFragment implements View.OnClickListener {
    private CircleImageView mAvatar;
    private ImageView mIvDownLoad;
    private TabLayout mTabLayout;
    private ViewPager mViewPager;
    private boolean isLogin = false;
    private MyGameViewPagerAdapter myGameViewPagerAdapter;

    public static MyGameFragment newInstance() {
        Bundle args = new Bundle();
        MyGameFragment fragment = new MyGameFragment();
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_game, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mAvatar = (CircleImageView) view.findViewById(R.id.civ_mygame_avatar);
        mIvDownLoad = (ImageView) view.findViewById(R.id.iv_mygame_download);
        mTabLayout = (TabLayout) view.findViewById(R.id.tl_mygame_tab);
        mViewPager = (ViewPager) view.findViewById(R.id.vp_mygame);


        myGameViewPagerAdapter = new MyGameViewPagerAdapter(getChildFragmentManager());
        mViewPager.setAdapter(myGameViewPagerAdapter);
        mTabLayout.setupWithViewPager(mViewPager);
        initViewOnClickListener();

    }

    private void initViewOnClickListener() {
        mAvatar.setOnClickListener(this);//个人中心
        mIvDownLoad.setOnClickListener(this);//下载中心
    }

    @Override
    protected void initLazyView(Bundle savedInstanceState) {
    }

    @Override
    public void onLazyInitView(@Nullable Bundle savedInstanceState) {
        super.onLazyInitView(savedInstanceState);
        L.d("懒加载"+this);
    }

    @Override
    public void onTabReselected() {
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id){
            case R.id.civ_mygame_avatar://
                /*isLogin = (boolean) SPUtil.get(App.mContext,"isLogin",false);
                if (isLogin){
                    //个人中心的唯一入口,传入用户信息
                    Intent intent = new Intent();
                    intent.setClass(_mActivity, UserCenterActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("loginType", (String) SPUtil.get(App.mContext,"loginType",""));
                    bundle.putString("thirdUserId", (String) SPUtil.get(App.mContext,"thirdUserId",""));
                    bundle.putString("userId", (String) SPUtil.get(App.mContext,"userId",""));
                    bundle.putString("token", (String) SPUtil.get(App.mContext,"token",""));
                    bundle.putString("uId", (String) SPUtil.get(App.mContext,"uId",""));
                    bundle.putString("chkMobile", (String) SPUtil.get(App.mContext,"chkMobile",""));
                    intent.putExtras(bundle);
                    startActivity(intent);
                }else {
                    intent.setClass(_mActivity, LoginActivity.class);
                    startActivity(intent);
                }
                break;*/
            case R.id.iv_mygame_download://跳转到下载中心
                startActivity(new Intent(_mActivity, ManagerActivity.class));
                break;
            default:break;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart("MyGameFragment");
        EB.register(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("MyGameFragment");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        L.d("onDestroy");
        EB.unregister(this);
    }

    @Subscribe
    public void onEvent(BaseEvent event) {
        switch (event.tag) {
            case EB.TAG.CLICK_INSATLL://点击了安装按钮
                BGame game = ((EventObject<BGame>) event).result;
                //todo 在安装记录的缓存文件中添加一条记录
                InstalledHelper.getInstance(App.mContext).addOneInstalledRecord(game.getPackageName(),game.getId());
                break;
            case EB.TAG.UNINSTALLED_APP_PACKAGE_NAME://卸载apk完成
                String uninstallPackageName = ((EventString) event).result;
                Map allInstalledRecord = InstalledHelper.getInstance(App.mContext).getAllInstalledRecord();
                if (allInstalledRecord.containsKey(uninstallPackageName)){
                    BGame newUninstallGame = (BGame) allInstalledRecord.get(uninstallPackageName);

                    //todo 在安装记录的缓存文件中删除一条记录
                    InstalledHelper.getInstance(App.mContext).removeOneInstalledRecord(uninstallPackageName);//删除一条记录
                }
                MyGameInstalledListFragment installedFragment = myGameViewPagerAdapter.getInstalledFragment();
                installedFragment.refresh();
                break;

            default:
                break;
        }
    }

}
