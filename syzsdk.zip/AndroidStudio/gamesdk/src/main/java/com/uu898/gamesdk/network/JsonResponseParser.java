package com.uu898.gamesdk.network;

import com.google.gson.Gson;
import com.uu898.gamesdk.log.L;

import org.xutils.http.app.ResponseParser;
import org.xutils.http.request.UriRequest;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.net.URLDecoder;

/**
 * Created by wyouflf on 15/11/5.
 */
public class JsonResponseParser implements ResponseParser {
    @Override
    public void checkResponse(UriRequest uriRequest) throws Throwable {
        L.d(uriRequest);
    }

    /**
     *
     * @param type
     * @param aClass
     * @param s
     * @return
     * @throws Throwable
     */
    @Override
    public Object parse(Type type, Class<?> aClass, String s) throws Throwable {
        //com.xx.gamesdk.model.BaseModel<com.xx.gamesdk.model.response.BImageAuthCode>
        //class com.xx.gamesdk.model.BaseModel
        //
        try {
            s = URLDecoder.decode(s, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
//        JSONObject jsonObject = new JSONObject(s);
//        String data = jsonObject.getString("Data");
        Gson gson = new Gson();
        return gson.fromJson(s, type);
    }

}
