package com.uu898app.model.response;

/**
 * Created by zhangbo on 2016/7/21.
 */
public class BMessage {

    /**
     * rowId : 1
     * ID : 39495569
     * ReceiverID : 13203713938
     * title : 您购买的订单交易失败
     * addTime : 2016/7/7 17:10:00
     * viewed : true
     */

    private int rowId;
    private int ID;
    private String ReceiverID;
    private String title;
    private String addTime;
    private boolean viewed;

    public int getRowId() {
        return rowId;
    }

    public void setRowId(int rowId) {
        this.rowId = rowId;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getReceiverID() {
        return ReceiverID;
    }

    public void setReceiverID(String ReceiverID) {
        this.ReceiverID = ReceiverID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }

    public boolean isViewed() {
        return viewed;
    }

    public void setViewed(boolean viewed) {
        this.viewed = viewed;
    }
}
