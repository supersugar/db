package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/3
 * Descrip    :
 * =====================================================
 */

public class GGetGiftBagDetail {
    /**
     * giftID : 123456（礼包唯一编码）
     */

    private String giftID;

    public String getGiftID() {
        return giftID;
    }

    public void setGiftID(String giftID) {
        this.giftID = giftID;
    }
}
