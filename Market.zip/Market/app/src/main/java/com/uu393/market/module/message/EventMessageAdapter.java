package com.uu393.market.module.message;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.model.response.BMessage;
import com.uu393.market.module.home.HotActionDetailsActivity;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/31
 * Descrip    :
 * =====================================================
 */

public class EventMessageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {


    List<BMessage> BGameMessage = new ArrayList<>();
    private Activity mContext;

    public EventMessageAdapter(Activity mContext){
        this.mContext = mContext;
    }

    public void updateData( List<BMessage> list){
        this.BGameMessage = list;
        notifyDataSetChanged();
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_event_message, parent, false);

        return new EventMessageHolder(view);
    }

    @Override
    public int getItemViewType(int position) {


        return super.getItemViewType(position);
    }


    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof EventMessageHolder){

        }
        ((EventMessageHolder) holder).bindItem(position,getItemViewType(position));
    }

    @Override
    public int getItemCount() {
            return BGameMessage.size();
    }
    public class EventMessageHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private ImageView ivItemIcon;
        private TextView tvItemDescription,tvItemTime;
        private CircleImageView civItemHint;
        private RelativeLayout GMessageDetail;
        BMessage mBMessage;

        public EventMessageHolder(View itemView) {
            super(itemView);
            ivItemIcon = (ImageView) itemView.findViewById(R.id.iv_message_item_icon);
            tvItemDescription = (TextView) itemView.findViewById(R.id.tv_event_message_description);
            tvItemTime = (TextView) itemView.findViewById(R.id.tv_event_message_time);
            civItemHint = (CircleImageView) itemView.findViewById(R.id.civ_message_item_hint);
            GMessageDetail = (RelativeLayout) itemView.findViewById(R.id.go_message_detail);
            GMessageDetail.setOnClickListener(this);
        }
        public void bindItem(int position,int type){

             mBMessage = BGameMessage.get(position);
            tvItemDescription.setText(mBMessage.getTitle());
            tvItemTime.setText(mBMessage.getAddTime());



            if (mBMessage.getInfoType().equals("0")){
                civItemHint.setVisibility(View.GONE);
            }else {
                if (mBMessage.getViewed()) {
                    civItemHint.setVisibility(View.GONE);
                }
            }


            if (mBMessage.getInfoType().equals("0")){
                ivItemIcon.setImageResource(R.drawable.ic_message_gift);
            }else if (mBMessage.getInfoType().equals("1")){
                ivItemIcon.setImageResource(R.drawable.ic_message_voice);
            }else if (mBMessage.getInfoType().equals("2")){
                ivItemIcon.setImageResource(R.drawable.ic_message_alert);
            }
        }

        @Override
        public void onClick(View v) {
            //需要做文本还有活动link

            if (mBMessage.getMesType().equals("0")){
                Intent intentText = new Intent(mContext, EventMessageDetailActivity.class);
                intentText.putExtra("id",mBMessage.getId());
                mContext.startActivity(intentText);
            }else if (mBMessage.getMesType().equals("1")){
                Intent intentLink = new Intent(mContext, EventMessageLinkActivity.class);
                intentLink.putExtra("link",mBMessage.getLink());
                mContext.startActivity(intentLink);
            }
        }
    }
    public void refresh(){
        this.notifyDataSetChanged();
    }
}
