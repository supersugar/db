package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/14
 * Description    : 分享订单
 * =====================================================
 */

public class BShareOrder implements Serializable {
    /**
     * gameName : dddd
     * addTime : 2017-04-13 00:00:00
     * money : 10
     * id : 10
     * status:""已完成”
     */
    /**改为这里
     * "appName":"dddd",（游戏名称）
     "completeTime":"2017-04-13 00:00:00",（时间）
     "totalMoney":"10",（金额）
     "id":"10",（订单唯一编号）
     "status":"已完成",（状态）
     }
     * */

    private String appName;
    private String completeTime;
    private String totalMoney;
    private String id;
    private String status;

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getCompleteTime() {
        return completeTime;
    }

    public void setCompleteTime(String completeTime) {
        this.completeTime = completeTime;
    }

    public String getTotalMoney() {
        return totalMoney;
    }

    public void setTotalMoney(String totalMoney) {
        this.totalMoney = totalMoney;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


}
