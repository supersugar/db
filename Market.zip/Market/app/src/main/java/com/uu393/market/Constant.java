package com.uu393.market;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/16
 * Descrip    :
 * =====================================================
 */

public class Constant {
    public static final String QQ_APP_ID = "1105912404";
    public static final String WX_APP_ID = "wx7fa84c51bbd10e94";
    public static final String WX_APP_SECRET = "2ac4d306840e259da82481a26c7a1285";
    public static final String WB_APP_KEY= "1231207046";

    public static final String XN_SITEID = "kf_9725";
    public static final String XN_SDKKEY = "kf_9725_1421659802125";
    public static final String SETTINGID_ZIXUN = "kf_9725_1421659802125";// 客服组咨询id
    public static final String SETTINGID_CHONGZHI = "kf_9725_1421659815826";// 客服组充值id

    public static final String BUG_TAG_APP_ID= "b617996cc3f64b1cc1f248046e3e43c4";// 日志跟踪sdk的appid

    //应用需要获得哪些接口的权限，由“，”分隔。
    public static String QQ_SCOPE = "all";
    public static String WX_SCOPE = "snsapi_userinfo";
    public static String WB_SCOPE = "email,direct_messages_read,direct_messages_write," +
            "friendships_groups_read,friendships_groups_write,statuses_to_me_read,follow_app_official_microblog,";//微博授权范围
    public static final String WB_REDIRECT_URL = "https://api.weibo.com/oauth2/default.html";// 应用的回调页
    public static final String WB_GET_USER_INFO = "https://api.weibo.com/2/users/show.json";//获取用户信息api
    public static final String UU898_LOGIN_URL = "http://open.uu898.com/open/OAuth/Authorize?client_id=1028850795&scope=getuserinfo&redirect_uri=http://user.shouyouzhu.com/oauth/UUSYUU898Login.aspx&response_type=code";


    public static String WX_GET_TOKEN ="https://api.weixin.qq.com/sns/oauth2/access_token";//通过code获取access_token的接口
    public static String WX_REFRESH_TOKEN ="https://api.weixin.qq.com/sns/oauth2/refresh_token";//刷新或续期access_token使用
    public static String WX_CHECK_TOKEN = "https://api.weixin.qq.com/sns/auth";//检验授权凭证（access_token）是否有效
    public static String WX_GET_USER_INFO= "https://api.weixin.qq.com/sns/userinfo";//获取用户个人信息（UnionID机制）

    /**
     * 当前 DEMO 应用的回调页，第三方应用可以使用自己的回调页。
     *
     * <p>
     * 注：关于授权回调页对移动客户端应用来说对用户是不可见的，所以定义为何种形式都将不影响，
     * 但是没有定义将无法使用 SDK 认证登录。
     * 建议使用默认回调页：https://api.weibo.com/oauth2/default.html
     * </p>
     */
    public static final String REDIRECT_URL = "http://www.sina.com";

    public static final String SCOPE =
            "email,direct_messages_read,direct_messages_write,"
                    + "friendships_groups_read,friendships_groups_write,statuses_to_me_read,"
                    + "follow_app_official_microblog," + "invitation_write";


    public static String REGISTER_TYPE_PHONE = "phone";
    public static String REGISTER_TYPE_CUSTOM = "custom";


    /**
     * 1 绑定手机短信验证码
     2修改绑定手机验证码
     3完善资料验证码
     4手机注册验证码
     5获取用户账户信息验证码
     6手机登录验证码
     7 找回登录密码验证码
     8 修改密码验证码
     9 更改提现账户验证码
     * */
    public static String GET_PHONE_CODE_TYPE_1 = "1";
    public static String GET_PHONE_CODE_TYPE_2 = "2";
    public static String GET_PHONE_CODE_TYPE_3 = "3";
    public static String GET_PHONE_CODE_TYPE_4 = "4";
    public static String GET_PHONE_CODE_TYPE_5= "5";
    public static String GET_PHONE_CODE_TYPE_6= "6";
    public static String GET_PHONE_CODE_TYPE_7= "7";
    public static String GET_PHONE_CODE_TYPE_8 = "8";
    public static String GET_PHONE_CODE_TYPE_9 = "9";
    public static String GET_PHONE_CODE_TYPE_10 = "10";


    //友盟统计自定义事件event_id
    public static String UMENG_EVENT_ID_DOWNLOAD= "UU_001";//点击下载APP游戏按钮
    public static String UMENG_EVENT_ID_PLAY_H5= "UU_002";//点击下载APP游戏按钮
}
