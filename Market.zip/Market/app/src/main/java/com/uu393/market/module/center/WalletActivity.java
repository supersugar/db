package com.uu393.market.module.center;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.DevConfig;
import com.uu393.market.model.response.BUserCenterInfo;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ContactCustomerServicesUtils;
import com.uu393.market.util.ToastUtil;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

public class WalletActivity extends BaseActivity {

    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    TextView mTitleBarRight;
    @Bind(R.id.tv_wallet_number)
    TextView mTvWalletNumber;
    @Bind(R.id.tv_wallet_check_share)
    TextView mTvWalletCheckShare;
    @Bind(R.id.layout_wallet_charge)
    RelativeLayout mLayoutWalletCharge;
    @Bind(R.id.layout_wallet_withdraw)
    RelativeLayout mLayoutWalletWithdraw;
    @Bind(R.id.tv_contact)
    TextView mTvContact;
    @Bind(R.id.rl_wallet_share_layout)
    RelativeLayout mRlWalletShareLayout;
    private BUserCenterInfo mUserInfo;
    private boolean hasBindedBank;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallet);
        ButterKnife.bind(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        doGetUserCenterInfo();
    }

    private void initViews(BUserCenterInfo userInfo) {
        if (userInfo == null) {
            ToastUtil.showToast(App.mContext, "获取用户信息失败");
            mTvWalletNumber.setText("无数据");
            mRlWalletShareLayout.setVisibility(View.GONE);
        } else {
            mTvWalletNumber.setText(userInfo.getMoney());
            //是否是分销用户
            if (!TextUtils.isEmpty(userInfo.getIsShareSale())) {
                if ("true".equals(userInfo.getIsShareSale().trim().toLowerCase())) {
                    mRlWalletShareLayout.setVisibility(View.VISIBLE);//显示查看分享栏
                } else {
                    mRlWalletShareLayout.setVisibility(View.GONE);//隐藏查看分享栏
                }
            } else {
                mRlWalletShareLayout.setVisibility(View.GONE);//隐藏查看分享栏
            }
            //是否已经绑定银行卡
            if (!TextUtils.isEmpty(userInfo.getIsTxBank())) {
                if ("true".equals(userInfo.getIsTxBank().trim().toLowerCase())) {
                    hasBindedBank = true;
                } else {
                    hasBindedBank = false;
                }
            } else {
                hasBindedBank = false;
            }
        }
    }

    @OnClick({R.id.title_bar_left, R.id.title_bar_right, R.id.tv_wallet_number,
            R.id.tv_wallet_check_share, R.id.layout_wallet_charge,
            R.id.layout_wallet_withdraw, R.id.tv_contact})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                super.onBackPressedSupport();
                break;
            case R.id.title_bar_right://钱包明细页
                startActivity(new Intent(this, WalletDetailActivity.class));
                break;
            case R.id.tv_wallet_check_share://查看分享赚
                startActivity(new Intent(this, ShareReportFormActivity.class));
                break;
            case R.id.layout_wallet_charge://充值页
                startActivity(new Intent(this, ChargeMoneyActivity.class));
                break;
            case R.id.layout_wallet_withdraw://提现页
                Intent intent = new Intent(this, WithdrawCashActivity.class);
                intent.putExtra("hasbindedbank", hasBindedBank);
                startActivity(intent);
                break;
            case R.id.tv_contact://客服
                ContactCustomerServicesUtils.doXiaoNeng();
                break;
        }
    }

    //获取个人中心用户账户信息APP040
    private void doGetUserCenterInfo() {
        showLoadToast(WalletActivity.this);
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetUserCenterInfo(new JsonCallback<BUserCenterInfo>() {
            @Override
            public void onSuccess(BUserCenterInfo bUserCenterInfo, Call call, Response response) {
                hideLoadToast();
                if (bUserCenterInfo != null) {
                    mUserInfo = bUserCenterInfo;
                    initViews(mUserInfo);
                } else {
                    initViews(mUserInfo);
                    if (DevConfig.DEBUG){
                        ToastUtil.showToast(App.mContext, "获取用户信息失败");
                    }
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
                initViews(mUserInfo);
            }
        });
    }
}
