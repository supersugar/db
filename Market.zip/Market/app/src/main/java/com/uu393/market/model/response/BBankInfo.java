package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    :
 * =====================================================
 */

public class BBankInfo implements Serializable {
    /**
     * id : 1
     * bankName : 工商银行
     * icon:银行图标
     */

    private String id;
    private String bankName;
    private String icon;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getIcon(){
        return  icon;
    }
    public void setIcon(String icon){
        this.icon = icon;
    }
}
