package com.uu661.model.request;

public class GGetDiamondCodeList {

    public int commodityId;//商品编号
    public String userId;//UZuanApp60004参与记录中返回的userId
    public String killOrderNo;//订单号
    public int periodNo;//期数号

}
