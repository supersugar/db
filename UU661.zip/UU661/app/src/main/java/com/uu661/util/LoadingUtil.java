package com.uu661.util;

import android.app.Activity;

import com.uu661.view.loadtoast.LoadToast;

import java.util.HashMap;
import java.util.Map;

/**
 * 公共的Loading工具类
 * Created by bo on 17/2/17.
 */
public class LoadingUtil {

    private static Map<String, LoadToast> mLoadingMap = new HashMap<>();

    public static void showLoading(Activity activity){
        if(!mLoadingMap.containsKey(activity.toString())){
            mLoadingMap.put(activity.toString(),new LoadToast(activity));
        }
        mLoadingMap.get(activity.toString()).show();
    }

    public static void hideLoading(Activity activity){
        if(null != mLoadingMap && mLoadingMap.containsKey(activity.toString())){
            mLoadingMap.get(activity.toString()).success();
        }
    }

}
