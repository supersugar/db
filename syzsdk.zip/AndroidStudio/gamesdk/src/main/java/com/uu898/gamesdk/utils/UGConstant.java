package com.uu898.gamesdk.utils;

import com.uu898.gamesdk.log.L;

import java.io.File;


public class UGConstant {

    public static final File CACHE_FOLDER = new File(ExternalStorage.getAllStorageLocations().get(ExternalStorage.SD_CARD), "ugsdk");//缓存目录

    static {
        CACHE_FOLDER.mkdirs();
        L.d("CACHE_FOLDER.mkdirs();");
    }

    public static class Cache {
        //登录的用户名，用分号隔开
        public static final String ACCOUNT_LIST = "account_list";

        //是否自动登陆
        public static final String AUTO_LOGIN = "auto_login";

        //是否上次修改了密码(登录后,修改密码成功,需要存为true;每次登录时判断值,如果为true,重置当前账号token,手动输入密码重新登录)
        public static final String LAST_CHANGE_PW = "last_change_pw";

        //存储用户token（根据用户登录名）
        public static final String TOKEN_NAME = "token_%1$s";
    }

}
