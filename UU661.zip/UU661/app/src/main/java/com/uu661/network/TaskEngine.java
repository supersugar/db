package com.uu661.network;

import com.google.gson.Gson;
import com.lzy.okgo.OkGo;
import com.uu661.core.AccountManager;
import com.uu661.core.DevConfig;
import com.uu661.model.BaseModel;
import com.uu661.model.PageModel;
import com.uu661.model.request.GCreateUUOrder;
import com.uu661.model.request.GGetBanner;
import com.uu661.model.request.GGetCouponList;
import com.uu661.model.request.GGetDiamondCodeList;
import com.uu661.model.request.GGetDiamondInfo;
import com.uu661.model.request.GGetDiamondList;
import com.uu661.model.request.GGetOrderDetail;
import com.uu661.model.request.GGetOrderList;
import com.uu661.model.request.GGetPaySign;
import com.uu661.model.request.GGetPayVerifyCode;
import com.uu661.model.request.GGetThirdOrderNo;
import com.uu661.model.request.GGetVerifyCode;
import com.uu661.model.request.GGoPay;
import com.uu661.model.request.GLogin;
import com.uu661.model.request.GLoginThird;
import com.uu661.model.request.GRegist;
import com.uu661.util.CommonUtils;
import com.uu661.util.log.L;

public class TaskEngine {

    private static TaskEngine mTaskEngine;

    private TaskEngine() {
    }

    public static TaskEngine getInstance() {
        if (null == mTaskEngine) {
            mTaskEngine = new TaskEngine();
        }
        return mTaskEngine;
    }


    /**
     * {
     * "mode": "app",
     * "signature": "1a4f1eb4751d8b7a7bcf234c44701a9f",
     * "token": "",
     * "type": "app002"
     * "deviceId": "c6ed6e41651131ee",
     * <p>
     * "data": {
     * "gameName": "",
     * "gameType": "-1"
     * },
     * <p>
     * "page": {
     * "index": 1,
     * "size": 10
     * }
     * <p>
     * }
     *
     * @param type
     * @param data
     * @return
     */
    public static <T> String genReqeustString(String type, T data, PageModel page) {
        BaseModel<T> baseModel = new BaseModel<T>();
        baseModel.setPlatform("apk");//固定
        baseModel.setAppId("1");//固定
        baseModel.setVersion("3.0");//接口版本
        baseModel.setDeviceId(CommonUtils.getDeviceId());
        baseModel.setToken(AccountManager.getInstance().getLoginInfo().token);
        baseModel.setType(type);
        baseModel.setPage(page);
        if (null != data) {
            baseModel.setData(data);
        }
        Gson gson = new Gson();
        String request = gson.toJson(baseModel);
        L.json(request);
        return request;
    }

    private <T> void commonPost(String api, Object model, JsonCallback<T> callback) {
        commonPost(api, model, null, callback);
    }

    private <T> void commonPost(String api, Object model, PageModel page, JsonCallback<T> callback) {
        String url = DevConfig.getInstance().getURL(api);
        L.d(url);
        OkGo.post(DevConfig.getInstance().getURL(api))
                .tag(api)
                .params("UZUAN_APP", genReqeustString(api, model, page))
                .execute(callback);

    }

    /**
     * 获取手机验证码
     */
    public <T> void doGetVerifyCode(GGetVerifyCode model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_VERIFY_CODE, model, callback);
    }

    /**
     * 注册
     */
    public <T> void doRegist(GRegist model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.REGIST, model, callback);
    }

    /**
     * 登陆
     *
     * @param callback
     * @param <T>
     */
    public <T> void doLogin(GLogin model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.LOGIN, model, callback);
    }

    /**
     * 支付策略
     * @param callback
     * @param <T>
     */
    public <T> void doGetPaySetting(JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_PAY_SETTING, null, callback);
    }


    /**
     * 第三方登陆
     *
     * @param callback
     * @param <T>
     */
    public <T> void doThirdLogin(GLoginThird model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.THIRD_LOGIN, model, callback);
    }

    /**
     *
     * @param callback
     * @param <T>
     */
    public <T> void doGetCouponEvent(JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_COUPON_EVENT, null, callback);
    }


    /**
     * 获取用户信息
     * @param callback
     * @param <T>
     */
    public <T> void doGetUserInfo(JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_USER_INFO, null, callback);
    }

    /**
     * 获取用户可用的验证方式
     * @param callback
     * @param <T>
     */
    public <T> void doGetUserVerifyInfo(JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_USER_VERIFY_INFO, null, callback);
    }

    /**
     * 获取支付时验证码
     * @param callback
     * @param <T>
     */
    public <T> void doGetPayVerifyCode(GGetPayVerifyCode model ,JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_PAY_VERIFY_CODE, model, callback);
    }

    /**
     * 获取轮播图
     *
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetBanner(GGetBanner model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_BANNERS, model, callback);
    }

    /**
     * 获取游戏列表
     *
     * @param model
     * @param callback
     * @param page
     * @param <T>
     */
    public <T> void doGetDiamondList(GGetDiamondList model, PageModel page, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_DIAMOND_LIST, model, page, callback);
    }

    /**
     * 获奖记录
     *
     * @param callback
     * @param <T>
     */
    public <T> void doGetAllLuckyManList(JsonCallback<T> callback) {
        commonPost(NetConstant.Api.ALL_LUCKY_MAN_LIST, null, callback);
    }

    /**
     * 获取钻石详情
     *
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetDiamondInfo(GGetDiamondInfo model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_DIAMOND_INFO, model, callback);
    }

    /**
     * 获取计算详情
     * @param model
     * @param page
     * @param callback
     * @param <T>
     */
    public <T> void doGetCalculateDetail(GGetDiamondInfo model, PageModel page, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_CALCULATE_DETAIL, model, page, callback);
    }

    /**
     * 获取钻石数量(返回已买和剩余人次)
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetDiamondNum(GGetDiamondInfo model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_DIAMOND_NUM, model, callback);
    }

    /**
     * 获取U钻每期的购买记录,有分页
     *
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetDiamondBuyRecord(GGetDiamondInfo model, PageModel page, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_DIAMOND_BUY_RECORD, model, page, callback);
    }

    /**
     * 生成UU订单号
     * @param callback
     * @param <T>
     */
    public <T> void doCreateUUOrder(GCreateUUOrder model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.CREATE_UU_ORDER, model, callback);
    }

    /**
     * 获取支付签名
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetPaySign(GGetPaySign model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_PAY_SIGN, model, callback);
    }

    /**
     * 余额支付
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGoPay(GGoPay model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GO_PAY, model, callback);
    }


    /**
     * 获取第三方支付订单号
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetThirdOrderNo(GGetThirdOrderNo model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_THIRD_ORDER_NO, model, callback);
    }

    /**
     * 查询订单详情  1000903927
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetOrderDetail(GGetOrderDetail model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_ORDER_DETAIL, model, callback);
    }

    /**
     * 查询订单列表
     * @param model
     * @param page
     * @param callback
     * @param <T>
     */
    public <T> void doGetOrderList(GGetOrderList model, PageModel page, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_ORDER_LIST, model, page, callback);
    }

    /**
     * 夺钻号码列表
     */
    public <T> void doGetDiamondCodeList(GGetDiamondCodeList model,JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_DIAMOND_CODE_LIST, model, callback);
    }

    /**
     * 获取红包列表
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetCouponList(GGetCouponList model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_COUPON_LIST, model, callback);
    }

    /**
     *  获取版本更新信息
     * @param callback
     * @param <T>
     */
    public <T> void doGetUpdate(JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_UPDATE, null, callback);
    }

}
