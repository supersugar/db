package com.uu661.model.request;

public class GCreateUUOrder {

    public int buyNum;//购买数量
    public int commodityId;//商品编号

}
