package com.uu898app.module.root;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uu898app.R;
import com.uu898app.module.base.BaseLazyFragment;
import com.uu898app.module.discover.DiscoverFragment;
import com.uu898app.util.log.L;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class RootDiscoverFragment extends BaseLazyFragment {

    public static RootDiscoverFragment newInstance() {
        Bundle args = new Bundle();
        RootDiscoverFragment fragment = new RootDiscoverFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return  inflater.inflate(R.layout.root_fragment, container, false);
    }

    @Override
    protected void initLazyView(@Nullable Bundle savedInstanceState) {
        L.d("RootDiscoverFragment.initLazyView");
        if (null == savedInstanceState) {
            loadRootFragment(R.id.fl_container, DiscoverFragment.newInstance());
        }
    }
}
