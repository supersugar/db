package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    : 钱包明细列表
 * =====================================================
 */

public class BWalletFundRecord implements Serializable {

    private String typeName;
    private String addTime;
    private String statusName;
    private String zfMoney;
    private String tradeNo;

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public String getZfMoney() {
        return zfMoney;
    }

    public void setZfMoney(String zfMoney) {
        this.zfMoney = zfMoney;
    }

    public String getTradeNo() {
        return tradeNo;
    }

    public void setTradeNo(String orderNo) {
        this.tradeNo = orderNo;
    }

    /**
     {
     "typeName":"收取货款",（类型名称  收取货款和提现有详情）
     "addTime":"2017-01-01 00:00:00",（操作时间）
     "statusName":"已完成",（状态）
     "zfMoney":"688",（金额）
     "tradeNo":"SC688",（订单编号）
     }
     */


}
