package com.uu393.market.module.search;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.model.response.BGame;
import com.uu393.market.module.h5game.H5GameDetailActivity;
import com.uu393.market.module.home.AppDetailActivity;
import com.uu393.market.util.eventbus.EB;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class LabelAdapter extends  RecyclerView.Adapter<LabelAdapter.ViewHolder> {

    private List<BGame> data = new ArrayList<>();
    private boolean isShowingPosition;
    private Activity activity;
    private static final int[] mBackgroud = new int[]{
            R.drawable.ic_share_label_one,
            R.drawable.ic_share_label_two,
            R.drawable.ic_share_label_three,
            R.drawable.ic_share_label_four,
            R.drawable.ic_share_label_five};

    public LabelAdapter(Activity activity) {
        this.activity = activity;
    }

    public void refreshAdapter(List<BGame> chipsEntities){
        this.data = chipsEntities;
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_search_label, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        if (data.get(position)!=null){
            holder.bindItem(data.get(position));
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (data.get(position).getPlatForm()!=null&& !TextUtils.isEmpty(data.get(position).getPlatForm())){
                        if (data.get(position).getPlatForm().equals("0")){
                            Intent intent = new Intent();
                            intent.setClass(activity, AppDetailActivity.class);
                            intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_ID, data.get(position).getId());
                            activity.startActivity(intent);
                        }else if (data.get(position).getPlatForm().equals("1")){
                            Intent intent = new Intent();
                            intent.setClass(activity, H5GameDetailActivity.class);
                            intent.putExtra("gameId", data.get(position).getId());
                            activity.startActivity(intent);
                        }
                    }
                }
            });
        }

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        private TextView tvName;

        ViewHolder(View itemView) {
            super(itemView);
            tvName = (TextView) itemView.findViewById(R.id.tvName);
        }

        void bindItem(BGame model) {
            itemView.setTag(model.getGameName());
            tvName.setText(model.getGameName());
            Random r = new Random();
            tvName.setBackgroundResource(mBackgroud[r.nextInt(5)]);
        }
    }

}
