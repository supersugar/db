package com.uu393.market.module.message;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.R;
import com.uu393.market.model.PageModel;
import com.uu393.market.model.response.BMessage;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.center.ApkListAdapterNew;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

public class EventMessageActivity extends BaseActivity {

    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;
    @Bind(R.id.rv_event_message)
    PullLoadMoreRecyclerView mRvEventMessage;

    EventMessageAdapter adapter;
    private int mPageIndex = 1;

    List<BMessage> BGameMessage = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_message);
        ButterKnife.bind(this);
        mTitleBarTitle.setText("我的消息");
        mTitleBarRight.setVisibility(View.GONE);
        mRvEventMessage.setLinearLayout();

        adapter = new EventMessageAdapter(EventMessageActivity.this);
        mRvEventMessage.setAdapter(adapter);
        showLoadToast(EventMessageActivity.this);
        mRvEventMessage.setRefreshing(true);

        mRvEventMessage.setOnPullLoadMoreListener(new PullLoadMoreRecyclerView.PullLoadMoreListener() {

            @Override
            public void onRefresh() {
                doGetMessageList(false);
            }

            @Override
            public void onLoadMore() {
                doGetMessageList(true);
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        doGetMessageList(false);
    }

    public void doGetMessageList(final boolean loadMore){

        if(loadMore == false){
            mPageIndex = 1;
        }
        PageModel page = new PageModel(mPageIndex);
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetMessageList(page, new JsonCallback<List<BMessage>>() {

            @Override
            public void onSuccess(List<BMessage> bMessages, Call call, Response response) {
                if (bMessages == null && bMessages.isEmpty()){
                    //无返回结果,需要根据当前页码判断是无结果,还是无更多
                    if(mPageIndex == 1){
                        changeView(false);
                    }else{
                        ToastUtil.showToast(EventMessageActivity.this,"没有更多了~");
                    }
                }else{


                    changeView(true);
                    mPageIndex++;
                    if (loadMore == false) {//非增量加载
                        BGameMessage.clear();
                    }
                    BGameMessage.addAll(bMessages);
                }

            }

            @Override
            public void onAfter(List<BMessage> bMessages, Exception e) {
                super.onAfter(bMessages, e);
                mRvEventMessage.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        adapter.updateData(BGameMessage);
                        mRvEventMessage.setPullLoadMoreCompleted();
                    }
                },100);
                hideLoadToast();
            }
        });


    }


    private void changeView(boolean hasData) {
//        mRvEventMessage.setVisibility(hasData ? View.VISIBLE : View.GONE);
//        mRvEventMessage.setVisibility(hasData ? View.GONE : View.VISIBLE);
    }


    @OnClick(R.id.title_bar_left)
    public void onClick() {
        super.onBackPressedSupport();
    }

}
