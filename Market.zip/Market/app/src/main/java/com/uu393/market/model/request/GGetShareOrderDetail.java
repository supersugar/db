package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/14
 * Description    :
 * =====================================================
 */

public class GGetShareOrderDetail {
    /**
     {
     "id":"25",（订单唯一编号）
     }
     */

    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
