package com.uu393.market.module;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.uu393.market.R;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.util.ImageHelper;
import com.youth.banner.Banner;
import com.youth.banner.BannerConfig;
import com.youth.banner.loader.ImageLoader;

import java.util.ArrayList;
import java.util.List;
/**
 * 折扣页没有立即进入键
 *
 * 主要从个人中心折扣页进入这里
 * */
public class ADActivity extends BaseActivity {
    private Banner mBanner;
    private ImageButton mGoBack;
    private int[] images = {R.drawable.start_1, R.drawable.start_2, R.drawable.start_3};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ad);
        mBanner = (Banner) findViewById(R.id.banner_start);
        mGoBack = (ImageButton) findViewById(R.id.ib_ad_go_back);
        initBanner();
        mGoBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ADActivity.super.onBackPressedSupport();
            }
        });
    }
    private void initBanner() {
        List<Integer> banners = new ArrayList<>();
        for (int i=0;i<images.length;i++){
            banners.add(images[i]);
        }

        mBanner.setImageLoader(new GlideImageLoader());
        mBanner.setImages(banners);
        mBanner.isAutoPlay(false);
        mBanner.setBannerStyle(BannerConfig.CIRCLE_INDICATOR);
        mBanner.setIndicatorGravity(Gravity.CENTER);
        mBanner.start();
    }
    public class GlideImageLoader extends ImageLoader {
        @Override
        public void displayImage(Context context, Object path, ImageView imageView) {
            /**
             注意：
             1.图片加载器由自己选择，这里不限制，只是提供几种使用方法
             2.返回的图片路径为Object类型，由于不能确定你到底使用的那种图片加载器，
             传输的到的是什么格式，那么这种就使用Object接收和返回，你只需要强转成你传输的类型就行，
             切记不要胡乱强转！
             */
            int defaultAndError = ImageHelper.randomImage();
            Glide.with(context).load((int) path).error(defaultAndError).placeholder(defaultAndError).into(imageView);
        }

    }

}
