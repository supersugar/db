package com.uu898.gamesdk.view;

import android.app.Activity;
import android.view.View;
import android.widget.TextView;

import com.uu898.gamesdk.core.ResourceUtils;
import com.uu898.gamesdk.fragmentation.SupportFragment;
import com.uu898.gamesdk.widget.loadtoast.LoadToast;

/**
 * Created by bo on 16/9/21.
 */

public class BaseFragment extends SupportFragment {

    private LoadToast mLoadToast;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mLoadToast = new LoadToast(_mActivity);
    }

    public Activity getSupportActivity(){
        return _mActivity;
    }

    public View initTitleBar(View v, String title){
        TextView tvTitle = (TextView) v.findViewById(getId("ug_tv_title"));
        tvTitle.setText(title);
        v.findViewById(getId("ug_bt_title_left")).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideSoftInput();
                _mActivity.onBackPressed();
            }
        });
        return v.findViewById(getId("ug_title_bar"));
    }

    public void showLoadToast(){
        mLoadToast.show();
    }

    public void hideLoadToast(){
        mLoadToast.success();
    }

    public int getLayoutId(String layoutId){
        return ResourceUtils.getLayoutId(_mActivity, layoutId);
    }

    public int getId(String id){
        return ResourceUtils.getId(_mActivity, id);
    }
}
