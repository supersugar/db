package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/18
 * Descrip    :
 * =====================================================
 */

public class GDoFindPassword {

    /**
     * userId : zzgxl
     * checkCode : 125465
     * decipheringType : 0//（设备类型：0安卓  1 IOS）
     * password : 123456
     */

    private String userId;
    private String checkCode;
    private String decipheringType;
    private String password;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCheckCode() {
        return checkCode;
    }

    public void setCheckCode(String checkCode) {
        this.checkCode = checkCode;
    }

    public String getDecipheringType() {
        return decipheringType;
    }

    public void setDecipheringType(String decipheringType) {
        this.decipheringType = decipheringType;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
