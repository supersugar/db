package com.uu393.market.model.response;

import java.io.Serializable;
import java.util.List;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    : 某天的游戏开服列表返回 bean
 * =====================================================
 */

public class BServerListByTime implements Serializable {
    /**
     * openTime : 8:00
     * serverList : [{"icon":"123456","gameName":"大主宰","androidPackage":"Http:1213","id":"1","serverName":"001服","discount":"1"}]
     */

    private String openTime;
    private List<ServerListBean> serverList;

    public String getOpenTime() {
        return openTime;
    }

    public void setOpenTime(String openTime) {
        this.openTime = openTime;
    }

    public List<ServerListBean> getServerList() {
        return serverList;
    }

    public void setServerList(List<ServerListBean> serverList) {
        this.serverList = serverList;
    }

    public static class ServerListBean {
        /**
         * icon : 123456
         * gameName : 大主宰
         * androidPackage : Http:1213
         * id : 1
         * serverName : 001服
         * discount : 1
         */

        private String icon;
        private String gameName;
        private String androidPackage;
        private String id;
        private String serverName;
        private String discount;
        private String packageName;
        private String versionCode;

        public String getVersionCode() {
            return versionCode;
        }

        public void setVersionCode(String versionCode) {
            this.versionCode = versionCode;
        }

        public String getPackageName() {
            return packageName;
        }

        public void setPackageName(String packageName) {
            this.packageName = packageName;
        }



        public String getIcon() {
            return icon;
        }

        public void setIcon(String icon) {
            this.icon = icon;
        }

        public String getGameName() {
            return gameName;
        }

        public void setGameName(String gameName) {
            this.gameName = gameName;
        }

        public String getAndroidPackage() {
            return androidPackage;
        }

        public void setAndroidPackage(String androidPackage) {
            this.androidPackage = androidPackage;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getServerName() {
            return serverName;
        }

        public void setServerName(String serverName) {
            this.serverName = serverName;
        }

        public String getDiscount() {
            return discount;
        }

        public void setDiscount(String discount) {
            this.discount = discount;
        }
    }
}
