package com.uu393.market.core;

import android.content.Context;

import com.uu393.market.app.App;
import com.uu393.market.util.CacheUtil;

import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/21
 * Descrip    : 记录安装过的APP
 * =====================================================
 */

public class InstalledHelper {
    private static Context mContext;
    private static CacheUtil cacheUtil ;

    private static Map<Object,Object> mInstalledApps ;
    private static InstalledHelper mInstance;

    public static InstalledHelper getInstance(Context context) {
        mContext = context;
        cacheUtil = CacheUtil.get(mContext, "installed_record");
        if (null == mInstance) {
            synchronized (InstalledHelper.class) {
                if (null == mInstance) {
                    mInstance = new InstalledHelper();
                }
            }
        }
        return mInstance;
    }

    private InstalledHelper(){
        mInstalledApps = Collections.synchronizedMap(new HashMap<Object, Object>());
    }

    public void addOneInstalledRecord(Object key,Object value){
        addOneInstalledRecord(mInstalledApps,key,value);
    }


    public void removeOneInstalledRecord(String key){
        if(hasKey(key)){
            mInstalledApps = (Map<Object, Object>) cacheUtil.getAsObject("installed_map");
            mInstalledApps.remove(key);
            cacheUtil.put("installed_map", (Serializable) mInstalledApps);
        }
    }
    private boolean hasKey(Object key){
        getAllInstalledRecord();
        Set<Object> objectSet = mInstalledApps.keySet();
        for (Object object:objectSet){
            if (key.equals(object)){
                return true;
            }
        }
        return false;
    }

    public Map getAllInstalledRecord(){
        mInstalledApps.clear();
        if ((Map<Object, Object>) cacheUtil.getAsObject("installed_map")!=null)
        mInstalledApps.putAll((Map<Object, Object>) cacheUtil.getAsObject("installed_map"));
        return  mInstalledApps;
    }

    private void addOneInstalledRecord(Map<Object,Object> map,Object key,Object value){
        map.put(key,value);
        cacheUtil.put("installed_map", (Serializable) map);
    }

}
