package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/6
 * Descrip    : 添加玩过的游戏记录的请求
 * =====================================================
 */

public class GDoAddPlayedGame {
    /**
     * gameID : 12345
     * platform : 1
     * APPID : 1
     */

    private String gameID;
    private String platform;
    private String APPID;

    public String getGameID() {
        return gameID;
    }

    public void setGameID(String gameID) {
        this.gameID = gameID;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getAPPID() {
        return APPID;
    }

    public void setAPPID(String APPID) {
        this.APPID = APPID;
    }
    /**
     {
     "gameID": "12345",（应用市场ID）
     "platform": "1",（0app游戏   1h5游戏）
     "APPID": "1",（sdk唯一标示）
     }

     */


}
