package com.uu898.gamesdk.model.request;

import com.uu898.gamesdk.model.GBaseModel;

/**
 * Created by bo on 16/9/14.
 */
public class GAddSubAccount extends GBaseModel {

    public String name;


}
