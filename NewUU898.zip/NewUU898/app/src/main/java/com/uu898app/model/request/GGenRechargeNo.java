package com.uu898app.model.request;

import com.uu898app.model.GBaseModel;

/**
 * 生成充值订单model
 * Created by zhangbo on 2016/7/18.
 */
public class GGenRechargeNo extends GBaseModel {

    public static final int TYPE_MOBILE_FEE = 1;//手机费
    public static final int TYPE_MOBILE_DATA = 3;//手机流量
    public static final int TYPE_QQ = 2;//QQ

    /**
     * type : 1
     * money : 10
     * mobileNumber : 13203713938
     * buyCount : 1
     * cardID : 2000976
     * SSID : 0FFC882222BCA9054038A5F81DBCD7E1
     */

    private int type;//充值类型
    private String money;//充值金额
    private String mobileNumber;//手机号/QQ号
    private int buyCount;//数量
    private String cardID;//充值的具体id,比如50M流量/红钻之类对应的id

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public int getBuyCount() {
        return buyCount;
    }

    public void setBuyCount(int buyCount) {
        this.buyCount = buyCount;
    }

    public String getCardID() {
        return cardID;
    }

    public void setCardID(String cardID) {
        this.cardID = cardID;
    }
}
