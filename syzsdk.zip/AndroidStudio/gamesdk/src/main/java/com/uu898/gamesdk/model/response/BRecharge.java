package com.uu898.gamesdk.model.response;

import android.text.TextUtils;

/**
 * Created by bo on 16/9/14*/
public class BRecharge {

    public static final String STATUS_ING = "0";
    public static final String STATUS_SUCCESS = "1";
    public static final String STATUS_CANCEL = "2";
    public static final String STATUS_WAITING = "4";

    public String tradeNo;
    public String addTime;
    public String money;
    public String status;

    public String getStatusForShow(){
        String show = "";
        if(TextUtils.isEmpty(status)){
            show = "未知状态";
        }else if(status.equals(STATUS_ING)){
            show = "处理中";
        }else if(status.equals(STATUS_SUCCESS)){
            show = "充值成功";
        }else if(status.equals(STATUS_CANCEL)){
            show = "充值取消";
        }else if(status.equals(STATUS_WAITING)){
            show = "等待汇款";
        }

        return show;
    }
}
