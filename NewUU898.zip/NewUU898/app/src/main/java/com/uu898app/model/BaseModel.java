package com.uu898app.model;

/**
 * Created by zhangbo on 2016/5/14.
 */
public class BaseModel<T> {


    /**
     * Mode : app
     * Type : App0001
     * Status : null
     * Message : null
     * Key : app
     * Data : {"password":"123456","userName":"ximingfan","uuid":"abc"}
     */

    private String Mode;
    private String Type;
    private String Status;
    private String Message;
    private String Key;
    private T Data;

    public boolean isSuccess() {
        return Status.equals("0");
    }

    public String getMode() {
        return Mode;
    }

    public void setMode(String Mode) {
        this.Mode = Mode;
    }

    public String getType() {
        return Type;
    }

    public void setType(String Type) {
        this.Type = Type;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String Message) {
        this.Message = Message;
    }

    public String getKey() {
        return Key;
    }

    public void setKey(String Key) {
        this.Key = Key;
    }

    public T getData() {
        return Data;
    }

    public void setData(T Data) {
        this.Data = Data;
    }

}
