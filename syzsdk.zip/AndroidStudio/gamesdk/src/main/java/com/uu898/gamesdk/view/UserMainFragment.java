package com.uu898.gamesdk.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uu898.gamesdk.R;
import com.uu898.gamesdk.core.ResourceUtils;
import com.uu898.gamesdk.log.L;
import com.uu898.gamesdk.widget.bottombar.BottomBar;
import com.uu898.gamesdk.widget.bottombar.BottomBarTab;

public class UserMainFragment extends BaseFragment {

    public static final int FIRST = 0;
    public static final int SECOND = 1;
    public static final int THIRD = 2;

    private BaseFragment[] mFragments = new BaseFragment[3];

    private BottomBar mBottomBar;

    public static UserMainFragment newInstance() {
        Bundle args = new Bundle();
        UserMainFragment fragment = new UserMainFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_main_fragment"), container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (savedInstanceState == null) {
            mFragments[FIRST] = UserCenterMoreFragment.newInstance();
            mFragments[SECOND] = UserGiftFragment.newInstance();
            mFragments[THIRD] = UserMessageFragment.newInstance();

            loadMultipleRootFragment(R.id.fl_container, FIRST, mFragments[FIRST], mFragments[SECOND], mFragments[THIRD]);
        } else {
            // 这里库已经做了Fragment恢复,所有不需要额外的处理了, 不会出现重叠问题
            // 这里我们需要拿到mFragments的引用,也可以通过getSupportFragmentManager.getFragments()自行进行判断查找(效率更高些),用下面的方法查找更方便些
            mFragments[FIRST] = findChildFragment(UserCenterMoreFragment.class);
            mFragments[SECOND] = findChildFragment(UserGiftFragment.class);
            mFragments[THIRD] = findChildFragment(UserMessageFragment.class);
        }

        mBottomBar = (BottomBar) view.findViewById(R.id.bottomBar);
        initView(view);
    }


    private void initView(View view) {
        mBottomBar.addItem(new BottomBarTab(_mActivity, R.drawable.ug_ic_tab_user, R.drawable.ug_ic_tab_user_pressed, "用户中心")).addItem(new
                BottomBarTab(_mActivity, R.drawable.ug_ic_tab_gift, R.drawable.ug_ic_tab_gift_pressed, "礼包福利")).addItem(new
                BottomBarTab(_mActivity, R.drawable.ug_ic_tab_message, R.drawable.ug_ic_tab_message_pressed, "消息"));

        mBottomBar.setOnTabSelectedListener(new BottomBar.OnTabSelectedListener() {

            @Override
            public boolean preSelected(int position) {
                return true;
            }

            @Override
            public void onTabSelected(int position, int prePosition) {
                L.d("当前位置" + position + " 前一个位置" + prePosition);
                //如果是点击位置2,即"我的",需要先判断登录状态
                showHideFragment(mFragments[position], mFragments[prePosition]);
            }

            @Override
            public void onTabUnselected(int position) {
            }

            @Override
            public void onTabReselected(int position) {
                L.d("onTabReselected" + position);
//                BaseFragment currentFragment = mFragments[position];
//                if (null != currentFragment) {
//                    currentFragment.onTabReselected();
//                }
            }

        });
    }


}
