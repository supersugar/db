package com.uu661.model.response;

import java.io.Serializable;

/**
 * Created by bo on 16/9/14.
 */
public class BPaySign implements Serializable {

    public String signature;//
}
