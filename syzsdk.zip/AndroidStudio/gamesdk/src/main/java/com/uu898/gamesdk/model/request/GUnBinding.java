package com.uu898.gamesdk.model.request;

import com.uu898.gamesdk.model.GBaseModel;

/**
 * Created by zhangbo on 2016/6/15.
 */
public class GUnBinding extends GBaseModel {


    private String code;//短信验证码

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

}
