package com.uu898.gamesdk.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.uu898.gamesdk.R;
import com.uu898.gamesdk.core.ResourceUtils;
import com.uu898.gamesdk.utils.FloatViewHelper;

import java.util.ArrayList;
import java.util.List;

/**
 *
 */
// TODO: 17/4/25 等待充值接口完成
public class UserDoRechargeFragment extends BaseFragment {

    private TextView mTvTitle;
    private TextView mTvTime;
    private TextView mTvMoeny;

    private static final int PAY_MONEY_5 = 5;
    private static final int PAY_MONEY_10 = 10;
    private static final int PAY_MONEY_50 = 50;
    private static final int PAY_MONEY_100 = 100;
    private static final int PAY_MONEY_500 = 500;
    private static final int PAY_MONEY_1000 = 1000;

    private Button mBt5;
    private Button mBt10;
    private Button mBt50;
    private Button mBt100;
    private Button mBt500;
    private Button mBt1000;
    private EditText mEdtMoney;

    private List<Button> mMoneyBts = new ArrayList<>();
    private int mCurrentPayMoney = PAY_MONEY_5;//默认支付金额是10元



    public static UserDoRechargeFragment newInstance() {
        Bundle args = new Bundle();
        UserDoRechargeFragment fragment = new UserDoRechargeFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_recharge"), container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "选择充值方式");
        initMoneyBts(view);
        setChoosePayMoney();
        mEdtMoney = (EditText) view.findViewById(getId("ug_edt_money"));
        mEdtMoney.addTextChangedListener(mTextWatcher);
        //        view.findViewById(getId("ug_bt_ali_pay")).setOnClickListener(onClickListener);
        //        view.findViewById(getId("ug_bt_wx_pay")).setOnClickListener(onClickListener);

    }

    private void initMoneyBts(View view) {
        mMoneyBts.clear();
        mBt5 = (Button) view.findViewById(getId("ug_bt_5"));
        mBt10 = (Button) view.findViewById(getId("ug_bt_10"));
        mBt50 = (Button) view.findViewById(getId("ug_bt_50"));
        mBt100 = (Button) view.findViewById(getId("ug_bt_100"));
        mBt500 = (Button) view.findViewById(getId("ug_bt_500"));
        mBt1000 = (Button) view.findViewById(getId("ug_bt_1000"));
        mBt5.setTag(PAY_MONEY_5);
        mBt10.setTag(PAY_MONEY_10);
        mBt50.setTag(PAY_MONEY_50);
        mBt100.setTag(PAY_MONEY_100);
        mBt500.setTag(PAY_MONEY_500);
        mBt1000.setTag(PAY_MONEY_1000);
        mBt5.setOnClickListener(mMoneyBtOnClickListener);
        mBt10.setOnClickListener(mMoneyBtOnClickListener);
        mBt50.setOnClickListener(mMoneyBtOnClickListener);
        mBt100.setOnClickListener(mMoneyBtOnClickListener);
        mBt500.setOnClickListener(mMoneyBtOnClickListener);
        mBt1000.setOnClickListener(mMoneyBtOnClickListener);
        mMoneyBts.add(mBt5);
        mMoneyBts.add(mBt10);
        mMoneyBts.add(mBt50);
        mMoneyBts.add(mBt100);
        mMoneyBts.add(mBt500);
        mMoneyBts.add(mBt1000);
    }

    @Override
    public void onResume() {
        super.onResume();
        FloatViewHelper.hideFloatingView();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        FloatViewHelper.showFloatingView();
    }

    View.OnClickListener mMoneyBtOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            mCurrentPayMoney = (int) v.getTag();
            mEdtMoney.setText(mCurrentPayMoney+"");
            mEdtMoney.setSelection(mEdtMoney.getText().length());
            setChoosePayMoney();
        }
    };

    private void  setChoosePayMoney(){
        for (Button temp : mMoneyBts) {
            int tempTag = (int) temp.getTag();
            if (tempTag == mCurrentPayMoney) {
                temp.setBackgroundResource(R.drawable.ug_button_pink_normal);
                temp.setTextColor(getResources().getColor(R.color.white));
            } else {
                temp.setBackgroundResource(R.drawable.ug_edt_bg_corners);
                temp.setTextColor(getResources().getColor(R.color.text_lv1));
            }
        }
    }

    private TextWatcher mTextWatcher = new TextWatcher() {

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            String text = s.toString();
            int len = s.toString().length();
            if (len == 1 && text.equals("0")) {
                s.clear();
            }
            if(len > 0){
                mCurrentPayMoney = Integer.parseInt(s.toString().trim());
                setChoosePayMoney();
            }
        }
    };

}
