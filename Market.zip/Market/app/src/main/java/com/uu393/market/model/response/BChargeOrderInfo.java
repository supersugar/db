package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    :  提交充值订单获取到的bean
 * =====================================================
 */

public class BChargeOrderInfo implements Serializable {
    /**
     * {
     "signOrderNo":"appid=432432432&ben=fdsfdsfdsfds",（签名后的订单信息）
     "tradeOrderNo":"SY342432432432"（支付宝交易订单号）
     }

     */

    private String signOrderNo;
    private String tradeOrderNo;

    public String getSignOrderNo() {
        return signOrderNo;
    }

    public void setSignOrderNo(String signOrderNo) {
        this.signOrderNo = signOrderNo;
    }

    public String getTradeOrderNo() {
        return tradeOrderNo;
    }

    public void setTradeOrderNo(String tradeOrderNo) {
        this.tradeOrderNo = tradeOrderNo;
    }
}
