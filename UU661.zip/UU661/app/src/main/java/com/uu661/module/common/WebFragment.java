package com.uu661.module.common;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.uu661.R;
import com.uu661.module.base.BaseFragment;
import com.uu661.util.log.L;

/**
 * Created by bo on 16/12/30.
 */

public class WebFragment extends BaseFragment {

    private ProgressBar mProgressBar;
    private WebView mWebView;

    private String mUrl;
    private String mTitle;

    public static WebFragment newInstance(String url, String title) {
        WebFragment fragment = new WebFragment();
        Bundle args = new Bundle();
        args.putString("url", url);
        args.putString("title", title);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.web_fragment, null);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Bundle args = getArguments();
        mUrl = args.getString("url");
        L.d("url = " + mUrl);
        mTitle = args.getString("title");
        initTitle(view, mTitle, true);
        mProgressBar = (ProgressBar) view.findViewById(R.id.progress_bar);
        mWebView = (WebView) view.findViewById(R.id.web_view);
        mProgressBar.setMax(100);
        initWebView(mWebView);
        mWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                mProgressBar.setProgress(newProgress);
                if (newProgress >= 100) {
                    mProgressBar.setVisibility(View.GONE);
                }
            }
        });
        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                L.d(url);
                if(url.equals("http://user.uu898.com/appmonitor.aspx")){
                    _mActivity.setResult(Activity.RESULT_OK);
                    _mActivity.finish();
                }else{
                    view.loadUrl(url);
                }
                return true;
            }
        });
        mWebView.loadUrl(mUrl);
    }

    private void initWebView(WebView mWebView) {
        WebSettings mWebSettings = mWebView.getSettings();
        mWebSettings.setSupportZoom(true);//支持缩放，默认为true。是下面那个的前提。
        mWebSettings.setLoadWithOverviewMode(true);// 缩放至屏幕的大小
        mWebSettings.setUseWideViewPort(true);//将图片调整到适合webview的大小
        mWebSettings.setDefaultTextEncodingName("utf-8");//将图片调整到适合webview的大小
        mWebSettings.setLoadsImagesAutomatically(true);//支持自动加载图片
        mWebSettings.setBuiltInZoomControls(true); //设置内置的缩放控件。
        mWebSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);//关闭webview中缓存

        //调用JS方法.安卓版本大于17,加上注解 @JavascriptInterface
        mWebSettings.setJavaScriptEnabled(true);//支持js
    }


    public View initTitle(View v, String title, boolean showBack) {
        TextView tvTitle = (TextView) v.findViewById(R.id.title_bar_title);
        tvTitle.setText(title);
        v.findViewById(R.id.title_bar_left).setVisibility(showBack ? View.VISIBLE : View.GONE);
        v.findViewById(R.id.title_bar_left).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _mActivity.finish();
            }
        });
        return v.findViewById(R.id.title_bar);
    }

    @Override
    public boolean onBackPressedSupport() {
        if (mWebView.canGoBack()) {
            mWebView.goBack();
            return true;
        }
        return super.onBackPressedSupport();
    }
}
