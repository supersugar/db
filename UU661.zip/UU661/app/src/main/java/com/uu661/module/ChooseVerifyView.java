package com.uu661.module;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.flipboard.bottomsheet.BottomSheetLayout;
import com.lzy.okgo.request.BaseRequest;
import com.uu661.R;
import com.uu661.model.request.GGetPayVerifyCode;
import com.uu661.model.response.BPayVerifyCode;
import com.uu661.model.response.BVerifyInfo;
import com.uu661.network.JsonCallback;
import com.uu661.network.TaskEngine;
import com.uu661.util.CountDownTimer;
import com.uu661.util.NoDoubleClickUtils;
import com.uu661.util.StringUtils;
import com.uu661.util.ToastUtil;
import com.uu661.view.gridpasswordview.GridPasswordView;
import com.uu661.view.gridpasswordview.PasswordType;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;


/**
 * Created by bo on 17/1/20.
 */

public class ChooseVerifyView extends FrameLayout {


    @BindView(R.id.pay_support_tv_title) TextView mPaySupportTvTitle;
    @BindView(R.id.pay_support_tv_phone) TextView mPaySupportTvPhone;
    @BindView(R.id.pay_support_bt_send_sms) Button mPaySupportBtSendSms;
    @BindView(R.id.pay_support_password_view_sms) GridPasswordView mPaySupportPasswordViewSms;
    @BindView(R.id.pay_support_view_sms) LinearLayout mPaySupportViewSms;
    @BindView(R.id.pay_support_password_view_ml) GridPasswordView mPaySupportPasswordViewMl;
    @BindView(R.id.pay_support_view_ml) LinearLayout mPaySupportViewMl;
    @BindView(R.id.pay_support_password_view_zf) EditText mPaySupportPasswordViewZf;
    @BindView(R.id.pay_support_bt_zf_next) Button mPaySupportBtZfNext;
    @BindView(R.id.pay_support_view_zf) LinearLayout mPaySupportViewZf;
    @BindView(R.id.pay_support_bt_one) Button mPaySupportBtOne;
    @BindView(R.id.pay_support_bt_two) Button mPaySupportBtTwo;
    @BindView(R.id.pay_support_view_bt) RelativeLayout mPaySupportViewBt;
    @BindView(R.id.pay_support_tv_wx) TextView mPaySupportTvWx;
    @BindView(R.id.pay_support_bt_send_wx) Button mPaySupportBtSendWx;
    @BindView(R.id.pay_support_password_view_wx) GridPasswordView mPaySupportPasswordViewWx;
    @BindView(R.id.pay_support_view_wx) LinearLayout mPaySupportViewWx;
    @BindView(R.id.pay_support_img_close) ImageView mPaySupportImgClose;
    @BindView(R.id.pay_support_view_tv_error) TextView mPaySupportViewTvError;


    //先inflat布局
    //设置数据
    //触发输入框dialog
    //callback返回结果
    private Context mContext;
    private View mView;
    private BottomSheetLayout mBottomSheetLayout;

    private BVerifyInfo mData;
    private String mOrderNo;

    private ChooseVerifyViewListener mListener;

    private int mCurrentTypeTag = -1;

    private CountDownTimer mCountDownTimerSms;
    private CountDownTimer mCountDownTimerWx;

    @OnClick({R.id.pay_support_img_close, R.id.pay_support_bt_send_sms, R.id.pay_support_bt_zf_next, R.id.pay_support_bt_one, R.id
            .pay_support_bt_two, R.id.pay_support_bt_send_wx})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.pay_support_img_close://关闭view
                if (mBottomSheetLayout.isSheetShowing()) {
                    mBottomSheetLayout.dismissSheet();
                }
                break;
            case R.id.pay_support_bt_send_sms://发送短信验证码
                TaskEngine.getInstance().doGetPayVerifyCode(new GGetPayVerifyCode(mOrderNo, GGetPayVerifyCode.SMS), new
                        JsonCallback<BPayVerifyCode>() {
                    @Override
                    public void onBefore(BaseRequest request) {
                        super.onBefore(request);
                        mCountDownTimerSms.start();
                    }

                    @Override
                    public void onSuccess(BPayVerifyCode result, Call call, Response response) {
                        mPaySupportTvPhone.setText(result.sendPhoneNumber + "系统已经将短信验证码发送到您的手机");
                        ToastUtil.showToast(mContext, "短信验证码以发送至您的手机，请注意查收");
                    }

                    @Override
                    public void onError(Call call, Response response, Exception e) {
                        super.onError(call, response, e);
                        mCountDownTimerSms.cancel();
                        mCountDownTimerSms.onFinish();
                    }
                });
                break;
            case R.id.pay_support_bt_send_wx://发送微信验证码
                TaskEngine.getInstance().doGetPayVerifyCode(new GGetPayVerifyCode(mOrderNo, GGetPayVerifyCode.WX), new
                        JsonCallback<BPayVerifyCode>() {

                    @Override
                    public void onBefore(BaseRequest request) {
                        super.onBefore(request);
                        mCountDownTimerWx.start();
                    }

                    @Override
                    public void onSuccess(BPayVerifyCode result, Call call, Response response) {
                        mPaySupportTvWx.setText(result.weChatNickName + "系统已经将微信验证码发送到您的微信");
                        ToastUtil.showToast(mContext, "微信验证码以发送至您的微信客户端，请注意查收");
                    }

                    @Override
                    public void onError(Call call, Response response, Exception e) {
                        super.onError(call, response, e);
                        mCountDownTimerWx.cancel();
                        mCountDownTimerWx.onFinish();
                    }
                });
                break;
            case R.id.pay_support_bt_zf_next://支付密码输入完毕提交(短信/密令/微信这三种都是6位的验证码)
                if (NoDoubleClickUtils.isDoubleClick()) {
                    return;
                }
                String temp0 = mPaySupportPasswordViewZf.getText().toString();
                if (StringUtils.isEmpty(temp0)) {
                    ToastUtil.showToast(mContext, "请输入支付密码");
                } else {
                    doSubmit(BVerifyInfo.TYPE_ZF, temp0);
                }
                break;
            case R.id.pay_support_bt_one://切换按钮1
                //交换按钮1的tag和当前tag
                int temp = (int) mPaySupportBtOne.getTag();
                mPaySupportBtOne.setTag(mCurrentTypeTag);
                showAndHideView(temp);//切换当前类型
                setSwitchBtsText();
                break;
            case R.id.pay_support_bt_two://切换按钮2
                int temp1 = (int) mPaySupportBtTwo.getTag();
                mPaySupportBtTwo.setTag(mCurrentTypeTag);
                showAndHideView(temp1);//切换当前类型
                setSwitchBtsText();
                break;
        }
    }


    public interface ChooseVerifyViewListener {
        void onSubmit(int type, String password);

        void showOrHideSoftInput(boolean show, View v);
    }

    public ChooseVerifyView(Context context, @Nullable BottomSheetLayout root) {
        this(context, null, root);
    }

    public ChooseVerifyView(Context context, AttributeSet attrs, @Nullable BottomSheetLayout root) {
        this(context, attrs, 0, root);
    }

    public ChooseVerifyView(Context context, AttributeSet attrs, int defStyleAttr, @Nullable BottomSheetLayout root) {
        super(context, attrs, defStyleAttr);
        init(context, root);
    }

    private void init(Context context, BottomSheetLayout root) {
        this.mContext = context;
        this.mBottomSheetLayout = root;
        mView = LayoutInflater.from(context).inflate(R.layout.pay_fragment_support_view, root, false);
        ButterKnife.bind(this, mView);//用butterKnife绑定

        addView(mView, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        initGridPasswordView();

        mCountDownTimerSms = new CountDownTimer(60000, 1000, mPaySupportBtSendSms, "获取验证码");
        mCountDownTimerWx = new CountDownTimer(60000, 1000, mPaySupportBtSendWx, "获取验证码");
    }

    private void initGridPasswordView() {
        mPaySupportPasswordViewSms.setPasswordVisibility(true);
        mPaySupportPasswordViewSms.setPasswordType(PasswordType.NUMBER);
        mPaySupportPasswordViewMl.setPasswordVisibility(true);
        mPaySupportPasswordViewMl.setPasswordType(PasswordType.NUMBER);
        mPaySupportPasswordViewWx.setPasswordVisibility(true);
        mPaySupportPasswordViewWx.setPasswordType(PasswordType.NUMBER);

        mPaySupportPasswordViewSms.setOnPasswordChangedListener(new MyPasswordViewListener(BVerifyInfo.TYPE_SMS));
        mPaySupportPasswordViewMl.setOnPasswordChangedListener(new MyPasswordViewListener(BVerifyInfo.TYPE_ML));
        mPaySupportPasswordViewWx.setOnPasswordChangedListener(new MyPasswordViewListener(BVerifyInfo.TYPE_WX));
    }

    public void updateData(BVerifyInfo data) {
        this.mData = data;
        refreshView();
    }

    public void setOrderNo(String orderNo) {
        this.mOrderNo = orderNo;
    }

    public void setOnSubmitListener(ChooseVerifyViewListener listener) {
        mListener = listener;
    }

    public ChooseVerifyViewListener getOnSubmitListener() {
        return mListener;
    }

    /**
     * 处理验证码错误情况
     * 验证码变红
     *
     * @param type
     * @param message
     */
    public void handleVerifyCodeError(int type, String message) {
        if (type == BVerifyInfo.TYPE_SMS) {
            mPaySupportPasswordViewSms.setError();
        } else if (type == BVerifyInfo.TYPE_WX) {
            mPaySupportPasswordViewWx.setError();
        } else if (type == BVerifyInfo.TYPE_ML) {
            mPaySupportPasswordViewMl.setError();
        }
        mPaySupportViewTvError.setVisibility(View.VISIBLE);
        mPaySupportViewTvError.setText(message);
    }

    /**
     * 处理成功情况
     * 底部弹出框消失,软键盘隐藏
     */
    public void handleSuccess() {
        showOrHideSoftInput(false, null);
        if (mBottomSheetLayout.isSheetShowing()) {
            mBottomSheetLayout.dismissSheet();
        }
    }

    /**
     * 业务逻辑相关
     * 如果绑定了微信/密令/手机短信 这三种任何一种验证方式,则不显示支付密码验证
     */
    private void refreshView() {
        if (!mData.getIsBindMobile() && !mData.getIsBindWeChat() && !mData.getIsBindUU()) {//均未绑定
            showAndHideView(BVerifyInfo.TYPE_ZF);
            mPaySupportViewBt.setVisibility(View.INVISIBLE);//切换view按钮不显示
        } else {
            //微信 UU密令 手机 绑定了任意一种
            if (mData.getDefaultValidType() == BVerifyInfo.TYPE_WX && mData.getIsBindWeChat()) {
                mPaySupportBtSendWx.performClick();//第一次弹出时,默认调用下发微信验证码接口
                showAndHideView(BVerifyInfo.TYPE_WX);
                showSwitchBts(BVerifyInfo.TYPE_SMS, BVerifyInfo.TYPE_ML, mData.getIsBindMobile(), mData.getIsBindUU());
            } else if (mData.getDefaultValidType() == BVerifyInfo.TYPE_ML && mData.getIsBindUU()) {
                showAndHideView(BVerifyInfo.TYPE_ML);
                showSwitchBts(BVerifyInfo.TYPE_SMS, BVerifyInfo.TYPE_WX, mData.getIsBindMobile(), mData.getIsBindWeChat());
            } else if (mData.getDefaultValidType() == BVerifyInfo.TYPE_SMS && mData.getIsBindMobile()) {
                mPaySupportBtSendSms.performClick();//第一次弹出时,默认调用下发短信验证码接口
                showAndHideView(BVerifyInfo.TYPE_SMS);
                showSwitchBts(BVerifyInfo.TYPE_ML, BVerifyInfo.TYPE_WX, mData.getIsBindUU(), mData.getIsBindWeChat());
            } else {
                ToastUtil.showToast(mContext, "服务器返回支付方式接口数据有误，只能使用支付密码验证");
                showAndHideView(BVerifyInfo.TYPE_ZF);
                mPaySupportViewBt.setVisibility(View.INVISIBLE);//切换view按钮不显示
            }
        }

    }

    /**
     * 显示切换按钮逻辑
     *
     * @param typeOne
     * @param typeTwo
     */
    private void showSwitchBts(int typeOne, int typeTwo, boolean isBindOne, boolean isBindTwo) {
        if (isBindOne == false && isBindTwo == false) {
            mPaySupportViewBt.setVisibility(View.INVISIBLE);//两种均未绑定
        } else {
            mPaySupportViewBt.setVisibility(View.VISIBLE);//只是绑定了一种
            if (isBindOne && isBindTwo) {//两种都绑定
                mPaySupportBtOne.setVisibility(View.VISIBLE);
                mPaySupportBtTwo.setVisibility(View.VISIBLE);

                mPaySupportBtOne.setTag(typeOne);
                mPaySupportBtTwo.setTag(typeTwo);
            } else {//只绑定了一种
                mPaySupportBtOne.setVisibility(View.VISIBLE);
                mPaySupportBtTwo.setVisibility(View.GONE);
                mPaySupportBtOne.setTag(isBindOne ? typeOne : typeTwo);
                mPaySupportBtTwo.setTag(null);
            }
            setSwitchBtsText();
        }
    }

    private void setSwitchBtsText() {
        //设置文字
        if (null != mPaySupportBtOne.getTag()) {
            if ((int) mPaySupportBtOne.getTag() == BVerifyInfo.TYPE_ML) {//密令
                mPaySupportBtOne.setText("UU密令验证");
            }
            if ((int) mPaySupportBtOne.getTag() == BVerifyInfo.TYPE_SMS) {
                mPaySupportBtOne.setText("短信验证");
            }
            if ((int) mPaySupportBtOne.getTag() == BVerifyInfo.TYPE_WX) {
                mPaySupportBtOne.setText("微信验证");
            }
        }

        if (null != mPaySupportBtTwo.getTag()) {
            if ((int) mPaySupportBtTwo.getTag() == BVerifyInfo.TYPE_ML) {//密令
                mPaySupportBtTwo.setText("UU密令验证");
            }
            if ((int) mPaySupportBtTwo.getTag() == BVerifyInfo.TYPE_SMS) {
                mPaySupportBtTwo.setText("短信验证");
            }
            if ((int) mPaySupportBtTwo.getTag() == BVerifyInfo.TYPE_WX) {
                mPaySupportBtTwo.setText("微信验证");
            }
        }
    }

    /**
     * 展示和隐藏界面
     *
     * @param showType 展示的类型
     */
    private void showAndHideView(int showType) {
        mCurrentTypeTag = showType;
        if (showType == BVerifyInfo.TYPE_ZF) {
            mPaySupportViewZf.setVisibility(View.VISIBLE);
            mPaySupportTvTitle.setText("支付密码验证");
            //支付密码EditText聚焦,弹出输入框
            mPaySupportPasswordViewZf.requestFocus();
            showOrHideSoftInput(true, mPaySupportPasswordViewZf);
        } else {
            mPaySupportViewZf.setVisibility(View.GONE);
        }

        if (showType == BVerifyInfo.TYPE_ML) {
            mPaySupportViewMl.setVisibility(View.VISIBLE);
            mPaySupportTvTitle.setText("UU密令验证");
            performPwViewOnClick(mPaySupportPasswordViewMl);
        } else {
            mPaySupportViewMl.setVisibility(View.GONE);
        }

        if (showType == BVerifyInfo.TYPE_SMS) {
            mPaySupportViewSms.setVisibility(View.VISIBLE);
            mPaySupportTvTitle.setText("短信验证");
            mPaySupportPasswordViewSms.performClick();
            performPwViewOnClick(mPaySupportPasswordViewSms);
        } else {
            mPaySupportViewSms.setVisibility(View.GONE);
        }

        if (showType == BVerifyInfo.TYPE_WX) {
            mPaySupportViewWx.setVisibility(View.VISIBLE);
            mPaySupportTvTitle.setText("微信验证");
            mPaySupportPasswordViewWx.performClick();
            performPwViewOnClick(mPaySupportPasswordViewWx);
        } else {
            mPaySupportViewWx.setVisibility(View.GONE);
        }
    }

    private class MyPasswordViewListener implements GridPasswordView.OnPasswordChangedListener {

        private int pwType;

        public MyPasswordViewListener(int pwType) {
            this.pwType = pwType;
        }

        @Override
        public void onTextChanged(String psw) {
            if (StringUtils.isEmpty(psw)) {
                mPaySupportViewTvError.setVisibility(View.GONE);
            }
        }

        @Override
        public void onInputFinish(String psw) {
            doSubmit(pwType, psw);
        }
    }

    /**
     * 通过接口回调完成事件
     *
     * @param type
     * @param password
     */
    private void doSubmit(int type, String password) {
        //通过回调接口回调到收银台界面
        if (null != mListener) {
            mListener.onSubmit(type, password);
        }
    }

    /**
     * 通过接口回调控制软键盘的展示/隐藏
     *
     * @param show
     * @param v
     */
    private void showOrHideSoftInput(boolean show, View v) {
        if (null != mListener) {
            mListener.showOrHideSoftInput(show, v);
        }
    }

    /**
     * 执行密码输入控件的点击事件,目的是为了使输入框聚焦,并且可以弹出软键盘
     *
     * @param view
     */
    private void performPwViewOnClick(final GridPasswordView view) {
        view.postDelayed(new Runnable() {
            @Override
            public void run() {
                view.performClick();
            }
        }, 300);
    }

}
