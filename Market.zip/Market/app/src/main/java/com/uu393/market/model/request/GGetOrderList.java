package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/3
 * Descrip    :
 * =====================================================
 */

public class GGetOrderList {
    /**
     * APPID : 123456
     * status : 0   //（0:已取消,1:支付完成,2:订单完成,3:订单失败,4:支付超时，已取消
     -2:所有没有完成的订单;
     -3:所有失败的订单
     传空则获取全部信息）
     */

    private String APPID;
    private String status;

    public String getAPPID() {
        return APPID;
    }

    public void setAPPID(String APPID) {
        this.APPID = APPID;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
