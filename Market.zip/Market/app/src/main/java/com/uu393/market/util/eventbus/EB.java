package com.uu393.market.util.eventbus;

import org.greenrobot.eventbus.EventBus;

/**
 * Created by zhangbo on 2016/6/27.
 */
public class EB {

    private static EventBus mEventBus;

    private static EventBus getDefaultEventBus() {
        if (null == mEventBus) {
            mEventBus = EventBus.getDefault();
        }
        return mEventBus;
    }

    public static void register(Object subscriber) {
        if (!getDefaultEventBus().isRegistered(subscriber)) {
            getDefaultEventBus().register(subscriber);
        }

    }

    public static void unregister(Object subscriber) {
        getDefaultEventBus().unregister(subscriber);
    }

    public static void postEmpty(int tag) {
        getDefaultEventBus().post(new EventEmpty(tag));
    }

    public static void postString(int tag, String result) {
        getDefaultEventBus().post(new EventString(tag, result));
    }

    public static <T> void postObject(int tag, T result) {
        getDefaultEventBus().post(new EventObject(tag, result));
    }

    public static <T> void postAnything(int tag, Object... result) {
        getDefaultEventBus().post(new EventAnything(tag, result));
    }

    public static final class TAG {

        public static final int APP_INSTALL = 0;

        public static final int GO_SEARCH = 1;
        public static final int GO_SEARCH_RESULT = 2;

        public static final int CLICK_SEARCH_SUGGEST_ITEM = 3;//点击了搜索的建议item
        public static final int CLICK_SEARCH_LABEL_ITEM = 4;//点击了搜索的标签item
        public static final int CLICK_SEARCH_HISTORY_ITEM = 5;//点击了搜索的历史item

        public static final int GO_ABOUT = 6;
        public static final int CLICK_INSATLL = 7;
        public static final int INSTALLED_APP_PACKAGE_NAME = 8;
        public static final int UNINSTALLED_APP_PACKAGE_NAME = 9;
        public static final int CLICK_PLAY = 10;
        public static final int LOGIN_SUCCESS = 11;
        public static final int HIDE_LOGINING = 12;
        public static final int REGISTER_SUCCESS = 13;
        public static final int TimePicker_kill = 14;
        public static final int REFRESH_IN_SHARE_ORDER_ALL_FRAGMENT = 15;//分享赚报表订单明细页，触发刷新数据
        public static final int SEND_SELECT_DATE_IN_SHARE_POP = 16;//分享赚报表订单明细页时间选择，确定选择后发送选择时间
        public static final int REFRESH_IN_SHARE_MORE_FRAGMENT = 17;//分享赚报表更多数据页，触发刷新数据(发送GGetShareFormMore)
        public static final int REFRESH_IN_SHARE_MORE_ACTIVITY = 18;//分享赚报表更多数据页，fragment刷新数据后数据回传(回传BShareFormMore)
        public static final int SHOW_APP_HOME = 19;//显示UU手游首页
        public static final int REQUEST_SD_CARD = 20;//获取sd卡权限申请，首页
        public static final int REQUEST_SD_CARD_APP_DETAIL = 21;//获取sd卡权限申请，APP详情页
        public static final int REQUEST_SD_CARD_SEARCH = 22;//获取sd卡权限申请，搜索页
        public static final int REQUEST_SD_CARD_DOWNLOAD_CENTER = 23;//获取sd卡权限申请，下载中心
        public static final int REQUEST_SD_CARD_COLLECT_ACTIVITY= 24;//获取sd卡权限申请，我的收藏
        public static final int REQUEST_SD_CARD_SEARCH_OPEN_SERVICE= 25;//获取sd卡权限申请，搜开服界面

    }
}
