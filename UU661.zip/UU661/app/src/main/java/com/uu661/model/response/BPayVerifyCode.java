package com.uu661.model.response;

import java.io.Serializable;

/**
 * Created by bo on 16/9/14.
 */
public class BPayVerifyCode implements Serializable {

    public String weChatNickName;//微信昵称
    public String sendPhoneNumber;//发送手机号
}
