package com.uu393.market.module.manager;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.format.Formatter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.module.base.BaseViewPagerFragment;
import com.uu393.market.util.ApkSearchUtils;
import com.uu393.market.util.ApkUtils;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.log.L;
import com.uu393.market.view.progressbutton.SubmitProcessButton;

import java.io.File;
import java.util.List;

import static android.text.format.Formatter.formatFileSize;
import static com.uu393.market.app.App.mContext;

/**
 * SD卡上apk管理页面
 */
public class SDApkFragment extends BaseViewPagerFragment {

    private ApkSearchUtils utils;

    private RecyclerView mRecyclerView;
    private TextView mTvAvailableSize;
    private TextView mTvTotalSize;
    private ProgressBar mProgressBar;

    private List<ApkSearchUtils.APKInfo> filse;

    private MyAdapter mAdapter;

    public static SDApkFragment newInstance() {
        SDApkFragment fragment = new SDApkFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.manage_sd_apk_fragment, null);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        utils = new ApkSearchUtils(_mActivity);
        mRecyclerView = (RecyclerView) view.findViewById(R.id.sd_recycler_view);
        mTvAvailableSize = (TextView) view.findViewById(R.id.tv_available_size);
        mTvTotalSize = (TextView) view.findViewById(R.id.tv_total_size);
        mProgressBar = (ProgressBar) view.findViewById(R.id.progress_bar);

        setProgress();

        new MyTask().execute();
    }

    private void setProgress() {
        File path = Environment.getExternalStorageDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long totalBlocks = stat.getBlockCount();
        long availableBlocks = stat.getAvailableBlocks();

        mProgressBar.setMax((int) totalBlocks);
        mProgressBar.setProgress((int) availableBlocks);

        mTvAvailableSize.setText( Formatter.formatFileSize(_mActivity, blockSize * availableBlocks));
        mTvTotalSize.setText( Formatter.formatFileSize(_mActivity, blockSize * totalBlocks));
    }


    public void refresh() {

    }

    private class MyTask extends AsyncTask {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Object doInBackground(Object[] params) {
            //检测SD卡是否存在
            File path = null;
            if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                path = Environment.getExternalStorageDirectory();
            } else {
            }
            utils.findAllAPKFile(path, _mActivity);
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            filse = utils.getMyFiles();
            mRecyclerView.setLayoutManager(new LinearLayoutManager(_mActivity) {
                @Override
                public boolean canScrollVertically() {
                    return false;
                }
            });
            mAdapter = new MyAdapter();
            mRecyclerView.setAdapter(mAdapter);
        }
    }

    public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ApkHolder> {

        @Override
        public MyAdapter.ApkHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_manage_sd_apk, parent, false);
            return new MyAdapter.ApkHolder(view);
        }

        @Override
        public void onBindViewHolder(MyAdapter.ApkHolder holder, int position) {
            L.d("onBindViewHolder" + position);
            ApkSearchUtils.APKInfo downloadInfo = filse.get(position);
            //holder更新持有对应的downloadinfo对象
            holder.bind(downloadInfo);
        }

        @Override
        public int getItemCount() {
            return filse.size();
        }

        public class ApkHolder extends RecyclerView.ViewHolder implements View.OnClickListener {


            private ApkSearchUtils.APKInfo apkInfo;
            private ImageView icon;
            private TextView name;
            private TextView version;
            private SubmitProcessButton downloadBt;

            public ApkHolder(View view) {
                super(view);
                icon = (ImageView) view.findViewById(R.id.app_icon);
                name = (TextView) view.findViewById(R.id.tv_one);
                version = (TextView) view.findViewById(R.id.tv_two);
                downloadBt = (SubmitProcessButton) view.findViewById(R.id.download_bt);
            }

            public void bind(ApkSearchUtils.APKInfo info) {
                this.apkInfo = info;
                icon.setImageDrawable(info.getApkIcon());
                name.setText(info.getApkName());
                version.setText("版本 v" + info.getVersionName());
                downloadBt.setOnClickListener(this);
                downloadBt.setProgress("安装");
            }

            @Override
            public void onClick(View v) {
                if (v.getId() == R.id.download_bt) {
                    //已安装的打开,未安装的安装
                    File temp = new File(apkInfo.getFilepath());
                    if (ApkUtils.hasInstalled(mContext, temp)) {
                        //EB.postObject(EB.TAG.CLICK_PLAY,gameModel);
                        ApkUtils.launchApp(mContext, temp);
                    } else {
                        ApkUtils.install(mContext, temp);
                        //EB.postObject(EB.TAG.CLICK_INSATLL,gameModel);//todo 4 SD卡  点击安装了
                    }
                }
            }

        }

    }


    /**
     * 获得SD卡总大小
     *
     * @return
     */
    private String getSDTotalSize() {
        File path = Environment.getExternalStorageDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long totalBlocks = stat.getBlockCount();
        return formatFileSize(_mActivity, blockSize * totalBlocks);
    }

    /**
     * 获得sd卡剩余容量，即可用大小
     *
     * @return
     */
    private String getSDAvailableSize() {
        File path = Environment.getExternalStorageDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long availableBlocks = stat.getAvailableBlocks();
        return formatFileSize(_mActivity, blockSize * availableBlocks);
    }

}
