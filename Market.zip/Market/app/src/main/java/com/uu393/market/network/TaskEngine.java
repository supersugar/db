package com.uu393.market.network;

import com.google.gson.Gson;
import com.lzy.okgo.OkGo;
import com.uu393.market.app.App;
import com.uu393.market.core.DevConfig;
import com.uu393.market.model.BaseModel;
import com.uu393.market.model.PageModel;
import com.uu393.market.model.request.GDoAddPlayedGame;
import com.uu393.market.model.request.GDoBindBank;
import com.uu393.market.model.request.GDoBindPhone;
import com.uu393.market.model.request.GDoChangeBank;
import com.uu393.market.model.request.GDoChangeWithdrawPassword;
import com.uu393.market.model.request.GDoCheckUpdate;
import com.uu393.market.model.request.GDoCommitChargeOrderInfo;
import com.uu393.market.model.request.GDoCommitWithdrawOrderInfo;
import com.uu393.market.model.request.GDoFindPassword;
import com.uu393.market.model.request.GDoJoinShareEarn;
import com.uu393.market.model.request.GDoLogin;
import com.uu393.market.model.request.GDoModifyPassword;
import com.uu393.market.model.request.GDoRemoveBindPhone;
import com.uu393.market.model.request.GDoThirdLogin;
import com.uu393.market.model.request.GDoUploadComment;
import com.uu393.market.model.request.GDoVerifyPhoneCode;
import com.uu393.market.model.request.GGetBanner;
import com.uu393.market.model.request.GGetGameDetail;
import com.uu393.market.model.request.GGetGameList;
import com.uu393.market.model.request.GGetGiftBagDetail;
import com.uu393.market.model.request.GGetH5AppIdAndKey;
import com.uu393.market.model.request.GGetH5GameList;
import com.uu393.market.model.request.GGetHotActivityDetail;
import com.uu393.market.model.request.GGetMessageDetail;
import com.uu393.market.model.request.GGetMessageList;
import com.uu393.market.model.request.GGetMultiGameDetail;
import com.uu393.market.model.request.GGetOrderDetail;
import com.uu393.market.model.request.GGetOrderList;
import com.uu393.market.model.request.GGetPayedInfo;
import com.uu393.market.model.request.GGetPhoneCode;
import com.uu393.market.model.request.GDoRegister;
import com.uu393.market.model.request.GGetSearchList;
import com.uu393.market.model.request.GGetServerListByGameId;
import com.uu393.market.model.request.GGetServerListByGameName;
import com.uu393.market.model.request.GGetServerListByTime;
import com.uu393.market.model.request.GGetShareFormHomeUserInfoByDay;
import com.uu393.market.model.request.GGetShareFormMore;
import com.uu393.market.model.request.GGetShareOrderDetail;
import com.uu393.market.model.request.GGetShareOrderList;
import com.uu393.market.model.request.GGetWalletFundRecord;
import com.uu393.market.model.request.GGetWalletIncomeDetail;
import com.uu393.market.model.request.GGetWalletWithdrawDetail;
import com.uu393.market.model.response.GGetSomeGameDetail;
import com.uu393.market.util.CommonUtils;
import com.uu393.market.util.MD5;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.log.L;

public class TaskEngine {

    public static void setTokenUseridPhoneState(int tokenUseridPhoneState) {
        TOKEN_USERID_PHONE_STATE = tokenUseridPhoneState;
    }

    private static int TOKEN_USERID_PHONE_STATE = 0;
    private static TaskEngine mTaskEngine;

    private TaskEngine() {
    }

    public static TaskEngine getInstance() {
        if (null == mTaskEngine) {
            mTaskEngine = new TaskEngine();
        }
        return mTaskEngine;
    }


    /**
     * {
     * "mode": "app",
     * "signature": "1a4f1eb4751d8b7a7bcf234c44701a9f",
     * "token": "",
     * "type": "app002"
     * "deviceId": "c6ed6e41651131ee",
     * "data": {
     * "gameName": "",
     * "gameType": "-1"
     * },
     * "page": {
     * "index": 1,
     * "size": 10
     * }
     * }
     *
     * @param type
     * @param data
     * @return
     */
    public static <T> String genReqeustString(String type, T data, PageModel page) {
        BaseModel<T> baseModel = new BaseModel<T>();
        //必传固定参数
        baseModel.setDeviceId(CommonUtils.getDeviceId());//根据设备固定
        baseModel.setMode("app");
        baseModel.setToken("");

        // TODO: 2017/2/18 token 和userID 和PhoneNumber三者在获取手机验证码时 只传一个
        switch (TOKEN_USERID_PHONE_STATE) {
            case 1://绑定手机发送验证码、找回密码发送验证码
                baseModel.setToken("");
                break;
            case 2://自动登录、绑定手机、修改密码
                baseModel.setToken((String) SPUtil.get(App.mContext, "token", ""));
                break;
        }

        //必传动态参数
        baseModel.setType(type);
        //签名必须和token一致
        baseModel.setSignature(MD5.getMD5((baseModel.getToken() + CommonUtils.getDeviceId() + NetConstant.APP_KEY).getBytes()));

        //非必传参数
        baseModel.setPage(page);
        if (null != data) {
            baseModel.setData(data);
        }

        Gson gson = new Gson();
        String request = gson.toJson(baseModel);
        L.json(request);//请求bean会打印两次
        return request;
    }

    private <T> void commonPost(String api, Object model, JsonCallback<T> callback) {
        commonPost(api, model, null, callback);
    }

    private <T> void commonPost(String api, Object model, PageModel page, JsonCallback<T> callback) {
        OkGo.post(DevConfig.getInstance().getURL())
                .params("SYZ_APP", genReqeustString(api, model, page))
                .execute(callback);
        App.EXCEPTION_URL.setLength(0);
        App.EXCEPTION_URL
                .append("请求地址url：\n")
                .append(DevConfig.getInstance().getURL())
                .append("SYZ_APP")
                .append(genReqeustString(api, model, page));
    }

    /**
     * 获取游戏类型
     *
     * @param callback
     * @param <T>
     */
    public <T> void doGetGameKinds(JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_GAME_KINDS, null, callback);
    }

    /**
     * 获取游戏列表
     *
     * @param model
     * @param callback
     * @param page
     * @param <T>
     */
    public <T> void doGetGameList(GGetGameList model, PageModel page, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_GAME_LIST, model, page, callback);
    }

    /**
     * 获取搜索结果列表
     *
     * @param model
     * @param callback
     * @param page
     * @param <T>
     */
    public <T> void doGetSearchList(GGetSearchList model, PageModel page, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_GAME_LIST, model, page, callback);
    }

    /**
     * 获取游戏详情
     *
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetGameDetail(GGetGameDetail model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_GAME_DETAIL, model, callback);
    }

    /**
     * 获取广告图片
     *
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetBanner(GGetBanner model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_BANNER, model, callback);
    }

    /**
     * 获取热门游戏列表
     *
     * @param callback
     * @param <T>
     */
    public <T> void doGetHotGameList(JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_HOT_GAME, null, callback);
    }

    /**
     * 检查更新
     *
     * @param callback
     * @param <T>
     */
    public <T> void doCheckUpdate(GDoCheckUpdate model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.CHECK_UPDATE, model, callback);
    }

    /**
     * @author wangxian
     * 获取图片验证码 ：APP007
     */
    public <T> void doGetImageCode(JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_IMAGE_CODE, null, callback);
    }

    /**
     * @author wangxian
     * 注册账号：APP008
     */
    public <T> void doRegister(GDoRegister model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.DO_ACCOUNT_REGISTER, model, callback);
    }

    /**
     * @author wangxian
     * 获取手机验证码 ：APP009
     */
    public <T> void doGetPhoneCode(GGetPhoneCode model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_PHONE_CODE, model, callback);
    }

    /**
     * @author wangxian
     * 用户登录：APP010
     */
    public <T> void doLogin(GDoLogin model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.DO_LOGIN, model, callback);
    }

    /**
     * @author wangxian
     * 绑定手机号 ：APP011
     */
    public <T> void doBindPhone(GDoBindPhone model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.DO_BIND_PHONE, model, callback);
    }

    /**
     * @author wangxian
     * 找回密码：APP012
     */
    public <T> void doFindPassword(GDoFindPassword model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.DO_FIND_PASSWORD, model, callback);
    }

    /**
     * @author wangxian
     * 修改密码：APP014
     */
    public <T> void doModifyPassword(GDoModifyPassword model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.DO_MODIFY_PASSWORD, model, callback);
    }

    /**
     * @author wangxian
     * 获取H5首页4个在玩游戏列表：APP015
     */
    public <T> void doGetH5ZaiWan(JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_H5_GAME_ZAIWAN, null, callback);
    }

    /**
     * @author wangxian
     * 获取H5所有在玩游戏列表：APP016
     */
    public <T> void doGetH5ZaiWanAll(JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_H5_GAME_ZAIWAN_ALL, null, callback);
    }

    /**
     * @author wangxian
     * 三方登录接口：APP017
     */
    public <T> void doThirdLogin(GDoThirdLogin model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.DO_THIRD_LOGIN, model, callback);
    }

    /**
     * @author wangxian
     * 获取H5游戏三个展示图片接口：APP018
     */
    public <T> void doGetH5Tree(JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_H5_GAME_THREE, null, callback);
    }

    /**
     * @author wangxian
     * 获取H5游戏详情接口：APP019
     */
    public <T> void doGetH5GameDetail(GGetGameDetail model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_H5_GAME_DETAIL, model, callback);
    }

    /**
     * @author wangxian
     * 获取H5游戏列表接口：APP020
     */
    public <T> void doGetH5GameList(GGetH5GameList model, PageModel page, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_H5_GAME_LIST, model, page, callback);
    }

    /**
     * @author wangxian
     * 获取用户充值信息：APP021
     */
    public <T> void doGetPayedInfo(GGetPayedInfo model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_PAYED_INFO, model, callback);
    }

    /**
     * @author wangxian
     * 获取订单列表：APP022
     */
    public <T> void doGetOrderList(GGetOrderList model, PageModel page, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_ORDER_LIST, model, page, callback);
    }

    /**
     * @author wangxian
     * 获取订单详情：APP023
     */
    public <T> void doGetOrderDetail(GGetOrderDetail model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_ORDER_DETAIL, model, callback);
    }

    /**
     * @author wangxian
     * 获取礼包列表：APP024
     */
    public <T> void doGetGiftBagList(GGetGameDetail model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_GIFT_BAG_LIST, model, callback);
    }

    /**
     * @author wangxian
     * 获取礼包详情：APP025
     */
    public <T> void doGetGiftBagDetail(GGetGiftBagDetail model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_GIFT_BAG_DETAIL, model, callback);
    }

    /**
     * @author wangxian
     * 获取礼包兑换码：APP026
     */
    public <T> void doGetGiftBagCode(GGetGiftBagDetail model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_GIFT_BAG_CODE, model, callback);
    }

    /**
     * @author wangxian
     * 添加一条玩过的游戏记录：APP027
     */
    public <T> void doAddOnePlayedGame(GDoAddPlayedGame model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.DO_ADD_PLAYED_GAME, model, callback);
    }

    /**
     * @author wangxian
     * 上传推荐人信息：APP028
     */
    public <T> void doUploadComment(GDoUploadComment model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.DO_UPLOAD_COMMENT, model, callback);
    }

    /**
     * @author wangxian
     * 获取H5游戏的APPID和APPKey：APP029
     */
    public <T> void doGetH5AppIdAndKey(GGetH5AppIdAndKey model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_H5_APPID_KEY, model, callback);
    }

    /**
     * @author wangxian
     * 获取游戏题材：APP030
     */
    public <T> void doGetGameThemes(JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_GAME_THEMES, null, callback);
    }

    /**
     * @author wangxian
     * 获取游戏开服列表通过 游戏id：APP031
     */
    public <T> void doGetServerListByGameId(GGetServerListByGameId model, PageModel page, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_SERVER_LIST_BY_GAME_ID, model,page, callback);
    }

    /**
     * @author wangxian
     * 获取游戏开服列表通过 日期：APP032
     */
    public <T> void doGetServerListByTime(GGetServerListByTime model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_SERVER_LIST_BY_TIME, model,callback);
    }

    /**
     * @author wangxian
     * 获取游戏开服列表通过 游戏名字：APP033
     */
    public <T> void doGetServerListByGameName(GGetServerListByGameName model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_SERVER_LIST_BY_GAME_NAME, model, callback);
    }

    /**
     * @author wangxian
     * 获取热门活动列表：APP034
     */
    public <T> void doGetHotActivityList(GGetGameList model,PageModel page,JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_HOT_ACTIVITY_LIST, model,page, callback);
    }

    /**
     * @author wangxian
     * 获取热门活动详情：APP035
     */
    public <T> void doGetHotActivityDetail(GGetHotActivityDetail model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_HOT_ACTIVITY_DETAIL, model, callback);
    }

    /**
     * @author wangxian
     * 获取消息列表：APP036
     */
    public <T> void doGetMessageList(PageModel page, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_MESSAGE_LIST, page, callback);
    }

    /**
     * @author wangxian
     * 获取消息详情：APP037
     */
    public <T> void doGetMessageDetail(GGetMessageDetail model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_MESSAGE_DETAIL, model, callback);
    }

    /**
     * @author wangxian
     * 获取多个游戏详情：APP038
     */
    public <T> void doGetMultiGameDetail(GGetMultiGameDetail model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_MULTI_GAME_DETAIL, model, callback);
    }

    /**
     * @author wangxian
     * 获取优惠券列表：APP039
     */
    public <T> void doGetCouponTicketList(JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_COUPON_TICKET_LIST, null, callback);
    }

    /**
     * @author wangxian
     * 获取个人中心用户信息（区别于登录后个人信息）：APP040
     */
    public <T> void doGetUserCenterInfo(JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_USER_CENTER_INFO, null, callback);
    }

    /**
     * @author wangxian
     * 提交充值订单信息：APP041
     */
    public <T> void doCommitChargeOrderInfo(GDoCommitChargeOrderInfo model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.DO_COMMIT_CHARGE_ORDER_INFO, model, callback);
    }

    /**
     * @author wangxian
     * 提交银行列表信息：APP042
     */
    public <T> void doGetBankList(JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_BANK_LIST, null, callback);
    }

    /**
     * @author wangxian
     * 绑定银行卡信息：APP043
     */
    public <T> void doBindBank(GDoBindBank model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.DO_BIND_BANK, model, callback);
    }

    /**
     * @author wangxian
     * 获取用户绑定的银行信息：APP044
     */
    public <T> void doGetWithdrawAccountInfo(JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_WITHDRAW_ACCOUNT_INFO, null, callback);
    }

    /**
     * @author wangxian
     * 提交提现订单信息：APP045
     */
    public <T> void doCommitWithdrawOrderInfo(GDoCommitWithdrawOrderInfo model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.DO_COMMIT_WITHDRAW_ORDER_INFO, model, callback);
    }

    /**
     * @author wangxian
     * 更改提现账户即银行卡：APP046
     */
    public <T> void doChangeBank(GDoChangeBank model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.DO_CHANGE_BANK, model, callback);
    }

    /**
     * @author wangxian
     * 更改提现密码：APP047
     */
    public <T> void doChangeWithdrawPassword(GDoChangeWithdrawPassword model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.DO_CHANGE_WITHDRAW_PASSWORD, model, callback);
    }
    /**
     * @author wangxian
     * 获取资金记录列表：APP048
     */
    public <T> void doGetWalletFundRecord(GGetWalletFundRecord model, PageModel page,JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_WALLET_RECORD, model,page, callback);
    }
    /**
     * @author wangxian
     * 获取收取货款详情：APP049
     */
    public <T> void doGetWalletIncomeDetail(GGetWalletIncomeDetail model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_WALLET_INCOME_DETAIL, model, callback);
    }
    /**
     * @author wangxian
     * 获取提现详情：APP050
     */
    public <T> void doGetWalletWithdrawDetail(GGetWalletWithdrawDetail model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_WALLET_WITHDRAW_DETAIL, model, callback);
    }
    /**
     * @author wangxian
     * 参加分享赚：APP051
     */
    public <T> void doJoinShareEarn(GDoJoinShareEarn model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.DO_JOIN_SHARE_EARN, model, callback);
    }
    /**
     * @author wangxian
     * 获取分享赚首页用户统计信息：APP052
     */
    public <T> void doGetShareFormHomeUserInfoTotal(JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_SHARE_FORM_HOME_USER_INFO_TOTAL, null, callback);
    }
    /**
     * @author wangxian
     * 获取分享赚首页简单的用户统计：APP053
     */
    public <T> void doGetShareFormHomeUserInfoByDay(GGetShareFormHomeUserInfoByDay model,JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_SHARE_FORM_HOME_USER_INFO_BY_DAY, model, callback);
    }
    /**
     * @author wangxian
     * 获取分享赚更多数据：APP054
     */
    public <T> void doGetShareFormMore(GGetShareFormMore model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_SHARE_FORM_MORE, model, callback);
    }
    /**
     * @author wangxian
     * 获取分享订单列表：APP055 分页加载
     */
    public <T> void doGetShareOrderList(GGetShareOrderList model,PageModel page, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_SHARE_ORDER_LIST, model,page, callback);
    }
    /**
     * @author wangxian
     * 获取分享订单详情：APP056
     */
    public <T> void doGetShareOrderDetail(GGetShareOrderDetail model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_SHARE_ORDER_DETAIL, model, callback);
    }

    /**
     * @author z
     * 获取某个游戏的所有活动：APP057
     */
    public <T> void doGetSomeGameDetail(GGetSomeGameDetail model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_SHARE_GASME_DETAIL, model, callback);
    }

    /**
     * @author wangxian
     * 获取用户是否绑定手机号：APP058
     */
    public <T> void doGetUserIsBindPhone(JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_IS_BIND_PHONE, null, callback);
    }

    /**
     * 获取游戏礼包列表：APP059
     */
    public <T> void doGetGameGiftBaglist(GGetGameDetail model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_Game_GiftBag_List, model, callback);
    }


    /**
     * 获取游戏礼包列表：APP061
     */
    public <T> void doGetGiftBagDetailNoH5(GGetGiftBagDetail model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_GIFT_BAGNHTML_CODE, model, callback);
    }

    /**
     * @author wangxian
     * 检验手机验证码是否正确：APP013
     */
    public <T> void doVerifyPhoneCode(GDoVerifyPhoneCode model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.DO_CHECK_PHONE_CODE, model, callback);
    }

    /**
     * @author wangxian
     * 解除绑定手机：APP060
     */
    public <T> void doRemoveBindPhone(GDoRemoveBindPhone model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.DO_REMOVE_BIND_PHONE, model, callback);
    }

    /**
     * @author wangxian
     * 获取游戏详情新版base64：APP062，，替换003
     */
    public <T> void doGetGameDetailNew(GGetGameDetail model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_GAME_DETAIL_NEW, model, callback);
    }

    /**
     * @author wangxian
     * 获取H5游戏详情接口新版base64：APP063,替换019
     */
    public <T> void doGetH5GameDetailNew(GGetGameDetail model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_H5_GAME_DETAIL_NEW, model, callback);
    }

    /**
     * @author wangxian
     * 获取礼包详情新版base64：APP064，替换025
     */
    public <T> void doGetGiftBagDetailNew(GGetGiftBagDetail model, JsonCallback<T> callback) {
        commonPost(NetConstant.Api.GET_GIFT_BAG_DETAIL_NEW, model, callback);
    }

}
