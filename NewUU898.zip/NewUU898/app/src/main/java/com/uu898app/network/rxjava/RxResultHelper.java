package com.uu898app.network.rxjava;

import com.uu898app.model.BaseModel;
import com.uu898app.network.Network;

import rx.Observable;
import rx.Subscriber;
import rx.functions.Func1;

/**
 * Created by zhangbo on 2016/6/30.
 */
public class RxResultHelper {
    public static <T> Observable.Transformer<BaseModel<T>, T> handleResult() {
        return new Observable.Transformer<BaseModel<T>, T>() {
            @Override
            public Observable<T> call(Observable<BaseModel<T>> tObservable) {
                return tObservable.flatMap(new Func1<BaseModel<T>, Observable<T>>() {
                            @Override
                            public Observable<T> call(BaseModel<T> result) {
                                if (result.isSuccess()) {
                                    return Observable.just(result.getData());
                                } else if (result.getStatus() == "") {
                                    // 处理被踢出登录情况
                                } else {
                                    return Observable.error(new Network.APIException(result.getStatus(), result.getMessage()));
                                }
                                return Observable.empty();
                            }
                        }
                );
            }
        };
    }

    private static <T> Observable<T> createData(final T t) {
        return Observable.create(new Observable.OnSubscribe<T>() {
            @Override
            public void call(Subscriber<? super T> subscriber) {
                try {
                    subscriber.onNext(t);
                    subscriber.onCompleted();
                } catch (Exception e) {
                    subscriber.onError(e);
                }
            }
        });
    }
}