package com.uu898app.view.loadtoast;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;

import com.nineoldandroids.view.ViewHelper;
import com.nineoldandroids.view.ViewPropertyAnimator;

/**
 * 原理是通过当前activity找到decorview，然后add一个自定义的view
 * 三个方法show，success，error，都是对view执行了一个动画，用以控制view的显示和隐藏
 * 同时调用了自定义view的show，success，error方法，这样自定义view内部也可以执行相应的动画效果
 */
public class LoadToast {

    private String mText = "";
    private LoadToastView mView;
    private ViewGroup mParentView;
    private int mTranslationY = 0;
    private boolean mShowCalled = false;
    private boolean mToastCanceled = false;
    private boolean mInflated = false;
    private boolean mVisible = false;


    public LoadToast(Context context){
        mView = new LoadToastView(context);
        mParentView = (ViewGroup) ((Activity) context).getWindow().getDecorView().findViewById(android.R.id.content);
        mParentView.addView(mView, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        ViewHelper.setAlpha(mView, 0);
        mParentView.postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.d("xx" ,"mParentView.postDelayed执行");
                //这里有个延迟任务，目的就是为了满足这种情况new LoadToast(this).show();实例化以后直接调show方法，有可能
                //界面还没有准备好，所以当界面准备好以后看有没有show的指示，有的话show出来
//                ViewHelper.setTranslationX(mView, (mParentView.getWidth() - mView.getWidth()) / 2);
//                ViewHelper.setTranslationY(mView, mParentView.getHeight() /2 );
                mInflated = true;
                if(!mToastCanceled && mShowCalled){
                    show();
                }
            }
        },1);

        mParentView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                checkZPosition();
            }
        });
    }

    public LoadToast setTranslationY(int pixels){
        mTranslationY = pixels;
        return this;
    }

    public LoadToast setBackgroundColor(int color){
        mView.setBackgroundColor(color);
        return this;
    }

    public LoadToast setProgressColor(int color){
        mView.setProgressColor(color);
        return this;
    }

    public LoadToast show(){
        Log.d("xx" ,"show()执行");
        if(mInflated == false){//没有inflated完成，只是表示应调用了show方法就返回
            mShowCalled = true;
            return this;
        }
        mView.show();
        ViewHelper.setAlpha(mView, 0f);
        ViewHelper.setTranslationX(mView, (mParentView.getWidth() - mView.getWidth()) / 2);
        ViewHelper.setTranslationY(mView, mParentView.getHeight() /2 );
        ViewPropertyAnimator.animate(mView)
                .alpha(1f)
//                .translationY(25 + mTranslationY)
                .setInterpolator(new DecelerateInterpolator())
                .setDuration(0)
                .setStartDelay(500)
                .start();

        mVisible = true;
        checkZPosition();
        return this;
    }
    private void slideUp(){
        ViewPropertyAnimator.animate(mView)
                .setStartDelay(0)
                .alpha(0f)
//                .translationY(-mView.getHeight() + mTranslationY)
                .setInterpolator(new AccelerateInterpolator())
                .setDuration(0)
                .start();

        mVisible = false;
    }


    public void success(){
        if(!mInflated){
            mToastCanceled = true;
            return;
        }
        mView.success();
        slideUp();
    }

    public void error(){
        if(!mInflated){
            mToastCanceled = true;
            return;
        }
        mView.error();
        slideUp();
    }

    private void checkZPosition(){
        // If the toast isn't visible, no point in updating all the views
        if(!mVisible) return;

        int pos = mParentView.indexOfChild(mView);
        int count = mParentView.getChildCount();
        if(pos != count-1){
            ((ViewGroup) mView.getParent()).removeView(mView);
            mParentView.requestLayout();
            mParentView.addView(mView, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
        }
    }
}
