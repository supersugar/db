package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/13
 * Description    :
 * =====================================================
 */

public class GDoCommitWithdrawOrderInfo {
    /**
     {
     "money":"60",（要提现的金额）
     "actMoney":"58",（实际提现金额）
     "payPassword":"FDSEAS",（提现密码（加密））
     "decipheringType": "0"（设备类型：0安卓  1 IOS）
     "ip": "0.0.0.0"（ip地址）
     }
     */

    private String money;
    private String actMoney;
    private String payPassword;

    public String getDecipheringType() {
        return decipheringType;
    }

    public void setDecipheringType(String decipheringType) {
        this.decipheringType = decipheringType;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    private String decipheringType;
    private String ip;

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getActMoney() {
        return actMoney;
    }

    public void setActMoney(String actMoney) {
        this.actMoney = actMoney;
    }

    public String getPayPassword() {
        return payPassword;
    }

    public void setPayPassword(String payPassword) {
        this.payPassword = payPassword;
    }
}
