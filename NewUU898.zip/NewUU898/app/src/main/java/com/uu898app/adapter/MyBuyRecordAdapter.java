package com.uu898app.adapter;

import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.uu898app.R;
import com.uu898app.model.response.BOrderCommon;
import com.uu898app.network.NetConstant;

import java.util.List;

/**
 *
 */
public class MyBuyRecordAdapter extends BaseQuickAdapter<BOrderCommon> {

    public MyBuyRecordAdapter(List<BOrderCommon> data) {
        super(R.layout.home_grid_item_big, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, BOrderCommon item) {
        helper.setText(R.id.tv_title, item.getTitle());
        Glide.with(mContext).load(NetConstant.URL.BASE_IMAGE_URL + item.getImages()).crossFade().into((ImageView) helper.getView(R.id.img));
    }
}
