package com.uu898.gamesdk.model.request;

import com.uu898.gamesdk.model.GBaseModel;

public class GGetRechargeList extends GBaseModel {

    private String status;//商品编号

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
