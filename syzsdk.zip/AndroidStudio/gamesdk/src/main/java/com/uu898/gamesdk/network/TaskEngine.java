package com.uu898.gamesdk.network;

import android.net.Network;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.uu898.gamesdk.core.UGCoreHelper;
import com.uu898.gamesdk.log.L;
import com.uu898.gamesdk.model.BaseModel;
import com.uu898.gamesdk.model.GBaseModel;
import com.uu898.gamesdk.model.request.GBinding;
import com.uu898.gamesdk.model.request.GChangePassword;
import com.uu898.gamesdk.model.request.GDeleteMessages;
import com.uu898.gamesdk.model.request.GGetMessageDetail;
import com.uu898.gamesdk.model.request.GGetOrderDetail;
import com.uu898.gamesdk.model.request.GGetOrderList;
import com.uu898.gamesdk.model.request.GGetOrderStatus;
import com.uu898.gamesdk.model.request.GGetPayMoney;
import com.uu898.gamesdk.model.request.GGetRechargeList;
import com.uu898.gamesdk.model.request.GGetSMSAuthCode;
import com.uu898.gamesdk.model.request.GLogin;
import com.uu898.gamesdk.model.request.GPay;
import com.uu898.gamesdk.model.request.GRegister;
import com.uu898.gamesdk.model.request.GResetPassword;
import com.uu898.gamesdk.model.request.GUnBinding;
import com.uu898.gamesdk.model.request.GVerifyCurrentPhone;
import com.uu898.gamesdk.model.request.GAddSubAccount;
import com.uu898.gamesdk.model.response.BAliPay;
import com.uu898.gamesdk.model.response.BImageAuthCode;
import com.uu898.gamesdk.model.response.BLogin;
import com.uu898.gamesdk.model.response.BMessage;
import com.uu898.gamesdk.model.response.BOrder;
import com.uu898.gamesdk.model.response.BOrderStatus;
import com.uu898.gamesdk.model.response.BPayMoney;
import com.uu898.gamesdk.model.response.BRecharge;
import com.uu898.gamesdk.model.response.BRegister;
import com.uu898.gamesdk.model.response.BSubAccount;
import com.uu898.gamesdk.model.response.BUserInfo;

import org.xutils.http.RequestParams;
import org.xutils.x;

import java.util.List;

/**
 * Created by zhangbo on 2016/6/22.
 */
public class TaskEngine {

    private static TaskEngine mTaskEngine;
    private Network mNetwork;

    private TaskEngine() {
    }

    public static TaskEngine getInstance() {
        if (null == mTaskEngine) {
            mTaskEngine = new TaskEngine();
        }
        return mTaskEngine;
    }


    private String genReqeustString(String type, GBaseModel data) {
        BaseModel<GBaseModel> baseModel = new BaseModel<GBaseModel>();
        baseModel.setData(data);
        baseModel.setType(type);
        baseModel.setKey("syzsdk");
        baseModel.setMode("app");
        Gson gson = new Gson();
        String request = gson.toJson(baseModel);
        L.json(request);
        return request;
    }

    private RequestParams genRequestParams(String type, GBaseModel model) {
        RequestParams params = new RequestParams(UGCoreHelper.getURL());
        L.d(UGCoreHelper.getURL());
        params.addParameter("SYZ_APP", genReqeustString(type, model));
        return params;
    }


    private <T> void xPost(RequestParams params, NetCallback<T> callback) {
        callback._onStart();
        x.http().post(params, callback);
    }

    /**
     * 获取图片验证码
     *
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetImageAuthCode(GBaseModel model, NetCallback<T> callback) {
        callback.setTargetClass(BImageAuthCode.class);
        xPost(genRequestParams(NetConstant.ApiType.GET_IMAGE_AUTH_CODE, model), callback);
    }


    /**
     * 获取短信验证码
     *
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetSMSAuthCode(GGetSMSAuthCode model, NetCallback<T> callback) {
        xPost(genRequestParams(NetConstant.ApiType.GET_SMS_AUTH_CODE, model), callback);
    }

    /**
     * 注册
     *
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doRegister(GRegister model, NetCallback<T> callback) {
        callback.setTargetClass(BRegister.class);
        xPost(genRequestParams(NetConstant.ApiType.REGISTER, model), callback);
    }

    /**
     * 登陆
     *
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doLogin(GLogin model, NetCallback<T> callback) {
        callback.setTargetClass(BLogin.class);
        xPost(genRequestParams(NetConstant.ApiType.LOGIN, model), callback);
    }

    /**
     * 获取用户信息
     *
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetUserInfo(GBaseModel model, NetCallback<T> callback) {
        callback.setTargetClass(BUserInfo.class);
        xPost(genRequestParams(NetConstant.ApiType.GET_USER_INFO, model), callback);
    }

    /**
     * 绑定手机
     *
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doBindingPhone(GBinding model, NetCallback<T> callback) {
        xPost(genRequestParams(NetConstant.ApiType.BINDING_PHONE, model), callback);
    }

    /**
     * 重置密码
     *
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doResetPassword(GResetPassword model, NetCallback<T> callback) {
        xPost(genRequestParams(NetConstant.ApiType.RESET_PASSWORD, model), callback);
    }

    /**
     * 支付宝支付
     *
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doAliPay(GPay model, NetCallback<T> callback) {
        callback.setTargetClass(BAliPay.class);
        xPost(genRequestParams(NetConstant.ApiType.PAY, model), callback);
    }

    /**
     * 获取订单列表
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetOrderList(GGetOrderList model, NetCallback<T> callback) {
        callback.setTargetType(new TypeToken<List<BOrder>> () {}.getType());
        xPost(genRequestParams(NetConstant.ApiType.GET_ORDER_LIST, model), callback);
    }

    /**
     * 获取订单详情
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetOrderDetail(GGetOrderDetail model, NetCallback<T> callback) {
        callback.setTargetClass(BOrder.class);
        xPost(genRequestParams(NetConstant.ApiType.GET_ORDER_DETAIL, model), callback);
    }

    /**
     * 查询订单状态
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetOrderStatus(GGetOrderStatus model, NetCallback<T> callback) {
        callback.setTargetClass(BOrderStatus.class);
        xPost(genRequestParams(NetConstant.ApiType.GET_ORDER_STATUS, model), callback);
    }

    /**
     * 验证当前手机
     *
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doVerifyCurrentPhone(GVerifyCurrentPhone model, NetCallback<T> callback) {
        xPost(genRequestParams(NetConstant.ApiType.VERIFY_CURRENT_PHONE, model), callback);
    }

    /**
     * 换绑手机
     *
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doChangeBindingPhone(GBinding model, NetCallback<T> callback) {
        xPost(genRequestParams(NetConstant.ApiType.CHANGE_BINDING_PHONE, model), callback);
    }

    /**
     * 修改密码
     *
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doChangePassword(GChangePassword model, NetCallback<T> callback) {
        xPost(genRequestParams(NetConstant.ApiType.CHANGE_PASSWORD, model), callback);
    }

    /**
     * 获取消息列表
     *
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetMessageList(GBaseModel model, NetCallback<T> callback) {
        callback.setTargetType(new TypeToken<List<BMessage>> () {}.getType());
        xPost(genRequestParams(NetConstant.ApiType.GET_MESSAGE_LIST, model), callback);
    }

    /**
     * 删除消息列表
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doDeleteMessages(GDeleteMessages model, NetCallback<T> callback) {
        xPost(genRequestParams(NetConstant.ApiType.DELETE_MESSAGES, model), callback);
    }

    /**
     * 获取消息详情
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetMessageDetail(GGetMessageDetail model, NetCallback<T> callback) {
        callback.setTargetClass(BMessage.class);
        xPost(genRequestParams(NetConstant.ApiType.GET_MESSAGE_DETAIL, model), callback);
    }

    /**
     * 获取充值金额
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetPayMoney(GGetPayMoney model, NetCallback<T> callback) {
        callback.setTargetClass(BPayMoney.class);
        xPost(genRequestParams(NetConstant.ApiType.GET_PAY_MONEY, model), callback);
    }

    /**
     * 获取充值记录列表
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetRechargeList(GGetRechargeList model, NetCallback<T> callback) {
        callback.setTargetType(new TypeToken<List<BRecharge>> () {}.getType());
        xPost(genRequestParams(NetConstant.ApiType.GET_RECHARGE_LIST, model), callback);
    }

    /**
     * 解绑手机
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doUnBinding(GUnBinding model, NetCallback<T> callback) {
        xPost(genRequestParams(NetConstant.ApiType.DO_UNBINDING, model), callback);
    }

    /**
     * 获取充值记录列表
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetGiftList(GGetRechargeList model, NetCallback<T> callback) {
        callback.setTargetType(new TypeToken<List<BRecharge>> () {}.getType());
        xPost(genRequestParams(NetConstant.ApiType.GET_RECHARGE_LIST, model), callback);
    }

    /**
     * 获取小号列表
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doGetSubAccountList(GBaseModel model, NetCallback<T> callback) {
        callback.setTargetClass(BSubAccount.class);
        xPost(genRequestParams(NetConstant.ApiType.GET_SUB_ACCOUNT_LIST, model), callback);
    }

    /**
     * 添加小号
     * @param model
     * @param callback
     * @param <T>
     */
    public <T> void doAddSubAccountList(GAddSubAccount model, NetCallback<T> callback) {
        xPost(genRequestParams(NetConstant.ApiType.ADD_SUB_ACCOUNT, model), callback);
    }
}
