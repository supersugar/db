package com.uu898.gamesdk.support.result;

/**
 * Created by bo on 16/10/17.
 */

public class UGPayResult {

    public static final int CODE_SUCCESS = 0;//成功
    public static final int CODE_CANCLE = 1;//取消
    public static final int CODE_PARAMS_WRONG = 2;//参数有误
    public static final int CODE_NOT_LOGIN = 3;//未登陆
    public static final int CODE_LOGIN_OUT_OF_DATE = 4;//登陆失效
    public static final int CODE_FAIL = 5;//支付失败

    public int resultCode = 0;
}
