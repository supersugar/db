package com.uu661.model.response;

import java.io.Serializable;

/**
 * Created by bo on 16/9/14.
 */
public class BDiamondInfo implements Serializable {

    public BDiamond commodityInfo;//
    public int beforePeriodNo;//上期期号
    public BLuckyManDetail winnerInfo;//(0:游戏详情页面  1:活动页面)
    public String myCodeList;//游戏ID
    public int myCodeCount = -1;//我的夺钻码数量
    public int winCodeCount;//中奖者购买数量
    public long delay;//

    public BDiamond getCommodityInfo() {
        return commodityInfo;
    }

    public void setCommodityInfo(BDiamond commodityInfo) {
        this.commodityInfo = commodityInfo;
    }

    public int getBeforePeriodNo() {
        return beforePeriodNo;
    }

    public void setBeforePeriodNo(int beforePeriodNo) {
        this.beforePeriodNo = beforePeriodNo;
    }

    public BLuckyManDetail getWinnerInfo() {
        return winnerInfo;
    }

    public void setWinnerInfo(BLuckyManDetail winnerInfo) {
        this.winnerInfo = winnerInfo;
    }

    public String getMyCodeList() {
        return myCodeList;
    }

    public void setMyCodeList(String myCodeList) {
        this.myCodeList = myCodeList;
    }

    public long getDelay() {
        return delay;
    }

    public void setDelay(long delay) {
        this.delay = delay;
    }

    public int getMyCodeCount() {
        return myCodeCount;
    }

    public void setMyCodeCount(int myCodeCount) {
        this.myCodeCount = myCodeCount;
    }

    public int getWinCodeCount() {
        return winCodeCount;
    }

    public void setWinCodeCount(int winCodeCount) {
        this.winCodeCount = winCodeCount;
    }
}
