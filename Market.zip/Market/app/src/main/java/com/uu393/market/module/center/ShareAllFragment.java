package com.uu393.market.module.center;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.PageModel;
import com.uu393.market.model.request.GGetShareOrderList;
import com.uu393.market.model.response.BShareOrder;
import com.uu393.market.module.base.BaseViewPagerFragment;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.BaseEvent;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.util.eventbus.EventAnything;
import com.uu393.market.util.eventbus.EventObject;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;

import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

/**
 * Created by Administrator on 2017/4/12.
 */

public class ShareAllFragment extends BaseViewPagerFragment implements View.OnClickListener {
    private static final String KEY_KIND = "kind";
    private static final String KEY_MODEL = "model";
    private PullLoadMoreRecyclerView mRecyclerView;
    private ShareAllRecyclerViewAdapter mAdapter;
    private View mLayoutNoResult;
    private Button mBtNoResult;
    private TextView mTvNoResultHint;
    private View mLayoutFunctionNotOpen;
    private View mLayoutFunctionOpen;
    private String mKind;
    private List<BShareOrder> mShareOrders;
    private GGetShareOrderList mGetShareOrderListModel;
    private int mPage = 1;//页数
    private boolean mIsLoadMore = false;//是否是加载更多

    public ShareAllFragment(){
        mShareOrders = new ArrayList<>();
    }

    public static ShareAllFragment newInstance(String kind,GGetShareOrderList getShareOrderListModel) {
        Bundle bundle = new Bundle();
        bundle.putString(KEY_KIND, kind);
        bundle.putSerializable(KEY_MODEL, getShareOrderListModel);//初始化时传入默认查询条件
        ShareAllFragment fragment = new ShareAllFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mKind = getArguments().getString(KEY_KIND);
            mGetShareOrderListModel = (GGetShareOrderList) getArguments().getSerializable(KEY_MODEL);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_share_all, container, false);
        mRecyclerView = (PullLoadMoreRecyclerView) view.findViewById(R.id.recycler_view);
        mLayoutNoResult = view.findViewById(R.id.layout_no_result);//无结果视图
        mLayoutFunctionOpen = view.findViewById(R.id.layout_share_all_function_open);//功能开通视图
        mLayoutFunctionNotOpen = view.findViewById(R.id.layout_function_not_open);//未开通功能视图
        mBtNoResult = (Button) view.findViewById(R.id.bt_no_result);//无结果视图中按钮
        mTvNoResultHint = (TextView) view.findViewById(R.id.tv_no_result_hint_text);//无结果视图中文本提示
        if ("H5游戏".equals(mKind)) {
            showFunctionOpen(false);
        }else {
            showFunctionOpen(true);
        }
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initRecyclerView();
    }

    @Override
    public void onResume() {
        super.onResume();
        EB.register(this);
        if (!"H5游戏".equals(mKind)) {
            this.refresh();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EB.unregister(this);
    }

    private void initRecyclerView() {
        mRecyclerView.setLinearLayout();
        mRecyclerView.setIsRefresh(true);
        mRecyclerView.setPullRefreshEnable(true);
        mRecyclerView.setPushRefreshEnable(true);
        mAdapter = new ShareAllFragment.ShareAllRecyclerViewAdapter();
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setOnPullLoadMoreListener(new PullLoadMoreRecyclerView.PullLoadMoreListener() {
            @Override
            public void onRefresh() {
                mIsLoadMore = false;
                ShareAllFragment.this.refresh();
            }

            @Override
            public void onLoadMore() {
                mIsLoadMore = true;
                ShareAllFragment.this.refresh();
            }
        });
    }

    private void showResult(boolean hasResult) {
        if (hasResult) {
            mRecyclerView.setVisibility(View.VISIBLE);
            mLayoutNoResult.setVisibility(View.GONE);
        } else {
            mRecyclerView.setVisibility(View.GONE);
            mLayoutNoResult.setVisibility(View.VISIBLE);
            mTvNoResultHint.setText("暂无数据");
            mBtNoResult.setText("点击刷新");
            mBtNoResult.setOnClickListener(this);
        }
    }

    //显示是否开通功能
    private void showFunctionOpen(boolean hasOpen) {
        if (hasOpen) {
            mLayoutFunctionOpen.setVisibility(View.VISIBLE);
            mLayoutFunctionNotOpen.setVisibility(View.GONE);
        } else {
            mLayoutFunctionOpen.setVisibility(View.GONE);
            mLayoutFunctionNotOpen.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void refresh() {
        doGetShareOrderList(mGetShareOrderListModel,mIsLoadMore);//显示视图，刷新数据
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bt_no_result://刷新页面数据
                this.refresh();
                break;
        }
    }
    //处理上层Activity传来的搜索条件对象，刷新数据
    @Subscribe
    public void onEvent(BaseEvent event){
        switch (event.tag){
            case EB.TAG.REFRESH_IN_SHARE_ORDER_ALL_FRAGMENT://触发刷新数据
                if (event instanceof EventAnything){
                    Object[] objects = ((EventAnything) event).result;
                    for (Object object:objects){
                        if (object instanceof GGetShareOrderList){
                            mGetShareOrderListModel = (GGetShareOrderList) object;
                            mIsLoadMore =false;//不是加载更多
                            ShareAllFragment.this.refresh();
                        }
                    }

                }
                break;
        }
    }

    public class ShareAllRecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private List<BShareOrder> mOrders=new ArrayList<>();
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_wallet_all_recycler_view, parent, false);
            return new ShareAllViewHolder(view);
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
            if (holder != null && holder instanceof ShareAllViewHolder) {
                ((ShareAllViewHolder) holder).bindItem(mOrders.get(position));
                ((ShareAllViewHolder) holder).itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //分享赚记录单项详情
                        if (mShareOrders.get(position)==null|| TextUtils.isEmpty(mShareOrders.get(position).getId()))
                            return;
                        Intent intent = new Intent(_mActivity, ShareReportFormOrderDetailActivity.class);
                        intent.putExtra(ShareReportFormOrderDetailActivity.INTENT_KEY_ORDER_ID,mShareOrders.get(position).getId());
                        _mActivity.startActivity(intent);
                    }
                });
            }
        }

        @Override
        public int getItemCount() {
            return mOrders.size();
        }

        public void refresh(List<BShareOrder> orders){
            if (orders==null) return;
            this.mOrders.clear();
            this.mOrders.addAll(orders);
            this.notifyDataSetChanged();
        }

        class ShareAllViewHolder extends RecyclerView.ViewHolder {
            private TextView itemTitle, itemStatus, itemTime, itemMoney;

            public ShareAllViewHolder(View itemView) {
                super(itemView);
                itemTitle = (TextView) itemView.findViewById(R.id.tv_item_title);
                itemStatus = (TextView) itemView.findViewById(R.id.tv_item_status);
                itemTime = (TextView) itemView.findViewById(R.id.tv_item_time);
                itemMoney = (TextView) itemView.findViewById(R.id.tv_item_money);

            }

            public void bindItem(BShareOrder order) {
                if (order ==null){
                    itemTitle.setText("无数据");
                    itemStatus.setText("无数据");
                    itemTime.setText("无数据");
                    itemMoney.setText("无数据");
                }else {
                    itemTitle.setText(order.getAppName());
                    itemStatus.setText(order.getStatus());
                    itemTime.setText(order.getCompleteTime());
                    itemMoney.setText(order.getTotalMoney());
                }

            }
        }
    }


    private void doGetShareOrderList(GGetShareOrderList model, final boolean loadMore){
        if (model ==null) return;
        showLoadToast();
        if (!loadMore) {
            mPage = 1;
        }
        //分页加载
        PageModel pageModel = new PageModel(mPage);
        pageModel.size = 20;
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetShareOrderList(model,pageModel, new JsonCallback<List<BShareOrder>>() {
            @Override
            public void onSuccess(List<BShareOrder> bShareOrderList, Call call, Response response) {
                hideLoadToast();
                if (bShareOrderList == null||bShareOrderList.isEmpty()){
                    if (mPage==1){
                        mShareOrders.clear();
                    }else {
                        ToastUtil.showToast(App.mContext, "没有更多了~");
                    }
                }else {
                    mPage++;
                    if (!loadMore){
                        mShareOrders.clear();
                    }
                    mShareOrders.addAll(bShareOrderList);
                }
            }
            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
                mShareOrders.clear();
            }

            @Override
            public void onAfter(List<BShareOrder> bShareOrders, Exception e) {
                super.onAfter(bShareOrders, e);
                mRecyclerView.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mAdapter.refresh(mShareOrders);
                        mRecyclerView.setPullLoadMoreCompleted();
                        if(mShareOrders==null||mShareOrders.isEmpty()){
                            showResult(false);
                        }else {
                            showResult(true);
                        }
                    }
                }, 100);
            }
        });
    }
}
