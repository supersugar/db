package com.uu661.network;


import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import com.lzy.okgo.callback.AbsCallback;
import com.lzy.okgo.request.BaseRequest;
import com.uu661.app.App;
import com.uu661.model.PageModel;
import com.uu661.module.base.BaseFragment;
import com.uu661.util.StringUtils;
import com.uu661.util.ToastUtil;
import com.uu661.util.log.L;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.net.ConnectException;
import java.net.SocketTimeoutException;

import okhttp3.Call;
import okhttp3.Response;


public abstract class JsonCallback<T> extends AbsCallback<T> {

    private BaseFragment mFragment;

    public JsonCallback() {
    }

    public JsonCallback(BaseFragment fragment) {
        this.mFragment = fragment;
    }

    @Override
    public void onBefore(BaseRequest request) {
        super.onBefore(request);
        if (mFragment != null) {
            mFragment.showLoadToast();
        }
    }

    @Override
    public void onAfter(T t, Exception e) {
        super.onAfter(t, e);
        if (mFragment != null) {
            mFragment.hideLoadToast();
        }
    }

    /**
     * 该方法是子线程处理，不能做ui相关的工作
     * 主要作用是解析网络返回的 response 对象,生产onSuccess回调中需要的数据对象
     * 这里的解析工作不同的业务逻辑基本都不一样,所以需要自己实现,以下给出的时模板代码,实际使用根据需要修改
     */
    @Override
    public T convertSuccess(Response response) throws Exception {
        String result = response.body().string();
        L.json(result);
        JSONObject jsonObject = null;
        String message = "";
        String status = "";
        String page = "";
        try {
            jsonObject = new JSONObject(result);
            status = jsonObject.getString("status");
            message = jsonObject.getString("message");
            if(jsonObject.has("page")){
                page = jsonObject.getString("page");
            }
            if (!status.equals("SUCCES000000") && !status.equals("SUCCES000001")) {
                throw new APIException(status, message);
            }
            result = jsonObject.getString("data");

            // TODO: 17/2/14 测试期间一分钱兼容处理,上线时代码需要删除
            /********额外处理1分钱的情况  0.01818181818181818 *******************************/
            if ((jsonObject.getString("type").equals("uzuanapp60001") || jsonObject.getString("type").equals("uzuanapp60003"))
                    && result.contains("0.01818181818181818")) {
                result = result.replace("0.01818181818181818", "999");
            }
            /********额外处理1分钱的情况  0.01818181818181818 *******************************/
        } catch (JSONException e) {
            e.printStackTrace();
            L.e(e.getMessage());
        }

        Type genType = getClass().getGenericSuperclass();
        Type[] params = ((ParameterizedType) genType).getActualTypeArguments();
        Type type = params[0];

        if (type == String.class) {
            return (T) result;
        }

        Gson gson = new Gson();
        try {
            if(!StringUtils.isEmpty(page)){
                onGetPage(gson.fromJson(page, PageModel.class));
            }
            return gson.fromJson(result, type);
        } catch (JsonParseException e) {
            e.printStackTrace();
            L.e(e.getMessage());
        }
        return null;
    }


    @Override
    public void onError(Call call, Response response, Exception e) {
        super.onError(call, response, e);
        L.d(e.getMessage());
        String error_msg = "";
        String apiCode = "";
        if (e instanceof APIException) {
            error_msg = e.getMessage();
            apiCode = ((APIException) e).getCode();
        } else if (e instanceof JSONException) {
            error_msg = "Json数据解析错误";
        } else if (e instanceof UnsupportedEncodingException) {
            error_msg = "UnsupportedEncodingException";
        } else if (e instanceof SocketTimeoutException) {
            error_msg = "请求数据超时,请稍后重试";
        } else if (e.getMessage().equals("Gateway Time-out")) {
            error_msg = "504网关超时,请稍后重试";
        } else if (e instanceof ConnectException) {
            error_msg = "网络中断,请检查您的网络状态";
        } else {
            error_msg = "未知错误 : " + e.getMessage();
        }
        ToastUtil.showToast(App.mContext, error_msg);
    }


    public void onGetPage(PageModel page) {

    }

    public static class APIException extends Exception {
        public String code;
        public String message;

        public APIException(String code, String message) {
            this.code = code;
            this.message = message;
        }

        @Override
        public String getMessage() {
            return message;
        }

        public String getCode() {
            return code;
        }
    }
}