package com.uu898app.model.request;

import com.uu898app.model.GBaseModel;

/**
 * Created by zhangbo on 2016/6/15.
 */
public class GLogin extends GBaseModel {

    /**
     * password : 123456
     * userName : ximingfan
     * uuid : abc
     */

    private String password;
    private String userName;
    private String uuid;
    private String decipheringType;

    public String getDecipheringType() {
        return decipheringType;
    }

    public void setDecipheringType(String decipheringType) {
        this.decipheringType = decipheringType;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }
}
