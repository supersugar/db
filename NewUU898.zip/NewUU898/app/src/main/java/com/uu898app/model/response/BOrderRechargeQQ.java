package com.uu898app.model.response;

/**
 * Created by zhangbo on 2016/7/11.
 */
public class BOrderRechargeQQ {
}
