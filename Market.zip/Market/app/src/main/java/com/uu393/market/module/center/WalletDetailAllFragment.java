package com.uu393.market.module.center;


import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.DevConfig;
import com.uu393.market.model.PageModel;
import com.uu393.market.model.request.GGetWalletFundRecord;
import com.uu393.market.model.response.BWalletFundRecord;
import com.uu393.market.module.base.BaseViewPagerFragment;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ContactCustomerServicesUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;

import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 * 我的钱包明细按钮跳转钱包明细页中的viewpager的单项Fragment（类型有：全部，充值、提现、收入、支出）
 */
public class WalletDetailAllFragment extends BaseViewPagerFragment implements View.OnClickListener {
    private static final String KEY_KIND = "kind";
    private PullLoadMoreRecyclerView mRecyclerView;
    private WalletAllRecyclerViewAdapter mAdapter;

    private View mLayoutNoResult;
    private Button mBtNoResultShare;
    private TextView mTvContact;
    private String mKind;
    private TextView mTvNoResultHintText;
    private LinearLayout mLlNoResultContact;
    private int mPageIndex = 1;//当前加载页数
    private String mType = "-1";//获取的记录类型
    private List<BWalletFundRecord> mRecord;

    public WalletDetailAllFragment() {
        mRecord = new ArrayList<>();
    }

    public static WalletDetailAllFragment newInstance(String kind) {
        Bundle bundle = new Bundle();
        bundle.putString(KEY_KIND, kind);
        WalletDetailAllFragment fragment = new WalletDetailAllFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    private static Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
        }
    };

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mKind = getArguments().getString(KEY_KIND).trim();
        }
        switch (mKind) {
            case "全部":
                mType = "-1";
                break;
            case "充值":
                mType = "0";
                break;
            case "提现":
                mType = "1";
                break;
            case "收入":
                mType = "3";
                break;
            case "支出":
                mType = "30";
                break;
        }
    }

    @Override
    public void onLazyInitView(@Nullable Bundle savedInstanceState) {
        super.onLazyInitView(savedInstanceState);
        GGetWalletFundRecord getWalletFundRecord = new GGetWalletFundRecord();
        getWalletFundRecord.setType(mType);
        doGetWalletFundRecord(getWalletFundRecord, false);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_wallet_detail_all, container, false);
        mRecyclerView = (PullLoadMoreRecyclerView) view.findViewById(R.id.recycler_view);

        mLayoutNoResult = view.findViewById(R.id.layout_no_result);
        mBtNoResultShare = (Button) view.findViewById(R.id.bt_no_result_share);
        mTvContact = (TextView) view.findViewById(R.id.tv_contact);
        mTvNoResultHintText = (TextView) view.findViewById(R.id.tv_no_result_hint_text);
        mLlNoResultContact = (LinearLayout) view.findViewById(R.id.ll_no_result_contact);
        mBtNoResultShare.setOnClickListener(this);
        mTvContact.setOnClickListener(this);
        initRecyclerView();
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        GGetWalletFundRecord getWalletFundRecord = new GGetWalletFundRecord();
        getWalletFundRecord.setType(mType);
        doGetWalletFundRecord(getWalletFundRecord, false);
    }

    private void initRecyclerView() {
        mRecyclerView.setLinearLayout();
        mRecyclerView.setPullRefreshEnable(true);
        mRecyclerView.setPushRefreshEnable(true);
        mRecyclerView.setIsRefresh(true);
        mAdapter = new WalletAllRecyclerViewAdapter();
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setOnPullLoadMoreListener(new PullLoadMoreRecyclerView.PullLoadMoreListener() {
            @Override
            public void onRefresh() {
                //-1全部   0充值   1提现   3收入   30支出
                GGetWalletFundRecord getWalletFundRecord = new GGetWalletFundRecord();
                getWalletFundRecord.setType(mType);
                doGetWalletFundRecord(getWalletFundRecord, false);
            }

            @Override
            public void onLoadMore() {
                //-1全部   0充值   1提现   3收入   30支出
                GGetWalletFundRecord getWalletFundRecord = new GGetWalletFundRecord();
                getWalletFundRecord.setType(mType);
                doGetWalletFundRecord(getWalletFundRecord, true);
            }
        });
    }

    private void showResult(boolean hasResult) {
        if (hasResult) {
            mRecyclerView.setVisibility(View.VISIBLE);
            mLayoutNoResult.setVisibility(View.GONE);
        } else {
            if ("收入".equals(mKind)) {
                mTvNoResultHintText.setText("您还没有分享收入哦~");
                mBtNoResultShare.setClickable(true);
                mBtNoResultShare.setVisibility(View.VISIBLE);
                mLlNoResultContact.setVisibility(View.VISIBLE);
            } else {
                mTvNoResultHintText.setText("暂无数据");
                mBtNoResultShare.setClickable(true);
                mBtNoResultShare.setText("点击刷新");
                mBtNoResultShare.setVisibility(View.VISIBLE);//不是收入的界面，不显示分享赚多少按钮，和联系客服视图
                mLlNoResultContact.setVisibility(View.GONE);
            }
            mRecyclerView.setVisibility(View.GONE);
            mLayoutNoResult.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void refresh() {
        //-1全部   0充值   1提现   3收入   30支出
        GGetWalletFundRecord getWalletFundRecord = new GGetWalletFundRecord();
        getWalletFundRecord.setType(mType);
        doGetWalletFundRecord(getWalletFundRecord, false);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bt_no_result_share://如何赚钱
                String text = mBtNoResultShare.getText().toString().trim().replace(" ", "");
                if ("点击刷新".equals(text)) {
                    this.refresh();
                } else {
                    _mActivity.startActivity(new Intent(_mActivity, JoinShareEarnActivity.class));
                }
                break;
            case R.id.tv_contact:
                ContactCustomerServicesUtils.doXiaoNeng();
                break;
        }
    }

    public class WalletAllRecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private List<BWalletFundRecord> mRecords = new ArrayList();

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_wallet_all_recycler_view, parent, false);
            return new WalletAllViewHolder(view);
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
            if (holder != null && holder instanceof WalletAllViewHolder) {
                ((WalletAllViewHolder) holder).bindItem(mRecords.get(position));
                String typeName = mRecords.get(position).getTypeName();
                if ("收取货款".equals(typeName)) {
                    ((WalletAllViewHolder) holder).itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //收取货款记录详情
                            Intent intent = new Intent(_mActivity, WalletDetailItemIncomeDetailActivity.class);
                            intent.putExtra("key_fund_order_no", mRecord.get(position).getTradeNo());
                            _mActivity.startActivity(intent);
                        }
                    });
                } else if ("提现".equals(typeName)) {
                    //提现记录详情
                    ((WalletAllViewHolder) holder).itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(_mActivity, WalletDetailItemWithdrawDetailActivity.class);
                            intent.putExtra("key_fund_order_no", mRecord.get(position).getTradeNo());
                            _mActivity.startActivity(intent);
                        }
                    });
                } else {
                    ((WalletAllViewHolder) holder).itemView.setClickable(false);
                }

            }
        }

        @Override
        public int getItemCount() {
            return mRecords.size();
        }

        public void refresh(List<BWalletFundRecord> records) {
            if (records != null && !records.isEmpty()) {
                this.mRecords.clear();
                this.mRecords.addAll(records);
                this.notifyDataSetChanged();
            }
        }

        class WalletAllViewHolder extends RecyclerView.ViewHolder {
            private TextView itemTitle, itemStatus, itemTime, itemMoney;

            public WalletAllViewHolder(View itemView) {
                super(itemView);
                itemTitle = (TextView) itemView.findViewById(R.id.tv_item_title);
                itemStatus = (TextView) itemView.findViewById(R.id.tv_item_status);
                itemTime = (TextView) itemView.findViewById(R.id.tv_item_time);
                itemMoney = (TextView) itemView.findViewById(R.id.tv_item_money);

            }

            public void bindItem(BWalletFundRecord record) {
                if (record == null) {
                    itemTitle.setText("充值平台币");
                    itemStatus.setText("已完成");
                    itemTime.setText("2017-08-18");
                    itemMoney.setText("+100元");
                } else {
                    itemTitle.setText(record.getTypeName());
                    itemStatus.setText(record.getStatusName());
                    itemTime.setText(record.getAddTime());
                    if (record.getZfMoney().contains("+")) {
                        itemMoney.setTextColor(getResources().getColor(R.color.green));
                    } else if (record.getZfMoney().contains("-")) {
                        itemMoney.setTextColor(getResources().getColor(R.color.text_lv2));
                    }
                    itemMoney.setText(record.getZfMoney());
                }

            }
        }
    }

    //获取资金记录列表APP048
    private void doGetWalletFundRecord(GGetWalletFundRecord model, final boolean loadMore) {
        if (model == null) return;
        showLoadToast();
        if (!loadMore) {
            mPageIndex = 1;
        }
        PageModel page = new PageModel(mPageIndex);
        page.size = 20;
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetWalletFundRecord(model, page, new JsonCallback<List<BWalletFundRecord>>() {
            @Override
            public void onSuccess(List<BWalletFundRecord> bWalletFundRecordList, Call call, Response response) {
                hideLoadToast();
                if (bWalletFundRecordList == null || bWalletFundRecordList.isEmpty()) {
                    if (mPageIndex == 1) {
                        showResult(false);
                    } else {
                        ToastUtil.showToast(App.mContext, "没有更多了~");
                    }
                } else {
                    showResult(true);
                    mPageIndex++;
                    if (!loadMore) {
                        mRecord.clear();
                    }
                    mRecord.addAll(bWalletFundRecordList);
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                hideLoadToast();
                showResult(false);
            }

            @Override
            public void onAfter(List<BWalletFundRecord> bWalletFundRecords, Exception e) {
                super.onAfter(bWalletFundRecords, e);
                mRecyclerView.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mAdapter.refresh(mRecord);
                        mRecyclerView.setPullLoadMoreCompleted();
                    }
                }, 100);
            }
        });
    }
}
