package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/14
 * Description    : 分享赚首页用户统计信息
 * =====================================================
 */

public class BShareFormHomeUserInfoTotal implements Serializable {
    /**
     {
     "tInCome":"180",（总收入）
     "mInCome":"180",（本月分享收入）
     "LMInCome":"180",（上月分享收入）
     “isTxBank”："True"(是否绑定银行卡）
     }
     */

    private String tInCome;
    private String mInCome;
    private String LMInCome;

    public String getIsTxBank() {
        return isTxBank;
    }

    public void setIsTxBank(String isTxBank) {
        this.isTxBank = isTxBank;
    }

    private String isTxBank;

    public String getTInCome() {
        return tInCome;
    }

    public void setTInCome(String tInCome) {
        this.tInCome = tInCome;
    }

    public String getMInCome() {
        return mInCome;
    }

    public void setMInCome(String mInCome) {
        this.mInCome = mInCome;
    }

    public String getLMInCome() {
        return LMInCome;
    }

    public void setLMInCome(String LMInCome) {
        this.LMInCome = LMInCome;
    }
}
