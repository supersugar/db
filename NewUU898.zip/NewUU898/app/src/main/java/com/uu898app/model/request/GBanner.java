package com.uu898app.model.request;

import com.uu898app.model.GBaseModel;

/**
 * Created by zhangbo on 2016/6/20.
 */
public class GBanner extends GBaseModel {

    private String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
