package com.uu898.gamesdk.utils;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.uu898.gamesdk.R;
import com.uu898.gamesdk.core.UGCoreHelper;
import com.uu898.gamesdk.log.L;
import com.uu898.gamesdk.network.NetConstant;

import org.xutils.x;

/**
 * Created by bo on 17/3/9.
 */

public class DevUtil {

    private long mLastClickTime;
    private int mSecretNumber = 0;

    private Activity mActivity;

    private static DevUtil mInstance;

    private DevUtil(Activity activity) {
        this.mActivity = activity;
    }

    public static DevUtil getInstance(Activity activity) {
        if (null == mInstance) {
            mInstance = new DevUtil(activity);
        }
        return mInstance;
    }

    public void open() {
        long currentClickTime = SystemClock.uptimeMillis();
        long elapsedTime = currentClickTime - mLastClickTime;
        mLastClickTime = currentClickTime;
        if (elapsedTime < 600) {
            ++mSecretNumber;
            if (15 == mSecretNumber) {
                L.init(true);
                showCustomizeDialog();
                ToastUtil.showToast(x.app(), "开发模式");
            }
        } else {
            mSecretNumber = 0;
        }
    }

    private void showCustomizeDialog() {
        final AlertDialog.Builder customizeDialog = new AlertDialog.Builder(mActivity);
        final View dialogView = LayoutInflater.from(x.app()).inflate(R.layout.ug_dev, null);
        customizeDialog.setView(dialogView);
        customizeDialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // 获取EditView中的输入内容
                //                EditText edit_text = (EditText) dialogView.findViewById(R.id.edit_text);
                dialog.dismiss();
            }
        });

        final EditText pw = (EditText) dialogView.findViewById(R.id.ug_super_pw_edt);
        final View moreView = dialogView.findViewById(R.id.ug_super_more);
        final TextView content = (TextView) dialogView.findViewById(R.id.ug_super_tv_content);
        RadioGroup rg = (RadioGroup) dialogView.findViewById(R.id.ug_super_radio_group);

        setContent(content);

        pw.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().equals("qqqqqq")) {
                    moreView.setVisibility(View.VISIBLE);
                    pw.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.ug_super_rb1) {
                    UGCoreHelper.setURL(NetConstant.URL.URL_SYZ_OFFICAL);
                } else if (checkedId == R.id.ug_super_rb2) {
                    UGCoreHelper.setURL(NetConstant.URL.URL_SYZ_TEST);
                }
                setContent(content);
            }
        });

        customizeDialog.setCancelable(false);
        customizeDialog.show();
    }

    private void setContent(TextView tv) {
        String temp = UGCoreHelper.getURL() + "\n"
                + "日志显示:" + L.isShowLog();
        tv.setText(temp);
    }


}
