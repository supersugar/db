package com.uu393.market.module.center;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.uu393.market.R;
import com.uu393.market.module.center.timepicker.view.TimePickerView;
import com.uu393.market.util.ScreenUtils;
import com.uu393.market.view.progressbutton.SubmitProcessButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by Administrator on 2017/4/12.
 */

public class ShareImgPopWindow implements View.OnClickListener {
    private Activity mActivity;
    private final View view;//弹框主视图
    private PopupWindow popupWindow;
    private EditText mEtAccountOrPhone;
    private EditText mEtGameName;
    private TextView mTvStartDate;
    private TextView mTvEndDate;
    private Button mBtnQuery;

    public ShareImgPopWindow(Activity context) {
        this.mActivity = context;
        //禁止弹出软键盘
        mActivity.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        view = LayoutInflater.from(mActivity).inflate(R.layout.popwindow_share_select, null, false);

        mEtAccountOrPhone = (EditText) view.findViewById(R.id.et_account_or_phone);
        mTvStartDate = (TextView) view.findViewById(R.id.et_begin_date);
        mTvEndDate = (TextView) view.findViewById(R.id.et_end_date);
        mEtGameName = (EditText) view.findViewById(R.id.et_game_name);
        mBtnQuery = (Button) view.findViewById(R.id.btn_query);

        mEtAccountOrPhone.setOnClickListener(this);
        mTvEndDate.setOnClickListener(this);
        mTvStartDate.setOnClickListener(this);
        mBtnQuery.setOnClickListener(this);
    }

    //底部弹出
    public void showSelectWindowFromTop() {
        int screenHeight = ScreenUtils.getScreenHeight(mActivity);
        popupWindow = new PopupWindow(view, ViewGroup.LayoutParams.MATCH_PARENT, screenHeight * 2 / 3);

        popupWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popupWindow.setAnimationStyle(android.R.style.Animation_InputMethod);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setFocusable(true);
        WindowManager.LayoutParams lp = mActivity.getWindow().getAttributes();
        lp.alpha = 0.5f;
        mActivity.getWindow().setAttributes(lp);
        popupWindow.showAtLocation(mActivity.getWindow().getDecorView(), Gravity.CENTER | Gravity.TOP, 0, 0);
        popupWindow.update();
        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                WindowManager.LayoutParams lp = mActivity.getWindow().getAttributes();
                lp.alpha = 1.0f;
                mActivity.getWindow().setAttributes(lp);
                if (mListener!=null){//将页面数据返回

                }
            }
        });

    }

    //隐藏弹窗
    public void hideSelectWindow() {
        if (popupWindow != null && popupWindow.isShowing()) {
            popupWindow.dismiss();
            popupWindow = null;
        }
    }

    public static String getTime(Date date) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        return format.format(date);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.et_account_or_phone://输入账户名或者手机号

                break;
            case R.id.et_begin_date://选择开始日期
                Intent intent = new Intent(mActivity, TimePickerPopActivity.class);
                mActivity.startActivity(intent);

                break;
            case R.id.et_end_date://选择结束日期

                break;
            case R.id.et_game_name://输入游戏名

                break;
            case R.id.btn_query://立即查询
                this.hideSelectWindow();
                break;
        }
    }

    private OnDismissListener mListener;
    public interface OnDismissListener{
        void onDismissListener();
    }
    public void setOnDismissListener(@NonNull OnDismissListener listener){
        this.mListener = listener;
    }

}

