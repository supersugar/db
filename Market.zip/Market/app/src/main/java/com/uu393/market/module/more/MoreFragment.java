package com.uu393.market.module.more;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;


import com.tencent.tauth.Tencent;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.DownloadHelper;
import com.uu393.market.util.CacheUtil;
import com.uu393.market.util.ContactCustomerServicesUtils;
import com.uu393.market.util.DensityUtils;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.log.L;
import com.uu393.market.view.loadtoast.LoadToast;
import com.zcw.togglebutton.ToggleButton;

import me.yokeyword.fragmentation.SupportFragment;

public class MoreFragment extends SupportFragment implements View.OnClickListener {

    public static final String SETTING_WHETHER_DOWNLOAD_NOT_WIFI = "whether_download_not_wifi";
    public static final String SETTING_WHETHER_KEEP_APK = "whether_keep_apk";

    private View mBtClearCache;
    private View mBtGoAbout;
    private View mBtCheckUpdate;

    private ToggleButton mSwitchDownload;
    private ToggleButton mSwitchDelete;

    private View mBtContactKefu;
    private View mBtQQGroup;
    private LoadToast mLoadToast;
    private ImageButton mIvTitleBarLeft;
    private TextView mTvTitleBarTitle;
    private android.widget.ToggleButton mTbTitleBarRight;
    private View mBtLogout;

    public static MoreFragment newInstance() {
        MoreFragment fragment = new MoreFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.more_fragment, null);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        mBtClearCache = view.findViewById(R.id.bt_clear_cache);
        mBtGoAbout = view.findViewById(R.id.bt_about);
        mBtCheckUpdate = view.findViewById(R.id.bt_check_update);

        mSwitchDownload = (ToggleButton) view.findViewById(R.id.download_switch);
        mSwitchDelete = (ToggleButton) view.findViewById(R.id.delete_switch);


        mBtContactKefu = view.findViewById(R.id.bt_contact_kefu);
        mBtQQGroup = view.findViewById(R.id.bt_qq_group);
        mBtLogout = view.findViewById(R.id.bt_logout);

        mBtClearCache.setOnClickListener(this);
        mBtGoAbout.setOnClickListener(this);
        mBtCheckUpdate.setOnClickListener(this);
        mBtContactKefu.setOnClickListener(this);
        mBtQQGroup.setOnClickListener(this);
        mBtLogout.setOnClickListener(this);

        mIvTitleBarLeft = (ImageButton) view.findViewById(R.id.title_bar_left);
        mTvTitleBarTitle = (TextView) view.findViewById(R.id.title_bar_title);
        mTbTitleBarRight = (android.widget.ToggleButton) view.findViewById(R.id.title_bar_right);
        mIvTitleBarLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _mActivity.onBackPressedSupport();
            }
        });
        mTvTitleBarTitle.setText("更多");
        mTbTitleBarRight.setVisibility(View.GONE);
        mLoadToast = new LoadToast(_mActivity);
        setSwitchButton();
    }


    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        L.d("onHiddenChanged" + hidden);
        if (hidden == false) {
            setSwitchButton();
        }
    }

    private void setSwitchButton() {
        //非wifi下是否可以下载游戏,默认不可以  false
        boolean downloadNotWifi = CacheUtil.get(_mActivity, "setting").getBoolean(SETTING_WHETHER_DOWNLOAD_NOT_WIFI, false);
        if (downloadNotWifi) {
            mSwitchDownload.setToggleOn();
        } else {
            mSwitchDownload.setToggleOff();
        }

        mSwitchDownload.setOnToggleChanged(new ToggleButton.OnToggleChanged() {
            @Override
            public void onToggle(boolean on) {
                CacheUtil.get(_mActivity, "setting").put(SETTING_WHETHER_DOWNLOAD_NOT_WIFI, on);
            }
        });

        //安装后是否保留apk文件,默认保留
        boolean keepApk = CacheUtil.get(_mActivity, "setting").getBoolean(SETTING_WHETHER_KEEP_APK, true);
        if (keepApk) {
            mSwitchDelete.setToggleOff();//保留
        } else {
            mSwitchDelete.setToggleOn();//不保留
        }

        mSwitchDelete.setOnToggleChanged(new ToggleButton.OnToggleChanged() {
            @Override
            public void onToggle(boolean on) {
                //如果是on为true,开关显示为开,这时候是不保留的意思,存的值要存false
                CacheUtil.get(_mActivity, "setting").put(SETTING_WHETHER_KEEP_APK, !on);
            }
        });
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.bt_clear_cache) {
            showLoadToast();
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    hideLoadToast();
                    ToastUtil.showToast(_mActivity, "清除成功");
                }
            }, 3000);
        } else if (v.getId() == R.id.bt_about) {
            start(AboutFragment.newInstance());
        } else if (v.getId() == R.id.bt_check_update) {
            DownloadHelper.checkUpdate(_mActivity, true);
        } else if (v.getId() == R.id.bt_contact_kefu) {
            ContactCustomerServicesUtils.doXiaoNeng();
        }else if(v.getId() == R.id.bt_qq_group){//todo qq group
            ContactCustomerServicesUtils.joinQQGroup(_mActivity);
        }else if (v.getId() == R.id.bt_logout){//退出登陆了
            doLogout();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart("MoreFragment");
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("MoreFragment");
    }
    public void showLoadToast() {
        mLoadToast.show();
    }

    public void hideLoadToast() {
        mLoadToast.success();
    }

    private void doLogout() {
        View inflate = LayoutInflater.from(App.mContext).inflate(R.layout.dialog_common, null, false);
        TextView dialogTitle2 = (TextView) inflate.findViewById(R.id.tv_dialog_title2);
        dialogTitle2.setText("是否要退出登陆？");
        Button dialogCancel = (Button) inflate.findViewById(R.id.btn_dialog_cancel);
        Button dialogConfirm = (Button) inflate.findViewById(R.id.btn_dialog_confirm);

        final Dialog dialog = new Dialog(_mActivity,R.style.DialogStyle);
        dialog.setContentView(inflate);
        Window window = dialog.getWindow();
        window.setGravity(Gravity.BOTTOM);

        WindowManager m = _mActivity.getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        //获得窗体的属性
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.y = DensityUtils.dp2px(App.mContext, 10);
        lp.height = DensityUtils.dp2px(App.mContext, 170);
        lp.width = d.getWidth() - DensityUtils.dp2px(App.mContext, 20);
        window.setAttributes(lp);
        dialog.show();//显示对话框
        dialogCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialogConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MobclickAgent.onProfileSignOff();
                SPUtil.put(App.mContext, "isLogin", false);
                SPUtil.put(App.mContext, "thirdUserId", "");
                SPUtil.put(App.mContext, "loginType", "");
                SPUtil.put(App.mContext, "token", "");
                SPUtil.put(App.mContext, "userId", "");
                SPUtil.put(App.mContext, "uId", "");
                SPUtil.put(App.mContext, "chkMobile", "");
                _mActivity.finish();
            }
        });
    }
}
