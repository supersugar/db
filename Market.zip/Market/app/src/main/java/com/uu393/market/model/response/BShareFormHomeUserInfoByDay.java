package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/14
 * Description    :
 * =====================================================
 */

public class BShareFormHomeUserInfoByDay implements Serializable {
    /**
     {
     "uUSYInstall":"18",（UUSY安装数）
     "paymentCount":"10",（付款总笔数）
     "inCome":"10",（收入）
     }
     */

    private String uUSYInstall;
    private String paymentCount;
    private String inCome;

    public String getUUSYInstall() {
        return uUSYInstall;
    }

    public void setUUSYInstall(String uUSYInstall) {
        this.uUSYInstall = uUSYInstall;
    }

    public String getPaymentCount() {
        return paymentCount;
    }

    public void setPaymentCount(String paymentCount) {
        this.paymentCount = paymentCount;
    }

    public String getInCome() {
        return inCome;
    }

    public void setInCome(String inCome) {
        this.inCome = inCome;
    }
}
