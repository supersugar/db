package com.uu661.module.account;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.StringCallback;
import com.tencent.tauth.IUiListener;
import com.tencent.tauth.Tencent;
import com.tencent.tauth.UiError;
import com.uu661.R;
import com.uu661.core.AccountManager;
import com.uu661.model.request.GLogin;
import com.uu661.model.request.GLoginThird;
import com.uu661.model.response.BLogin;
import com.uu661.module.base.BaseFragment;
import com.uu661.network.JsonCallback;
import com.uu661.network.NetConstant;
import com.uu661.network.TaskEngine;
import com.uu661.util.CommonUtils;
import com.uu661.util.NoDoubleClickUtils;
import com.uu661.util.PushUtil;
import com.uu661.util.ToastUtil;
import com.uu661.util.log.L;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.finalteam.toolsfinal.StringUtils;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 登录页面
 */
public class LoginFragment extends BaseFragment {

    @BindView(R.id.edt_account) EditText mEdtAccount;
    @BindView(R.id.edt_password) EditText mEdtPassword;
    @BindView(R.id.bt_submit) Button mBtSubmit;
    @BindView(R.id.bt_goto_register) TextView mBtGotoRegister;
    @BindView(R.id.bt_forget_password) TextView mBtForgetPassword;
    @BindView(R.id.bt_qq) ImageView mBtQq;

    private Tencent tencent;

    public static LoginFragment newInstance() {
        Bundle args = new Bundle();
        LoginFragment fragment = new LoginFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.account_login_fragment, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "欢迎登录", false);
        mEdtAccount.addTextChangedListener(mTextWatcher);
        //        mEdtAccount.setText("18530021191");
        //        mEdtPassword.setText("qqqqqq");

        //        mEdtAccount.setText("13203713938");
        //        mEdtPassword.setText("aiuu898");
    }


    @OnClick({R.id.bt_submit, R.id.bt_goto_register, R.id.bt_forget_password, R.id.bt_qq})
    public void onClick(View view) {
        if (NoDoubleClickUtils.isDoubleClick()) {
            return;
        }
        switch (view.getId()) {
            case R.id.bt_submit:
                verifyLoginForm();
                break;
            case R.id.bt_goto_register:
                start(RegisterFragment.newInstance());
                break;
            case R.id.bt_forget_password://忘记密码,调用系统浏览器
                Intent intent = new Intent();
                intent.setAction("android.intent.action.VIEW");
                Uri url = Uri.parse(NetConstant.WEB.FORGET_PASSWORD);
                intent.setData(url);
                startActivity(intent);
                break;
            case R.id.bt_qq:
                showLoadToast();
                //                LoginUtil.login(_mActivity, LoginPlatform.QQ, listener, true);
                tencent = Tencent.createInstance("1105959613", _mActivity);
                tencent.login(this, "get_simple_userinfo", iUiListener);
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Tencent.onActivityResultData(requestCode,resultCode,data,iUiListener);
    }

    IUiListener iUiListener = new IUiListener() {
        @Override
        public void onComplete(Object o) {
            //登录成功后回调该方法,可以跳转相关的页面
            JSONObject object = (JSONObject) o;
            try {
                final String token = object.getString("access_token");
                final String expires = object.getString("expires_in");
                final String openId = object.getString("openid");
                tencent.setOpenId(openId);
                tencent.setAccessToken(token, expires);

                L.d("token = " + token);
                String url = "https://graph.qq.com/oauth2.0/me?access_token=" + token + "&unionid=1";
                OkGo.get(url).execute(new StringCallback() {
                    @Override
                    public void onSuccess(String result, Call call, Response response) {
                        if (!StringUtils.isEmpty(result) && result.contains("callback")) {
                            result = result.substring(result.indexOf("{"), result.indexOf("}") + 1);
                            Gson gson = new Gson();
                            QQUnionInfo temp = gson.fromJson(result, QQUnionInfo.class);
                            L.d(temp.unionid);
                            if (null != temp && temp.openid.equals(openId)) {
                                GLoginThird model = new GLoginThird();
                                model.loginType = GLoginThird.TYPE_QQ;
                                model.loginThirdId = temp.openid;
                                model.qqUnionid = temp.unionid;
                                model.accessToken = token;
                                thirdLogin(model);
                            } else {
                                ToastUtil.showToast(_mActivity, "获取QQ登陆信息失败");
                            }
                        } else {
                            ToastUtil.showToast(_mActivity, "获取QQ登陆信息失败");
                        }
                    }
                });
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onError(UiError uiError) {
            L.d(uiError.toString());
        }

        @Override
        public void onCancel() {
            L.d("onCancel");
        }
    };

    private class QQUnionInfo {
        public String client_id;
        public String openid;
        public String unionid;
    }


    TextWatcher mTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            if (StringUtils.isEmpty(s.toString())) {
                mEdtPassword.setText("");
            }
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    /**
     * 校验登录表单信息
     */
    private void verifyLoginForm() {
        String account = mEdtAccount.getText().toString();
        String password = mEdtPassword.getText().toString();

        if (StringUtils.isEmpty(account)) {
            ToastUtil.showToast(_mActivity, "请输入帐号");
            return;
        }
        if (StringUtils.isEmpty(password)) {
            ToastUtil.showToast(_mActivity, "请输入密码");
            return;
        }
        login(account, password);
    }

    /**
     * 登录以后需要获取用户信息
     *
     * @param account
     * @param password
     */
    private void login(final String account, String password) {
        GLogin model = new GLogin();
        model.userId = account;
        model.password = CommonUtils.encryptString(password);
        model.clientIP = CommonUtils.getIP(_mActivity);
        TaskEngine.getInstance().doLogin(model, new JsonCallback<BLogin>(this) {

            @Override
            public void onSuccess(BLogin result, Call call, Response response) {
                AccountManager.getInstance().saveLoginInfo(result);
                PushUtil.addAlias(result.Uid, _mActivity);
                _mActivity.setResult(Activity.RESULT_OK);
                _mActivity.finish();
                ToastUtil.showToast(_mActivity, "登录成功");
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                //登录失败
                AccountManager.getInstance().logout();
            }
        });
    }

    /**
     * 第三方登陆
     * public static final int STATUS_UNBIND = 0;//未绑定
     * public static final int STATUS_BIND = 1;//绑定
     */
    private void thirdLogin(final GLoginThird model) {
        TaskEngine.getInstance().doThirdLogin(model, new JsonCallback<BLogin>(this) {

            @Override
            public void onSuccess(BLogin result, Call call, Response response) {
                L.d(result.Uid);
                if (result.status == BLogin.STATUS_BIND) {
                    AccountManager.getInstance().saveLoginInfo(result);
                    PushUtil.addAlias(result.Uid, _mActivity);
                    _mActivity.setResult(Activity.RESULT_OK);
                    _mActivity.finish();
                    ToastUtil.showToast(_mActivity, "登录成功");
                } else if (result.status == BLogin.STATUS_UNBIND) {
                    start(ThirdBindFragment.newInstance(model));
                }
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                //登录失败
                AccountManager.getInstance().logout();
            }
        });
    }

}
