package com.uu898app.module.helper;

import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.AppCompatDrawableManager;

import com.uu898app.R;
import com.uu898app.app.App;

/**
 * Created by zhangbo on 2016/8/11.
 */
public class UiHelper {

    public static Drawable getColorFilterDwawable(int drawable) {
        return getColorFilterDwawable(R.color.colorAccent , drawable);
    }

    public static Drawable getColorFilterDwawable(int color, int drawable) {
        AppCompatDrawableManager manager = AppCompatDrawableManager.get();
        return getColorFilterDwawable(color, manager.getDrawable(App.mContext, drawable));
    }

    public static Drawable getColorFilterDwawable(int color, Drawable drawable) {
        drawable.setColorFilter(ContextCompat.getColor(App.mContext, color) , PorterDuff.Mode.SRC_ATOP);
        return drawable;
    }

    /**
     * 将px值转换为sp值，保证文字大小不变
     */
    public static int px2sp(Context context, float pxValue) {
        final float fontScale = context.getResources().getDisplayMetrics().scaledDensity;
        return (int) (pxValue / fontScale + 0.5f);
    }

    /**
     * 将sp值转换为px值，保证文字大小不变
     */
    public static int sp2px(Context context, float spValue) {
        final float fontScale = context.getResources().getDisplayMetrics().scaledDensity;
        return (int) (spValue * fontScale + 0.5f);
    }
}
