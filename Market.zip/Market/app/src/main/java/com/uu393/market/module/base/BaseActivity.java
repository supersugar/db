package com.uu393.market.module.base;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.MotionEvent;

import com.bugtags.library.Bugtags;
import com.umeng.analytics.MobclickAgent;
import com.umeng.message.PushAgent;
import com.uu393.market.view.loadtoast.LoadToast;

import me.yokeyword.fragmentation.SupportActivity;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class BaseActivity extends SupportActivity{
    private LoadToast mLoadToast;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        StatusBarUtil.setColor(this, getResources().getColor(R.color.text_lv2), 0);
//        //官方在Android6.0中提供了亮色状态栏模式,就是说状态栏上的文字和图标都是黑色,比如使用了白色的背景,测试有效
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            this.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View
//                    .SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
//        }
        PushAgent.getInstance(this).onAppStart();//使用umeng推送服务需要添加该行代码
    }

    @Override
    protected void onResume() {
        super.onResume();
        MobclickAgent.onResume(this);//统计时长
        //注：回调 1
        Bugtags.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        MobclickAgent.onPause(this);
        //注：回调 2
        Bugtags.onPause(this);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        //注：回调 3
        Bugtags.onDispatchTouchEvent(this, event);
        return super.dispatchTouchEvent(event);
    }
    public void showLoadToast(@NonNull Activity activity) {
        if (mLoadToast == null){
            mLoadToast = new LoadToast(activity);
        }
        mLoadToast.show();
    }

    public void hideLoadToast() {
        if (mLoadToast == null){
            return;
        }
        mLoadToast.success();
    }
}
