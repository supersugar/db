package com.uu898.gamesdk.utils;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.view.WindowManager;

import com.uu898.gamesdk.log.L;
import com.uu898.gamesdk.service.FloatViewService;

import org.xutils.x;

/**
 * Created by bo on 16/10/12.
 */

public class FloatViewHelper {

    private static FloatViewService mFloatViewService;
    /**
     * 用于控制在屏幕上添加或移除悬浮窗
     */
    private static WindowManager mWindowManager;

    /**
     * 用于获取手机可用内存
     */
    private static ActivityManager mActivityManager;

    /**
     * 连接到Service
     */
    private final static ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            mFloatViewService = ((FloatViewService.FloatViewServiceBinder) iBinder).getService();
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mFloatViewService = null;
        }
    };

    public static void init(){
        try {
            x.app().bindService(new Intent(x.app(), FloatViewService.class), mServiceConnection, Context.BIND_AUTO_CREATE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void exit(){
        try {
            x.app().unbindService(mServiceConnection);

            //if( mFloatViewService != null ) {
            //    mFloatViewService.destroyFloat();
            //}

            //mContext.unregisterReceiver(mHomeKeyEventReceiver);
        } catch (Exception e) {
        } finally {
            mFloatViewService = null;
        }
    }


    /**
     * 显示悬浮图标
     */
    public static void showFloatingView() {
        L.d("floatview showFloatingView");
        if (mFloatViewService != null && AccountManager.getInstance().getStatus() == AccountManager.Status.LOGIN) {
            mFloatViewService.showFloat();
        }
    }

    /**
     * 隐藏悬浮图标
     */
    public static void hideFloatingView() {
        if (mFloatViewService != null) {
            mFloatViewService.hideFloat();
        }
    }

}
