package com.uu898app.module.cart;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.uu898app.R;
import com.uu898app.model.request.GMessage;
import com.uu898app.model.response.BMessage;
import com.uu898app.module.base.BaseFragment;
import com.uu898app.module.helper.ToolbarHelper;
import com.uu898app.network.TaskEngine;
import com.uu898app.network.rxjava.RxSubscriber;
import com.uu898app.util.ToastUtil;

import java.util.List;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class CartFragment extends BaseFragment {

    private SwipeRefreshLayout mSwipeRefreshLayout;
    private RecyclerView mRecyclerView;
    private MessageAdapter mAdapter;
    private String mSsid;
    private boolean mInAtTop = true;
    private int mScrollTotal;

    public static CartFragment newInstance() {
        Bundle args = new Bundle();
        CartFragment fragment = new CartFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.home_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Toolbar toolbar = (Toolbar) view.findViewById(R.id.toolbar);
        new ToolbarHelper.Builder(toolbar,this, _mActivity)
                .title("我的消息")
                .build();

        mSwipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.refresh_layout);
        mSwipeRefreshLayout.setColorSchemeResources(R.color.colorPrimary);
        mSwipeRefreshLayout.setOnRefreshListener(onRefreshListener);

        mRecyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        mAdapter = new MessageAdapter(null);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(_mActivity));
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                mScrollTotal += dy;
                if (mScrollTotal <= 0) {
                    mInAtTop = true;
                } else {
                    mInAtTop = false;
                }
            }
        });

        doGetMessageList();
    }

    SwipeRefreshLayout.OnRefreshListener onRefreshListener = new SwipeRefreshLayout.OnRefreshListener() {
        @Override
        public void onRefresh() {
            doGetMessageList();
        }
    };

    private void doGetMessageList() {
        mSwipeRefreshLayout.post(new Runnable() {
            @Override
            public void run() {
                mSwipeRefreshLayout.setRefreshing(true);
                TaskEngine.getInstance().getMyMessages(new GMessage(1)).subscribe(new RxSubscriber<List<BMessage>>() {
                    @Override
                    public void _onNext(List<BMessage> result) {
                        mAdapter.setNewData(result);
                        mSwipeRefreshLayout.setRefreshing(false);
                    }

                    @Override
                    public void _onError(String msg) {
                        mSwipeRefreshLayout.setRefreshing(false);
                        ToastUtil.showToast(_mActivity, msg);
                    }
                });
            }
        });

    }

    protected class MessageAdapter extends BaseQuickAdapter<BMessage> {

        public MessageAdapter(List<BMessage> data) {
            super(R.layout.order_list_item_common, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, BMessage item) {
            helper.setText(R.id.tv_title, item.getTitle() + "   " + item.getAddTime());
        }
    }
}
