package com.uu898.gamesdk.model.response;

/**
 * Created by bo on 16/9/14.
 */
public class BRegister {

    public String SSID;
}
