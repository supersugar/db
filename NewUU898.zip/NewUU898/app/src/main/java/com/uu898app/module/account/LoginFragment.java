package com.uu898app.module.account;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;

import com.uu898app.R;
import com.uu898app.model.GBaseModel;
import com.uu898app.model.request.GLogin;
import com.uu898app.model.response.BLogin;
import com.uu898app.model.response.BUserInfo;
import com.uu898app.module.base.BaseFragment;
import com.uu898app.module.helper.AccountManager;
import com.uu898app.module.helper.ToolbarHelper;
import com.uu898app.network.TaskEngine;
import com.uu898app.network.rxjava.RxSubscriber;
import com.uu898app.util.CommonUtil;
import com.uu898app.util.ToastUtil;
import com.uu898app.util.eventbus.EB;

import butterknife.BindView;
import butterknife.ButterKnife;
import rx.Observable;
import rx.functions.Func1;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class LoginFragment extends BaseFragment {


    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    @BindView(R.id.account_editor)
    AppCompatEditText mEdtAccount;
    @BindView(R.id.psw_editor)
    AppCompatEditText mEdtPw;
    @BindView(R.id.login)
    Button mBtlogin;
    @BindView(R.id.forget_pwd)
    AppCompatTextView mEdtForget;
    @BindView(R.id.checkbox)
    CheckBox checkbox;

    public static LoginFragment newInstance() {
        Bundle args = new Bundle();
        LoginFragment fragment = new LoginFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.login_layout, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init();
        new ToolbarHelper.Builder(mToolbar, this, _mActivity)
                .title("登陆")
                .showBack(true)
                .build();
        mBtlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String account = mEdtAccount.getText().toString();
                String password = mEdtPw.getText().toString();
                doLogin(account, password);
            }
        });
    }

    private void init() {
        mEdtAccount.setText("13203713938");
        mEdtPw.setText("9805308");
    }

    private void doLogin(final String account, final String password) {
        GLogin login = new GLogin();
        login.setUserName(account);
        login.setPassword(CommonUtil.encryptString(password));
        login.setUuid(CommonUtil.getDeviceId());
        login.setDecipheringType("0");

//        TaskEngine.getInstance().logins(login).subscribe(new RxSubscriber<BLogin>(this, true) {
//            @Override
//            public void _onNext(final BLogin bLogin) {
//                /**
//                 * 登陆成功之后，要判断用户是否选择自动登陆
//                 *  是：保存账号，密码，自动登陆true，登陆时间，用户信息BUserInfo
//                 *  否：保存账号，自动登陆false，登陆时间，用户信息BUserInfo
//                 */
//                TaskEngine.getInstance().getUserInfo(new GBaseModel(bLogin.getSSID())).subscribe(new Action1<BUserInfo>() {
//                    @Override
//                    public void call(BUserInfo bUserInfo) {
//                        AccountManager.getInstance().saveLoginInfo(bLogin.getSSID(), bLogin.getUserid());
//                        if (checkbox.isChecked()) {
//                            AccountManager.getInstance().saveLoginInfoMore(account, password, true, System.currentTimeMillis());
//                        }else{
//                            AccountManager.getInstance().saveLoginInfoMore(account, "", false, System.currentTimeMillis());
//                        }
//                        AccountManager.getInstance().setStatus(AccountManager.Status.LOGIN);
//                        EB.postEmpty(EB.TAG.LOGIN_SUCCESS);
//                    }
//                });
//            }
//
//            @Override
//            public void _onError(String msg) {
//                ToastUtil.showToast(_mActivity, msg);
//            }
//        });

        final BLogin[] bLoginResult = {null};
        TaskEngine.getInstance().logins(login)
                .flatMap(new Func1<BLogin, Observable<BUserInfo>>() {
                    @Override
                    public Observable<BUserInfo> call(BLogin bLogin) {
                        bLoginResult[0] = bLogin;
                        return TaskEngine.getInstance().getUserInfo(new GBaseModel(bLogin.getSSID()));
                    }
                })
                .subscribe(new RxSubscriber<BUserInfo>(LoginFragment.this, true) {
                    @Override
                    public void _onNext(BUserInfo bUserInfo) {
                        AccountManager.getInstance().saveLoginInfo(bLoginResult[0].getSSID(), bLoginResult[0].getUserid());
                        AccountManager.getInstance().saveUserInfo(bUserInfo);
                        if (checkbox.isChecked()) {
                            AccountManager.getInstance().saveLoginInfoMore(account, password, true, System.currentTimeMillis());
                        }else{
                            AccountManager.getInstance().saveLoginInfoMore(account, "", false, System.currentTimeMillis());
                        }
                        AccountManager.getInstance().setStatus(AccountManager.Status.LOGIN);
                        EB.postEmpty(EB.TAG.LOGIN_SUCCESS);
                    }

                    @Override
                    public void _onError(String msg) {
                        ToastUtil.showToast(_mActivity, msg);
                    }
                });
    }
}
