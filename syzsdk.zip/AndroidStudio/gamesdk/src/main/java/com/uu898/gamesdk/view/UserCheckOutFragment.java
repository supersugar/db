package com.uu898.gamesdk.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.alipay.sdk.app.PayTask;
import com.uu898.gamesdk.core.ResourceUtils;
import com.uu898.gamesdk.log.L;
import com.uu898.gamesdk.model.request.GGetPayMoney;
import com.uu898.gamesdk.model.request.GPay;
import com.uu898.gamesdk.model.response.BAliPay;
import com.uu898.gamesdk.model.response.BPayMoney;
import com.uu898.gamesdk.network.NetCallback;
import com.uu898.gamesdk.network.TaskEngine;
import com.uu898.gamesdk.pay.AliPayResult;
import com.uu898.gamesdk.support.model.UGPayModel;
import com.uu898.gamesdk.utils.CommonUtils;
import com.uu898.gamesdk.utils.FloatViewHelper;
import com.uu898.gamesdk.utils.ToastUtil;

import org.xutils.common.task.AbsTask;
import org.xutils.x;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 收银台界面
 * Created by zhangbo on 2016/6/23.
 */
public class UserCheckOutFragment extends BaseFragment {

    private TextView mTvTitle;
    private TextView mTvTime;
    private TextView mTvMoeny;

    private View ug_view_discount_one;
    private View ug_view_discount_two;
    private TextView ug_tv_discount;



    private View ug_bt_choose_coupon;
    private View ug_view_first_recharge;
    private ToggleButton ug_toggle_first_recharge;

    private View ug_view_tip1;

    private View ug_view_use_money;
    private View ug_tv_use_money;
    private ToggleButton ug_toggle_use_money;
    private ImageView ug_check_use_money;

    private View ug_view_verify_phone;
    private EditText ug_edt_verify_phone;
    private EditText ug_edt_verify_code;
    private Button ug_bt_verify_code;

    private View ug_view_tip2;

    private View ug_bt_ali_pay;
    private ImageView ug_check_ali_pay;
    private View ug_bt_wx_pay;
    private ImageView ug_check_wx_pay;

    private TextView ug_tv_final_money;
    private TextView ug_tv_go_pay;

    private UGPayModel mPayodel;



    private int mRealMoney = -1;

    public static UserCheckOutFragment newInstance(UGPayModel model) {
        Bundle args = new Bundle();
        args.putSerializable("model", model);
        UserCheckOutFragment fragment = new UserCheckOutFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        if (args != null) {
            mPayodel = (UGPayModel) args.getSerializable("model");
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_checkout"), container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "选择充值方式");

        initView(view);
        setPayInfo();
        doGetPayMoney(view);
    }


    private void initView(View view) {
        mTvTitle = (TextView) view.findViewById(getId("ug_tv_pay_title"));
        mTvTime = (TextView) view.findViewById(getId("ug_tv_time"));
        mTvMoeny = (TextView) view.findViewById(getId("ug_tv_money"));
        ug_view_discount_one = view.findViewById(getId("ug_view_discount_one"));
        ug_view_discount_two =  view.findViewById(getId("ug_view_discount_two"));
        ug_tv_discount = (TextView) view.findViewById(getId("ug_tv_discount"));

        ug_bt_choose_coupon = view.findViewById(getId("ug_bt_choose_coupon"));
        ug_view_first_recharge = view.findViewById(getId("ug_view_first_recharge"));
        ug_toggle_first_recharge = (ToggleButton) view.findViewById(getId("ug_toggle_first_recharge"));

        ug_view_tip1 = view.findViewById(getId("ug_view_tip1"));

        ug_view_use_money = view.findViewById(getId("ug_view_use_money"));
        ug_tv_use_money = view.findViewById(getId("ug_tv_use_money"));
        ug_toggle_use_money = (ToggleButton) view.findViewById(getId("ug_toggle_use_money"));
        ug_check_use_money = (ImageView) view.findViewById(getId("ug_check_use_money"));

        ug_view_verify_phone = view.findViewById(getId("ug_view_verify_phone"));
        ug_edt_verify_phone = (EditText) view.findViewById(getId("ug_edt_verify_phone"));
        ug_edt_verify_code = (EditText) view.findViewById(getId("ug_edt_verify_code"));
        ug_bt_verify_code = (Button) view.findViewById(getId("ug_bt_verify_code"));

        ug_view_tip2 = view.findViewById(getId("ug_view_tip2"));

        ug_bt_ali_pay = view.findViewById(getId("ug_bt_ali_pay"));
        ug_check_ali_pay = (ImageView) view.findViewById(getId("ug_check_ali_pay"));
        ug_bt_wx_pay = view.findViewById(getId("ug_bt_wx_pay"));
        ug_check_wx_pay = (ImageView) view.findViewById(getId("ug_check_wx_pay"));

        ug_tv_final_money = (TextView) view.findViewById(getId("ug_tv_final_money"));
        ug_tv_go_pay = (TextView) view.findViewById(getId("ug_tv_go_pay"));

        ug_bt_choose_coupon.setOnClickListener(onClickListener);//选择优惠券

        ug_bt_ali_pay.setOnClickListener(onClickListener);
        ug_bt_wx_pay.setOnClickListener(onClickListener);




        
    }

    private void setContent(BPayMoney result) {
        mRealMoney = result.Price;
        if (result.IsDiscount.equals("0")) {//无折扣
            ug_view_discount_one.setVisibility(View.GONE);
            ug_view_discount_two.setVisibility(View.GONE);
        } else if (result.IsDiscount.equals("1")) {//有折扣
            ug_view_discount_one.setVisibility(View.VISIBLE);
            ug_view_discount_two.setVisibility(View.VISIBLE);
            ug_tv_discount.setText("特价折扣 : " + result.Discount + "折");
        }
        mTvMoeny.setText(getMoney(mRealMoney));//设置真实金额
        // TODO: 17/4/28 必须要获取到优惠券信息
    }

    @Override
    public void onResume() {
        super.onResume();
        FloatViewHelper.hideFloatingView();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        FloatViewHelper.showFloatingView();
    }

    /**
     * 设置显示支付信息
     */
    private void setPayInfo() {
        mTvTitle.setText(mPayodel.title);
        mTvTime.setText(getTime());
    }

    private String getTime() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return format.format(new Date());
    }

    private String getMoney(int realMoney) {
        return CommonUtils.fenToYuan(realMoney) + " 元 ";
    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v.getId() == getId("ug_bt_ali_pay")) {
                doAliPay();
            } else if (v.getId() == getId("ug_bt_wx_pay")) {
                //需要先判断有没有安装微信
                if (!CommonUtils.isWeixinInstall(x.app())) {
                    ToastUtil.showToast(_mActivity, "请安装微信客户端");
                    return;
                }
                doWxPay();
            }
        }
    };

    /**
     * 获取充值金额
     *
     * @param view
     */
    private void doGetPayMoney(final View view) {
        GGetPayMoney model = new GGetPayMoney();
        model.setOriginalPrice(mPayodel.originalPrice);
        TaskEngine.getInstance().doGetPayMoney(model, new NetCallback<BPayMoney>(this) {
            @Override
            public void _onNext(BPayMoney result) {
                setContent(result);

            }

            @Override
            public void _onError(String msg) {

            }
        });
    }



    /**
     *
     */
    private void doWxPay() {
        GPay model = new GPay();
        model.setCpOrderNo(mPayodel.cpOrderNo);
        model.setPayType(GPay.PAY_TYPE_WX);
        model.setIP(CommonUtils.getIP(x.app()));
        if (mRealMoney >= 0) {//取到了服务器返回的实际金额
            model.setPrice(String.valueOf(mRealMoney));
        } else {//值小于0,按无折扣算,取游戏传递的原始金额
            model.setPrice(String.valueOf(mPayodel.originalPrice));
        }
        model.setTitle(mPayodel.title);
        model.setDescribe(mPayodel.describe);
        model.setNumber(String.valueOf(mPayodel.number));
        model.setProductID(mPayodel.productID);
        model.setOriginalPrice(String.valueOf(mPayodel.originalPrice));
        model.setReserved(mPayodel.reserved);

        TaskEngine.getInstance().doAliPay(model, new NetCallback<BAliPay>(this) {
            @Override
            public void _onNext(BAliPay order) {
                start(WebWXPayFragment.newInstance(order));
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

    private void doAliPay() {
        GPay model = new GPay();
        model.setCpOrderNo(mPayodel.cpOrderNo);
        model.setPayType(GPay.PAY_TYPE_ZFB);
        model.setIP(CommonUtils.getIP(x.app()));
        if (mRealMoney >= 0) {//取到了服务器返回的实际金额
            model.setPrice(String.valueOf(mRealMoney));
        } else {//值小于0,按无折扣算,取游戏传递的原始金额
            model.setPrice(String.valueOf(mPayodel.originalPrice));
        }
        model.setTitle(mPayodel.title);
        model.setDescribe(mPayodel.describe);
        model.setNumber(String.valueOf(mPayodel.number));
        model.setProductID(mPayodel.productID);
        model.setOriginalPrice(String.valueOf(mPayodel.originalPrice));
        model.setReserved(mPayodel.reserved);

        TaskEngine.getInstance().doAliPay(model, new NetCallback<BAliPay>(this) {
            @Override
            public void _onNext(BAliPay order) {
                callAliPay(order);
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

    /**
     * 调用支付宝支付
     *
     * @param order
     */
    private void callAliPay(final BAliPay order) {
        final String orderString = order.signOrderNo;
        x.task().start(new AbsTask<String>() {
            @Override
            protected String doBackground() throws Throwable {
                return new PayTask(_mActivity).pay(orderString, false);
            }

            @Override
            protected void onSuccess(String s) {
                //如果支付成功/不确定是否成功,延时跳转到结果页面,查询服务器结果
                //如果支付失败,返回收银台
                L.d(s);
                AliPayResult payResult = new AliPayResult(s);
                String resultStatus = payResult.getResultStatus();
                // 判断resultStatus 为“9000”则代表支付成功，具体状态码代表含义可参考接口文档
                if (TextUtils.equals(resultStatus, "9000")) {
                    ToastUtil.showToast(_mActivity, "支付完成,请稍等...");
                    replaceFragment(UserPayResultFragment.newInstance(order), false);
                } else {
                    // 判断resultStatus 为非"9000"则代表可能支付失败
                    // "8000"代表支付结果因为支付渠道原因或者系统原因还在等待支付结果确认，最终交易是否成功以服务端异步通知为准（小概率状态）
                    if (TextUtils.equals(resultStatus, "8000")) {
                        ToastUtil.showToast(_mActivity, "支付结果确认中...");
                        replaceFragment(UserPayResultFragment.newInstance(order), false);
                    } else if (TextUtils.equals(resultStatus, "6001")) {
                        ToastUtil.showToast(_mActivity, "支付取消");
                    } else {
                        // 其他值就可以判断为支付失败，包括用户主动取消支付，或者系统返回的错误
                        ToastUtil.showToast(_mActivity, "支付失败");
                    }
                }
            }

            @Override
            protected void onError(Throwable throwable, boolean b) {
                ToastUtil.showToast(_mActivity, "调用支付宝失败");
            }
        });
    }

}
