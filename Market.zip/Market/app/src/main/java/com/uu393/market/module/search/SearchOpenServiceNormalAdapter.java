package com.uu393.market.module.search;

import android.app.Activity;
import android.content.Context;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.response.BH5ZaiWanAll;
import com.uu393.market.model.response.BServerListByTime;
import com.uu393.market.model.response.BServrerItem;
import com.uu393.market.util.DateUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/4/1
 * Descrip    :
 * =====================================================
 */

public class SearchOpenServiceNormalAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<BServerListByTime> mBServerListByTime = new ArrayList<>();
    private Activity mcontext;
    private int mStar = 1;

    public  SearchOpenServiceNormalAdapter(Activity context){
        this.mcontext = context;

    }

    public void refresh(List<BServerListByTime> list, int star){
        this.mBServerListByTime = list;
        this.mStar = star;
        notifyDataSetChanged();
    }
    public void refreshView(){
        this.notifyDataSetChanged();
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_open_server_normal, parent, false);
        return new SearchOpenServiceNormalHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        if (holder!=null&&holder instanceof SearchOpenServiceNormalHolder){
            if (mStar == 1){
                ((SearchOpenServiceNormalHolder) holder).mtomrrow_star.setImageResource(R.drawable.ic_star);
            }else if (mStar == 2){
                ((SearchOpenServiceNormalHolder) holder).mtomrrow_star.setImageResource(R.drawable.torrowstar);
            }
            ((SearchOpenServiceNormalHolder) holder).bindItem(position);
        }
    }

    @Override
    public int getItemCount() {
        return mBServerListByTime.size();
    }

    public class SearchOpenServiceNormalHolder extends RecyclerView.ViewHolder{
        private TextView openServiceTime;
        private RecyclerView subRvInNormal;
        public ImageView mtomrrow_star;
        private List<BServrerItem> mBServrerItem;
        SubSearchOpenServiceNormalAdapter adapter;

        public SearchOpenServiceNormalHolder(View itemView) {
            super(itemView);
            mBServrerItem = new ArrayList<>();
            if (itemView!=null){
                openServiceTime = (TextView) itemView.findViewById(R.id.tv_open_service_normal_date);
                subRvInNormal = (RecyclerView) itemView.findViewById(R.id.rv_open_service_normal_in_item);
                mtomrrow_star = (ImageView) itemView.findViewById(R.id.tomrrow_star);

            }else {
                return;
            }

             adapter = new SubSearchOpenServiceNormalAdapter(mcontext);
            LinearLayoutManager layoutManager = new LinearLayoutManager(App.mContext, LinearLayoutManager.VERTICAL, false);
            subRvInNormal.setLayoutManager(layoutManager);
            subRvInNormal.setAdapter(adapter);
        }

        public void bindItem(int position){
            String playTime = mBServerListByTime.get(position).getOpenTime();
                openServiceTime.setText(playTime);

            if (mBServerListByTime.get(position).getServerList() !=null && !mBServerListByTime.get(position).getServerList().isEmpty()){
                mBServrerItem.clear();
                for (BServerListByTime.ServerListBean game:mBServerListByTime.get(position).getServerList()) {
                    BServrerItem gameModle = new BServrerItem();
                    gameModle.setAndroidPackage(game.getAndroidPackage());
                    gameModle.setDiscount(game.getDiscount());
                    gameModle.setGameName(game.getGameName());
                    gameModle.setIcon(game.getIcon());
                    gameModle.setServerName(game.getServerName());
                    gameModle.setId(game.getId());
                    gameModle.setPackageName(game.getPackageName());
                    mBServrerItem.add(gameModle);
                }
            }
            adapter.updateData(mBServrerItem);
        }

    }


}
