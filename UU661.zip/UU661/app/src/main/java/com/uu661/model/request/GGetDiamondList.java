package com.uu661.model.request;

public class GGetDiamondList {

    private int totalCount = 0;//秒杀所需人次：0全部 -1多人 2两人 5五人

    public GGetDiamondList(int totalCount) {
        this.totalCount = totalCount;
    }
}
