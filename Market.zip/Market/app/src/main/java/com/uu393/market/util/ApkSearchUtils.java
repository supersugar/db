package com.uu393.market.util;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by bo on 16/12/16.
 */

public class ApkSearchUtils {

    private static int INSTALLED = 0; // 表示已经安装，且跟现在这个apk文件是一个版本
    private static int UNINSTALLED = 1; // 表示未安装
    private static int INSTALLED_UPDATE = 2; // 表示已经安装，版本比现在这个版本要低，可以点击按钮更新

    private Context context;
    private List<APKInfo> myFiles = new ArrayList<APKInfo>();

    private PackageManager mPackageManager;


    public ApkSearchUtils(Context context) {
        super();
        this.context = context;
        mPackageManager = context.getPackageManager();
    }

    public List<APKInfo> getMyFiles() {
        return myFiles;
    }

    public void setMyFiles(List<APKInfo> myFiles) {
        this.myFiles = myFiles;
    }


    /**
     * 运用递归的思想，递归去找每个目录下面的apk文件
     */
    public void findAllAPKFile(File file, Context context) {

        // 手机上的文件,目前只判断SD卡上的APK文件
        // file = Environment.getDataDirectory();
        // SD卡上的文件目录
        if (file.isFile()) {
            String fileName = file.getName();
            if (fileName.toLowerCase().endsWith(".apk")) {
                //判断应用是否已经安装,只显示未安装的
                APKInfo apkInfo = new APKInfo();
                String filePath = file.getAbsolutePath();
                PackageInfo packageInfo = mPackageManager.getPackageArchiveInfo(filePath, PackageManager.GET_ACTIVITIES);
                if (null != packageInfo) {
                    try {
                        mPackageManager.getPackageInfo(packageInfo.packageName, 0);
                    } catch (PackageManager.NameNotFoundException e) {
                        //未安装
                        e.printStackTrace();
                        ApplicationInfo appInfo = packageInfo.applicationInfo;

                        /** 获取apk的图标 */
                        appInfo.sourceDir = filePath;
                        appInfo.publicSourceDir = filePath;

                        apkInfo.setApkName(mPackageManager.getApplicationLabel(appInfo).toString());
                        apkInfo.setApkIcon(appInfo.loadIcon(mPackageManager));
                        apkInfo.setFilepath(file.getAbsolutePath());
                        apkInfo.setPackageName(packageInfo.packageName);
                        apkInfo.setVersionName(packageInfo.versionName);
                        apkInfo.setVersionCode(packageInfo.versionCode);

                        myFiles.add(apkInfo);
                    }

                }
            }
        } else {
            File[] files = file.listFiles();
            if (files != null && files.length > 0) {
                for (File file_str : files) {
                    findAllAPKFile(file_str, context);
                }
            }
        }
    }


    public static class APKInfo {
        private Drawable apkIcon;
        private String apkName;
        private String packageName;
        private String filepath;
        private String versionName;
        private int versionCode;

        public String getApkName() {
            return apkName;
        }

        public void setApkName(String apkName) {
            this.apkName = apkName;
        }

        public Drawable getApkIcon() {
            return apkIcon;
        }

        public void setApkIcon(Drawable apkIcon) {
            this.apkIcon = apkIcon;
        }

        public String getPackageName() {
            return packageName;
        }

        public void setPackageName(String packageName) {
            this.packageName = packageName;
        }

        public String getFilepath() {
            return filepath;
        }

        public void setFilepath(String filepath) {
            this.filepath = filepath;
        }

        public String getVersionName() {
            return versionName;
        }

        public void setVersionName(String versionName) {
            this.versionName = versionName;
        }

        public int getVersionCode() {
            return versionCode;
        }

        public void setVersionCode(int versionCode) {
            this.versionCode = versionCode;
        }
    }
}
