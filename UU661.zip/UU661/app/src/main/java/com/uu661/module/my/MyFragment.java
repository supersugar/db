package com.uu661.module.my;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.github.florent37.viewanimator.AnimationListener;
import com.github.florent37.viewanimator.ViewAnimator;
import com.lcodecore.tkrefreshlayout.RefreshListenerAdapter;
import com.lcodecore.tkrefreshlayout.TwinklingRefreshLayout;
import com.orhanobut.hawk.Hawk;
import com.uu661.R;
import com.uu661.core.AccountManager;
import com.uu661.model.response.BUserInfo;
import com.uu661.module.MainActivity;
import com.uu661.module.base.BaseFragment;
import com.uu661.module.base.BaseTabLazyFragment;
import com.uu661.network.JsonCallback;
import com.uu661.network.TaskEngine;
import com.uu661.util.CommonUtils;
import com.uu661.util.NoDoubleClickUtils;
import com.uu661.util.PushUtil;
import com.uu661.util.log.L;
import com.zcw.togglebutton.ToggleButton;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import me.yokeyword.fragmentation.SupportFragment;
import okhttp3.Call;
import okhttp3.Response;


public class MyFragment extends BaseTabLazyFragment {


    @BindView(R.id.my_tv_money) TextView mMyTvMoney;
    @BindView(R.id.my_bt_charge_money) Button mMyBtChargeMoney;
    @BindView(R.id.my_tv_diamond) TextView mMyTvDiamond;
    @BindView(R.id.my_bt_use_diamond) Button mMyBtChargeDiamond;
    @BindView(R.id.my_img_head) ImageView mMyImgHead;
    @BindView(R.id.my_tv_nickname) TextView mMyTvNickname;
    @BindView(R.id.my_bt_my_history) RelativeLayout mMyBtMyHistory;
    @BindView(R.id.my_bt_my_coupon) RelativeLayout mMyBtMyCoupon;
    @BindView(R.id.my_tv_my_coupon) TextView mMyTvMyCoupon;
    @BindView(R.id.my_bt_go_about) RelativeLayout mMyBtGoAbout;
    @BindView(R.id.my_bt_logout) Button mMyBtLogout;
    @BindView(R.id.refreshLayout) TwinklingRefreshLayout mRefreshLayout;
    @BindView(R.id.my_toggle_push_enable) ToggleButton mMyTogglePushEnable;

    @BindView(R.id.use_diamond_close) ImageView mUseDiamondClose;
    @BindView(R.id.use_diamond) RelativeLayout mUseDiamond;


    private boolean isUseDiamondShow = false;//

    public static MyFragment newInstance() {
        MyFragment fragment = new MyFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.my_fragment, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onLazyInitView(@Nullable Bundle savedInstanceState) {
        L.d("initLazyView " + this);
        initRefreshLayout();
        initUseDiamondView();
    }

    @Override
    public void onSupportVisible() {
        super.onSupportVisible();
        L.d("onSupportVisible " + this);
        doGetUserInfo(true);
        AccountManager.getInstance().whetherShowAfterLoginCouponDialog(_mActivity);
    }

    private void setContent() {
        setToggleButton();
        BUserInfo userInfo = AccountManager.getInstance().getUserInfo();
        if (null != userInfo) {
            mMyTvMoney.setText(CommonUtils.fenToYuan(userInfo.money));
            mMyTvDiamond.setText(userInfo.UZuan);
            mMyTvNickname.setText(userInfo.userId);
            mMyTvMyCoupon.setText("我的红包(" + userInfo.counts + ")");
        } else {
            mMyTvMoney.setText("--");
            mMyTvDiamond.setText("--");
            mMyTvNickname.setText("");
            mMyTvMyCoupon.setText("我的红包");
        }
    }

    @Override
    public void onTabReselected() {

    }

    private void initRefreshLayout() {
        //以下代码是使用黑色转圈Loading
        //        ProgressLayout headerView = new ProgressLayout(_mActivity);
        //        mRefreshLayout.setHeaderView(headerView);
        mRefreshLayout.setEnableLoadmore(false);
        mRefreshLayout.setEnableOverScroll(false);//是否允许越界回弹

        mRefreshLayout.setOnRefreshListener(new RefreshListenerAdapter() {
            @Override
            public void onRefresh(final TwinklingRefreshLayout refreshLayout) {
                doGetUserInfo(false);
            }
        });
    }

    private void initUseDiamondView() {


    }


    public void doGetUserInfo(boolean showLoading) {
        if (!AccountManager.getInstance().isLogin()) {
            return;
        }
        TaskEngine.getInstance().doGetUserInfo(new JsonCallback<BUserInfo>(showLoading ? this : null) {
            @Override
            public void onSuccess(BUserInfo result, Call call, Response response) {
                AccountManager accountManager = AccountManager.getInstance();
                //获取完用户信息以后,要判断regStatus值是否有变化
                BUserInfo oldUserInfo = accountManager.getUserInfo();
                if (null == oldUserInfo) {
                    accountManager.setIsShowStatusChanged(true);
                } else {
                    if (result.showStatus != oldUserInfo.showStatus) {
                        accountManager.setIsShowStatusChanged(true);
                    }
                }
                accountManager.saveUserInfo(result);
                setContent();
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                //                ToastUtil.showToast(_mActivity, "获取用户信息失败，请下拉重新获取");
            }

            @Override
            public void onAfter(BUserInfo userInfo, Exception e) {
                super.onAfter(userInfo, e);
                if (!isVisible()) {
                    return;
                }
                mRefreshLayout.finishRefreshing();
            }
        });
    }

    @OnClick({R.id.my_bt_charge_money, R.id.my_bt_use_diamond, R.id.my_bt_my_history, R.id.my_bt_my_coupon, R.id.my_bt_go_about, R.id
            .my_bt_logout, R.id.use_diamond_close})
    public void onClick(View view) {
        if (NoDoubleClickUtils.isDoubleClick()) {
            return;
        }
        switch (view.getId()) {
            case R.id.my_bt_charge_money:
                //                BUserInfo info = AccountManager.getInstance().getUserInfo();
                //                if (null != info) {
                //                    String url = NetConstant.WEB.CHARGE_MONEY + "u0=" + info.UId + "&u1=" + info.userId + "&u2=1";
                //                    Intent intent = new Intent(_mActivity, WebActivity.class);
                //                    intent.putExtra(WebActivity.INTENT_KEY_URL, url);
                //                    intent.putExtra(WebActivity.INTENT_KEY_TITLE, "充值");
                //                    startActivity(intent);
                //                }
                BaseFragment parent0 = (BaseFragment) getParentFragment();
                parent0.start(RechargeCenterFragment.newInstance());
                break;
            case R.id.my_bt_my_history:
                BaseFragment parent = (BaseFragment) getParentFragment();
                parent.start(MyOrderFragment.newInstance());
                break;
            case R.id.my_bt_my_coupon:
                BaseFragment parent1 = (BaseFragment) getParentFragment();
                parent1.start(MyCouponFragment.newInstance());
                break;
            case R.id.my_bt_go_about:
                ((SupportFragment) getParentFragment()).start(AboutFragment.newInstance());
                break;
            case R.id.my_bt_logout:
                doLogout();
                break;
            case R.id.my_bt_use_diamond:
                showUseDiamondView();
                break;
            case R.id.use_diamond_close:
                hideUseDiamondView();
                break;
        }
    }

    private void doLogout() {
        MaterialDialog.Builder builder = new MaterialDialog.Builder(_mActivity).content("您确认要退出吗？").positiveText("是").negativeText("否")
                .onPositive(new MaterialDialog.SingleButtonCallback() {
            @Override
            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                if (null != AccountManager.getInstance().getUserInfo()) {
                    PushUtil.removeAlias(AccountManager.getInstance().getUserInfo().UId, _mActivity);
                }
                AccountManager.getInstance().logout();
                setContent();
                dialog.dismiss();
                //退出以后回到首页
                //                startActivity(new Intent(_mActivity, LoginActivity.class));
                //                EB.postEmpty(EB.TAG.GO_HOME);
                Intent intent = new Intent(_mActivity, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra(MainActivity.INTENT_KEY_CHECK_UPDATE, false);
                startActivity(intent);

            }
        });
        MaterialDialog dialog = builder.build();
        dialog.show();
    }

    /**
     * 设置开关按钮
     */
    private void setToggleButton() {
        //是否接受推送, 默认true
        boolean pushEnable = Hawk.get("push_enable", true);
        if (pushEnable) {
            mMyTogglePushEnable.setToggleOn();
        } else {
            mMyTogglePushEnable.setToggleOff();
        }

        mMyTogglePushEnable.setOnToggleChanged(new ToggleButton.OnToggleChanged() {
            @Override
            public void onToggle(boolean enable) {
                MainActivity activity = (MainActivity) _mActivity;
                //是否运行友盟推送,必须放在activity中写,在fragment中写无效
                activity.pushEnable(enable);
                Hawk.put("push_enable", enable);
            }
        });
    }

    /**
     * 显示中奖提示蒙层view
     */
    private void showUseDiamondView() {

        ViewAnimator.animate(mUseDiamond).alpha(0, 1).scale(0.2f, 1f).duration(200).onStart(new AnimationListener.Start() {
            @Override
            public void onStart() {
                mUseDiamond.setVisibility(View.VISIBLE);
            }
        }).onStop(new AnimationListener.Stop() {
            @Override
            public void onStop() {
                isUseDiamondShow = true;
            }
        }).start();
    }

    private void hideUseDiamondView() {
        ViewAnimator.animate(mUseDiamond).alpha(1, 0).scale(1f, 0.2f).duration(200).onStart(new AnimationListener.Start() {
            @Override
            public void onStart() {

            }
        }).onStop(new AnimationListener.Stop() {
            @Override
            public void onStop() {
                isUseDiamondShow = false;
                mUseDiamond.setVisibility(View.GONE);
            }
        }).start();
    }

    @Override
    public boolean onBackPressedSupport() {

        if (isUseDiamondShow) {
            hideUseDiamondView();
            return true;
        }
        return super.onBackPressedSupport();
    }

    @Override
    public void onSupportInvisible() {
        super.onSupportInvisible();
        if (isUseDiamondShow) {
            hideUseDiamondView();
        }
    }
}
