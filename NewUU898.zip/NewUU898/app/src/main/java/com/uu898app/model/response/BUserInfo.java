package com.uu898app.model.response;

import java.io.Serializable;

/**
 * Created by zhangbo on 2016/6/18.
 */
public class BUserInfo implements Serializable{

    private String _account;
    private String _accountname;
    private int _activation;
    private int _bank;
    private int _bankcity;
    private String _bindip;
    private int _buyinfomoney;
    private int _concompletecount;
    private int _conjifen;
    private int _contradecount;
    private int _coupon;
    private String _creditno;
    private int _drawings;
    private String _email;
    private String _firstmobile;
    private String _firstqq;
    private String _firsttelephone;
    private int _gonghui;
    private int _id;
    private int _invitecode;
    private int _isFreeze;
    private int _isvalid;
    private int _isvip;
    private String _lastloginip;
    private String _lastlogintime;
    private String _loginip;
    private String _logintime;
    private int _logintimes;
    private String _mobilenumber;
    private double _money;
    private int _online;
    private int _ordercummoney;
    private Object _password;
    private Object _payment;
    private Object _paypassword;
    private Object _pwdanswer;
    private Object _pwdquestion;
    private Object _qq;
    private Object _regfrom;
    private Object _regtime;
    private Object _releasetime;
    private String _remark;
    private Object _selcompletecount;
    private Object _seljifen;
    private Object _seltradecount;
    private Object _status;
    private Object _telephone;
    private String _userid;
    private Object _username;
    private String _vipendtime;
    private String _vipgames;
    private Object _virtualmoney;
    private Object _yajin;
    private String _bankName;
    private String _chkMobile;
    private int _chkMobileOrderStatus;
    private int _chkMobileStatus;
    private String _chkMobileUUID;
    private Object _chkType;
    private String _cityName;
    private int _defaultChkType;
    private Object _isRightIp;
    private String _provinceName;
    private String _weChatNo;
    private int _weChatStatus;

    public String get_account() {
        return _account;
    }

    public void set_account(String _account) {
        this._account = _account;
    }

    public String get_accountname() {
        return _accountname;
    }

    public void set_accountname(String _accountname) {
        this._accountname = _accountname;
    }

    public int get_activation() {
        return _activation;
    }

    public void set_activation(int _activation) {
        this._activation = _activation;
    }

    public int get_bank() {
        return _bank;
    }

    public void set_bank(int _bank) {
        this._bank = _bank;
    }

    public int get_bankcity() {
        return _bankcity;
    }

    public void set_bankcity(int _bankcity) {
        this._bankcity = _bankcity;
    }

    public String get_bindip() {
        return _bindip;
    }

    public void set_bindip(String _bindip) {
        this._bindip = _bindip;
    }

    public int get_buyinfomoney() {
        return _buyinfomoney;
    }

    public void set_buyinfomoney(int _buyinfomoney) {
        this._buyinfomoney = _buyinfomoney;
    }

    public int get_concompletecount() {
        return _concompletecount;
    }

    public void set_concompletecount(int _concompletecount) {
        this._concompletecount = _concompletecount;
    }

    public int get_conjifen() {
        return _conjifen;
    }

    public void set_conjifen(int _conjifen) {
        this._conjifen = _conjifen;
    }

    public int get_contradecount() {
        return _contradecount;
    }

    public void set_contradecount(int _contradecount) {
        this._contradecount = _contradecount;
    }

    public int get_coupon() {
        return _coupon;
    }

    public void set_coupon(int _coupon) {
        this._coupon = _coupon;
    }

    public String get_creditno() {
        return _creditno;
    }

    public void set_creditno(String _creditno) {
        this._creditno = _creditno;
    }

    public int get_drawings() {
        return _drawings;
    }

    public void set_drawings(int _drawings) {
        this._drawings = _drawings;
    }

    public String get_email() {
        return _email;
    }

    public void set_email(String _email) {
        this._email = _email;
    }

    public String get_firstmobile() {
        return _firstmobile;
    }

    public void set_firstmobile(String _firstmobile) {
        this._firstmobile = _firstmobile;
    }

    public String get_firstqq() {
        return _firstqq;
    }

    public void set_firstqq(String _firstqq) {
        this._firstqq = _firstqq;
    }

    public String get_firsttelephone() {
        return _firsttelephone;
    }

    public void set_firsttelephone(String _firsttelephone) {
        this._firsttelephone = _firsttelephone;
    }

    public int get_gonghui() {
        return _gonghui;
    }

    public void set_gonghui(int _gonghui) {
        this._gonghui = _gonghui;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public int get_invitecode() {
        return _invitecode;
    }

    public void set_invitecode(int _invitecode) {
        this._invitecode = _invitecode;
    }

    public int get_isFreeze() {
        return _isFreeze;
    }

    public void set_isFreeze(int _isFreeze) {
        this._isFreeze = _isFreeze;
    }

    public int get_isvalid() {
        return _isvalid;
    }

    public void set_isvalid(int _isvalid) {
        this._isvalid = _isvalid;
    }

    public int get_isvip() {
        return _isvip;
    }

    public void set_isvip(int _isvip) {
        this._isvip = _isvip;
    }

    public String get_lastloginip() {
        return _lastloginip;
    }

    public void set_lastloginip(String _lastloginip) {
        this._lastloginip = _lastloginip;
    }

    public String get_lastlogintime() {
        return _lastlogintime;
    }

    public void set_lastlogintime(String _lastlogintime) {
        this._lastlogintime = _lastlogintime;
    }

    public String get_loginip() {
        return _loginip;
    }

    public void set_loginip(String _loginip) {
        this._loginip = _loginip;
    }

    public String get_logintime() {
        return _logintime;
    }

    public void set_logintime(String _logintime) {
        this._logintime = _logintime;
    }

    public int get_logintimes() {
        return _logintimes;
    }

    public void set_logintimes(int _logintimes) {
        this._logintimes = _logintimes;
    }

    public String get_mobilenumber() {
        return _mobilenumber;
    }

    public void set_mobilenumber(String _mobilenumber) {
        this._mobilenumber = _mobilenumber;
    }

    public double get_money() {
        return _money;
    }

    public void set_money(double _money) {
        this._money = _money;
    }

    public int get_online() {
        return _online;
    }

    public void set_online(int _online) {
        this._online = _online;
    }

    public int get_ordercummoney() {
        return _ordercummoney;
    }

    public void set_ordercummoney(int _ordercummoney) {
        this._ordercummoney = _ordercummoney;
    }

    public Object get_password() {
        return _password;
    }

    public void set_password(Object _password) {
        this._password = _password;
    }

    public Object get_payment() {
        return _payment;
    }

    public void set_payment(Object _payment) {
        this._payment = _payment;
    }

    public Object get_paypassword() {
        return _paypassword;
    }

    public void set_paypassword(Object _paypassword) {
        this._paypassword = _paypassword;
    }

    public Object get_pwdanswer() {
        return _pwdanswer;
    }

    public void set_pwdanswer(Object _pwdanswer) {
        this._pwdanswer = _pwdanswer;
    }

    public Object get_pwdquestion() {
        return _pwdquestion;
    }

    public void set_pwdquestion(Object _pwdquestion) {
        this._pwdquestion = _pwdquestion;
    }

    public Object get_qq() {
        return _qq;
    }

    public void set_qq(Object _qq) {
        this._qq = _qq;
    }

    public Object get_regfrom() {
        return _regfrom;
    }

    public void set_regfrom(Object _regfrom) {
        this._regfrom = _regfrom;
    }

    public Object get_regtime() {
        return _regtime;
    }

    public void set_regtime(Object _regtime) {
        this._regtime = _regtime;
    }

    public Object get_releasetime() {
        return _releasetime;
    }

    public void set_releasetime(Object _releasetime) {
        this._releasetime = _releasetime;
    }

    public String get_remark() {
        return _remark;
    }

    public void set_remark(String _remark) {
        this._remark = _remark;
    }

    public Object get_selcompletecount() {
        return _selcompletecount;
    }

    public void set_selcompletecount(Object _selcompletecount) {
        this._selcompletecount = _selcompletecount;
    }

    public Object get_seljifen() {
        return _seljifen;
    }

    public void set_seljifen(Object _seljifen) {
        this._seljifen = _seljifen;
    }

    public Object get_seltradecount() {
        return _seltradecount;
    }

    public void set_seltradecount(Object _seltradecount) {
        this._seltradecount = _seltradecount;
    }

    public Object get_status() {
        return _status;
    }

    public void set_status(Object _status) {
        this._status = _status;
    }

    public Object get_telephone() {
        return _telephone;
    }

    public void set_telephone(Object _telephone) {
        this._telephone = _telephone;
    }

    public String get_userid() {
        return _userid;
    }

    public void set_userid(String _userid) {
        this._userid = _userid;
    }

    public Object get_username() {
        return _username;
    }

    public void set_username(Object _username) {
        this._username = _username;
    }

    public String get_vipendtime() {
        return _vipendtime;
    }

    public void set_vipendtime(String _vipendtime) {
        this._vipendtime = _vipendtime;
    }

    public String get_vipgames() {
        return _vipgames;
    }

    public void set_vipgames(String _vipgames) {
        this._vipgames = _vipgames;
    }

    public Object get_virtualmoney() {
        return _virtualmoney;
    }

    public void set_virtualmoney(Object _virtualmoney) {
        this._virtualmoney = _virtualmoney;
    }

    public Object get_yajin() {
        return _yajin;
    }

    public void set_yajin(Object _yajin) {
        this._yajin = _yajin;
    }

    public String get_bankName() {
        return _bankName;
    }

    public void set_bankName(String _bankName) {
        this._bankName = _bankName;
    }

    public String get_chkMobile() {
        return _chkMobile;
    }

    public void set_chkMobile(String _chkMobile) {
        this._chkMobile = _chkMobile;
    }

    public int get_chkMobileOrderStatus() {
        return _chkMobileOrderStatus;
    }

    public void set_chkMobileOrderStatus(int _chkMobileOrderStatus) {
        this._chkMobileOrderStatus = _chkMobileOrderStatus;
    }

    public int get_chkMobileStatus() {
        return _chkMobileStatus;
    }

    public void set_chkMobileStatus(int _chkMobileStatus) {
        this._chkMobileStatus = _chkMobileStatus;
    }

    public String get_chkMobileUUID() {
        return _chkMobileUUID;
    }

    public void set_chkMobileUUID(String _chkMobileUUID) {
        this._chkMobileUUID = _chkMobileUUID;
    }

    public Object get_chkType() {
        return _chkType;
    }

    public void set_chkType(Object _chkType) {
        this._chkType = _chkType;
    }

    public String get_cityName() {
        return _cityName;
    }

    public void set_cityName(String _cityName) {
        this._cityName = _cityName;
    }

    public int get_defaultChkType() {
        return _defaultChkType;
    }

    public void set_defaultChkType(int _defaultChkType) {
        this._defaultChkType = _defaultChkType;
    }

    public Object get_isRightIp() {
        return _isRightIp;
    }

    public void set_isRightIp(Object _isRightIp) {
        this._isRightIp = _isRightIp;
    }

    public String get_provinceName() {
        return _provinceName;
    }

    public void set_provinceName(String _provinceName) {
        this._provinceName = _provinceName;
    }

    public String get_weChatNo() {
        return _weChatNo;
    }

    public void set_weChatNo(String _weChatNo) {
        this._weChatNo = _weChatNo;
    }

    public int get_weChatStatus() {
        return _weChatStatus;
    }

    public void set_weChatStatus(int _weChatStatus) {
        this._weChatStatus = _weChatStatus;
    }
}
