package com.uu898.gamesdk.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.uu898.gamesdk.core.ResourceUtils;
import com.uu898.gamesdk.fragmentation.SupportFragment;
import com.uu898.gamesdk.model.GBaseModel;
import com.uu898.gamesdk.model.request.GGetSMSAuthCode;
import com.uu898.gamesdk.model.request.GUnBinding;
import com.uu898.gamesdk.model.response.BUserInfo;
import com.uu898.gamesdk.network.NetCallback;
import com.uu898.gamesdk.network.TaskEngine;
import com.uu898.gamesdk.utils.AccountManager;
import com.uu898.gamesdk.utils.CountDownTimer;
import com.uu898.gamesdk.utils.StringUtils;
import com.uu898.gamesdk.utils.ToastUtil;

import java.util.List;

/**
 *  解除绑定手机界面
 * Created by zhangbo on 2016/6/23.
 */
public class UserUnBindingFragment extends BaseFragment {

    private EditText mEdtAuthCode;
    private Button mBtGetSMSCode;
    private Button mBtNext;

    public static UserUnBindingFragment newInstance() {
        Bundle args = new Bundle();
        UserUnBindingFragment fragment = new UserUnBindingFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        View view = inflater.inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_change_binding"), container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "解除绑定");

        TextView tv = (TextView) view.findViewById(getId("ug_tv_prompt"));
        String _userid = AccountManager.getInstance().getCurrentUserID();
        tv.setText(_userid);
        mEdtAuthCode = (EditText) view.findViewById(getId("ug_edt_auth_code"));
        mBtGetSMSCode = (Button) view.findViewById(getId("ug_bt_get_sms_code"));
        mBtNext = (Button) view.findViewById(getId("ug_bt_next"));

        mBtGetSMSCode.setOnClickListener(onClickListener);
        mBtNext.setOnClickListener(onClickListener);
    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v.getId() == getId("ug_bt_get_sms_code")) {
                verifyPhone();
            } else if (v.getId() == getId("ug_bt_next")) {
                verifyForm();
            }
        }
    };

    private void verifyPhone() {
        doGetSMSCode(AccountManager.getInstance().getUserInfo().phoneNo);
    }

    private void verifyForm() {
        String authCode = mEdtAuthCode.getText().toString();

        if (StringUtils.isEmpty(authCode)) {
            ToastUtil.showToast(_mActivity, "请输入验证码");
            return;
        }
        doUnBinding(authCode);
    }

    private void doGetSMSCode(String phone) {
        GGetSMSAuthCode model = new GGetSMSAuthCode();
        model.setType(GGetSMSAuthCode.type_2);//2 修改绑定手机验证码
        TaskEngine.getInstance().doGetSMSAuthCode(model, new NetCallback(this) {

            @Override
            public void _onNext(Object o) {
                new CountDownTimer(60000, 1000, mBtGetSMSCode, "获取验证码").start();
                ToastUtil.showToast(_mActivity, "短信验证码已发送至您的手机");
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

    // TODO: 17/4/25 需要改成解除绑定的逻辑
    private void doUnBinding(String authcode) {
        GUnBinding model = new GUnBinding();
        model.setCode(authcode);
        TaskEngine.getInstance().doUnBinding(model, new NetCallback(this) {

            @Override
            public void _onNext(Object o) {
                ToastUtil.showToast(_mActivity, "解绑成功");
                doGetUserInfo();
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

    /**
     * 不管是绑定成功,还是换绑成功,都要重新获取一次用户信息
     */
    private void doGetUserInfo() {
        TaskEngine.getInstance().doGetUserInfo(new GBaseModel(), new NetCallback<BUserInfo>(this) {
            @Override
            public void _onNext(BUserInfo result) {
                AccountManager.getInstance().saveAccountInfo(result);
                List<Fragment> fragmentList = getFragmentManager().getFragments();
                if (null != fragmentList) {
                    Fragment fragment = fragmentList.get(0);
                    if (fragment instanceof SupportFragment) {
                        popTo(fragment.getClass(), false);
                    }
                }else{
                    _mActivity.finish();
                }
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }

}
