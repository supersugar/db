package com.uu898app.model.request;

import com.uu898app.model.GBaseModel;

/**
 * 生成微信订单号
 * Created by zhangbo on 2016/7/13.
 */
public class GGenWxPayNo extends GBaseModel{

    /**
     * money : 101
     */

    private String Money;
    private String actMoney;

    public String getActMoney() {
        return actMoney;
    }

    public void setActMoney(String actMoney) {
        this.actMoney = actMoney;
    }

    public String getMoney() {
        return Money;
    }

    public void setMoney(String money) {
        this.Money = money;
    }
}
