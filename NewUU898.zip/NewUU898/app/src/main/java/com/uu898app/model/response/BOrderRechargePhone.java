package com.uu898app.model.response;

/**
 * Created by zhangbo on 2016/7/11.
 */
public class   BOrderRechargePhone {

    /**
     * rowId : 1
     * ID : 708467
     * orderNo : MSJ20160716164041-32757
     * CardName : 河南联通手机快充20元
     * UserId : 13203713938
     * Phone : 13203713938
     * ParValue : 20
     * Price : 20
     * number : 1
     * status : 3
     * addtime : 2016/7/16 16:40:07
     * kefu : 227
     * remark :
     * payTime : 2016/7/16 16:40:51
     * PayType : 6
     * CardId : 152001
     * Type : 1
     * CompleteTime : 2016/7/16 16:42:50
     * IsMO : 0
     * inPrice : 19.91
     * dealLevel : A
     * operateTime : 2016/7/16 16:42:49
     * IP : 171.8.225.205
     * kefuName : 点卡客服801
     * statusName : 交易成功
     */

    private int rowId;
    private int ID;
    private String orderNo;
    private String CardName;
    private String UserId;
    private String Phone;
    private int ParValue;
    private int Price;
    private int number;
    private int status;
    private String addtime;
    private int kefu;
    private String remark;
    private String payTime;
    private int PayType;
    private String CardId;
    private int Type;
    private String CompleteTime;
    private int IsMO;
    private double inPrice;
    private String dealLevel;
    private String operateTime;
    private String IP;
    private String kefuName;
    private String statusName;

    public int getRowId() {
        return rowId;
    }

    public void setRowId(int rowId) {
        this.rowId = rowId;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getCardName() {
        return CardName;
    }

    public void setCardName(String CardName) {
        this.CardName = CardName;
    }

    public String getUserId() {
        return UserId;
    }

    public void setUserId(String UserId) {
        this.UserId = UserId;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String Phone) {
        this.Phone = Phone;
    }

    public int getParValue() {
        return ParValue;
    }

    public void setParValue(int ParValue) {
        this.ParValue = ParValue;
    }

    public int getPrice() {
        return Price;
    }

    public void setPrice(int Price) {
        this.Price = Price;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getAddtime() {
        return addtime;
    }

    public void setAddtime(String addtime) {
        this.addtime = addtime;
    }

    public int getKefu() {
        return kefu;
    }

    public void setKefu(int kefu) {
        this.kefu = kefu;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getPayTime() {
        return payTime;
    }

    public void setPayTime(String payTime) {
        this.payTime = payTime;
    }

    public int getPayType() {
        return PayType;
    }

    public void setPayType(int PayType) {
        this.PayType = PayType;
    }

    public String getCardId() {
        return CardId;
    }

    public void setCardId(String CardId) {
        this.CardId = CardId;
    }

    public int getType() {
        return Type;
    }

    public void setType(int Type) {
        this.Type = Type;
    }

    public String getCompleteTime() {
        return CompleteTime;
    }

    public void setCompleteTime(String CompleteTime) {
        this.CompleteTime = CompleteTime;
    }

    public int getIsMO() {
        return IsMO;
    }

    public void setIsMO(int IsMO) {
        this.IsMO = IsMO;
    }

    public double getInPrice() {
        return inPrice;
    }

    public void setInPrice(double inPrice) {
        this.inPrice = inPrice;
    }

    public String getDealLevel() {
        return dealLevel;
    }

    public void setDealLevel(String dealLevel) {
        this.dealLevel = dealLevel;
    }

    public String getOperateTime() {
        return operateTime;
    }

    public void setOperateTime(String operateTime) {
        this.operateTime = operateTime;
    }

    public String getIP() {
        return IP;
    }

    public void setIP(String IP) {
        this.IP = IP;
    }

    public String getKefuName() {
        return kefuName;
    }

    public void setKefuName(String kefuName) {
        this.kefuName = kefuName;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }
}
