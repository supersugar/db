package com.uu393.market.module.h5game;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import com.uu393.market.R;
import com.uu393.market.model.response.BH5ZaiWanAll;
import com.uu393.market.module.base.BaseFragment;
import com.uu393.market.module.search.SearchActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class ZaiWanH5MoreFragment extends BaseFragment {


    @Bind(R.id.ptf_zaiwan_more)
    PullLoadMoreRecyclerView mPtfRecyclerView;
    @Bind(R.id.ib_h5game_zaiwan_more_go_back)
    ImageButton mGoBack;
    @Bind(R.id.iv_h5game_zaiwan_do_search)
    ImageButton mDoSearch;
    private ZaiWanMoreRecyclerAdapter mAdapter;
    private List<BH5ZaiWanAll> datas;
    public static ZaiWanH5MoreFragment newInstance() {
        ZaiWanH5MoreFragment fragment = new ZaiWanH5MoreFragment();
        Bundle bundle = new Bundle();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_zai_wan_h5_more, container, false);
        ButterKnife.bind(this, view);
        datas = new ArrayList<>();
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mPtfRecyclerView.setLinearLayout();
        mAdapter = new ZaiWanMoreRecyclerAdapter(_mActivity);
        mPtfRecyclerView.setPullRefreshEnable(true);
        mPtfRecyclerView.setPushRefreshEnable(false);
        mPtfRecyclerView.setAdapter(mAdapter);

        getGames();
        mPtfRecyclerView.setOnPullLoadMoreListener(new PullLoadMoreRecyclerView.PullLoadMoreListener() {
            @Override
            public void onRefresh() {

                getGames();
                mPtfRecyclerView.setPullLoadMoreCompleted();
            }

            @Override
            public void onLoadMore() {

            }
        });
    }

    private void getGames(){
        TaskEngine.setTokenUseridPhoneState(2);
        TaskEngine.getInstance().doGetH5ZaiWanAll(new JsonCallback<List<BH5ZaiWanAll>>() {
            @Override
            public void onSuccess(List<BH5ZaiWanAll> list, Call call, Response response) {

                if (list!=null&&!list.isEmpty()){
                    datas.clear();
                    datas.addAll(list);
                    mAdapter.refresh(datas);
                }
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @OnClick({R.id.ib_h5game_zaiwan_more_go_back, R.id.iv_h5game_zaiwan_do_search})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ib_h5game_zaiwan_more_go_back:
                getActivity().finish();
                break;
            case R.id.iv_h5game_zaiwan_do_search:
                startActivity(new Intent(getActivity(), SearchActivity.class));
                break;
        }
    }
}
