package com.uu661.util;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by bo on 16/12/1.
 */

public class ItemsFactory {

    public static List<String> getSameLabels() {
        List<String> mLabels = new ArrayList<String>();
        mLabels.add("倚天屠龙记");
        mLabels.add("新大主宰");
        mLabels.add("逍遥西游");
        mLabels.add("仙逆");
        mLabels.add("无双剑姬");
        mLabels.add("完美世界3D");
        mLabels.add("天子");
        mLabels.add("天天有喜");
        return mLabels;
    }

}
