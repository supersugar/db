package com.uu393.market.module;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.eventbus.EB;

public class AdvertisementActivity extends BaseActivity implements View.OnClickListener {
    private ImageView mIvAdvertisement;//广告图片
    private TextView mCountDown,mSkip;
    private Button mCheckNow;
    private int time=5;

    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what==0x99){
                if (time>=0){
                    mCountDown.setText("0"+time);
                    time--;
                    mHandler.sendEmptyMessageDelayed(0x99,1000);
                }else {
                    //广告结束，跳转到主页
                    AdvertisementActivity.this.startActivity(new Intent(AdvertisementActivity.this,MainActivity.class));
                    AdvertisementActivity.this.finish();
                }
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advertisement);
        mIvAdvertisement = (ImageView) findViewById(R.id.iv_advertisement);
        mCountDown = (TextView) findViewById(R.id.tv_advertisement_countdown);
        mSkip = (TextView) findViewById(R.id.tv_advertisement_skip);
        mCheckNow = (Button) findViewById(R.id.btn_advertisement_go);

        mSkip.setOnClickListener(this);
        mCheckNow.setOnClickListener(this);
        mHandler.sendEmptyMessage(0x99);//开启倒计时
    }



    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.tv_advertisement_skip:
                //跳过广告，进入主页
                mHandler.removeMessages(0x99);
                AdvertisementActivity.this.startActivity(new Intent(AdvertisementActivity.this,MainActivity.class));
                AdvertisementActivity.this.finish();
                break;
            case R.id.btn_advertisement_go:
                //跳过广告，进入主页并显示bt游戏
                mHandler.removeMessages(0x99);
                SPUtil.put(App.mContext,"isSelectBT",true);
                AdvertisementActivity.this.startActivity(new Intent(AdvertisementActivity.this,MainActivity.class));
                AdvertisementActivity.this.finish();
                break;
            default:
                break;
        }
    }
}
