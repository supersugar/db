package com.uu898app.model.response;

import com.chad.library.adapter.base.entity.MultiItemEntity;

import java.io.Serializable;

/**
 * Created by zhangbo on 2016/6/20.
 */
public class BGame implements Serializable,MultiItemEntity {
    /**
     * ID : 281
     * name : 暗黑破坏神3
     * firstCharactor : A
     * pinyin : anheipohuaishen3
     * hot : false
     * strongDisplay : false
     * gameImage : images/logo.jpg
     * fName : A-暗黑破坏神3
     */

    private int ID;
    private String name;
    private String firstCharactor;
    private String pinyin;
    private boolean hot;
    private boolean strongDisplay;
    private String gameImage;
    private String fName;


    private int type;
    public static final int MULTI_TYPE_SMALL = 1;
    public static final int MULTI_TYPE_BIG  = 2;
    private int itemType = MULTI_TYPE_SMALL;

    public void setItemType(int itemType) {
        this.itemType = itemType;
    }

    @Override
    public int getItemType() {
        return itemType;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFirstCharactor() {
        return firstCharactor;
    }

    public void setFirstCharactor(String firstCharactor) {
        this.firstCharactor = firstCharactor;
    }

    public String getPinyin() {
        return pinyin;
    }

    public void setPinyin(String pinyin) {
        this.pinyin = pinyin;
    }

    public boolean isHot() {
        return hot;
    }

    public void setHot(boolean hot) {
        this.hot = hot;
    }

    public boolean isStrongDisplay() {
        return strongDisplay;
    }

    public void setStrongDisplay(boolean strongDisplay) {
        this.strongDisplay = strongDisplay;
    }

    public String getGameImage() {
        return gameImage;
    }

    public void setGameImage(String gameImage) {
        this.gameImage = gameImage;
    }

    public String getFName() {
        return fName;
    }

    public void setFName(String fName) {
        this.fName = fName;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }


}
