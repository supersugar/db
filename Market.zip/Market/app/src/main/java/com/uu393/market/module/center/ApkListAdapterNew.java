package com.uu393.market.module.center;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.request.GetRequest;
import com.lzy.okserver.download.DownloadInfo;
import com.lzy.okserver.download.DownloadManager;
import com.lzy.okserver.download.DownloadService;
import com.lzy.okserver.listener.DownloadListener;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.core.DownloadHelper;
import com.uu393.market.model.request.GGetGameDetail;
import com.uu393.market.model.response.BGame;
import com.uu393.market.module.center.slider.ISlideHelper;
import com.uu393.market.module.center.slider.SlideViewHolder;
import com.uu393.market.module.home.AppDetailActivity;
import com.uu393.market.module.share.*;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ApkUtils;
import com.uu393.market.util.DateUtils;
import com.uu393.market.util.GlideRoundTransform;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.StringUtils;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.eventbus.EB;
import com.uu393.market.view.progressbutton.SubmitProcessButton;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Response;

import static com.uu393.market.Constant.UMENG_EVENT_ID_DOWNLOAD;

/**
 * Created by Administrator on 2017/4/11.
 */

public class ApkListAdapterNew extends RecyclerView.Adapter<ApkListAdapterNew.ApkHolder> {

    private Activity mContext;
    private DownloadManager mDownloadManager;
    private List<BGame> data = new ArrayList<>();
    private ISlideHelper mISlideHelper = new ISlideHelper();
    private Map<Integer, Boolean> mItemCheckStates = new HashMap<>();//存放单项选中状态
    private boolean mIsShareUser = false;
    public void setIsShareUser (boolean isShareUser){
        this.mIsShareUser = isShareUser;
        notifyDataSetChanged();
    }

    public void removeReference(){
        mContext = null;
        mDownloadManager =null;
    }

    public ApkListAdapterNew(Activity context) {
        this.mContext = context;
        this.mDownloadManager = DownloadService.getDownloadManager();
        initItemCheckState();
    }

    private void initItemCheckState() {//初始化全为未选中
        for (int i = 0; i < data.size(); i++) {
            mItemCheckStates.clear();
            mItemCheckStates.put(i, false);
        }
    }

    //返回集合给MainActivity
    public Map<Integer, Boolean> getMap() {
        return mItemCheckStates;
    }

    public void updateData(List<BGame> data) {
        this.data = data;
        initItemCheckState();
        notifyDataSetChanged();
    }

    public void slideOpen() {
        mISlideHelper.slideOpen();
    }

    public void slideClose() {
        mISlideHelper.slideClose();
    }

    public void updateView() {
        notifyDataSetChanged();
    }

    @Override
    public ApkListAdapterNew.ApkHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_collectgame, parent, false);
        ApkListAdapterNew.ApkHolder oneSlideViewHolder = new ApkListAdapterNew.ApkHolder(view);
        mISlideHelper.add(oneSlideViewHolder);
        return oneSlideViewHolder;
    }

    @Override
    public void onBindViewHolder(ApkListAdapterNew.ApkHolder holder, final int position) {
        if (data.get(position) != null) {
            holder.bind();
            BGame gameModel = data.get(position);
            holder.bind(gameModel, position);
            holder.refresh();
            holder.root.setTag(position);
            holder.mCbCancelCollect.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    mItemCheckStates.put(position, isChecked);
                }
            });
            if (mItemCheckStates.get(position) == null) {
                mItemCheckStates.put(position, false);
            }
            holder.mCbCancelCollect.setChecked(mItemCheckStates.get(position));
        }
    }


    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ApkHolder extends SlideViewHolder implements View.OnClickListener {
        private int showTagNumber;//显示的标签数量，超过3时后面的不显示
        private View root;
        private DownloadInfo downloadInfo;
        private BGame gameModel;
        private ImageView icon;
        private CheckBox mCbCancelCollect;
        private TextView name;
        private TextView tvShare;//分享赚按钮
        private TextView discount;
        private TextView typeAndSize;
        private TextView describe;
        private TextView isBt;
        private TextView first;
        private TextView isQuick;
        private TextView isGift;
        private TextView isActivity;
        private SubmitProcessButton downloadBt;
        private ImageView isRecommend;
        private LinearLayout layout_one;
        private DownloadListener downloadListener;
        private LinearLayout Tmove_item;

        private TextView juanPrice ;
        private TextView juanSurplus ;
        private TextView juanTotal;
        private View juanBar;

        public ApkHolder(View view) {
            super(view);
            this.root = view;
            icon = (ImageView) view.findViewById(R.id.app_icon);
            name = (TextView) view.findViewById(R.id.tv_one);
            tvShare = (TextView) view.findViewById(R.id.bt_app_detail_share);
            mCbCancelCollect = (CheckBox) view.findViewById(R.id.item_select);
            discount = (TextView) view.findViewById(R.id.tv_discount);
            typeAndSize = (TextView) view.findViewById(R.id.tv_two);
            describe = (TextView) view.findViewById(R.id.tv_three);
            layout_one = (LinearLayout) view.findViewById(R.id.layout_one);
            isBt = (TextView) view.findViewById(R.id.tv_bt);
            first = (TextView) view.findViewById(R.id.tv_first);
            isQuick = (TextView) view.findViewById(R.id.tv_add);
            isGift = (TextView) view.findViewById(R.id.tv_gift);
            isActivity = (TextView) view.findViewById(R.id.tv_activity);
            downloadBt = (SubmitProcessButton) view.findViewById(R.id.download_bt);
            isRecommend = (ImageView) view.findViewById(R.id.app_recommend);
            Tmove_item = (LinearLayout) view.findViewById(R.id.move_item);
            juanPrice = (TextView) view.findViewById(R.id.juannumber_tv);//优惠券面额
            juanSurplus = (TextView) view.findViewById(R.id.shengtyu_number);//优惠券剩余数量
            juanTotal = (TextView) view.findViewById(R.id.total_number);//优惠券总数量
            juanBar = view.findViewById(R.id.juan_layout);
        }

        public void bind(final BGame gameModel, final int position) {
            this.gameModel = gameModel;
            //更新持有的downloadInfo对象
            if (gameModel==null) return;
            downloadInfo = mDownloadManager.getDownloadInfo(gameModel.getId());
            if (null != downloadInfo) {
                downloadListener = new ApkListAdapterNew.MyDownloadListener();
                downloadListener.setUserTag(this);
                downloadInfo.setListener(downloadListener);
            }

            //固定不变的在这里设置
            int defaultAndError = ImageHelper.randomImage();
            Glide.with(App.mContext)
                    .load(gameModel.getIcon())
                    .error(defaultAndError)
                    .placeholder(defaultAndError)
                    .transform(new GlideRoundTransform(App.mContext, 10))
                    .into(icon);
            name.setText(gameModel.getGameName());
            if (gameModel.getDiscount().equals("10")) {
                discount.setVisibility(View.GONE);
            } else {
                discount.setVisibility(View.VISIBLE);
                discount.setText(gameModel.getDiscount() + "折");
            }
            if ("0".equals(gameModel.getIsRecommend())) {//不是推荐游戏
                isRecommend.setVisibility(View.GONE);
            } else {//是推荐游戏
                isRecommend.setVisibility(View.VISIBLE);
            }

            if ("0".equals(gameModel.getIsBT().trim().replace(" ",""))){//不是BT
                isBt.setVisibility(View.GONE);
            }else {
                isBt.setVisibility(View.VISIBLE);
                showTagNumber++;
            }
            if (!TextUtils.isEmpty(gameModel.getIsFirst())) {
                if ("1".equals(gameModel.getIsFirst())) {//是首发游戏
                    String firstTime = gameModel.getFirstTime();
                    if (TextUtils.isEmpty(firstTime)) {
                        first.setVisibility(View.GONE);
                    } else {

                        Date date = DateUtils.parse(firstTime, "yyyy-MM-dd HH:mm:ss");//"firstTime": "2017-3-31 00:00:00”,(首发时间)
                        SimpleDateFormat format = new SimpleDateFormat("MM-dd");
                        if (date != null) {

                            SimpleDateFormat formatDay = new SimpleDateFormat("d日");
                            String day = formatDay.format(date);
                            Date nextDay = DateUtils.getNextDay(new Date());
                            Calendar calendar = Calendar.getInstance();
                            calendar.setTime(date);
                            calendar.add(Calendar.DAY_OF_MONTH, 7);
                            Date dateAfterSeven = calendar.getTime();

                            int compareTo = dateAfterSeven.compareTo(new Date());
                            if (format.format(date).equals(format.format(new Date()))) {//当天
                                showTagNumber++;
                                first.setVisibility(View.VISIBLE);
                                first.setText("今日首发");
                            } else if (format.format(date).equals(format.format(nextDay))) {
                                showTagNumber++;
                                first.setVisibility(View.VISIBLE);
                                first.setText("明日首发");
                            } else if (compareTo < 0) {//已经超过一周，不显示
                                first.setVisibility(View.GONE);
                            } else {
                                showTagNumber++;
                                first.setVisibility(View.VISIBLE);
                                first.setText(day + "首发");
                            }

                        } else {
                            first.setVisibility(View.GONE);
                        }
                    }
                } else {
                    first.setVisibility(View.GONE);
                }
            }
            if ("0".equals(gameModel.getIsActivity().trim().replace(" ",""))){//不是活动
                isActivity.setVisibility(View.GONE);
            }else {
                isActivity.setVisibility(View.VISIBLE);
                showTagNumber++;
            }
            if ("1".equals(gameModel.getIsGift().trim().replace(" ",""))&&showTagNumber<3){//不是礼包
                isGift.setVisibility(View.VISIBLE);
            }else {
                isGift.setVisibility(View.GONE);

            }

            if ("1".equals(gameModel.getIsQuick().trim().replace(" ",""))&&showTagNumber<3){//不是加速
                isQuick.setVisibility(View.VISIBLE);
            }else {
                isQuick.setVisibility(View.GONE);
            }


            typeAndSize.setText(gameModel.getTypeName() + " / " + gameModel.getSize());
            describe.setText(gameModel.getDescribe());
            downloadBt.setOnClickListener(this);
            layout_one.setOnClickListener(this);
            if (mIsShareUser){//是分享赚用户
                String royaltyRate = gameModel.getRoyaltyRate();//提成比例
                if (StringUtils.isRealMoney(royaltyRate)){
                    Float rotate = Float.valueOf(royaltyRate.trim().replace(" ", ""));
                    Float rotatePercentage = StringUtils.keepTwoDecimals(rotate * 100);//百分数
                    tvShare.setText("分享赚"+rotatePercentage+"%");
                }
                tvShare.setVisibility(View.VISIBLE);
                tvShare.setClickable(true);
                tvShare.setOnClickListener(this);
            }else {
                tvShare.setClickable(false);
                tvShare.setVisibility(View.GONE);
            }
            if (TextUtils.isEmpty(gameModel.getCouponPrice())&&TextUtils.isEmpty(gameModel.getSurplusNum())&&TextUtils.isEmpty(gameModel.getTotalNum())){
                juanBar.setVisibility(View.GONE);
            }else {
                juanBar.setVisibility(View.VISIBLE);
                if (!TextUtils.isEmpty(gameModel.getCouponPrice())){
                    juanPrice.setText(gameModel.getCouponPrice());
                }
                if (!TextUtils.isEmpty(gameModel.getSurplusNum())){
                    juanSurplus.setText(gameModel.getSurplusNum());
                }
                if (!TextUtils.isEmpty(gameModel.getTotalNum())){
                    juanTotal.setText(gameModel.getTotalNum());
                }
            }

        }

        @Override
        public void onClick(View v) {
            if (v.getId() == R.id.download_bt) {//下载按钮
                EB.postEmpty(EB.TAG.REQUEST_SD_CARD_COLLECT_ACTIVITY);
                String text = downloadBt.getText().toString();
                if (text.equals("打开")) {
                    EB.postObject(EB.TAG.CLICK_PLAY, gameModel);
                    ApkUtils.launchApp(mContext, gameModel.getPackageName());
                }
                if (text.equals("安装")) {
                    //先判断安装文件是否存在
                    File temp = new File(downloadInfo.getTargetPath());
                    if (temp.exists()) {
                        ApkUtils.install(mContext, temp);
                        EB.postObject(EB.TAG.CLICK_INSATLL, gameModel);
                    } else {
                        mDownloadManager.removeTask(gameModel.getId(), true);
                        ToastUtil.showToast(App.mContext, "安装包可能被删除了，请重新下载");
                        notifyDataSetChanged();
                    }
                }
                if (text.equals("下载") || text.equals("更新")) {
                    //一旦触发下载动作(下载/更新/重试/继续),都要综合判断当前手机情况及设置是否允许下载
                    if (DownloadHelper.checkCanDownload(mContext)) {
                        HashMap<String, String> map = new HashMap<>();
                        map.put("gameName", gameModel.getGameName());
                        MobclickAgent.onEvent(mContext, UMENG_EVENT_ID_DOWNLOAD, map);//友盟统计下载事件
                        String url = gameModel.getAndroidPackage();

                        if (StringUtils.isEmpty(url)) {
                            ToastUtil.showToast(App.mContext, "下载链接错误 " + url);
                            return;
                        }
                        GetRequest request = OkGo.get(gameModel.getAndroidPackage());
                        mDownloadManager.addTask(gameModel.getId(), gameModel, request, downloadListener);
                        notifyDataSetChanged();
                    }
                }
                if (text.equals("重试") || text.equals("暂停中")) {

                    if (DownloadHelper.checkCanDownload(mContext)) {
                        mDownloadManager.addTask(gameModel.getId(), downloadInfo.getRequest(), downloadInfo.getListener());
                    }
                }
                if (text.contains("%")) {
                    mDownloadManager.pauseTask(downloadInfo.getTaskKey());
                }
                if (text.equals("等待")) {
                    ToastUtil.showToast(App.mContext, "已经加入下载队列");
                }
            } else if (v.getId() == R.id.layout_one) {
                Intent intent = new Intent(mContext, AppDetailActivity.class);
                intent.putExtra(AppDetailActivity.INTENT_KEY_GAME_ID, gameModel.getId());
                mContext.startActivity(intent);

            }else if (v.getId() == R.id.bt_app_detail_share){
                Intent intent = new Intent(mContext, com.uu393.market.module.share.ShareActivity.class);
                intent.putExtra("gameId", gameModel.getId());
                mContext.startActivity(intent);
            }

        }

        //更新单项内容显示状态
        private void refresh() {
            //先根据包名判断游戏是否安装
            if (ApkUtils.hasInstalled(mContext, gameModel.getPackageName())) {
                //InstalledHelper.getInstance(App.mContext).addOneInstalledRecord(gameModel.getPackageName(), gameModel.getId());
                //已安装的,有可能正在升级
                if (null != downloadInfo && downloadInfo.getState() == DownloadManager.DOWNLOADING) {
                    double progress = Math.round(downloadInfo.getProgress() * 10000.00) * 1 / 100.00;
                    downloadBt.setProgress(progress, progress + "%");
                    return;
                }
                //已经安装的,需要判断是否需要升级
                if (ApkUtils.whetherUpdate(mContext, gameModel.getPackageName(), gameModel.getVersionCode())) {
                    downloadBt.setProgress("更新");
                } else {
                    downloadBt.setProgress("打开");
                    downloadBt.setTextColor(mContext.getResources().getColor(R.color.white));
                    downloadBt.setBackground(mContext.getResources().getDrawable(R.drawable.third_pb_green));
                }
                return;
            }

            if (null == downloadInfo) {
                downloadBt.setProgress("下载");
                downloadBt.setTextColor(mContext.getResources().getColor(R.color.blue));
                downloadBt.setBackground(mContext.getResources().getDrawable(R.drawable.third_pb_normal));
                return;
            }
            switch (downloadInfo.getState()) {
                case DownloadManager.NONE:
                    downloadBt.setProgress("下载");
                    break;
                case DownloadManager.DOWNLOADING:
                    double progress = Math.round(downloadInfo.getProgress() * 10000.00) * 1 / 100.00;
                    downloadBt.setProgress(progress, progress + "%");
                    break;
                case DownloadManager.PAUSE://当前为暂停状态
                    downloadBt.setProgress(Math.round(downloadInfo.getProgress() * 10000) * 1 / 100.00, "暂停中");
                    break;
                case DownloadManager.WAITING://当前为等待状态
                    downloadBt.setProgress("等待");
                    break;
                case DownloadManager.ERROR://当前为错误状态
                    downloadBt.setProgress("重试");
                    break;
                case DownloadManager.FINISH://当前为完成状态
                    if (ApkUtils.hasInstalled(mContext, new File(downloadInfo.getTargetPath()))) {
                        //这里需要再判断当前已安装的版本号是否为最新的，否，显示为安装
                        downloadBt.setProgress("打开");

                    } else {
                        downloadBt.setProgress("安装");
                        downloadBt.setTextColor(App.mContext.getResources().getColor(R.color.white));
                        downloadBt.setBackground(mContext.getResources().getDrawable(R.drawable.third_pb_pressed));
                    }
                    break;
            }
        }

        @Override
        public void doAnimationSet(int offset, float fraction) {
            Tmove_item.scrollTo(offset, 0);
            mCbCancelCollect.setScaleX(fraction);
            mCbCancelCollect.setScaleY(fraction);
            mCbCancelCollect.setAlpha(fraction * 255);
        }

        @Override
        public void onBindSlideClose(int state) {

        }

        @Override
        public void doAnimationSetOpen(int state) {

        }

        public void bind() {
            setOffset(40);
            onBindSlide(Tmove_item);
        }
    }

    private class MyDownloadListener extends DownloadListener {

        public MyDownloadListener() {
        }

        @Override
        public void onProgress(DownloadInfo downloadInfo) {
            //需要找到正确的位置刷新
            if (getUserTag() == null) {
                return;
            }
            ApkListAdapterNew.ApkHolder holder = (ApkListAdapterNew.ApkHolder) getUserTag();
            holder.refresh();  //这里不能使用传递进来的 DownloadInfo，否者会出现条目错乱的问题
        }

        @Override
        public void onFinish(DownloadInfo downloadInfo) {
            if (downloadInfo == null)
                return;
            String taskKey = downloadInfo.getTaskKey();
            if (taskKey == null)
                return;
            GGetGameDetail model = new GGetGameDetail(taskKey);
            TaskEngine.setTokenUseridPhoneState(1);
            TaskEngine.getInstance().doGetGameDetailNew(model, new JsonCallback<BGame>() {
                @Override
                public void onSuccess(BGame bGame, Call call, Response response) {
                    if (bGame != null && bGame.getGameName() != null)
                        ToastUtil.showToast(mContext, bGame.getGameName() + "已经下载完成");
                }
            });
            DownloadHelper.addOneDownloadRecord(mContext, downloadInfo);//todo 向缓存的下载记录中加入一条游戏信息记录
        }

        @Override
        public void onError(DownloadInfo downloadInfo, String errorMsg, Exception e) {
            if (StringUtils.isEmpty(errorMsg)) {
                errorMsg = "下载出错，请重试";
            }
            ToastUtil.showToast(App.mContext, errorMsg);
        }
    }

}

