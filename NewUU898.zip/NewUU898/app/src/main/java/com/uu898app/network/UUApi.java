package com.uu898app.network;


import com.uu898app.model.BaseModel;
import com.uu898app.model.response.BBannerResponse;
import com.uu898app.model.response.BMessage;
import com.uu898app.model.response.BOrderCommon;
import com.uu898app.model.response.BOrderGameDK;
import com.uu898app.model.response.BOrderRechargePhone;
import com.uu898app.model.response.BCheckUpdate;
import com.uu898app.model.response.BGame;
import com.uu898app.model.response.BGameArea;
import com.uu898app.model.response.BGameDKList;
import com.uu898app.model.response.BGameKind;
import com.uu898app.model.response.BGameServer;
import com.uu898app.model.response.BGoods;
import com.uu898app.model.response.BGoodsDetail;
import com.uu898app.model.response.BLogin;
import com.uu898app.model.response.BMobileData;
import com.uu898app.model.response.BOrderRechargeQQ;
import com.uu898app.model.response.BPayMoney;
import com.uu898app.model.response.BPayNo;
import com.uu898app.model.response.BRechargeDKNoResult;
import com.uu898app.model.response.BRechargeNoResult;
import com.uu898app.model.response.BUserInfo;
import com.uu898app.model.response.BUserInfoIntegrity;
import com.uu898app.network.NetConstant;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import rx.Observable;

/**
 *
 */
public interface UUApi {

    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<ResponseBody> common(@Field("UU898_APP") String request);

    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<BLogin>> login(@Field("UU898_APP") String request);

    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<BCheckUpdate>> checkUpdate(@Field("UU898_APP") String request);

    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<BUserInfo>> getUserInfo(@Field("UU898_APP") String request);

    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<List<BGame>>> getGameList(@Field("UU898_APP") String request);

    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<List<BGameArea>>> getGameAreaList(@Field("UU898_APP") String request);

    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<List<BGameServer>>> getGameServerList(@Field("UU898_APP") String request);

    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<List<BGameKind>>> getGameKindList(@Field("UU898_APP") String request);

    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<BGoodsDetail>> getGameDetail(@Field("UU898_APP") String request);

    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<List<BOrderGameDK>>> getBuyGamecardList(@Field("UU898_APP") String request);

    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<List<BOrderRechargePhone>>> getBuyRechargeList(@Field("UU898_APP") String request);

    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<BBannerResponse>> getBanners(@Field("UU898_APP") String request);

    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<List<BGoods>>> getGoodsList(@Field("UU898_APP") String request);

    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<BUserInfoIntegrity>> queryUserInfoIntegrity(@Field("UU898_APP") String request);

    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<BPayMoney>> getPayMoney(@Field("UU898_APP") String request);

    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<BPayNo>> genAliPayNo(@Field("UU898_APP") String request);

    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<BPayNo>> genWxPayNo(@Field("UU898_APP") String request);

    /***********账户**************/
    /**
     * 获取我的消息列表
     */
    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<List<BMessage>>> getMyMessages(@Field("UU898_APP") String request);


    /***********订单***********/
    /**
     * 我购买的商品(寄售、担保、账号)列表
     */
    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<List<BOrderCommon>>> getBuyCommonList(@Field("UU898_APP") String request);

    /**
     * 我购买的点卡列表
     */
    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<List<BOrderGameDK>>> getBuyCardList(@Field("UU898_APP") String request);

    /**
     * 我的手机话费充值订单列表
     */
    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<List<BOrderRechargePhone>>> getPhoneRechargeList(@Field("UU898_APP") String request);

    /**
     * 我的QQ专区充值订单列表
     */
    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<List<BOrderRechargeQQ>>> getQQRechargeList(@Field("UU898_APP") String request);

    /***********充值**************/
    /**
     * 生成充值订单(话费/流量/QQ)
     */
    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<BRechargeNoResult>> genRechargeNo(@Field("UU898_APP") String request);

    /**
     * 获取点卡列表
     */
    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<BGameDKList>> getGameDkList(@Field("UU898_APP") String request);

    /**
     * 生成点卡订单
     */
    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<BRechargeDKNoResult>> genRechargeDkNo(@Field("UU898_APP") String request);

    /**
     * 根据手机号,获取流量类型列表
     */
    @FormUrlEncoded
    @POST(NetConstant.URL.SERVICE_COMMON)
    Observable<BaseModel<List<BMobileData>>> getMobileDataList(@Field("UU898_APP") String request);
}
