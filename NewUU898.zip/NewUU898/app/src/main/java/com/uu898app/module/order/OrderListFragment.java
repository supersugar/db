package com.uu898app.module.order;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.uu898app.R;
import com.uu898app.adapter.MyBuyRecordAdapter;
import com.uu898app.model.request.GPage;
import com.uu898app.model.response.BOrderCommon;
import com.uu898app.model.response.BOrderGameDK;
import com.uu898app.model.response.BOrderRechargePhone;
import com.uu898app.module.base.BaseFragment;
import com.uu898app.network.NetConstant;
import com.uu898app.network.TaskEngine;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import rx.functions.Action1;

/**
 * 订单列表页面
 * Created by zhangbo on 2016/6/23.
 */
public class OrderListFragment extends BaseFragment {

    private final static String TYPE = "type";//类型

    public static final int TYPE_COMMON = 0;//寄售,担保,账号
    public static final int TYPE_GAME_DK = 1;//点卡
    public static final int TYPE_PHONEQQ = 2;//手机,qq


    @BindView(R.id.recycler_view)
    RecyclerView recyclerView;
    @BindView(R.id.refresh_layout)
    SwipeRefreshLayout refreshLayout;

    private BaseQuickAdapter mAdapter;
    private int mType;

    public static OrderListFragment newInstance(int type) {
        Bundle args = new Bundle();
        OrderListFragment fragment = new OrderListFragment();
        args.putInt(TYPE, type);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        if (args != null) {
            mType = args.getInt(TYPE);
        }
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.my_buy_record_list_layout, container, false);
        ButterKnife.bind(this, view);
        recyclerView.setLayoutManager(new LinearLayoutManager(_mActivity));
        getOrderListByType();
        return view;
    }

    private void getOrderListByType() {
        switch (mType) {
            case TYPE_COMMON:
                TaskEngine.getInstance().getBuyCommonList(new GPage(1)).subscribe(new Action1<List<BOrderCommon>>() {
                    @Override
                    public void call(List<BOrderCommon> result) {
                        mAdapter = new OrderCommonAdapter(result);
                        recyclerView.setAdapter(mAdapter);
//                        mAdapter.setOnRecyclerViewItemClickListener(new BaseQuickAdapter.OnRecyclerViewItemClickListener() {
//                            @Override
//                            public void onItemClick(View view, int i) {
//                                start(LoginFragment.newInstance());
//                            }
//                        });
                    }
                });
                break;
            case TYPE_GAME_DK:
                TaskEngine.getInstance().getBuyCardList(new GPage(1)).subscribe(new Action1<List<BOrderGameDK>>() {
                    @Override
                    public void call(List<BOrderGameDK> result) {
                        mAdapter = new OrderGameDKAdapter(result);
                        recyclerView.setAdapter(mAdapter);
                    }
                });
                break;
            case TYPE_PHONEQQ:
                TaskEngine.getInstance().getPhoneRechargeList(new GPage(1)).subscribe(new Action1<List<BOrderRechargePhone>>() {
                    @Override
                    public void call(List<BOrderRechargePhone> result) {
                        mAdapter = new OrderGameDKPhoneQQ(result);
                        recyclerView.setAdapter(mAdapter);
                    }
                });
                break;
            default:
                break;
        }
    }

    protected class OrderCommonAdapter extends BaseQuickAdapter<BOrderCommon> {

        public OrderCommonAdapter(List<BOrderCommon> data) {
            super(R.layout.order_list_item_common, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, BOrderCommon item) {
            helper.setText(R.id.tv_title, item.getTitle());
            Glide.with(mContext).load(NetConstant.URL.BASE_IMAGE_URL + item.getImages()).crossFade().into((ImageView) helper.getView(R.id.img));
        }
    }

    protected class OrderGameDKAdapter extends BaseQuickAdapter<BOrderGameDK> {

        public OrderGameDKAdapter(List<BOrderGameDK> data) {
            super(R.layout.order_list_item_game_dk, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, BOrderGameDK item) {
            helper.setText(R.id.tv_title, item.getName() + "    " + item.getTitle());
            helper.setText(R.id.tv_desc, item.getTradeTime() + "    " + item.getStatusName());
        }
    }

    protected class OrderGameDKPhoneQQ extends BaseQuickAdapter<BOrderRechargePhone> {

        public OrderGameDKPhoneQQ(List<BOrderRechargePhone> data) {
            super(R.layout.order_list_item_phone_qq, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, BOrderRechargePhone item) {
            helper.setText(R.id.tv_title, item.getCardName());
            helper.setText(R.id.tv_desc, item.getPhone());
            helper.setText(R.id.tv_desc, item.getCompleteTime() + "    " + item.getStatusName());
        }
    }

}
