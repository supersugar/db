package com.uu661.model.response;

import java.io.Serializable;

/**
 * 首页滚动显示全站中奖名单中的model
 * Created by bo on 16/12/6.
 */

public class BLuckyMan implements Serializable {


    /**
     * title : 10U钻【可兑换全站任意商品】
     * commodityID : 236
     * periodNo : 701160018
     * name : 1002398
     * nickName : 玉米味奶糖
     * uu898UserId : 10****98
     * buyNum : 1
     * totalCount : 11
     * addTime : 2017-01-16T10:16:27.93
     * price : 10
     */

    private String title;
    private int commodityID;
    private int periodNo;
    private String name;
    private String nickName;
    private String uu898UserId;
    private int buyNum;
    private int totalCount;
    private String addTime;
    private int price;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getCommodityID() {
        return commodityID;
    }

    public void setCommodityID(int commodityID) {
        this.commodityID = commodityID;
    }

    public int getPeriodNo() {
        return periodNo;
    }

    public void setPeriodNo(int periodNo) {
        this.periodNo = periodNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getUu898UserId() {
        return uu898UserId;
    }

    public void setUu898UserId(String uu898UserId) {
        this.uu898UserId = uu898UserId;
    }

    public int getBuyNum() {
        return buyNum;
    }

    public void setBuyNum(int buyNum) {
        this.buyNum = buyNum;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
