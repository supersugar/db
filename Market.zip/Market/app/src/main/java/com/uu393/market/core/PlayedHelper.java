package com.uu393.market.core;

import android.content.Context;

import com.uu393.market.util.CacheUtil;
import com.uu393.market.util.log.L;

import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/22
 * Descrip    : 记录打开过的APP
 * =====================================================
 */

public class PlayedHelper {
    private static Context mContext;
    private static CacheUtil cacheUtil ;
    private static PlayedHelper mInstance;

    private static Map<Object,Object> mPlayedApps ;

    private PlayedHelper(){
        mPlayedApps = Collections.synchronizedMap(new HashMap<Object, Object>());
    }

    public static PlayedHelper getInstance(Context context) {
        mContext = context;
        cacheUtil = CacheUtil.get(mContext, "played_record");//保存在缓存中的文件名
        if (null == mInstance) {
            synchronized (PlayedHelper.class) {
                if (null == mInstance) {
                    mInstance = new PlayedHelper();
                }
            }
        }
        return mInstance;
    }

    public void addOnePlayedRecord(Object key,Object value){
        addOnePlayedRecord(mPlayedApps,key,value);
    }
    private void addOnePlayedRecord(Map<Object,Object> map,Object key,Object value){
        map.put(key,value);
        cacheUtil.put("played_map", (Serializable) map);//保存在缓存文件played_record中的map的key
    }
    public void removeOnePlayedRecord(String key){
        if (hasKey(key)){
            mPlayedApps = (Map<Object, Object>) cacheUtil.getAsObject("played_map");
            mPlayedApps.remove(key);
            cacheUtil.put("installed_map", (Serializable) mPlayedApps);
        }
    }

    private boolean hasKey(Object key){
        getAllPlayedRecord();
        Set<Object> objectSet = mPlayedApps.keySet();
        for (Object object:objectSet){
            if (key.equals(object)){
                return true;
            }
        }
        return false;
    }

    public Map getAllPlayedRecord(){
        mPlayedApps.clear();
        if ((Map<Object, Object>) cacheUtil.getAsObject("played_map")!=null)
            mPlayedApps.putAll((Map<Object, Object>) cacheUtil.getAsObject("played_map"));
        return  mPlayedApps;
    }
}
