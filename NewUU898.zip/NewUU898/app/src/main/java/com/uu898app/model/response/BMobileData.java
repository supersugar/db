package com.uu898app.model.response;

/**
 * Created by zhangbo on 2016/7/19.
 */
public class BMobileData {

    /**
     * id : 2000976
     * name : 20M联通流量
     * fee : 3
     * price : 3
     * flowSize : 20
     */

    private int id;
    private String name;
    private int fee;
    private int price;
    private int flowSize;

    @Override
    public String toString() {
        return getName() + "\r\n" + "价格 : " + getPrice() + "元";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getFee() {
        return fee;
    }

    public void setFee(int fee) {
        this.fee = fee;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getFlowSize() {
        return flowSize;
    }

    public void setFlowSize(int flowSize) {
        this.flowSize = flowSize;
    }
}
