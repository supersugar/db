package com.uu898.gamesdk.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.uu898.gamesdk.core.ResourceUtils;
import com.uu898.gamesdk.model.request.GGetMessageDetail;
import com.uu898.gamesdk.model.response.BMessage;
import com.uu898.gamesdk.network.NetCallback;
import com.uu898.gamesdk.network.TaskEngine;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class UserMessageDetailFragment extends BaseFragment {

    private BMessage mMessageModel;

    private TextView mTvTitle;
    private TextView mTvTime;
    private TextView mTvContent;


    public static UserMessageDetailFragment newInstance(BMessage model) {
        Bundle args = new Bundle();
        args.putSerializable("model", model);
        UserMessageDetailFragment fragment = new UserMessageDetailFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        if (args != null) {
            mMessageModel = (BMessage) args.getSerializable("model");
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        View view = inflater.inflate(ResourceUtils.getLayoutId(_mActivity, "ug_user_message_detail"), container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "我的消息");

        mTvTitle = (TextView) view.findViewById(getId("ug_tv_message_title"));
        mTvTime = (TextView) view.findViewById(getId("ug_tv_time"));
        mTvContent = (TextView) view.findViewById(getId("ug_tv_content"));

        doGetMessageDetail();
    }

    private void setContent() {
        mTvTitle.setText(mMessageModel.Title);
        mTvTime.setText(mMessageModel.AddTime);
        mTvContent.setText(mMessageModel.Content);
    }

    private void doGetMessageDetail() {
        GGetMessageDetail model  = new GGetMessageDetail();
        model.setID(mMessageModel.ID);
        TaskEngine.getInstance().doGetMessageDetail(model, new NetCallback<BMessage>(this) {
            @Override
            public void _onNext(BMessage result) {
                mMessageModel = result;
                setContent();
            }

            @Override
            public void _onError(String msg) {

            }
        });
    }


}
