package com.uu898.gamesdk.model.response;

import java.io.Serializable;

/**
 * Created by bo on 16/9/14.
 */
public class BPayMoney implements Serializable {

    public String IsDiscount;//（是否有折扣（0无折扣，1有折扣））
    public int Price;//单个商品原价（分）
    public String Discount;//折扣
}
