package com.uu661.module.my;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.uu661.R;
import com.uu661.core.AccountManager;
import com.uu661.model.response.BUserInfo;
import com.uu661.module.base.BaseFragment;
import com.uu661.module.common.WebActivity;
import com.uu661.util.StringUtils;
import com.uu661.util.ToastUtil;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;


/**
 * Created by zhangbo on 2016/6/23.
 */
public class RechargeCenterFragment extends BaseFragment {

    private static final int PAY_TYPE_WX = 0;
    private static final int PAY_TYPE_ZFB = 1;

    private static final int PAY_MONEY_10 = 10;
    private static final int PAY_MONEY_50 = 50;
    private static final int PAY_MONEY_100 = 100;
    private static final int PAY_MONEY_200 = 200;
    private static final int PAY_MONEY_500 = 500;
    private static final int PAY_MONEY_OTHER = -1;

    @BindView(R.id.check_wx) ImageView mCheckWx;
    @BindView(R.id.bt_wx) RelativeLayout mBtWx;
    @BindView(R.id.check_zfb) ImageView mCheckZfb;
    @BindView(R.id.bt_zfb) RelativeLayout mBtZfb;
    @BindView(R.id.bt_10) Button mBt10;
    @BindView(R.id.bt_50) Button mBt50;
    @BindView(R.id.bt_100) Button mBt100;
    @BindView(R.id.bt_200) Button mBt200;
    @BindView(R.id.bt_500) Button mBt500;
    @BindView(R.id.view_other) View mViewOther;
    @BindView(R.id.bt_other) Button mBtOther;
    @BindView(R.id.edt_other) EditText mEdtOther;
    @BindView(R.id.bt_submit) Button mBtSubmit;

    private int mCurrentPayType = PAY_TYPE_ZFB;//默认支付方式是支付宝
    private int mCurrentPayMoney = PAY_MONEY_10;//默认支付金额是10元

    private List<Button> mMoneyBts = new ArrayList<>();

    private boolean isClickWx = false;

    public static RechargeCenterFragment newInstance() {
        Bundle args = new Bundle();
        RechargeCenterFragment fragment = new RechargeCenterFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.recharge_center_fragment, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "充值中心", true);
        initMoneyBts();
        setChoosePayType();
        setChoosePayMoney();
        mEdtOther.addTextChangedListener(mTextWatcher);
    }

    private void initMoneyBts() {
        mMoneyBts.clear();
        mBt10.setTag(PAY_MONEY_10);
        mBt50.setTag(PAY_MONEY_50);
        mBt100.setTag(PAY_MONEY_100);
        mBt200.setTag(PAY_MONEY_200);
        mBt500.setTag(PAY_MONEY_500);
        mBtOther.setTag(PAY_MONEY_OTHER);
        mMoneyBts.add(mBt10);
        mMoneyBts.add(mBt50);
        mMoneyBts.add(mBt100);
        mMoneyBts.add(mBt200);
        mMoneyBts.add(mBt500);
        mMoneyBts.add(mBtOther);
    }

    private void setChoosePayType() {
        switch (mCurrentPayType) {
            case PAY_TYPE_WX:
                mCheckWx.setVisibility(View.VISIBLE);
                mCheckZfb.setVisibility(View.GONE);
                break;
            case PAY_TYPE_ZFB:
                mCheckWx.setVisibility(View.GONE);
                mCheckZfb.setVisibility(View.VISIBLE);
                break;
        }
    }

    private void setChoosePayMoney() {
        for (Button temp : mMoneyBts) {
            int tempTag = (int) temp.getTag();
            if (tempTag == mCurrentPayMoney) {
                if (tempTag == PAY_MONEY_OTHER) {
                    mViewOther.setBackgroundResource(R.drawable.ic_shape_bt_blue);
                    mEdtOther.setVisibility(View.VISIBLE);
                    mBtOther.setVisibility(View.GONE);
                    mEdtOther.requestFocus();
                    showSoftInput(mEdtOther);
                } else {
                    temp.setBackgroundResource(R.drawable.ic_shape_bt_blue);
                    temp.setTextColor(getResources().getColor(R.color.white));
                }
            } else {
                if (tempTag == PAY_MONEY_OTHER) {
                    mViewOther.setBackgroundResource(R.drawable.ic_shape_bt_blue_white);
                    mEdtOther.setVisibility(View.GONE);
                    mBtOther.setVisibility(View.VISIBLE);
                    mEdtOther.setText("");
                    hideSoftInput();
                } else {
                    temp.setBackgroundResource(R.drawable.ic_shape_bt_blue_white);
                    temp.setTextColor(getResources().getColor(R.color.blue));
                }
            }
        }
    }


    @OnClick({R.id.bt_wx, R.id.bt_zfb, R.id.bt_10, R.id.bt_50, R.id.bt_100, R.id.bt_200, R.id.bt_500, R.id.bt_other, R.id.bt_submit})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.bt_wx:
                mCurrentPayType = PAY_TYPE_WX;
                setChoosePayType();
                break;
            case R.id.bt_zfb:
                mCurrentPayType = PAY_TYPE_ZFB;
                setChoosePayType();
                break;
            case R.id.bt_10:
                mCurrentPayMoney = PAY_MONEY_10;
                setChoosePayMoney();
                break;
            case R.id.bt_50:
                mCurrentPayMoney = PAY_MONEY_50;
                setChoosePayMoney();
                break;
            case R.id.bt_100:
                mCurrentPayMoney = PAY_MONEY_100;
                setChoosePayMoney();
                break;
            case R.id.bt_200:
                mCurrentPayMoney = PAY_MONEY_200;
                setChoosePayMoney();
                break;
            case R.id.bt_500:
                mCurrentPayMoney = PAY_MONEY_500;
                setChoosePayMoney();
                break;
            case R.id.bt_other:
                mCurrentPayMoney = PAY_MONEY_OTHER;
                setChoosePayMoney();
                break;
            case R.id.bt_submit:
                doRecharge();
                break;
        }
    }

    private TextWatcher mTextWatcher = new TextWatcher() {

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            String text = s.toString();
            int len = s.toString().length();
            if (len == 1 && text.equals("0")) {
                s.clear();
            }
        }
    };

    /**
     * 安卓使用微信：
     * http://user.uu898.com/account/chongzhim.aspx?u0=&u1=&u2=0&ct=0&cm=
     * <p>
     * 安卓使用支付宝：
     * http://user.uu898.com/account/chongzhim.aspx?u0=&u1=&u2=0&ct=1&cm=
     * <p>
     * u0：uu898的user.id
     * u1：uu898的user.userId
     * u2：页面调用方，0表示安卓应用调起，1表示IOS应用调起
     * ct：充值方式，0微信，1支付宝
     * cm：充值金额，>0
     */
    private void doRecharge() {
        String money = "";
        if (mCurrentPayMoney != PAY_MONEY_OTHER) {
            money = String.valueOf(mCurrentPayMoney);
        } else {
            money = mEdtOther.getText().toString();
            if (StringUtils.isEmpty(money)) {
                ToastUtil.showToast(_mActivity, "请输入要充值的金额");
                return;
            }
        }

        StringBuilder sb = new StringBuilder();
        sb.append("http://user.uu898.com/account/chongzhim.aspx?");
        BUserInfo userInfo = AccountManager.getInstance().getUserInfo();
        if (null != userInfo) {
            sb.append("u0=").append(userInfo.UId);
            sb.append("&u1=").append(userInfo.userId);
            sb.append("&u2=").append("0");
            sb.append("&ct=").append(mCurrentPayType + "");
            sb.append("&cm=").append(money);
            sb.append("&").append(System.currentTimeMillis() + "");

            //支付宝支付跳转程序内webview,微信支付跳转到系统浏览器
            if (mCurrentPayType == PAY_TYPE_ZFB) {
                Intent intent = new Intent(_mActivity, WebActivity.class);
                intent.putExtra(WebActivity.INTENT_KEY_URL, sb.toString());
                intent.putExtra(WebActivity.INTENT_KEY_TITLE, "充值");
                startActivityForResult(intent, 9);
            } else if (mCurrentPayType == PAY_TYPE_WX) {
                Intent intent = new Intent();
                intent.setAction("android.intent.action.VIEW");
                Uri url = Uri.parse(sb.toString());
                intent.setData(url);
                startActivity(intent);
                isClickWx = true;
            }
        } else {
            ToastUtil.showToast(_mActivity, "获取用户信息失败,请重新登录");
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 9 && resultCode == RESULT_OK) {
            _mActivity.onBackPressed();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (isClickWx) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if(isVisible()){
                        isClickWx = false;
                        _mActivity.onBackPressed();
                    }
                }
            }, 1000);
        }
    }
}
