package com.uu393.market.model.response;

import java.io.Serializable;

/**
 * =====================================================
 * Created by     : wang xian
 * Created on     : 2017/4/14
 * Description    :
 * =====================================================
 */

public class BShareFormMore implements Serializable {
    /**
     * inCome : 10
     * uUSYInstall : 10
     * sDKInstall : 10
     * uUSYActive : 10
     * newUser : 10
     * paymentUser : 10
     * paymentMoney : 10
     * paymentCount : 10
     */

    private String inCome;
    private String uUSYInstall;
    private String sDKInstall;
    private String uUSYActive;
    private String newUser;
    private String paymentUser;
    private String paymentMoney;
    private String paymentCount;

    public String getInCome() {
        return inCome;
    }

    public void setInCome(String inCome) {
        this.inCome = inCome;
    }

    public String getUUSYInstall() {
        return uUSYInstall;
    }

    public void setUUSYInstall(String uUSYInstall) {
        this.uUSYInstall = uUSYInstall;
    }

    public String getSDKInstall() {
        return sDKInstall;
    }

    public void setSDKInstall(String sDKInstall) {
        this.sDKInstall = sDKInstall;
    }

    public String getUUSYActive() {
        return uUSYActive;
    }

    public void setUUSYActive(String uUSYActive) {
        this.uUSYActive = uUSYActive;
    }

    public String getNewUser() {
        return newUser;
    }

    public void setNewUser(String newUser) {
        this.newUser = newUser;
    }

    public String getPaymentUser() {
        return paymentUser;
    }

    public void setPaymentUser(String paymentUser) {
        this.paymentUser = paymentUser;
    }

    public String getPaymentMoney() {
        return paymentMoney;
    }

    public void setPaymentMoney(String paymentMoney) {
        this.paymentMoney = paymentMoney;
    }

    public String getPaymentCount() {
        return paymentCount;
    }

    public void setPaymentCount(String paymentCount) {
        this.paymentCount = paymentCount;
    }
    /**{
     "inCome":"10",（收入）
     "uUSYInstall":"10",（UUSY安装数）
     "sDKInstall":"10",（SDK安装数）
     "uUSYActive":"10",（UUSY设备活跃数）
     "newUser":"10",（新增用户数）
     "paymentUser":"10",（付费用户）
     "paymentMoney":"10",（付费金额）
     "paymentCount":"10",（付款总笔数）
     }

     */

}
