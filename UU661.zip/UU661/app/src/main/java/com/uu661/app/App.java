package com.uu661.app;

import android.app.Application;
import android.content.Context;

import com.bugtags.library.Bugtags;
import com.bugtags.library.BugtagsOptions;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.cache.CacheEntity;
import com.lzy.okgo.cache.CacheMode;
import com.orhanobut.hawk.Hawk;
import com.umeng.analytics.MobclickAgent;
import com.uu661.core.DevConfig;
import com.uu661.util.PushUtil;

import me.yokeyword.fragmentation.Fragmentation;


public class App extends Application {

    private static final int DEFAULT_TIMEOUT = 10000;       //默认的超时时间 10秒
    public static int PAY_SETTING = 1;//(1为app支付，0为网页支付)

    public static Context mContext;

    @Override
    public void onCreate() {
        super.onCreate();
        mContext = this;
        DevConfig.getInstance().init();//开发配置项初始化
        Hawk.init(this).build();;//SP存储初始哈
        OkGo.init(this);//OkGo初始化
        configOkGo();
        initBugTags();
        initPush();
        configUmengAnalytics();
        initFragmentation();
    }

    private void initPush() {
        PushUtil.init(this);
    }

    /**
     * 配置友盟统计
     */
    private void configUmengAnalytics() {
        MobclickAgent.openActivityDurationTrack(false);//禁止默认的页面统计方式，这样将不会再自动统计Activity
        MobclickAgent.setDebugMode(false);
        MobclickAgent.setScenarioType(this, MobclickAgent.EScenarioType.E_UM_NORMAL);//普通统计场景类型
        MobclickAgent.setCatchUncaughtExceptions(true);//设置是否对日志信息进行加密, 默认false(不加密)
        MobclickAgent.enableEncrypt(true);//SDK会对日志进行加密。加密模式可以有效防止网络攻击，提高数据安全性。
    }

    private void initFragmentation() {
        Fragmentation.builder()
                // 显示悬浮球 ; 其他Mode:SHAKE: 摇一摇唤出   NONE：隐藏
                .stackViewMode(Fragmentation.NONE)
                .install();
    }

    private void initBugTags(){
        BugtagsOptions options = new BugtagsOptions.Builder().
                trackingLocation(false).//是否获取位置，默认 true
                trackingCrashLog(true).//是否收集crash，默认 true
                trackingConsoleLog(true).//是否收集console log，默认 true
                trackingUserSteps(true).//是否收集用户操作步骤，默认 true
                trackingNetworkURLFilter("(.*)").//自定义网络请求跟踪的 url 规则，默认 null
                build();

        Bugtags.start("d4a48c0de2961fa5516ca87e83582fa8", this, Bugtags.BTGInvocationEventNone, options);
    }

    /**
     * 配置okgo
     */
    private void configOkGo() {
        //以下设置的所有参数是全局参数,同样的参数可以在请求的时候再设置一遍,那么对于该请求来讲,请求中的参数会覆盖全局参数
        //好处是全局参数统一,特定请求可以特别定制参数
        try {
            //以下都不是必须的，根据需要自行选择,一般来说只需要 debug,缓存相关,cookie相关的 就可以了
            OkGo.getInstance()

                    // 打开该调试开关,打印级别INFO,并不是异常,是为了显眼,不需要就不要加入该行
                    // 最后的true表示是否打印okgo的内部异常，一般打开方便调试错误
//                      .debug("uu661", Level.INFO, DevConfig.DEBUG)

                    .setConnectTimeout(DEFAULT_TIMEOUT)  //全局的连接超时时间
                    .setReadTimeOut(DEFAULT_TIMEOUT)     //全局的读取超时时间
                    .setWriteTimeOut(DEFAULT_TIMEOUT)    //全局的写入超时时间

                    //可以全局统一设置缓存模式,默认是不使用缓存,可以不传,具体其他模式看 github 介绍 https://github.com/jeasonlzy/
                    .setCacheMode(CacheMode.NO_CACHE)

                    //可以全局统一设置缓存时间,默认永不过期,具体使用方法看 github 介绍
                    .setCacheTime(CacheEntity.CACHE_NEVER_EXPIRE)

                    //可以全局统一设置超时重连次数,默认为三次,那么最差的情况会请求4次(一次原始请求,三次重连请求),不需要可以设置为0
                    .setRetryCount(0);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onTerminate() {
        super.onTerminate();
    }
}
