package com.uu393.market.module.login;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.module.base.BaseActivity;
import com.uu393.market.module.h5game.H5WebViewActivity;
import com.uu393.market.util.SPUtil;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class RegisterSuccessActivity extends BaseActivity {

    @Bind(R.id.btn_register_success_know)
    Button mBtnRegisterSuccessKnow;
    @Bind(R.id.btn_register_success_bind)
    Button mBtnRegisterSuccessBind;
    @Bind(R.id.title_bar_left)
    ImageButton mTitleBarLeft;
    @Bind(R.id.title_bar_right)
    ToggleButton mTitleBarRight;
    @Bind(R.id.title_bar_title)
    TextView mTitleBarTitle;

    private String mGameId;
    private String APPID;
    private String mGameUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_success);
        ButterKnife.bind(this);
        initTitleBar();
    }
    private void initTitleBar() {
        mTitleBarRight.setVisibility(View.GONE);
        mTitleBarTitle.setText("注册成功");
    }

    @OnClick({R.id.title_bar_left, R.id.btn_register_success_know, R.id.btn_register_success_bind})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_bar_left:
                super.onBackPressedSupport();
                break;
            case R.id.btn_register_success_know:
                mGameId = (String) SPUtil.get(App.mContext, "GameId", "");
                APPID = (String) SPUtil.get(App.mContext, "APPID", "");
                mGameUrl = (String) SPUtil.get(App.mContext, "GameUrl", "");
                if (!TextUtils.isEmpty(mGameId)) {

                    Intent intent = new Intent();
                    intent.putExtra("gameId", mGameId);
                    intent.putExtra("APPID", APPID);
                    intent.putExtra("url", mGameUrl);
                    intent.setClass(RegisterSuccessActivity.this, H5WebViewActivity.class);
                    startActivity(intent);
                    SPUtil.put(App.mContext, "GameId", "");
                    SPUtil.put(App.mContext, "APPID", "");
                    SPUtil.put(App.mContext, "GameUrl", "");
                } else {
                    startActivity(new Intent(RegisterSuccessActivity.this, LoginActivity.class));
                }
                RegisterSuccessActivity.this.finish();
                break;
            case R.id.btn_register_success_bind:
                startActivity(new Intent(RegisterSuccessActivity.this, BindPhoneActivity.class));
                break;
        }
    }
}
