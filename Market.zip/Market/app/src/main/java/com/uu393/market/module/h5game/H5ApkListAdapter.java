package com.uu393.market.module.h5game;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.app.App;
import com.uu393.market.model.request.GDoAddPlayedGame;
import com.uu393.market.model.response.BH5Game;
import com.uu393.market.module.login.LoginActivity;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.GlideRoundTransform;
import com.uu393.market.util.ImageHelper;
import com.uu393.market.util.SPUtil;
import com.uu393.market.util.log.L;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

import static com.uu393.market.Constant.UMENG_EVENT_ID_PLAY_H5;

/**
 * =====================================================
 * Created by : Administrator
 * Created on : 2017/2/14
 * Descrip    : H5游戏的List的适配器
 * =====================================================
 */

public class H5ApkListAdapter extends RecyclerView.Adapter<H5ApkListAdapter.H5ApkHolder> {
    private Activity mContext;
    private List<BH5Game> data = new ArrayList<>();

    public H5ApkListAdapter(Activity context){
        mContext = context;
    }
    @Override
    public H5ApkHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_h5game_recyclerview, parent, false);
        return new H5ApkHolder(view);
    }

    @Override
    public void onBindViewHolder(H5ApkHolder holder, int position) {
        holder.bindItem(data.get(position));
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public void updateData(List<BH5Game> data) {
        this.data = data;
        notifyDataSetChanged();
    }

    public class H5ApkHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private BH5Game game;
        private ImageView icon;
        private TextView name;
        private TextView discount;
        private TextView typeAndSize;
        private TextView describe;
        private TextView play;
        private View parent;
        public H5ApkHolder(View itemView) {
            super(itemView);
            parent = itemView.findViewById(R.id.rl_parent);
            icon = (ImageView) itemView.findViewById(R.id.h5_app_icon);
            name = (TextView) itemView.findViewById(R.id.h5_tv_one);
            discount = (TextView) itemView.findViewById(R.id.h5_tv_discount);
            typeAndSize = (TextView) itemView.findViewById(R.id.h5_tv_two);
            describe = (TextView) itemView.findViewById(R.id.h5_tv_three);
            play = (TextView) itemView.findViewById(R.id.tv_play);
        }
        public void bindItem(BH5Game model){
            this.game = model;
            int defaultAndError = ImageHelper.randomImage();
            Glide.with(App.mContext)
                    .load(model.getIcon())
                    .error(defaultAndError)
                    .placeholder(defaultAndError)
                    .transform(new GlideRoundTransform(mContext, 10))
                    .into(icon);

            name.setText(model.getGameName());
            typeAndSize.setText(model.getTypeName());
            if (model.getDescribe()!=null&&!model.getDescribe().isEmpty()){
                describe.setVisibility(View.VISIBLE);
                describe.setText(model.getDescribe());
            }else {
                describe.setVisibility(View.GONE);
            }

            play.setOnClickListener(this);
            parent.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int id = v.getId();
            Intent intent = new Intent();
            if (id==R.id.tv_play){
                if ((boolean)SPUtil.get(App.mContext,"isLogin",false)){
                    HashMap<String, String> map = new HashMap<>();
                    map.put("H5GameName",game.getGameName());
                    MobclickAgent.onEvent(mContext, UMENG_EVENT_ID_PLAY_H5,map);//

                    intent.putExtra("gameId",game.getId());
                    intent.putExtra("APPID",game.getAPPID());
                    intent.putExtra("url",game.getAndroidPackage());
                    intent.setClass(mContext,H5WebViewActivity.class);
                    mContext.startActivity(intent);
                }else {
                    SPUtil.put(App.mContext, "GameId", game.getId());
                    SPUtil.put(App.mContext, "APPID", game.getAPPID());
                    SPUtil.put(App.mContext, "GameUrl", game.getAndroidPackage());

                    intent.setClass(mContext,LoginActivity.class);
                    mContext.startActivity(intent);
                }
            }else {// TODO: 2017/2/14 详情页
                intent.putExtra("gameId",game.getId());
                intent.setClass(mContext,H5GameDetailActivity.class);
                mContext.startActivity(intent);
            }
        }
    }
}
