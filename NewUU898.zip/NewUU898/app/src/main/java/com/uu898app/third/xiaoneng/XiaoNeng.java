package com.uu898app.third.xiaoneng;

import android.content.Context;
import android.widget.Toast;

import com.uu898app.app.App;
import com.uu898app.util.log.L;

import cn.xiaoneng.uiapi.Ntalker;

/**
 * Created by zhangbo on 2016/6/27.
 */
public class XiaoNeng {

    private static final String SITE_ID = "kf_9725";
    private static final String KEY = "BBB84E42-975B-4FFE-9BA9-9F1966A8D2C3";
    private static final String SETTINGID_ZIXUN = "kf_9725_1421659802125";// 客服组咨询id
    private static final String SETTINGID_CHONGZHI = "kf_9725_1421659815826";// 客服组充值id

    private static XiaoNeng mXiaoNeng;
    private Context mContext;

    private XiaoNeng() {
        mContext = App.mContext;
    }

    public static XiaoNeng getInstance() {
        if (null == mXiaoNeng) {
            mXiaoNeng = new XiaoNeng();
        }
        return mXiaoNeng;
    }

    public void init(boolean debug) {
        int initCode = Ntalker.getInstance().initSDK(mContext, SITE_ID, KEY);// 初始化SDK
        int debugCode = Ntalker.getInstance().enableDebug(debug);// 选择debug模式
        L.d("小能初始化 code = " + initCode + "Debug code = " + debugCode + " (成功为0)");
    }

    public void startSimpleChat(int type) {
        String settingId = "";
        String groupName = "";
        if (type == 0) {
            settingId = SETTINGID_ZIXUN;
            groupName = "咨询客服";
        } else if (type == 1) {
            settingId = SETTINGID_CHONGZHI;
            groupName = "充值提现客服";
        }
        int code = Ntalker.getInstance().startChat(mContext, settingId, groupName,null, null, null, false);// 打开聊窗
        if (0 != code) {
            Toast.makeText(mContext, "打开聊窗失败", Toast.LENGTH_SHORT).show();
            L.d("打开聊窗失败 + code = " + code);
        }
    }


}
