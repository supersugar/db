package com.uu898.gamesdk;

import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;

import com.uu898.gamesdk.core.ResourceUtils;
import com.uu898.gamesdk.fragmentation.SupportActivity;
import com.uu898.gamesdk.support.model.UGPayModel;
import com.uu898.gamesdk.view.ExitFragment;
import com.uu898.gamesdk.view.LoginFragment;
import com.uu898.gamesdk.view.UserCenterFragment;
import com.uu898.gamesdk.view.UserCheckOutFragment;

public class UGActivity extends SupportActivity {

    public static final String INTENT_KEY_TO = "intent_key_to";
    public static final String INTENT_KEY_PAY_MODEL = "intent_key_pay_model";//支付model

    public static final int INTENT_VALUE_TO_LOGIN = 0;//登陆
    public static final int INTENT_VALUE_TO_USER_CENTER = 1;//用户中心
    public static final int INTENT_VALUE_TO_CHECKOUT = 2;//支付
    public static final int INTENT_VALUE_TO_EXIT = 3;//退出

    private int mTo = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //禁止弹出软键盘
        getWindow().setSoftInputMode( WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        setContentView(ResourceUtils.getLayoutId(this, "ug_activity_base"));
        Intent intent = getIntent();
        if(intent != null ){
            mTo = intent.getIntExtra(INTENT_KEY_TO, -1);
        }
        if (null == savedInstanceState) {
            switch (mTo){
                case INTENT_VALUE_TO_LOGIN:
                    loadRootFragment(ResourceUtils.getId(this, "fl_container"), LoginFragment.newInstance());
                    break;
                case INTENT_VALUE_TO_USER_CENTER:
                    loadRootFragment(ResourceUtils.getId(this, "fl_container"), UserCenterFragment.newInstance());
                    break;
                case INTENT_VALUE_TO_CHECKOUT:
                    UGPayModel model = (UGPayModel) intent.getSerializableExtra(INTENT_KEY_PAY_MODEL);
                    loadRootFragment(ResourceUtils.getId(this, "fl_container"), UserCheckOutFragment.newInstance(model));
                    break;
                case INTENT_VALUE_TO_EXIT:
                    loadRootFragment(ResourceUtils.getId(this, "fl_container"), ExitFragment.newInstance());
                    break;
            }
        }
    }

}
