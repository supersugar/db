package com.uu661.module.home;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.uu661.R;
import com.uu661.core.AccountManager;
import com.uu661.model.PageModel;
import com.uu661.model.request.GGetDiamondInfo;
import com.uu661.model.request.GGetDiamondList;
import com.uu661.model.response.BDiamond;
import com.uu661.model.response.BDiamondInfo;
import com.uu661.module.account.LoginActivity;
import com.uu661.module.base.BaseViewPagerFragment;
import com.uu661.network.JsonCallback;
import com.uu661.network.TaskEngine;
import com.uu661.util.eventbus.EB;
import com.uu661.util.log.L;
import com.uu661.view.SpaceItemDecoration;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import cn.finalteam.toolsfinal.DeviceUtils;
import okhttp3.Call;
import okhttp3.Response;

/**
 * 钻石列表界面
 */
public class DiamondListFragment extends BaseViewPagerFragment {

    @BindView(R.id.diamond_recycler_view)
    RecyclerView mRecyclerView;
    @BindView(R.id.no_result_view)
    LinearLayout mNoResultView;
    //    @BindView(R.id.refreshLayout)
    //    TwinklingRefreshLayout mRefreshLayout;
    private int mCount;//

    private DiamondListAdapter mAdapter;
    private int mPageIndex = 1;
    private List<BDiamond> mDiamonds = new ArrayList<>();

    public static DiamondListFragment newInstance(int count) {
        DiamondListFragment fragment = new DiamondListFragment();
        Bundle args = new Bundle();
        args.putInt("count", count);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mCount = getArguments().getInt("count");
        View view = inflater.inflate(R.layout.home_diamond_list, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initRecycleView();
    }

    private void initRecycleView(){
        GridLayoutManager manager = new GridLayoutManager(_mActivity, 2);
        mRecyclerView.setLayoutManager(manager);
        mAdapter = new DiamondListAdapter(_mActivity);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.addItemDecoration(new SpaceItemDecoration(DeviceUtils.dip2px(_mActivity, 1)));
        mAdapter.setOnViewClickListener(new DiamondListAdapter.OnViewClickListener() {
            @Override
            public void onItemClick(int position) {
                Intent intent = new Intent(_mActivity, DiamondDetailActivity.class);
                intent.putExtra(DiamondDetailActivity.INTENT_KEY_COMMODITY_ID, mDiamonds.get(position).getId());
                intent.putExtra(DiamondDetailActivity.INTENT_KEY_PERIOD_NO, 0);//进入最新一期
                _mActivity.startActivity(intent);
            }

            @Override
            public void onBuyButtonClick(int position) {
                //如果没有登录的,去往登录页面
                if (!AccountManager.getInstance().isLogin()) {//未登录
                    startActivity(new Intent(_mActivity, LoginActivity.class));
                }else{
                    //取得点击的钻石id,查询最新一期的信息
                    doGetDiamondInfo(mDiamonds.get(position).getId());
                }
            }
        });
    }

    private void doGetDiamondList(boolean showLoading) {
        GGetDiamondList model = new GGetDiamondList(mCount);
        PageModel page  = new PageModel(1, -1);
        TaskEngine.getInstance().doGetDiamondList(model, page, new JsonCallback<List<BDiamond>>(showLoading ? this : null) {
            @Override
            public void onSuccess(List<BDiamond> result, Call call, Response response) {
                if(null != result && !result.isEmpty()){
                    mDiamonds = result;
                    mAdapter.updateData(mDiamonds);
                }
            }
        });
    }

    private void doGetDiamondInfo(int commodityId) {
        TaskEngine.getInstance().doGetDiamondInfo(new GGetDiamondInfo(commodityId, 0), new JsonCallback<BDiamondInfo>(this) {

            @Override
            public void onSuccess(BDiamondInfo result, Call call, Response response) {
                //局部刷新列表
                if(null != mDiamonds && !mDiamonds.isEmpty()){
                    for(BDiamond temp : mDiamonds){
                        if(null!= result.getCommodityInfo() && temp.getId() == result.getCommodityInfo().getId()){
                            temp.setLeftCount(result.getCommodityInfo().getLeftCount());
                            temp.setTotalCount(result.getCommodityInfo().getTotalCount());
                            temp.setAlreadySold(result.getCommodityInfo().getAlreadySold());
                            break;
                        }
                    }
                    mAdapter.updateData(mDiamonds);
                    //通知MainFragment弹出框
                    EB.postObject(EB.TAG.SHOW_MAIN_BOTTOM_VIEW, result);
                }

            }
        });
    }

    @Override
    public void refresh(boolean showLoading) {
        doGetDiamondList(showLoading);
    }

    @Override
    public void onResume() {
        super.onResume();
        L.d("onResume()");
        doGetDiamondList(true);
    }
}
