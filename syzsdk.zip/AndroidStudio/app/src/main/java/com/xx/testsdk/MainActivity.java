package com.xx.testsdk;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.uu898.gamesdk.UGSdk;
import com.uu898.gamesdk.log.L;
import com.uu898.gamesdk.support.listener.UGChangeAccountListener;
import com.uu898.gamesdk.support.listener.UGExitListener;
import com.uu898.gamesdk.support.listener.UGLoginListener;
import com.uu898.gamesdk.support.listener.UGPayListener;
import com.uu898.gamesdk.support.model.UGPayModel;
import com.uu898.gamesdk.support.result.UGPayResult;
import com.uu898.gamesdk.utils.FloatViewHelper;


public class MainActivity extends Activity {

    public static String APPID = "1";//898正式版是2 其余是1
    public static String APP_KEY = "34E11C0C93954DF0BBBF2B07BCE38538";//手游猪

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        UGSdk.getInstance().init(getApplication(), APPID, APP_KEY, false);
        L.init(true);

        UGSdk.getInstance().changeAccount(new UGChangeAccountListener() {
            @Override
            public void onChange() {
                Toast.makeText(MainActivity.this, "切换账号了啊啊", Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.login).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                UGSdk.getInstance().login(new UGLoginListener() {
                    @Override
                    public void onSuccess(String token, String userId) {
                        Toast.makeText(MainActivity.this, "token & userId = " + token + "\r\n" + userId, Toast.LENGTH_SHORT).show();
                    }

                });
            }
        });

        findViewById(R.id.pay).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText edt = (EditText) findViewById(R.id.edt_money);
                if (TextUtils.isEmpty(edt.getText().toString())) {
                    Toast.makeText(MainActivity.this, "请输入金额", Toast.LENGTH_SHORT).show();
                    return;
                }
                String tempPrice = Utils.yuanToFen(edt.getText().toString());
                UGPayModel model = new UGPayModel();
                model.originalPrice = Integer.parseInt(tempPrice);
                model.title = "充值游戏币";
                model.describe = "商品描述";
                model.cpOrderNo = "SY20160924000002";
                model.productID = "001";
                model.reserved = "";

                UGSdk.getInstance().pay(model, new UGPayListener() {
                    @Override
                    public void onPayDone(UGPayResult result) {
                        if (result.resultCode == UGPayResult.CODE_NOT_LOGIN) {
                            Toast.makeText(MainActivity.this, "回调--> 未登录", Toast.LENGTH_SHORT).show();
                        } else if (result.resultCode == UGPayResult.CODE_FAIL) {
                            Toast.makeText(MainActivity.this, "回调--> 支付失败", Toast.LENGTH_SHORT).show();
                        } else if (result.resultCode == UGPayResult.CODE_SUCCESS) {
                            Toast.makeText(MainActivity.this, "回调--> 支付成功", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        FloatViewHelper.showFloatingView();
    }

    @Override
    protected void onPause() {
        super.onPause();
        FloatViewHelper.hideFloatingView();
    }

    @Override
    public void onBackPressed() {
        UGSdk.getInstance().exit(new UGExitListener() {
            @Override
            public void onExit() {
                MainActivity.this.finish();
            }
        });
    }
}
