package com.uu661.model.response;

import java.io.Serializable;

/**
 * Created by bo on 16/9/14.
 */
public class BDiamondCodeList implements Serializable {

    public String killCodeList;//夺钻码
    public int killCodeCount;//个数
}
