package com.uu393.market.module.home;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.umeng.analytics.MobclickAgent;
import com.uu393.market.R;
import com.uu393.market.model.PageModel;
import com.uu393.market.model.request.GGetGameList;
import com.uu393.market.model.response.BGame;
import com.uu393.market.module.base.BaseViewPagerFragment;
import com.uu393.market.network.JsonCallback;
import com.uu393.market.network.TaskEngine;
import com.uu393.market.util.ToastUtil;
import com.uu393.market.util.log.L;
import com.uu393.market.view.pulltorefresh.PullLoadMoreRecyclerView;

import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

public class AppListFragment extends BaseViewPagerFragment implements View.OnClickListener{

    private String mGameType;

    private PullLoadMoreRecyclerView mRecyclerView;
    private View mNoResultView;
    private Button mGetDataAgain;
    private ArrayList<BGame> mGameList = new ArrayList<>();

    private ApkListAdapter adapter;
    private int mPageIndex = 1;

    public static AppListFragment newInstance(String id) {
        AppListFragment fragment = new AppListFragment();
        Bundle args = new Bundle();
        args.putString("id", id);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mGameType = getArguments().getString("id", "-1");

        View view = inflater.inflate(R.layout.fragment_item_list, container, false);
        mGetDataAgain  = (Button) view.findViewById(R.id.bt_no_result);
        mGetDataAgain.setOnClickListener(this);
        mRecyclerView = (PullLoadMoreRecyclerView) view.findViewById(R.id.sd_recycler_view);
        mNoResultView = view.findViewById(R.id.no_result_view);
        mNoResultView.setVisibility(View.GONE);
        mRecyclerView.setLinearLayout();
        adapter = new ApkListAdapter(_mActivity);
        mRecyclerView.setAdapter(adapter);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mRecyclerView.setRefreshing(true);

        doGetGameList(false);
        mRecyclerView.setOnPullLoadMoreListener(new PullLoadMoreRecyclerView.PullLoadMoreListener() {
            @Override
            public void onRefresh() {
                doGetGameList(false);
            }

            @Override
            public void onLoadMore() {
                doGetGameList(true);
            }
        });
    }

    private void doGetGameList(final boolean loadMore) {
        GGetGameList model = new GGetGameList();
        model.gameType = mGameType;
        if(loadMore == false){
            mPageIndex = 1;
        }
        PageModel page = new PageModel(mPageIndex);
        TaskEngine.setTokenUseridPhoneState(1);
        TaskEngine.getInstance().doGetGameList(model, page, new JsonCallback<List<BGame>>() {
            @Override
            public void onSuccess(List<BGame> bGames, Call call, Response response) {
                if (null == bGames || bGames.isEmpty()) {
                    //无返回结果,需要根据当前页码判断是无结果,还是无更多
                    if(mPageIndex == 1){
                        changeView(false);
                    }else{
                        ToastUtil.showToast(_mActivity,"没有更多了~");
                    }
                } else {
                    changeView(true);
                    mPageIndex++;
                    if (loadMore == false) {//非增量加载
                        mGameList.clear();
                    }
                    mGameList.addAll(bGames);
                }
            }

            @Override
            public void onAfter(List<BGame> bGames, Exception e) {
                super.onAfter(bGames, e);
                mRecyclerView.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        adapter.updateData(mGameList);
                        mRecyclerView.setPullLoadMoreCompleted();
                    }
                }, 100);
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                if (mPageIndex == 1){
                    changeView(false);
                }else {
                    changeView(true);
                }

            }
        });
    }

    private void changeView(boolean hasData) {
        mRecyclerView.setVisibility(hasData ? View.VISIBLE : View.GONE);
        mNoResultView.setVisibility(hasData ? View.GONE : View.VISIBLE);
    }


    @Override
    public void refresh() {
        if (null != adapter) {
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        L.d("onHiddenChanged");
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("AppListFragment");
        L.d("onPause");
    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart("AppListFragment");
        adapter.setrefresh();
        L.d("onResume");
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.bt_no_result){
            doGetGameList(true);
        }
    }
}
