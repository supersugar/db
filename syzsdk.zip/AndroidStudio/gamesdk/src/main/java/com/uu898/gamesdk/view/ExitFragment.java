package com.uu898.gamesdk.view;

import android.graphics.Point;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;

import com.uu898.gamesdk.core.ListenerCenter;
import com.uu898.gamesdk.log.L;
import com.uu898.gamesdk.support.listener.UGExitListener;
import com.uu898.gamesdk.utils.AccountManager;
import com.uu898.gamesdk.utils.CommonUtils;
import com.uu898.gamesdk.utils.FloatViewHelper;

/**
 * Created by zhangbo on 2016/6/23.
 */
public class ExitFragment extends BaseFragment {

    private View mParentView;//父布局
    private View mViewAsDialog;//对话框
    private Button mBtNext;

    private UGExitListener mExitListener;

    public static ExitFragment newInstance() {
        Bundle args = new Bundle();
        ExitFragment fragment = new ExitFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(getLayoutId("ug_exit"), container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mParentView = view.findViewById(getId("parent_view"));

        mExitListener = ListenerCenter.getInstance().getExitListener();

        mViewAsDialog = view.findViewById(getId("ug_as_dialog_content"));
        mBtNext = (Button) view.findViewById(getId("ug_bt_next"));
        mViewAsDialog.setOnClickListener(onClickListener);
        mParentView.setOnClickListener(onClickListener);
        mBtNext.setOnClickListener(onClickListener);

        contentAsDialog(mViewAsDialog);

    }

    private void contentAsDialog(View v) {
        int[] point = onLayoutCallBack();
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(point[0], point[1]);
        v.setLayoutParams(params);
    }

    public int[] onLayoutCallBack() {
        int space = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 40F, _mActivity.getResources()
                .getDisplayMetrics());
        Point point = CommonUtils.getScreenSize(_mActivity);
        int width = Math.min(point.x, point.y);
        int height = Math.max(point.x, point.y);
        return new int[]{width - space, height / 3 + 50 };
    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(v.getId() == getId("ug_as_dialog_content")) {
            }
            if(v.getId() == getId("parent_view")){
                _mActivity.finish();
            }
            if (v.getId() == getId("ug_bt_next")) {
                L.d("doExit");
                AccountManager.getInstance().setStatus(AccountManager.Status.LOGOUT, AccountManager.getInstance().getCurrentUserID());
                FloatViewHelper.exit();
                mExitListener.onExit();
                _mActivity.finish();
            }
        }
    };
}
