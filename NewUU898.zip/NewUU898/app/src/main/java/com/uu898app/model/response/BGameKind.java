package com.uu898app.model.response;

public class BGameKind {


	/**
	 * firstCharactor : Y
	 * tradeType : 0
	 * gameID : 0
	 * orderIndex : 10
	 * typeStatus : 1
	 * isBuyNeedServer : false
	 * minMoney : 0
	 * isSuportQiuGou : false
	 * isCUpdating : false
	 * inputType : 1
	 * name : 游戏账号
	 * ID : -6
	 * isAllServer : false
	 * pinyin : youxizhanghao
	 */

	private String firstCharactor;
	private int tradeType;
	private int gameID;
	private int orderIndex;
	private int typeStatus;
	private boolean isBuyNeedServer;
	private int minMoney;
	private boolean isSuportQiuGou;
	private boolean isCUpdating;
	private int inputType;
	private String name;
	private int ID;
	private boolean isAllServer;
	private String pinyin;

	public String getFirstCharactor() {
		return firstCharactor;
	}

	public void setFirstCharactor(String firstCharactor) {
		this.firstCharactor = firstCharactor;
	}

	public int getTradeType() {
		return tradeType;
	}

	public void setTradeType(int tradeType) {
		this.tradeType = tradeType;
	}

	public int getGameID() {
		return gameID;
	}

	public void setGameID(int gameID) {
		this.gameID = gameID;
	}

	public int getOrderIndex() {
		return orderIndex;
	}

	public void setOrderIndex(int orderIndex) {
		this.orderIndex = orderIndex;
	}

	public int getTypeStatus() {
		return typeStatus;
	}

	public void setTypeStatus(int typeStatus) {
		this.typeStatus = typeStatus;
	}

	public boolean isIsBuyNeedServer() {
		return isBuyNeedServer;
	}

	public void setIsBuyNeedServer(boolean isBuyNeedServer) {
		this.isBuyNeedServer = isBuyNeedServer;
	}

	public int getMinMoney() {
		return minMoney;
	}

	public void setMinMoney(int minMoney) {
		this.minMoney = minMoney;
	}

	public boolean isIsSuportQiuGou() {
		return isSuportQiuGou;
	}

	public void setIsSuportQiuGou(boolean isSuportQiuGou) {
		this.isSuportQiuGou = isSuportQiuGou;
	}

	public boolean isIsCUpdating() {
		return isCUpdating;
	}

	public void setIsCUpdating(boolean isCUpdating) {
		this.isCUpdating = isCUpdating;
	}

	public int getInputType() {
		return inputType;
	}

	public void setInputType(int inputType) {
		this.inputType = inputType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getID() {
		return ID;
	}

	public void setID(int ID) {
		this.ID = ID;
	}

	public boolean isIsAllServer() {
		return isAllServer;
	}

	public void setIsAllServer(boolean isAllServer) {
		this.isAllServer = isAllServer;
	}

	public String getPinyin() {
		return pinyin;
	}

	public void setPinyin(String pinyin) {
		this.pinyin = pinyin;
	}
}
