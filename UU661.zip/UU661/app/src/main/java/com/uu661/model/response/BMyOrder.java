package com.uu661.model.response;

import java.io.Serializable;

/**
 * Created by bo on 16/9/14.
 */
public class BMyOrder implements Serializable {


    /**
     * commodityId : 237
     * title : 100U钻【可兑换全站任意商品】
     * imageUrl :
     * periodNo : 701220083
     * periodStatus : 3
     * buyNum : 50
     * additionalNum : 0
     * alreadyBuy : 0
     * addTime : 2017/1/22 17:16:42
     * statusMessage : 已揭晓,已中奖
     * isWin : 1
     */

    private int commodityId;
    private String title;
    private String imageUrl;
    private int periodNo;
    private int periodStatus;
    private int buyNum;
    private String additionalNum;
    private int alreadyBuy;
    private String addTime;
    private String statusMessage;
    private int isWin;


    public int getCommodityId() {
        return commodityId;
    }

    public void setCommodityId(int commodityId) {
        this.commodityId = commodityId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public int getPeriodNo() {
        return periodNo;
    }

    public void setPeriodNo(int periodNo) {
        this.periodNo = periodNo;
    }

    public int getPeriodStatus() {
        return periodStatus;
    }

    public void setPeriodStatus(int periodStatus) {
        this.periodStatus = periodStatus;
    }

    public int getBuyNum() {
        return buyNum;
    }

    public void setBuyNum(int buyNum) {
        this.buyNum = buyNum;
    }

    public String getAdditionalNum() {
        return additionalNum;
    }

    public void setAdditionalNum(String additionalNum) {
        this.additionalNum = additionalNum;
    }

    public int getAlreadyBuy() {
        return alreadyBuy;
    }

    public void setAlreadyBuy(int alreadyBuy) {
        this.alreadyBuy = alreadyBuy;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public int getIsWin() {
        return isWin;
    }

    public void setIsWin(int isWin) {
        this.isWin = isWin;
    }
}
