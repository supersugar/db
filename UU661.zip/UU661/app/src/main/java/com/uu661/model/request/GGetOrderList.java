package com.uu661.model.request;

public class GGetOrderList {

    public static final int TYPE_ALL = 1;//所有夺钻列表
    public static final int TYPE_LUCKY = 2;//中奖列表

    private int listType;//

    public GGetOrderList(int listType) {
        this.listType = listType;
    }
}
