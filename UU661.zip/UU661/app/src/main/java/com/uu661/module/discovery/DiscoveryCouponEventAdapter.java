package com.uu661.module.discovery;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.uu661.R;
import com.uu661.model.response.BCoupon;
import com.uu661.util.CommonUtils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by bo on 16/11/4.
 */

public class DiscoveryCouponEventAdapter extends RecyclerView.Adapter<DiscoveryCouponEventAdapter.MyHolder> {

    private Context mContext;
    private List<BCoupon> data = new ArrayList<>();
    private int type;

    public void updateData(List<BCoupon> data) {
        this.data = data;
        notifyDataSetChanged();
    }

    @Override
    public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_discovery_coupon, parent, false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(MyHolder holder, int position) {
        BCoupon model = data.get(position);
        holder.bindItem(model);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }


    public class MyHolder extends RecyclerView.ViewHolder{

        @BindView(R.id.item_parent) LinearLayout mItemParent;
        @BindView(R.id.item_img) ImageView mItemImg;
        @BindView(R.id.tv_coupon_price) TextView mTvCouponPrice;
        @BindView(R.id.item_tv1) TextView mItemTv1;
        @BindView(R.id.item_tv2) TextView mItemTv2;
        @BindView(R.id.img_status) ImageView mImgStatus;

        private BCoupon mModel;

        public MyHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);//用butterKnife绑定
        }

        /**
         *  public int ifGet;//是否已领取
            public int ifOver;//是否已领完
         * @param model
         */
        void bindItem(BCoupon model) {
            this.mModel = model;
            String voucherMoney = CommonUtils.fenToYuan(mModel.voucherMoney);
            if(voucherMoney.endsWith(".00")){
                voucherMoney = voucherMoney.substring(0, voucherMoney.lastIndexOf("."));
            }
            mTvCouponPrice.setText(voucherMoney + "元");
            mItemTv1.setText(mModel.title);
            mItemTv2.setText("有效期 : " + mModel.validTime);
            //先判断是否领取
            if(model.ifGet == 1){
                mItemImg.setImageResource(R.drawable.ic_red_enable);
                mImgStatus.setVisibility(View.VISIBLE);
                mImgStatus.setImageResource(R.drawable.ic_coupon_ylq);
                mItemParent.setBackgroundResource(R.drawable.ic_shape_bt_blue_white);
            }else if(model.ifGet == 0){//未领取
                if(model.ifOver == 1){//已发完
                    mItemImg.setImageResource(R.drawable.ic_red_disable);
                    mImgStatus.setVisibility(View.VISIBLE);
                    mImgStatus.setImageResource(R.drawable.ic_coupon_yfw);
                    mItemParent.setBackgroundResource(R.drawable.ic_shape_bt_gray_white);
                }else if(model.ifOver == 0){//未发完
                    mItemImg.setImageResource(R.drawable.ic_red_enable);
                    mImgStatus.setVisibility(View.GONE);
                    mItemParent.setBackgroundResource(R.drawable.ic_shape_bt_white);
                }
            }
        }


    }

}
