package com.uu661.module.home;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.gongwen.marqueen.MarqueeFactory;
import com.gongwen.marqueen.MarqueeView;
import com.lcodecore.tkrefreshlayout.RefreshListenerAdapter;
import com.lcodecore.tkrefreshlayout.TwinklingRefreshLayout;
import com.lzy.okgo.request.BaseRequest;
import com.uu661.R;
import com.uu661.core.AccountManager;
import com.uu661.model.request.GGetBanner;
import com.uu661.model.response.BBanner;
import com.uu661.model.response.BLuckyMan;
import com.uu661.module.base.BaseFragment;
import com.uu661.module.base.BaseTabLazyFragment;
import com.uu661.module.base.BaseViewPagerFragment;
import com.uu661.module.common.WebActivity;
import com.uu661.module.discovery.DiscoveryCouponEvent;
import com.uu661.network.JsonCallback;
import com.uu661.network.TaskEngine;
import com.uu661.util.StringUtils;
import com.uu661.util.log.L;
import com.uu661.view.lazyviewpager.LazyFragmentPagerAdapter;
import com.youth.banner.Banner;
import com.youth.banner.BannerConfig;
import com.youth.banner.listener.OnBannerListener;
import com.youth.banner.loader.ImageLoader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Response;


/**
 * Created by zhangbo on 2016/6/23.
 */
public class HomeFragment extends BaseTabLazyFragment {


    @BindView(R.id.tabs) TabLayout mTabLayout;
    @BindView(R.id.appbar) AppBarLayout mAppbar;
    @BindView(R.id.tabs_viewpager) ViewPager mViewPager;
    @BindView(R.id.marquee_view) MarqueeView mMarqueeView;
    @BindView(R.id.refreshLayout) TwinklingRefreshLayout mRefreshLayout;
    @BindView(R.id.banner_view) Banner mBannerView;

    private Map<Integer, BaseViewPagerFragment> fragmentsMap = new HashMap<>();
    private int mCurrentFragmentIndex = 0;
    private MarqueeFactory<View, BLuckyMan> factory;
    private List<BBanner> mBanners = new ArrayList<>();

    public static HomeFragment newInstance() {
        Bundle args = new Bundle();
        HomeFragment fragment = new HomeFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.home_fragment, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initTitleBar(view, "UU夺钻", false);
        initRefreshLayout();
        initMarqueeView();
        initViewPager();
        initBannerView();
    }

    @Override
    public void onLazyInitView(@Nullable Bundle savedInstanceState) {
        L.d("懒加载" + this);
        doGetBanner();
        doGetAllLuckyManList();
    }

    private void initMarqueeView() {
        factory = new NoticeMF(_mActivity);
        mMarqueeView.setMarqueeFactory(factory);
        factory.setOnItemClickListener(new MarqueeFactory.OnItemClickListener<View, BLuckyMan>() {
            @Override
            public void onItemClickListener(MarqueeFactory.ViewHolder<View, BLuckyMan> holder) {

            }
        });
    }

    private void initRefreshLayout() {
        //以下代码是使用黑色转圈Loading
        //        ProgressLayout headerView = new ProgressLayout(_mActivity);
        //        mRefreshLayout.setHeaderView(headerView);
        mRefreshLayout.setEnableLoadmore(false);
        mRefreshLayout.setEnableOverScroll(false);//是否允许越界回弹
        mAppbar.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
                //                L.d(verticalOffset);
                if (verticalOffset >= 0) {
                    mRefreshLayout.setEnableRefresh(true);
                } else {
                    mRefreshLayout.setEnableRefresh(false);
                }
            }
        });

        mRefreshLayout.setOnRefreshListener(new RefreshListenerAdapter() {
            @Override
            public void onRefresh(final TwinklingRefreshLayout refreshLayout) {
                doGetAllLuckyManList();
                refreshCurrentGameFragment(false);
                doGetBanner();
            }
        });
    }

    private void initViewPager() {
        mViewPager.setAdapter(new MyPagerAdapter(getChildFragmentManager()));
        mTabLayout.setupWithViewPager(mViewPager);
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                mCurrentFragmentIndex = position;
                //                mViewPager.postDelayed(new Runnable() {
                //                    @Override
                //                    public void run() {
                //                        refreshCurrentGameFragment();
                //                    }
                //                }, 100);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private void initBannerView(){
        mBannerView.setImageLoader(new GlideImageLoader());
        mBannerView.isAutoPlay(true);//设置自动轮播，默认为true
        mBannerView.setDelayTime(5000);//设置轮播时间
        mBannerView.setBannerStyle(BannerConfig.CIRCLE_INDICATOR);//设置banner样式

        mBannerView.setOnBannerListener(new OnBannerListener() {
            @Override
            public void OnBannerClick(int position) {
                BBanner temp = mBanners.get(position);
                if(StringUtils.isEmpty(temp.event)){
                    if (StringUtils.isEmpty(temp.linkUrl)) {
                        //ToastUtil.showToast(_mActivity, "链接参数错误");
                        return;
                    }
                    Intent intent = new Intent(_mActivity, WebActivity.class);
                    intent.putExtra(WebActivity.INTENT_KEY_URL, temp.linkUrl);
                    startActivity(intent);
                } else if(temp.event.equals(BBanner.GOTO_SEND_HB)){
                    BaseFragment parent1 = (BaseFragment) getParentFragment();
                    parent1.start(DiscoveryCouponEvent.newInstance());
                }

            }
        });
    }

    private void doGetAllLuckyManList() {
        TaskEngine.getInstance().doGetAllLuckyManList(new JsonCallback<List<BLuckyMan>>() {
            @Override
            public void onBefore(BaseRequest request) {
                super.onBefore(request);
                mMarqueeView.stopFlipping();
            }

            @Override
            public void onSuccess(final List<BLuckyMan> result, Call call, Response response) {
                if(null != result && !result.isEmpty()){
                    L.d("全站中奖纪录数量 = " + result.size());
                    factory.resetData(result);
                    mMarqueeView.startFlipping();
                }
            }

            @Override
            public void onAfter(List<BLuckyMan> bLuckyMen, Exception e) {
                super.onAfter(bLuckyMen, e);
                if (null != mRefreshLayout) {
                    mRefreshLayout.finishRefreshing();
                }
            }
        });
    }

    public void doGetBanner() {
        int temp = 0;
        if(null != AccountManager.getInstance().getUserInfo()){
            temp = AccountManager.getInstance().getUserInfo().regStatus;
        }
        GGetBanner gGetBanner = new GGetBanner(temp);
        TaskEngine.getInstance().doGetBanner(gGetBanner, new JsonCallback<List<BBanner>>() {

            @Override
            public void onBefore(BaseRequest request) {
                super.onBefore(request);
                mBannerView.stopAutoPlay();
            }

            @Override
            public void onSuccess(final List<BBanner> result, Call call, Response response) {
                // TODO: 16/12/20  You cannot start a load for a destroyed activity
                if (null != result && !result.isEmpty()) {
                    mBanners.clear();
                    mBanners.addAll(result);
                    List<String> imageUrls = new ArrayList<String>();
                    for (int i = 0; i < mBanners.size(); i++) {
                        //                        images[i] = "http://www.shouyouzhu.com/activity/images/sh/sh_pic1.jpg";
                        imageUrls.add(mBanners.get(i).imgUrl);
                    }
                    mBannerView.setImages(imageUrls);//设置图片集合
                    mBannerView.start();//banner设置方法全部调用完毕时最后调用
                }
            }
        });
    }

    public class GlideImageLoader extends ImageLoader {
        @Override
        public void displayImage(Context context, Object path, ImageView imageView) {
            /**
             注意：
             1.图片加载器由自己选择，这里不限制，只是提供几种使用方法
             2.返回的图片路径为Object类型，由于不能确定你到底使用的那种图片加载器，
             传输的到的是什么格式，那么这种就使用Object接收和返回，你只需要强转成你传输的类型就行，
             切记不要胡乱强转！
             */

            //Glide 加载图片简单用法
            Glide.with(context).load(path).error(R.drawable.ic_banner).into(imageView);
        }
    }

    private void refreshCurrentGameFragment(boolean showLoading) {
        //fragmentsMap有可能会是空的
        if (!fragmentsMap.isEmpty() && null != fragmentsMap.get(mCurrentFragmentIndex)) {
            fragmentsMap.get(mCurrentFragmentIndex).refresh(showLoading);
        }
    }

    @Override
    public void onTabReselected() {
        L.d("onTabReselected " + this);
    }

    @OnClick({R.id.tabs, R.id.tabs_viewpager})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tabs:
                break;
            case R.id.tabs_viewpager:
                break;
        }
    }

    public class MyPagerAdapter extends LazyFragmentPagerAdapter {

        private String[] titles = new String[]{"  全部  ", "2人夺钻", "5人夺钻", "多人夺钻"};

        public MyPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public int getCount() {
            return 4;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return titles[position];
        }

        @Override
        protected Fragment getItem(ViewGroup container, int position) {
            int count = 0;//秒杀所需人次：0全部 -1多人 2两人 5五人
            if (position == 0) {
                count = 0;
            } else if (position == 1) {
                count = 2;
            } else if (position == 2) {
                count = 5;
            } else if (position == 3) {
                count = -1;
            }
            BaseViewPagerFragment fragment = DiamondListFragment.newInstance(count);
            fragmentsMap.put(position, fragment);
            return fragment;
        }
    }

    public class NoticeMF extends MarqueeFactory<View, BLuckyMan> {
        private LayoutInflater inflater;

        public NoticeMF(Context mContext) {
            super(mContext);
            inflater = LayoutInflater.from(mContext);
        }

        @Override
        public View generateMarqueeItemView(BLuckyMan data) {
            TextView textView = new TextView(_mActivity);
            textView.setLines(1);
            textView.setBackgroundColor(getResources().getColor(R.color.white));
            textView.setText(Html.fromHtml("<font color='#fc5669'>" + data.getAddTime() + " </font>" + "恭喜" + "<font color='#0fabff'>" + data
                    .getUu898UserId() + "</font>" + "获得" + "<font color='#fc5669'>" + data.getPrice() + "U钻</font>"));
            return textView;
        }
    }

    @Override
    public void onSupportVisible() {
        super.onSupportVisible();
        L.d("onSupportVisible()");
        //退出账户的时候回到首页,会执行这里的代码
        refreshCurrentGameFragment(true);
        if(AccountManager.getInstance().getIsShowStatusChanged()){
            doGetBanner();
            AccountManager.getInstance().setIsShowStatusChanged(false);
        }
        AccountManager.getInstance().whetherShowAfterLoginCouponDialog(_mActivity);
    }

}
