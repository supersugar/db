package com.uu898app.model.request;

import com.uu898app.model.GBaseModel;

/**
 * Created by zhangbo on 2016/7/19.
 */
public class GGenRechargeDKNo extends GBaseModel{


    /**
     * buyCount : 1
     * point : 10
     * serverID : null
     * areaID : null
     * account : 急急急
     * isAreaServer : False
     * gameID : 159
     */

    private int buyCount;
    private String point;
    private String serverID;
    private String areaID;
    private String account;
    private String isAreaServer;
    private int gameID;

    public int getBuyCount() {
        return buyCount;
    }

    public void setBuyCount(int buyCount) {
        this.buyCount = buyCount;
    }

    public String getPoint() {
        return point;
    }

    public void setPoint(String point) {
        this.point = point;
    }

    public String getServerID() {
        return serverID;
    }

    public void setServerID(String serverID) {
        this.serverID = serverID;
    }

    public String getAreaID() {
        return areaID;
    }

    public void setAreaID(String areaID) {
        this.areaID = areaID;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getIsAreaServer() {
        return isAreaServer;
    }

    public void setIsAreaServer(String isAreaServer) {
        this.isAreaServer = isAreaServer;
    }

    public int getGameID() {
        return gameID;
    }

    public void setGameID(int gameID) {
        this.gameID = gameID;
    }
}
