package com.uu393.market.model.request;

/**
 * =====================================================
 * Created by : wangxian
 * Created on : 2017/3/7
 * Descrip    :
 * =====================================================
 */

public class GGetSearchList {
    /**
     {
     "gameType": "-1",（游戏类型  -1表示所有类型）
     "gameName": "",（游戏名称）
     "platForm": "-1",（游戏平台，0app游戏  1h5游戏  -1所有游戏）
     }

     */

    private String gameType;
    private String gameName;
    private String platForm;

    public String getGameType() {
        return gameType;
    }

    public void setGameType(String gameType) {
        this.gameType = gameType;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }

    public String getPlatForm() {
        return platForm;
    }

    public void setPlatForm(String platForm) {
        this.platForm = platForm;
    }
}
